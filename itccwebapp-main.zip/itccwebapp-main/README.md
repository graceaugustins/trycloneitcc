# SITASI ITCC 
## _Sistem Terintegrasi ITCC ITPLN_

![deploy on staging](https://github.com/itccitpln/itccwebapp/actions/workflows/deploy_staging.yml/badge.svg)
![deploy on production](https://github.com/itccitpln/itccwebapp/actions/workflows/deploy_production.yml/badge.svg)

## Poin Penting

- Repository ini terdiri dari 2 project, yaitu `app` dan `admin`.
- Masing-masing project menggunakan [CodeIgniter 3.1.1](https://codeigniter.com/userguide3/installation/downloads.html)
- Database yang digunakan adalah MySQL dengan PDO. Schema yang digunakan sendiri adalah InnoDB.
- Data yang ditarik dari database disimpan dalam Data Class (Class dengan prefix `D_`).
- Untuk pengolahan data dan query DB menggunakan Model Class (Class dengan prefix `M_`)
- Model development sama dengan development CI pada umumnya.
- Proses deployment (mengupdate file project di server) di staging dilakukan secara otomatis menggunakan 
  [Github Actions](https://github.com/itccitpln/itccwebapp/blob/main/.github/workflows/). 
  Jadi kalian tidak perlu upload manual lagi. Cukup `push` saja, maka actions untuk deployment tersebut
  akan langsung berjalan otomatis.
- Proses deployment di production tidak dilakukan otomatis ketika `push`, namun dilakukan manual,
  dengan memberikan commit ID. Commit ID tersebut yang akan jadi acuan deployment. Hal ini dilakukan
  agar jika terjadi kesalahan di repo / terjadi kesalahan di staging, tidak akan langsung merembet ke 
  production. Bahkan sekalipun terjadi kesalahan/error di production, bisa _dimundurkan_ dengan cara deploy
  pakai commit ID yang sebelumnya.

## Data Class
Data class adalah definisi class yang digunakan khusus untuk menampung data 
(beserta beberapa method juga). Seluruh hal yang didefinisikan dalam data class
cukup berhubungan dengan class itu, tidak perlu ke class lain. 

**Data class dibuat karena menerima data dari database itu sangat rentan kesalahan, 
apalagi jika banyak kasus**. Misalkan kita mau mengambil data satu kegiatan dari 
database, dan ada 8 kasus (mengambil kegiatan yang dibatalkan, mengambil kegiatan
untuk ditampilkan di trainer, dll), ini sangat rentan akan kesalahan.

Selain itu, dengan adanya data class, kita bisa melakukan formatting dengan lebih konsisten,
terutama jika kita mengingat fakta bahwa **data yang diambil dari database semuanya
dalam tipe string**. Jadi dengan data class, kita bisa melakukan casting `string` ke `int`,
`float`, atau bahkan `DateTime`.

## Model Class
Disini dipakai istilah model hanya untuk membedakan dari data class, karena sebenarnya
definisi model lebih tepat diterapkan di data class. 

Disini, model class adalah definisi class yang dibuat dengan sudut pandang ketiga.
Misal, ada data class user. Bagaimana kita mengambil data user dengan tipe mahasiswa?
Karena tidak mungkin semua data user dengan tipe mahasiswa ditampung dalam 1 data class.
Disini kita bisa pakai model class - misal `M_user`, lalu kita buat 1 method `get_all_user_mahasiswa()`
dengan returnnya adalah `[]D_User`, dan `D_user` adalah data class untuk 1 user.


## Template Sertifikat
Setiap user yang tidak lulus sertifikasi akan mendapatkan sertifikat keikutsertaan,
yang dapat diakses dan diverifikasi di dalam website SITASI. Untuk itu, setiap 
sertifikasi wajib memiliki template sertifikat, dalam hal ini setiap sertifikasi 
perlu ada link template sertifikat.

Karena hanya membutuhkan link, maka pembuatan template dibebaskan dengan cara apapun, 
selama linknya bisa diakses lewat internet secara langsung. Namun, direkomendasikan untuk
menggunakan Elementor dalam pembuatan templatenya, untuk memudahkan kalian.

Di Elementor sendiri kalian perlu tambahkan script untuk trigger auto-print di browser,
dan styling untuk set ukuran halaman ke A4 landscape, agar ketika diprint bisa sesuai.

Langkah-langkah membuat template :
1. Buat page WordPress baru menggunakan Elementor, lalu desain sesuai keinginan kalian.
1. Ada beberapa tag yang disediakan sebagai placeholder untuk kalian pakai:
    1. `${nama}` -> nama lengkap peserta, mis. `JOHN DOE STUBBORN`
    2. `${sertifikasi}` -> nama sertifikasi, mis. `Microsoft Office Specialist`
    3. `${serial}` -> kode verifikasi sertifikat, mis. `ABCDE-FGHIJ`
    4. `${tanggal_terbit}` -> tanggal sertifikat disimpan di database dengan format baku, mis. `January 1, 2022`
1. Periksa terlebih dahulu apakah sudah ada custom code untuk page sertifikat yang baru kalian buat di Elementor.
Jika belum, buat Custom Code baru, dengan location di `<head>` (priority biarkan 1), dan isi dengan kode berikut:
   ```
   <style>
      @media print {
        @page {
        size: A4 landscape;
        }
      }
    </style>
    <script>
      document.onreadystatechange = function () {
        if (document.readyState === 'complete') {
          window.print();
        }
      };
    </script>
   ```
1. Terapkan custom code tersebut ke page template sertifikat yang sudah dibuat. 
   Tutorial: [https://elementor.com/help/custom-code-pro/](https://elementor.com/help/custom-code-pro/).
1. Periksa bahwa custom code sudah benar diterapkan, 
   dengan mencoba visit link page tersebut di incognito window

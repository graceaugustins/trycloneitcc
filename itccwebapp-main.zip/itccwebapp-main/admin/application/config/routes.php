<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|   example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|   https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|   $route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|   $route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|   $route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples: my-controller/index -> my_controller/index
|       my-controller/my-method -> my_controller/my_method
*/
$route['default_controller']    = 'welcome';
$route['404_override']          = 'error_page';
$route['translate_uri_dashes']  = FALSE;

$route['msauth/callback'] 	= 'auth/callback';
$route['msauth/signin'] 	= 'auth/signin';
$route['msauth/signout'] 	= 'auth/signout';

// routing rules trainer
$route['trainer']                   = 'trainer/show_dashboard';
$route['trainer/not_active']        = 'trainer/show_not_active';
$route['trainer/login']             = 'trainer/show_login';
$route['trainer/proses_login']  	= 'trainer/proses_login';
$route['trainer/logout'] 			= 'trainer/logout';
$route['trainer/profile']['GET'] 	= 'trainer/show_profile';
$route['trainer/profile']['POST'] 	= 'trainer/update_profile';
$route['trainer/materi']['GET'] 	= 'trainer/show_materi_training';
$route['trainer/materi']['POST'] 	= 'trainer/upload_materi_training';
$route['trainer/materi/update']['POST'] 	= 'trainer/update_materi_training';
$route['trainer/materi/delete']['POST'] 	= 'trainer/hapus_materi_training';

$route['trainer/kelompok'] 			                = 'trainer/show_kelompok';
$route['trainer/kelompok/absensi/(:num)']['GET'] 	= 'trainer/show_absensi/$1';
$route['trainer/kelompok/absensi/(:num)']['POST'] 	= 'trainer/update_absensi/$1';
$route['trainer/history'] 			= 'trainer/show_history';
$route['trainer/history/(:num)'] 	= 'trainer/show_detail_history/$1';

$route['trainer/kesediaan/(:num)']['GET'] 	        = 'trainer/show_kesediaan/$1';
$route['trainer/kesediaan/(:num)/update']['POST'] 	= 'trainer/update_kesediaan/$1';

// routing rules proctor
$route['proctor']                   = 'proctor/show_dashboard';
$route['proctor/not_active']        = 'proctor/show_not_active';
$route['proctor/login']             = 'proctor/show_login';
$route['proctor/proses_login']  	= 'proctor/proses_login';
$route['proctor/logout'] 			= 'proctor/logout';
$route['proctor/profile']['GET'] 	= 'proctor/show_profile';
$route['proctor/profile']['POST'] 	= 'proctor/update_profile';

$route['proctor/kelompok'] 			                = 'proctor/show_kelompok';
$route['proctor/kelompok_t/absensi/(:num)']['GET'] 	= 'proctor/show_absensi_training/$1';
$route['proctor/kelompok_t/absensi/(:num)']['POST'] = 'proctor/update_absensi_training/$1';
$route['proctor/kelompok_u/absensi/(:num)']['GET'] 	= 'proctor/show_absensi/$1';
$route['proctor/kelompok_u/absensi/(:num)']['POST'] = 'proctor/update_absensi/$1';
$route['proctor/history'] 			= 'proctor/show_history';
$route['proctor/history/(:num)'] 	= 'proctor/show_detail_history/$1';

$route['proctor/kesediaan/(:num)']['GET'] 	        = 'proctor/show_kesediaan/$1';
$route['proctor/kesediaan_t/(:num)/update']['POST'] 	= 'proctor/update_kesediaan_t/$1';
$route['proctor/kesediaan_u/(:num)/update']['POST'] 	= 'proctor/update_kesediaan_u/$1';

// routing rules admin
$route['admin']             	= 'admin/show_dashboard';

$route['admin/login']       	= 'admin/show_login';
$route['admin/proses_login'] 	= 'admin/proses_login';
$route['admin/logout'] 			= 'admin/logout';

$route['admin/sertifikasi/kegiatan']                		        = 'admin/show_all_kegiatan';
$route['admin/sertifikasi/kegiatan/add_kegiatan']['GET'] 	        = 'admin/show_add_kegiatan';
$route['admin/sertifikasi/kegiatan/add_kegiatan']['POST'] 	        = 'admin/add_kegiatan';
$route['admin/sertifikasi/kegiatan/(:num)/detail']  		        = 'admin/show_detail_kegiatan/$1';
$route['admin/sertifikasi/kegiatan/(:num)/download_csv_program']    = 'admin/download_csv_program_kegiatan/$1';
$route['admin/sertifikasi/kegiatan/(:num)/tambah_peserta']    		= 'admin/tambah_peserta_kegiatan/$1';
$route['admin/sertifikasi/kegiatan/(:num)/ubah']['GET']             = 'admin/show_update_kegiatan/$1';
$route['admin/sertifikasi/kegiatan/(:num)/ubah']['POST']            = 'admin/update_kegiatan/$1';
$route['admin/sertifikasi/kegiatan/(:num)/ubah_kriteria']['POST']   = 'admin/update_kriteria_kegiatan/$1';
$route['admin/sertifikasi/kegiatan/(:num)/batal']['POST']           = 'admin/batalkan_kegiatan/$1';
$route['admin/sertifikasi/kegiatan/(:num)/add_kelompok_t']['POST']    			= 'admin/tambah_kelompok_t/$1';
$route['admin/sertifikasi/kegiatan/(:num)/add_kelompok_u']['POST']    			= 'admin/tambah_kelompok_u/$1';
$route['admin/sertifikasi/kegiatan/(:num)/download-data-peserta']['GET']    	= 'admin/download_peserta_kegiatan/$1';
$route['admin/sertifikasi/kegiatan/(:num)/download-data-bukti-bayar']['GET']    = 'admin/download_bukti_bayar_kegiatan/$1';
$route['admin/sertifikasi/kegiatan/(:num)/download-data-registrasi']['GET']    	= 'admin/download_registrasi_kegiatan/$1';
$route['admin/sertifikasi/kegiatan/(:num)/add_klaim']['POST']    				= 'admin/tambah_klaim_kegiatan/$1';
$route['admin/sertifikasi/kegiatan/(:num)/ubah_data_registrasi']['POST']        = 'admin/ubah_data_registrasi/$1';
$route['admin/sertifikasi/kegiatan/(:num)/hapus_data_registrasi']['POST']        = 'admin/hapus_data_registrasi';
$route['admin/sertifikasi/kegiatan/klaim/ubah']['POST']    					= 'admin/ubah_klaim_kegiatan';
$route['admin/sertifikasi/kegiatan/klaim/hapus']['POST']    					= 'admin/hapus_klaim_kegiatan';

$route['admin/sertifikasi/kegiatan/kelompok_t/(:num)/update']['GET']  = 'admin/show_update_kelompok_t/$1';
$route['admin/sertifikasi/kegiatan/kelompok_t/(:num)/update']['POST'] = 'admin/update_kelompok_t/$1';

$route['admin/sertifikasi/kegiatan/kelompok_u/(:num)/update']['GET']  = 'admin/show_update_kelompok_u/$1';
$route['admin/sertifikasi/kegiatan/kelompok_u/(:num)/update']['POST'] = 'admin/update_kelompok_u/$1';

$route['admin/sertifikasi/kegiatan/kelompok_t/delete']['POST']        = 'admin/hapus_kelompok_t';
$route['admin/sertifikasi/kegiatan/kelompok_u/delete']['POST']        = 'admin/hapus_kelompok_u';

$route['admin/sertifikasi/kegiatan/kelompok_t/detail/(:num)']['GET']  = 'admin/detail_kelompok_t/$1';
$route['admin/sertifikasi/kegiatan/kelompok_t/detail/(:num)']['POST'] = 'admin/update_peserta_kelompok_t/$1';

$route['admin/sertifikasi/kegiatan/kelompok_u/detail/(:num)']['GET']  = 'admin/detail_kelompok_u/$1';
$route['admin/sertifikasi/kegiatan/kelompok_u/detail/(:num)']['POST'] = 'admin/update_peserta_kelompok_u/$1';

$route['admin/sertifikasi/program']                 				= 'admin/show_program_sertif';
$route['admin/sertifikasi/program/add_sertifikasi']['POST']     	= 'admin/add_sertif';
$route['admin/sertifikasi/program/update_sertifikasi']['POST'] 		= 'admin/update_sertifikasi';
$route['admin/sertifikasi/program/delete_sertifikasi']['POST'] 		= 'admin/delete_sertifikasi';
$route['admin/sertifikasi/program/add_program']['POST']				= 'admin/add_program_sertif';
$route['admin/sertifikasi/program/update_program']['POST'] 			= 'admin/update_program';
$route['admin/sertifikasi/program/delete_program']['POST']			= 'admin/delete_program';

$route['admin/sertifikasi/history']                         = 'admin/show_history_kegiatan';
$route['admin/sertifikasi/history/(:num)']                  = 'admin/show_history_kegiatan/$1';
$route['admin/sertifikasi/history/kelompok_t/(:num)']       = 'admin/show_history_kelompok_t/$1';
$route['admin/sertifikasi/history/kelompok_u/(:num)']       = 'admin/show_history_kelompok_u/$1';

$route['admin/trainer']         			= 'admin/show_trainer';
$route['admin/trainer/add_new']['POST'] 	= 'admin/add_trainer';
$route['admin/trainer/update']['POST'] 		= 'admin/update_trainer';
$route['admin/trainer/delete']['POST'] 		= 'admin/delete_trainer';
$route['admin/trainer/set_aktif']['POST'] 	= 'admin/set_trainer_aktif';

$route['admin/proctor']         			= 'admin/show_proctor';
$route['admin/proctor/add_new']['POST']		= 'admin/add_proctor';
$route['admin/proctor/update']['POST'] 		= 'admin/update_proctor';
$route['admin/proctor/delete']['POST'] 		= 'admin/delete_proctor';
$route['admin/proctor/set_aktif']['POST'] 	= 'admin/set_proctor_aktif';

$route['admin/user/mahasiswa']              = 'admin/show_user_mhs';
$route['admin/user/mahasiswa/add']['POST']  = 'admin/add_new_user/mahasiswa';
$route['admin/user/umum']                   = 'admin/show_user_umum';
$route['admin/user/umum/add']['POST']  		= 'admin/add_new_user/umum';
$route['admin/user/itpln']                  = 'admin/show_user_itpln';
$route['admin/user/itpln/add']['POST']      = 'admin/add_new_user/itpln';
$route['admin/user/(:num)']['GET']          = 'admin/show_user/$1';
$route['admin/user/(:num)']['POST']         = 'admin/update_user/$1';

$route['admin/user/bidang_jabatan']['GET']         			= 'admin/show_bidang_jabatan_itpln';

$route['admin/user/bidang_jabatan/add_bidang']['POST']      = 'admin/add_new_bidang';
$route['admin/user/bidang_jabatan/update_bidang']['POST']   = 'admin/update_bidang';
$route['admin/user/bidang_jabatan/delete_bidang']['POST']   = 'admin/delete_bidang';

$route['admin/user/bidang_jabatan/add_jabatan']['POST']      = 'admin/add_new_jabatan';
$route['admin/user/bidang_jabatan/update_jabatan']['POST']   = 'admin/update_jabatan';
$route['admin/user/bidang_jabatan/delete_jabatan']['POST']   = 'admin/delete_jabatan';

$route['admin/user/instansi']                       = 'admin/show_instansi';
$route['admin/user/instansi/(:num)']['GET']         = 'admin/show_instansi/$1';
$route['admin/user/instansi/add_new']['POST']       = 'admin/tambah_instansi';
$route['admin/user/instansi/(:num)']['POST']        = 'admin/update_instansi/$1';
$route['admin/user/instansi/(:num)/delete']['POST'] = 'admin/hapus_instansi/$1';
$route['admin/user/instansi/(:num)/add_users']['POST']     = 'admin/tambah_user_instansi/$1';
$route['admin/user/instansi/(:num)/remove_user']['POST']   = 'admin/hapus_user_instansi/$1';

$route['admin/user/certiport']              = 'admin/show_akun_certiport';

$route['admin/user/certiport/bulk-registration-data']['GET']    = 'admin/export_bulk_registration_certiport';
$route['admin/user/certiport/upload-template']                  = 'admin/get_template_upload_certiport';
$route['admin/user/certiport/bulk-registration-data']['POST']   = 'admin/upload_certiport_account';

$route['admin/administrators']  					= 'admin/show_administrators';
$route['admin/administrators/add_new']['POST']		= 'admin/add_administrator';
$route['admin/administrators/update']['POST'] 		= 'admin/update_administrator';
$route['admin/administrators/delete']['POST'] 		= 'admin/delete_administrator';

$route['admin/roles'] 								= 'admin/show_roles';

$route['admin/roles/add_role']['POST'] 				= 'admin/add_role';
$route['admin/roles/update_cap']['POST']			= 'admin/update_cap_role';
$route['admin/roles/update_role']['POST']			= 'admin/update_role';
$route['admin/roles/delete_role']['POST'] 			= 'admin/delete_role';

$route['admin/roles/tambah_capability']['POST'] 	= 'admin/tambah_cap';
$route['admin/roles/update_capability']['POST']		= 'admin/update_cap';
$route['admin/roles/hapus_capability']['POST']		= 'admin/hapus_cap';

$route['admin/keuangan']        = 'admin/show_keuangan';

$route['admin/history']        = 'admin/show_history';

$route['admin/sistem']                          = 'admin/show_sistem';
$route['admin/sistem/update-system-email']      = 'admin/update_system_email';
$route['admin/sistem/callback']                 = 'admin/callback_system_email';

$route['ajax/sertifikasi/get_all']['POST']  		= 'ajax/get_sertifikasi';
$route['ajax/kegiatan/set_bukti_bayar']['POST']  	= 'ajax/set_bukti_bayar';
$route['ajax/kegiatan/approve_registrasi']['POST']  = 'ajax/approve_registrasi';
$route['ajax/kegiatan/ubah_kelompok_peserta/t']['POST']       = 'ajax/ubah_kelompok_peserta/t';
$route['ajax/kegiatan/ubah_kelompok_peserta/u']['POST']       = 'ajax/ubah_kelompok_peserta/u';
$route['ajax/user_mhs/get']['POST']                 = 'ajax/get_data_mhs';
$route['ajax/user_umum/get']['POST']                = 'ajax/get_data_umum';
$route['ajax/user_itpln/get']['POST']               = 'ajax/get_data_itpln';
$route['ajax/instansi/get_all']['POST']  		    = 'ajax/get_instansi';

$route['ajax/trainer/sertifikasi/statistik_lulus_tidaklulus_pending']['POST']  	= 'ajax/get_statistik_sertifikasi_trainer';
$route['ajax/trainer/program/statistik_lulus_tidaklulus_pending']['POST']  		= 'ajax/get_statistik_program_trainer';
$route['ajax/proctor/sertifikasi/statistik_lulus_tidaklulus_pending']['POST']  	= 'ajax/get_statistik_sertifikasi_proctor';


$route['storage'] = 'storage/get_file';

$route['test'] = 'admin/test';

$route['error'] = 'error_page';

// disable accessing controller directly (dirty hack)
$route['[^`]+'] = 'error_page';

SET default_storage_engine=INNODB;
-- DROP DATABASE IF EXISTS `itcc_app`;
-- CREATE DATABASE `itcc_app` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- USE `itcc_app`;

CREATE TABLE limit_action(
	waktu 	TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	email 	VARCHAR(100) NOT NULL,
	act		VARCHAR(30) NOT NULL
);
CREATE INDEX idx_act_waktu ON limit_action(waktu);
CREATE INDEX idx_act_limit ON limit_action(act); 
CREATE INDEX idx_act_email ON limit_action(email); 

CREATE TABLE config(
	name 	VARCHAR(50) NOT NULL,
	value 	TEXT,
	PRIMARY KEY (name)
);

CREATE TABLE history(
	id 				INT UNSIGNED NOT NULL AUTO_INCREMENT,
	waktu 			DATETIME NOT NULL,
	deskripsi 		VARCHAR(250) NOT NULL,
	
	PRIMARY KEY(id)
);

CREATE TABLE roles(
	id 				INT UNSIGNED NOT NULL AUTO_INCREMENT,
	nama_role 		VARCHAR(50) NOT NULL,
	
	PRIMARY KEY (id)
);

CREATE TABLE capabilities(
	id 				INT UNSIGNED NOT NULL AUTO_INCREMENT,
	nama 		VARCHAR(50) NOT NULL,
	deskripsi 		VARCHAR(200) NOT NULL,
	
	PRIMARY KEY (id)
);
CREATE UNIQUE INDEX idx_capability ON capabilities(nama);

CREATE TABLE hak_akses(
	id 				INT UNSIGNED NOT NULL AUTO_INCREMENT,
	id_role			INT UNSIGNED NOT NULL,
	id_capabilities INT UNSIGNED NOT NULL,
	
	PRIMARY KEY (id),
	FOREIGN KEY(id_role) REFERENCES roles(id) ON DELETE CASCADE,
	FOREIGN KEY(id_capabilities) REFERENCES capabilities(id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX idx_capability_role ON hak_akses(id_role, id_capabilities);

CREATE TABLE bidang_itpln(
	id 				INT UNSIGNED NOT NULL AUTO_INCREMENT,
	nama_bidang 	VARCHAR(100) NOT NULL,
	
	PRIMARY KEY (id)
);

CREATE TABLE jabatan_itpln(
	id 				INT UNSIGNED NOT NULL AUTO_INCREMENT,
	id_bidang 		INT UNSIGNED NOT NULL,
	nama_jabatan 	VARCHAR(100) NOT NULL,
	
	PRIMARY KEY (id),
	FOREIGN KEY (id_bidang) REFERENCES bidang_itpln(id) ON DELETE CASCADE
);


CREATE TABLE itcc_internal(
	id 					INT UNSIGNED NOT NULL AUTO_INCREMENT,
	email 				VARCHAR(100) NOT NULL,
	nama 		 		VARCHAR(100) NOT NULL,
	id_role				INT UNSIGNED NOT NULL,
	
	PRIMARY KEY(id),
	FOREIGN KEY (id_role) REFERENCES roles(id) ON DELETE RESTRICT
); 
CREATE UNIQUE INDEX idx_email_admin ON itcc_internal(email);

CREATE TABLE sertifikasi(
	id 							INT UNSIGNED NOT NULL AUTO_INCREMENT,
	nama 						VARCHAR(50) NOT NULL,
	deskripsi 					VARCHAR(500) NOT NULL,
	file_logo 					VARCHAR(100) NOT NULL,
	link_template_sertifikat 	VARCHAR(100) NOT NULL,
	
	PRIMARY KEY(id)
);

CREATE TABLE trainer(
	id 					INT UNSIGNED NOT NULL AUTO_INCREMENT,
	email 				VARCHAR(50) NOT NULL,
	nama_lengkap 		VARCHAR(100) NOT NULL,
	no_telepon 			VARCHAR(15) NOT NULL,
	file_foto 			VARCHAR(100) NOT NULL,
	aktif 				VARCHAR(20) NOT NULL DEFAULT 'y',
	
	PRIMARY KEY (id)
); 
CREATE UNIQUE INDEX idx_email_trainer ON trainer(email);

CREATE TABLE proctor(
	id 					INT UNSIGNED NOT NULL AUTO_INCREMENT,
	email 				VARCHAR(50) NOT NULL,
	nama_lengkap 		VARCHAR(100) NOT NULL,
	no_telepon 			VARCHAR(15) NOT NULL,
	file_foto 			VARCHAR(100) NOT NULL,
	aktif 				VARCHAR(20) NOT NULL DEFAULT 'y',
	
	PRIMARY KEY (id)
); 
CREATE UNIQUE INDEX idx_email_proctor ON proctor(email);

CREATE TABLE users(
	id 					INT UNSIGNED NOT NULL AUTO_INCREMENT,
	time_registered 	TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	aktif 				VARCHAR(20) NOT NULL DEFAULT 'y',
	tipe_user 			VARCHAR(20) NOT NULL, 			-- 'mahasiswa', 'umum', 'itpln'
	nama_depan 			VARCHAR(50) NOT NULL,
	nama_belakang 		VARCHAR(50) NOT NULL,
	jenis_kelamin 		enum('l', 'p') NOT NULL, 		-- dibiarkan enum karena tidak akan berubah kedepannya
	email 				VARCHAR(100) NOT NULL,
	user_pass 			VARCHAR(150), 				-- data khusus umum
	angkatan 			VARCHAR(9), 				-- data khusus mahasiswa
	jurusan 			VARCHAR(9), 				-- data khusus mahasiswa
	nim 				VARCHAR(9), 				-- data khusus mahasiswa
	nik 				VARCHAR(16), 				-- data khusus umum
	alamat 				VARCHAR(200) NOT NULL,
	no_telepon 			VARCHAR(15) NOT NULL,
	id_line 			VARCHAR(30), 				
	id_telegram 		VARCHAR(30),
	file_ktm 			VARCHAR(100), 				-- data khusus mahasiswa
	file_ktp 			VARCHAR(100), 				-- data khusus umum
	file_fotoprofil 	VARCHAR(100) NOT NULL,
	username_certiport  VARCHAR(100),
	password_certiport 	VARCHAR(100),
	id_jabatan			INT UNSIGNED,        		-- data khusus karyawan itpln
	
	PRIMARY KEY (id),
	FOREIGN KEY (id_jabatan) REFERENCES jabatan_itpln(id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX idx_unique_email_user ON users(email);
CREATE INDEX idx_nd_user ON users(nama_depan);
CREATE INDEX idx_nb_user ON users(nama_belakang);
CREATE INDEX idx_angkatan_user ON users(angkatan);
CREATE INDEX idx_jurusan_user ON users(jurusan);
CREATE INDEX idx_nim_user ON users(nim);
CREATE INDEX idx_tipe_user ON users(tipe_user);
CREATE INDEX idx_aktif_user ON users(aktif);
CREATE INDEX idx_jabatan_user ON users(id_jabatan);

CREATE TABLE instansi(
	id 				INT UNSIGNED NOT NULL AUTO_INCREMENT,
	nama 			VARCHAR(100) NOT NULL,
	alamat 			VARCHAR(200) NOT NULL,
	no_telepon 		VARCHAR(15) NOT NULL,
	
	PRIMARY KEY (id)
);
CREATE INDEX idx_nama_instansi ON instansi(nama);

CREATE TABLE instansi_user(
	id 				INT UNSIGNED NOT NULL AUTO_INCREMENT,
	id_user 		INT UNSIGNED NOT NULL,
	id_instansi 	INT UNSIGNED NOT NULL,
	
	PRIMARY KEY (id),
	FOREIGN KEY (id_user) REFERENCES users(id) ON DELETE CASCADE,
	FOREIGN KEY (id_instansi) REFERENCES instansi(id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX idx_instansi_user ON instansi_user(id_user, id_instansi);

CREATE TABLE info_user(
	id 				INT UNSIGNED NOT NULL AUTO_INCREMENT,
	id_user 		INT UNSIGNED NOT NULL,
	waktu 			TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	info 			VARCHAR(200) NOT NULL,
	display 		VARCHAR(20) NOT NULL DEFAULT 'y',
	
	PRIMARY KEY (id),
	FOREIGN KEY (id_user) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX idx_info_user_waktu ON info_user(waktu);
CREATE INDEX idx_info_user ON info_user(id_user);
CREATE INDEX idx_info_user_display ON info_user(display);

CREATE TABLE program(
	id 				INT UNSIGNED NOT NULL AUTO_INCREMENT,
	id_sertif 		INT UNSIGNED NOT NULL,
	nama_program 	VARCHAR(50) NOT NULL,
	link_assesment 	VARCHAR(150) NOT NULL,
	file_modul 		VARCHAR(100),
	min_skor 		SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	max_skor 		SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	file_logo 		VARCHAR(100) NOT NULL,
	
	PRIMARY KEY (id),
	FOREIGN KEY (id_sertif) REFERENCES sertifikasi(id) ON DELETE RESTRICT
);

CREATE TABLE program_trainer(
	id 				INT UNSIGNED NOT NULL AUTO_INCREMENT,
	id_trainer 		INT UNSIGNED NOT NULL,
	id_program 		INT UNSIGNED NOT NULL,
	
	PRIMARY KEY (id),
	FOREIGN KEY (id_trainer) REFERENCES trainer(id) ON DELETE CASCADE,
	FOREIGN KEY (id_program) REFERENCES program(id) ON DELETE CASCADE
); 
CREATE UNIQUE INDEX idx_program_trainer ON program_trainer(id_trainer, id_program);

CREATE TABLE sertifikasi_proctor(
	id 				INT UNSIGNED NOT NULL AUTO_INCREMENT,
	id_proctor 		INT UNSIGNED NOT NULL,
	id_sertifikasi 	INT UNSIGNED NOT NULL,
	
	PRIMARY KEY (id),
	FOREIGN KEY (id_proctor) REFERENCES proctor(id) ON DELETE CASCADE,
	FOREIGN KEY (id_sertifikasi) REFERENCES sertifikasi(id) ON DELETE CASCADE
); 
CREATE UNIQUE INDEX idx_sertif_proctor ON sertifikasi_proctor(id_proctor, id_sertifikasi);

CREATE TABLE materi_training(
	id 				INT UNSIGNED NOT NULL AUTO_INCREMENT,
	id_trainer 		INT UNSIGNED,
	id_program 		INT UNSIGNED,
	nama_file 		VARCHAR(100) NOT NULL,
	deskripsi 		VARCHAR(250) NOT NULL DEFAULT '-',
	
	PRIMARY KEY (id),
	FOREIGN KEY (id_trainer) REFERENCES trainer(id) ON DELETE SET NULL,
	FOREIGN KEY (id_program) REFERENCES program(id) ON DELETE SET NULL
);

CREATE TABLE kegiatan(
	id 									INT UNSIGNED NOT NULL AUTO_INCREMENT,
	nama_kegiatan 						VARCHAR(100) NOT NULL,
	batal 								VARCHAR(20) NOT NULL DEFAULT 'n',
	keterangan_batal 					VARCHAR(100),
	harga_t_u 							INT UNSIGNED NOT NULL,
	harga_u 							INT UNSIGNED NOT NULL,
	registrasi_dibuka 					VARCHAR(20) NOT NULL DEFAULT 'n',
	awal_registrasi 					DATETIME,
	akhir_registrasi 					DATETIME,
	batas_upload_bukti_bayar			DATETIME,
	awal_persiapan 						DATE NOT NULL,
	akhir_persiapan 					DATE NOT NULL,
	awal_pelaporan 						DATE NOT NULL,
	akhir_pelaporan 					DATE NOT NULL,
	keterangan_training 				VARCHAR(250) NOT NULL,
	keterangan_ujian 					VARCHAR(250) NOT NULL,
	id_sertifikasi 						INT UNSIGNED NOT NULL,
	deskripsi 							VARCHAR(300) DEFAULT '',
	dibuka_untuk 						VARCHAR(20) NOT NULL, 			-- 'mahasiswa', 'umum', 'itpln'
	link_grup 							VARCHAR(100) NOT NULL,
	kriteria_registrasi 				TEXT NOT NULL,
	kriteria_diskon 					TEXT NOT NULL,
	kriteria_peserta_boleh_ujian_saja 	TEXT NOT NULL,
	catatan 							TEXT,  -- catatan khusus admin
	
	PRIMARY KEY (id),
	FOREIGN KEY (id_sertifikasi) REFERENCES sertifikasi(id) ON DELETE RESTRICT
);
CREATE INDEX idx_keg_batal ON kegiatan(batal);
CREATE INDEX idx_sertif_kegiatan ON kegiatan(id_sertifikasi);
CREATE INDEX idx_regis_kegiatan_dibuka ON kegiatan(registrasi_dibuka);
CREATE INDEX idx_awal_regis_kegiatan ON kegiatan(awal_registrasi);
CREATE INDEX idx_keg_dibuka_untuk ON kegiatan(dibuka_untuk);

CREATE TABLE klaim_dana_kegiatan(
	id 									INT UNSIGNED NOT NULL AUTO_INCREMENT,
	id_kegiatan 						INT UNSIGNED,
	nominal_klaim 						INT UNSIGNED NOT NULL,
	keterangan 							VARCHAR(300) NOT NULL,
	file_bukti_klaim 					VARCHAR(100) NOT NULL,
	
	PRIMARY KEY (id),
	FOREIGN KEY (id_kegiatan) REFERENCES kegiatan(id) ON DELETE SET NULL
);
CREATE INDEX idx_klaim_id_kegiatan ON klaim_dana_kegiatan(id_kegiatan);

CREATE TABLE program_kegiatan(
	id 					INT UNSIGNED NOT NULL AUTO_INCREMENT,
	id_kegiatan 		INT UNSIGNED NOT NULL,
	id_program 			INT UNSIGNED NOT NULL,
	
	PRIMARY KEY (id),
	FOREIGN KEY (id_kegiatan) REFERENCES kegiatan(id) ON DELETE CASCADE,
	FOREIGN KEY (id_program) REFERENCES program(id) ON DELETE RESTRICT
);

CREATE TABLE peserta_kegiatan_itpln(
	id_kegiatan 		INT UNSIGNED NOT NULL AUTO_INCREMENT,
	email 				VARCHAR(100) NOT NULL,
	id_program_kegiatan INT UNSIGNED NOT NULL,
	FOREIGN KEY (id_kegiatan) REFERENCES kegiatan(id) ON DELETE CASCADE,
	FOREIGN KEY (id_program_kegiatan) REFERENCES program_kegiatan(id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX idx_peserta_kegiatan_karyawan_kegiatan ON peserta_kegiatan_itpln(id_kegiatan, email);
CREATE INDEX idx_peserta_kegiatan_karyawan_email ON peserta_kegiatan_itpln(email);

CREATE UNIQUE INDEX idx_program_kegiatan ON program_kegiatan(id_kegiatan, id_program);

CREATE TABLE kelompok_t(
	id 						INT UNSIGNED NOT NULL AUTO_INCREMENT,
	nama_kelompok 			VARCHAR(50) NOT NULL,
	id_kegiatan 			INT UNSIGNED NOT NULL,
	id_program_kegiatan 	INT UNSIGNED NOT NULL,
	lokasi_training 		VARCHAR(100) NOT NULL,
	mulai_training 			DATETIME,
	selesai_training 		DATETIME,
	id_trainer_sesi1 		INT UNSIGNED,
	id_trainer_sesi2 		INT UNSIGNED,
	id_proctor_training 	INT UNSIGNED,
	min_peserta_training 	SMALLINT UNSIGNED NOT NULL,
	max_peserta_training 	SMALLINT UNSIGNED NOT NULL,
	beritaacara_t_sesi1 	TEXT,
	beritaacara_t_sesi2 	TEXT,
	
	PRIMARY KEY (id),
	FOREIGN KEY (id_kegiatan) REFERENCES kegiatan(id) ON DELETE CASCADE,
	FOREIGN KEY (id_program_kegiatan) REFERENCES program_kegiatan(id) ON DELETE CASCADE,
	FOREIGN KEY (id_trainer_sesi1) REFERENCES trainer(id) ON DELETE RESTRICT,
	FOREIGN KEY (id_trainer_sesi2) REFERENCES trainer(id) ON DELETE RESTRICT,
	FOREIGN KEY (id_proctor_training) REFERENCES proctor(id) ON DELETE RESTRICT
);
CREATE INDEX idx_kegiatan_kelompok_t ON kelompok_t(id_kegiatan);
CREATE INDEX idx_program_kegiatan_kelompok_t ON kelompok_t(id_program_kegiatan);
CREATE INDEX idx_kelompok_t_mulai_training ON kelompok_t(mulai_training);
CREATE INDEX idx_kelompok_t_trainer_sesi1 ON kelompok_t(id_trainer_sesi1);
CREATE INDEX idx_kelompok_t_trainer_sesi2 ON kelompok_t(id_trainer_sesi2);
CREATE INDEX idx_kelompok_t_proctor_training ON kelompok_t(id_proctor_training);

CREATE TABLE kelompok_u(
	id 						INT UNSIGNED NOT NULL AUTO_INCREMENT,
	nama_kelompok 			VARCHAR(50) NOT NULL,
	id_kegiatan 			INT UNSIGNED NOT NULL,
	id_program_kegiatan 	INT UNSIGNED NOT NULL,
	lokasi_ujian 			VARCHAR(100) NOT NULL,
	mulai_ujian 			DATETIME,
	selesai_ujian 			DATETIME,
	id_proctor_ujian 		INT UNSIGNED,
	min_peserta_ujian 		SMALLINT UNSIGNED NOT NULL,
	max_peserta_ujian 		SMALLINT UNSIGNED NOT NULL,
	beritaacara_ujian 		TEXT,
	
	PRIMARY KEY (id),
	FOREIGN KEY (id_kegiatan) REFERENCES kegiatan(id) ON DELETE CASCADE,
	FOREIGN KEY (id_program_kegiatan) REFERENCES program_kegiatan(id) ON DELETE CASCADE,
	FOREIGN KEY (id_proctor_ujian) REFERENCES proctor(id) ON DELETE RESTRICT
);
CREATE INDEX idx_kegiatan_kelompok_u ON kelompok_u(id_kegiatan);
CREATE INDEX idx_program_kegiatan_kelompok_u ON kelompok_u(id_program_kegiatan);
CREATE INDEX idx_kelompok_u_mulai_ujian ON kelompok_u(mulai_ujian);
CREATE INDEX idx_kelompok_u_proctor_ujian ON kelompok_u(id_proctor_ujian);

CREATE TABLE kesediaan_trainer(
	id 					INT UNSIGNED NOT NULL AUTO_INCREMENT,
	waktu 				TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	id_trainer 			INT UNSIGNED NOT NULL,
	id_kelompok_t 		INT UNSIGNED NOT NULL,
	
	PRIMARY KEY (id),
	FOREIGN KEY (id_trainer) REFERENCES trainer(id) ON DELETE CASCADE,
	FOREIGN KEY (id_kelompok_t) REFERENCES kelompok_t(id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX idx_unique_k_trainer ON kesediaan_trainer(id_trainer, id_kelompok_t);
CREATE INDEX idx_k_trainer_waktu ON kesediaan_trainer(waktu);
CREATE INDEX idx_k_trainer_id_trainer ON kesediaan_trainer(id_trainer);

CREATE TABLE kesediaan_proctor_training(
	id 					INT UNSIGNED NOT NULL AUTO_INCREMENT,
	waktu 				TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	id_proctor 			INT UNSIGNED NOT NULL,
	id_kelompok_t 		INT UNSIGNED NOT NULL,
	
	PRIMARY KEY (id),
	FOREIGN KEY (id_proctor) REFERENCES proctor(id) ON DELETE CASCADE,
	FOREIGN KEY (id_kelompok_t) REFERENCES kelompok_t(id) ON DELETE CASCADE
);
CREATE INDEX idx_k_proctor_t_id_proctor ON kesediaan_proctor_training(id_proctor);
CREATE INDEX idx_k_proctor_t_waktu ON kesediaan_proctor_training(waktu);
CREATE UNIQUE INDEX idx_unique_k_proctor_t ON kesediaan_proctor_training(id_proctor, id_kelompok_t);

CREATE TABLE kesediaan_proctor_ujian(
	id 					INT UNSIGNED NOT NULL AUTO_INCREMENT,
	waktu 				TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	id_proctor 			INT UNSIGNED NOT NULL,
	id_kelompok_u 		INT UNSIGNED NOT NULL,
	
	PRIMARY KEY (id),
	FOREIGN KEY (id_proctor) REFERENCES proctor(id) ON DELETE CASCADE,
	FOREIGN KEY (id_kelompok_u) REFERENCES kelompok_u(id) ON DELETE CASCADE
);
CREATE INDEX idx_k_proctor_u_id_proctor ON kesediaan_proctor_ujian(id_proctor);
CREATE INDEX idx_k_proctor_u_waktu ON kesediaan_proctor_ujian(waktu);
CREATE UNIQUE INDEX idx_unique_k_proctor_u ON kesediaan_proctor_ujian(id_proctor, id_kelompok_u);

CREATE TABLE pendaftaran(
	id 						INT UNSIGNED NOT NULL AUTO_INCREMENT,
	waktu 					TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	id_user 				INT UNSIGNED NOT NULL,
	id_kegiatan 			INT UNSIGNED NOT NULL,
	id_program_kegiatan 	INT UNSIGNED NOT NULL,
	jenis 					VARCHAR(20) NOT NULL,                 -- 'u','t_u'
	diskon 					INT UNSIGNED NOT NULL DEFAULT 0,
	approved 				ENUM('n', 'y') NOT NULL DEFAULT 'n',
	id_kelompok_t 			INT UNSIGNED,
	id_kelompok_u 			INT UNSIGNED,
	hadir_training_sesi1 	ENUM('n', 'y') NOT NULL DEFAULT 'n',
	hadir_training_sesi2 	ENUM('n', 'y') NOT NULL DEFAULT 'n',
	hadir_ujian 			ENUM('n', 'y') NOT NULL DEFAULT 'n',
	skor_ujian 				INT NOT NULL DEFAULT -1,
	
	PRIMARY KEY (id),
	FOREIGN KEY (id_user) REFERENCES users(id) ON DELETE RESTRICT,
	FOREIGN KEY (id_kegiatan) REFERENCES kegiatan(id) ON DELETE RESTRICT,
	FOREIGN KEY (id_program_kegiatan) REFERENCES program_kegiatan(id) ON DELETE RESTRICT,
	FOREIGN KEY (id_kelompok_t) REFERENCES kelompok_t(id) ON DELETE SET NULL,
	FOREIGN KEY (id_kelompok_u) REFERENCES kelompok_u(id) ON DELETE SET NULL
);
CREATE INDEX idx_waktu_daftar ON pendaftaran (waktu);
CREATE INDEX idx_kelompok_t_daftar ON pendaftaran (id_kelompok_t);
CREATE INDEX idx_kelompok_u_daftar ON pendaftaran (id_kelompok_u);
CREATE INDEX idx_kegiatan_daftar ON pendaftaran (id_kegiatan);
CREATE UNIQUE INDEX idx_unique_pendaftaran ON pendaftaran(id_user, id_kegiatan);

CREATE TABLE bukti_bayar(
	id 						INT UNSIGNED NOT NULL AUTO_INCREMENT,
	waktu 					TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	id_pendaftaran 			INT UNSIGNED NOT NULL,
	file_bukti 				VARCHAR(100) NOT NULL,
	waktu_transfer 			DATETIME NOT NULL,
	nominal_dibayar 		INT UNSIGNED NOT NULL,
	nama_pengirim 			VARCHAR(100) NOT NULL,
	bank 					VARCHAR(30) NOT NULL,
	diterima 				ENUM('pending', 'reject', 'accept') NOT NULL,
	
	PRIMARY KEY (id),
	FOREIGN KEY (id_pendaftaran) REFERENCES pendaftaran(id) ON DELETE RESTRICT
);
CREATE INDEX idx_upload_bukti_bayar ON bukti_bayar(waktu);
CREATE INDEX idx_waktu_tf ON bukti_bayar(waktu_transfer);

CREATE TABLE sertifikat_keikutsertaan(
	id 						INT UNSIGNED NOT NULL AUTO_INCREMENT,
	id_pendaftaran 			INT UNSIGNED NOT NULL,
	tanggal_terbit 			DATETIME NOT NULL,
	kode 					VARCHAR(30) NOT NULL,
	
	PRIMARY KEY (id),
	FOREIGN KEY (id_pendaftaran) REFERENCES pendaftaran(id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX idx_kode_sertifikat_keikutsertaan ON sertifikat_keikutsertaan(kode);
CREATE UNIQUE INDEX idx_pendaftaran_sertifikat_keikutsertaan ON sertifikat_keikutsertaan(id_pendaftaran);

INSERT INTO config (name, value) VALUES 
('superadmin_email', 'rian1631178@itpln.ac.id'),
('access_token', NULL),
('refresh_token', NULL),
('token_expires', NULL),
('token_identifier', NULL);

UPDATE config SET value='eyJ0eXAiOiJKV1QiLCJub25jZSI6ImFvTE4xQ3VjU2dNUmtYN3ZHWlNXdWFKNC1TTmROOEhEMTNxbHlIT1llMFEiLCJhbGciOiJSUzI1NiIsIng1dCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyIsImtpZCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyJ9.eyJhdWQiOiIwMDAwMDAwMy0wMDAwLTAwMDAtYzAwMC0wMDAwMDAwMDAwMDAiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC83YjM4OGQxOC0xOTAwLTQxOGMtYTVkMy1lMjhkN2E5YTM4ZTYvIiwiaWF0IjoxNjE5OTkxOTkyLCJuYmYiOjE2MTk5OTE5OTIsImV4cCI6MTYxOTk5NTg5MiwiYWNjdCI6MCwiYWNyIjoiMSIsImFjcnMiOlsidXJuOnVzZXI6cmVnaXN0ZXJzZWN1cml0eWluZm8iLCJ1cm46bWljcm9zb2Z0OnJlcTEiLCJ1cm46bWljcm9zb2Z0OnJlcTIiLCJ1cm46bWljcm9zb2Z0OnJlcTMiLCJjMSIsImMyIiwiYzMiLCJjNCIsImM1IiwiYzYiLCJjNyIsImM4IiwiYzkiLCJjMTAiLCJjMTEiLCJjMTIiLCJjMTMiLCJjMTQiLCJjMTUiLCJjMTYiLCJjMTciLCJjMTgiLCJjMTkiLCJjMjAiLCJjMjEiLCJjMjIiLCJjMjMiLCJjMjQiLCJjMjUiXSwiYWlvIjoiQVNRQTIvOFRBQUFBdmtyem9SMmRKOFdvckRWNzVCN1FnZTZnUS9tTnRWeVVvem4wRUd2b0hLTT0iLCJhbXIiOlsicHdkIl0sImFwcF9kaXNwbGF5bmFtZSI6IklUQ0MgU3lzdGVtIEFQSSAoSW50ZXJuYWwgT25seSkiLCJhcHBpZCI6IjE3MWVhOWQ0LWU4NzUtNDcwNy04MjM2LWQxNDYwODU3YWU5YyIsImFwcGlkYWNyIjoiMSIsImZhbWlseV9uYW1lIjoiSEFTSUFORE8gU0lMQUVOIiwiZ2l2ZW5fbmFtZSI6IlJJQU4iLCJpZHR5cCI6InVzZXIiLCJpcGFkZHIiOiIxMTIuMjE1LjY1LjUzIiwibmFtZSI6IlJJQU4gSEFTSUFORE8gU0lMQUVOIiwib2lkIjoiZGJhZGM4YzUtY2MyMy00NjEyLWExNDMtMjhlMjdmMWE3MzgyIiwicGxhdGYiOiIxNCIsInB1aWQiOiIxMDAzN0ZGRTlBQzUwQzFCIiwicmgiOiIwLkFWUUFHSTA0ZXdBWmpFR2wwLUtOZXBvNDV0U3BIaGQxNkFkSGdqYlJSZ2hYcnB4VUFNRS4iLCJzY3AiOiJGaWxlcy5SZWFkV3JpdGUgRmlsZXMuUmVhZFdyaXRlLkFsbCBNYWlsLlNlbmQgTWFpbGJveFNldHRpbmdzLlJlYWQgb3BlbmlkIHByb2ZpbGUgU2l0ZXMuUmVhZFdyaXRlLkFsbCBVc2VyLlJlYWQgZW1haWwiLCJzaWduaW5fc3RhdGUiOlsia21zaSJdLCJzdWIiOiJTZHJhWFlsazhnSFR1eFVPcm8tWVVPSXpGQmIwNkViX29ieW9SWWdQOWxZIiwidGVuYW50X3JlZ2lvbl9zY29wZSI6IkFTIiwidGlkIjoiN2IzODhkMTgtMTkwMC00MThjLWE1ZDMtZTI4ZDdhOWEzOGU2IiwidW5pcXVlX25hbWUiOiJyaWFuMTYzMTE3OEBpdHBsbi5hYy5pZCIsInVwbiI6InJpYW4xNjMxMTc4QGl0cGxuLmFjLmlkIiwidXRpIjoiWVhQQ2VKM0RxMHFkWGtpLWRLQjNBUSIsInZlciI6IjEuMCIsIndpZHMiOlsiYjc5ZmJmNGQtM2VmOS00Njg5LTgxNDMtNzZiMTk0ZTg1NTA5Il0sInhtc19zdCI6eyJzdWIiOiJody1MV1BxN2w3MW41NUFEME81NFoweWpjRzJhcXRXVjhPX29IQ21UZnprIn0sInhtc190Y2R0IjoxNDMzOTI2OTExfQ.Nleymvu9prtrSsK43vYpaWPkJEGzYPCASTxISPxf4tx_lDuHFpp4xFpWNhlxs6nIv06I0jiFhOTNo3bV_HXlrnEcVfh_aC4LBaDRTpPebSv4v0URce5Z2g0IFZXi4MZPMnyaqo-liaXVGPiW1wMX63cuUl1Jyc-SbRi32pUFyEvbVI4RQAGZ6jKCXrEf176R6i-2H1ecDo4PH1zJLAdhG-io_I9dI0y3d-vDCO8PG5pH2UfMQaeXZ9had8oV1Xsqu1VEo0Y5cTCuNViZp2D0k9TpGrft7zN1ZZtXQvEKuFQlgSBCmoIl2XAXmTCB01Rqa-SP5lk1R_g6-leeRWtiVw'
WHERE name='access_token';

UPDATE config SET value='0.AVQAGI04ewAZjEGl0-KNepo45tSpHhd16AdHgjbRRghXrpxUAME.AgABAAAAAAD--DLA3VO7QrddgJg7WevrAgDs_wQA9P--9xqUUwhWNP7d9JbbYZbNDKZCw8HiWHil4RLQ7s_CBZJYHcrDvFPEppjRddBsKUr2bnt_D9XZLexhQuZAy84WwNQSG93iFTfPCTLp11H4v3qEScbayt_UJWweOfl7EQTzs1qEVQhIp6MPAw1oIFUieymJwI8_pnnxgdKpYchRDsxhV1DzGW8c5XpsA9uKsbKADeFeCCO_GH2ChSIrMInu3CZffjGhtBVlPEsWgfkk2rSCNcdyjk6Jg8UoLq7nNv6RqD3LbiwN4hoS5nFfJGUSl9FRHnIBgWLgnar8peaJWgSFOM-QjbMbAHJFnm32-Ed__PRDHTGaS09xidSR6zFWBJjyRGEASuhH5CUjcrAKCT5LFfPxXEd9LYhYBwTQ6VEmK-vHdDrQIlsbGFfz7H7as35l3GJETHP7Px7B9PRj9dRFB3n650y0r90nrc97MJjsV4350ziJ2OHvo8zGh3xdiCEneoMyhQ6PxxFLi-qFENbwyoGlKHhxKRo0X9Bb_bXl9SaPy_rzUg0flGi4e9Ky6Z6nM0M11SUpkKy4s8E77qyQ2BU6TtdILi4txOogbPIfhNTcHJqZ-CC5NHpduCnATJsIxDf7vRjU76E-tiOmJbbyq8niykNnBaBhQaUlfTeM3bI9OfRUJqv3FTL8y7QdNduyq57UWwAHR9HyAvC-g1Kb0Em4_9xFn2JTSY9IWXmdSa7WWwsLn9pZPdKr68cT4_yuVT8vv0pq5eAQA-5CVStHsTbLNe58qbXasYwhyxAYkI1-ikKfIcDttJLPD69U_xqOpnyX0WzCd3Jh-F5HlPryxDaWlE0DqhkVSpac8Wp_lKbAyf5ombwa2LV1opRlD9LWHJp99fyNIWM0x_D9F56OksI5nMmNkfWtyBHVhXnye-nKsy67luopNAhA0l0W4zETzGCI7Jah98sMNnWvYqCiCPJX-83tzUptRYfEAtFNDjBn9lSC8jILWmQVY37HYBCPzIaX4aU'
WHERE name='refresh_token';

UPDATE config SET value='1620021089' WHERE name='token_expires';
UPDATE config SET value='rian1631178@itpln.ac.id' WHERE name='token_identifier';

INSERT INTO capabilities(nama, deskripsi) VALUES
('lihat_kegiatan_sertifikasi'	, 'Lihat data kegiatan sertifikasi'),
('tambah_kegiatan_sertifikasi'  , 'Mengadakan kegiatan sertifikasi baru'),
('edit_kegiatan_sertifikasi'  	, 'Edit data kegiatan sertifikasi'),
('hapus_kegiatan_sertifikasi'   , 'Membatalkan kegiatan sertifikasi (hapus jika sertifikasi belum ada yang registrasi)'),

('lihat_keuangan_kegiatan_sertifikasi'	, 'Lihat data keuangan kegiatan sertifikasi (pembayaran, klaim dana, dll)'),
('edit_keuangan_kegiatan_sertifikasi'	, 'Edit data keuangan kegiatan sertifikasi (pembayaran, klaim dana, dll)'),

('lihat_list_sertifikasi' 		, 'Lihat daftar sertifikasi dan program'),
('tambah_list_sertifikasi' 		, 'Menambahkan sertifikasi dan program baru'),
('edit_list_sertifikasi'		, 'Edit data program sertifikasi yang sudah ada'),
('hapus_list_sertifikasi' 		, 'Hapus data program sertifikasi (jika sudah ada kegiatan, dinonaktifkan)'),

('lihat_history_sertifikasi'    , 'Lihat history kegiatan sertifikasi'),

('lihat_list_trainer'			, 'Lihat data trainer'),
('tambah_list_trainer'			, 'Tambah trainer baru'),
('edit_list_trainer'			, 'Lihat & edit data trainer yang sudah ada'),
('hapus_list_trainer' 			, 'Menonaktifkan trainer (hapus jika trainer belum pernah berpartisipasi)'),

('lihat_list_proctor'			, 'Lihat data proctor'),
('tambah_list_proctor' 			, 'Tambah proctor baru'),
('edit_list_proctor'			, 'Lihat & edit data proctor'),
('hapus_list_proctor'        	, 'Menonaktifkan proctor (hapus jika proctor belum pernah berpartisipasi)'),

-- User : Mahasiswa, itpln dan umum 
('lihat_list_user'				, 'Lihat seluruh data user'),
('tambah_list_user' 			, 'Tambah user baru'),
('edit_list_user'               , 'Edit data user'),
('hapus_list_user'              , 'Nonaktifkan user (hapus jika user masih baru)'),

-- List bidang dan jabatan
('lihat_list_bidang_jabatan'	, 'Lihat seluruh data bidang & jabatan'),
('tambah_list_bidang_jabatan' 	, 'Tambah bidang & jabatan baru'),
('edit_list_bidang_jabatan'     , 'Edit data bidang & jabatan'),
('hapus_list_bidang_jabatan'    , 'Hapus bidang & jabatan'),

-- Instansi untuk user umum
('lihat_list_instansi'			, 'Lihat seluruh data instansi'),
('tambah_list_instansi' 		, 'Tambah instansi baru'),
('edit_list_instansi'           , 'Edit data instansi, menambah/menghapus user dari instansi'),
('hapus_list_instansi'          , 'Hapus list instansi'),

('lihat_list_administrator'		, 'Lihat data admin internal'),
('tambah_list_administrator'    , 'Tambah administrator baru'),
('edit_list_administrator'		, 'Edit data administrator yang sudah ada'),
('hapus_list_administrator'     , 'Hapus administrator'),

('lihat_list_hak_akses'         , 'Lihat daftar role dan capability admin'),
('tambah_list_hak_akses'		, 'Tambah role atau capability baru'),
('edit_list_hak_akses'  		, 'Edit data role dan capability yang ada'),
('hapus_list_hak_akses' 		, 'Hapus data role dan capability'),

('edit_konfigurasi_sistem'		, 'Mengubah konfigurasi dari sistem'),
('lihat_history_sistem'			, 'Lihat History Login & Logout Admin lain')
;

INSERT INTO roles(nama_role) VALUES
('Teknis'),
('Administrasi');

INSERT INTO hak_akses (id_role, id_capabilities) VALUES
(1,2),
(1,4),
(1,5),
(2,2);

INSERT INTO itcc_internal (email, nama, id_role) VALUES
('rian1631178@itpln.ac.id', 'Rian Hasiando Silaen, MOS, MTA', 1);









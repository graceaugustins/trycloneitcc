<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @property M_trainer $m_trainer
 * @property M_sertifikasi $m_sertifikasi
 * @property M_program $m_program
 * @property M_proctor $m_proctor
 * @property M_kegiatan $m_kegiatan
 * @property M_kelompok_t $m_kelompok_t
 * @property M_kelompok_u $m_kelompok_u
 * @property CI_Input $input
 */
class Proctor extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if (!isset($_SESSION['warning']))
			$_SESSION['warning'] = [];
        if (!empty($_SESSION['isProctor']))
        {
            $this->load->model('proctor_model');
            $proctor = $this->proctor_model->get_proctor($_SESSION['isProctor']['id']);
            if (empty($proctor)) unset($_SESSION['isProctor']);
            else $_SESSION['isProctor'] = reset($proctor);
        }
	}

	public function show_login()
	{
		$data = [];
		$data['next'] = base_url('proctor');
		// cek variabel get next (dari halaman lain)
		if (!empty($this->input->get('next')))
		{
			$get = explode('?', $this->input->get('next'));
			$data['next'] = base_url($get[0]);
		}
		$this->load->view('proctor/login', $data);
	}

	// Proses lanjutan login
	// setelah MSauth
	public function proses_login()
	{
		// Kalau akun valid dan
		// mengunjungi url ini lagi, redirect
		if (isset($_SESSION['isProctor']))
		{
			$next = isset($_SESSION['next']) ? $_SESSION['next'] : base_url('proctor');
			redirect($next);
		}
		$this->load->library('user_token');
		$email = trim(strtolower($this->user_token->getEmail()));
		// Email ada : auth berhasil tapi tidak valid
		// Email tidak ada : belum auth dan tidak valid
		if (empty($email)) redirect(base_url("proctor/login"));

		// Cek valid email
		$this->load->model('proctors_model');

		// cek apakah proctor atau bukan
		if (!$this->proctors_model->is_proctor($email))
		{
			redirect(base_url("proctor/login"));
			return;
		}
		// ambil detail proctor
		$_SESSION['isProctor'] = $this->proctors_model->get_detail($email);
		$next = isset($_SESSION['next']) ? $_SESSION['next'] : base_url('proctor');
		redirect($next);
	}

	public function logout()
	{
		$_SESSION = [];
		session_destroy();
		redirect(base_url('msauth/signout'));
	}

    private function redirect_if_not_logged_in()
    {
        if (empty($_SESSION['isProctor']))
        {
            clear_warning();
            redirect(base_url('proctor/login?next='.$this->uri->uri_string()));
        }
	}

    private function redirect_if_not_active()
    {
        $this->redirect_if_not_logged_in();
        if ($_SESSION['isProctor']['aktif'] === FALSE)
            redirect(base_url('proctor/not_active'));
    }

    public function show_not_active()
    {
        $this->redirect_if_not_logged_in();
        if ($_SESSION['isProctor']['aktif'] === FALSE)
            $this->load->view('proctor/not_active');
        else redirect(base_url('proctor'));
    }

    public function show_profile()
    {
        $this->redirect_if_not_active();
        $proctor = $_SESSION['isProctor'];
        $this->load->model('sertifikasi_model');
        $sertifikasi = $this->sertifikasi_model->get_sertifikasi();
        $sertifikasi_proctor = [];
        foreach($proctor['sertifikasi'] as $p)
        {
            $sertifikasi_proctor[] = (int)$p['id'];
        }
        foreach($sertifikasi as $k_s => $s)
        {
            if (!in_array((int)$s['id'], $sertifikasi_proctor))
                unset($sertifikasi[$k_s]);
        }
        $data = [
            'proctor' => $proctor,
            'sertifikasi' => $sertifikasi
        ];
        $this->load->view('proctor/profile', ['data' => html_escape($data)]);
    }

    public function update_profile()
    {
        $this->redirect_if_not_active();
        $id = $_SESSION['isProctor']['id'];
        $nama = $this->input->post('nama');
        $no_telepon = $this->input->post('no_telepon');
        if (!is_string($nama) || trim($nama) === '')
        {
            set_warning('Nama proctor tidak valid.');
            redirect(base_url('proctor'));
        }
        if (!ctype_digit($no_telepon))
        {
            set_warning('Nomor telepon hanya terdiri dari angka saja.');
            redirect(base_url('proctor'));
        }
        $file_foto = NULL;
        if (isset($_FILES['file_foto']) && trim($_FILES['file_foto']['name']) !== '')
        {
            $this->load->library('upload', config_item('UPLOAD_PROFIL_PROCTOR'));
            if($this->upload->do_upload('file_foto'))
            {
                $file_foto = $this->upload->data('file_name');
            }
            else
            {
                set_warning('Gagal mengupload foto profil.');
            }
        }
        $this->load->model('proctor_model');
        $columns = [];
        $columns['nama_lengkap'] = $nama;
        $columns['no_telepon'] = $no_telepon;
        if (!empty($file_foto)) $columns['file_foto'] = $file_foto;
        if ($this->proctor_model->update_proctor($id, $columns) === FALSE)
        {
            if (!empty($file_foto)) unlink(config_item('UPLOAD_PROFIL_PROCTOR')['upload_path'].$file_foto);
            set_warning('Gagal mengupdate data profil proctor yang baru.');
            redirect(base_url('proctor'));
        }
        // hapus profil trainer yang lama
        if (!empty($file_foto) && $_SESSION['isProctor']['file_foto'] !== 'default.jpg')
            unlink(config_item('UPLOAD_PROFIL_PROCTOR')['upload_path'].$_SESSION['isProctor']['file_foto']);
        redirect(base_url('proctor/profile'));
    }

	/**
	 * filter kegiatan yang sertifikasi sesuai dengan proctor
	 * @param D_Kegiatan[] $array_kegiatan
	 * @return D_Kegiatan[]
	 * */
	private function filter_kegiatan_sesuai_sertifikasi_proctor(array $array_kegiatan, D_Proctor $proctor): array
	{
		$proctor->load_list_sertifikasi();
		$id_sertifikasi = [];
		foreach($proctor->list_sertifikasi as $s)
		{
			$id_sertifikasi[] = (int)$s->id;
		}

		// cek apakah program kegiatan masuk di trainer
		foreach($array_kegiatan as $k_keg => $keg)
		{
			if (!in_array((int)$keg->id_sertifikasi, $id_sertifikasi))
				unset($array_kegiatan[$k_keg]);
		}
		return $array_kegiatan;
	}

	/**
	 * filter kegiatan apakah proctor berpartisipasi atau tidak
	 * (sebagai proctor training atau ujian)
	 * @param D_Kegiatan[] $array_kegiatan
	 * @return D_Kegiatan[]
	 * */
	private function filter_kegiatan_diikuti_proctor(array $array_kegiatan, D_Proctor $proctor): array
	{
		$id_proctor = (int)$proctor->id;
		foreach ($array_kegiatan as $k_k => $k)
		{
			$k->load_kelompok_training();
			$proctor_training_kelompok = array_filter($k->list_kelompok_training, function($kelompok_t) use ($id_proctor){
				return (int)$kelompok_t->id_proctor_training === $id_proctor;
			});

			$k->load_kelompok_ujian();
			$proctor_ujian_kelompok = array_filter($k->list_kelompok_ujian, function($kelompok_u) use ($id_proctor){
				return (int)$kelompok_u->id_proctor_ujian === $id_proctor;
			});


			if (empty($proctor_training_kelompok) && empty($proctor_ujian_kelompok))
				unset($array_kegiatan[$k_k]);
		}
		return $array_kegiatan;
	}

	public function show_dashboard()
	{
        $this->redirect_if_not_active();
		load_data_class('Proctor');
		$me = new D_Proctor($_SESSION['isProctor']['id']);

		$this->load->model('m_kegiatan');
		$list_kegiatan_akan_dilaksanakan = $this->filter_kegiatan_sesuai_sertifikasi_proctor(
			$this->m_kegiatan->get_kegiatan_before_pelaksanaan(),
			$me
		);
		foreach ($list_kegiatan_akan_dilaksanakan as $kegiatan)
		{
			$kegiatan->load_sertifikasi();
			$kegiatan->load_list_program();
			$kegiatan->load_kelompok_training();
			$kegiatan->load_kelompok_ujian();
		}

		$list_kegiatan_sedang_dilaksanakan = $this->filter_kegiatan_diikuti_proctor(
			$this->m_kegiatan->get_kegiatan_in_pelaksanaan(),
			$me
		);
		foreach ($list_kegiatan_sedang_dilaksanakan as $kegiatan)
		{
			$kegiatan->load_sertifikasi();
			$kegiatan->load_list_program();
			$kegiatan->load_kelompok_training();
			$kegiatan->load_kelompok_ujian();
		}

		$data = [
			'list_kegiatan_akan_dilaksanakan' => $list_kegiatan_akan_dilaksanakan,
			'list_kegiatan_sedang_dilaksanakan' => $list_kegiatan_sedang_dilaksanakan
		];

		$min_hari_proctor_training = config_item('max_day_isi_kesediaan_trainer');
		set_warning(sprintf(
			"Maksimal pengisian kesediaan proctor training adalah %s hari sebelum training pertama.",
			$min_hari_proctor_training
		));

		$min_hari_proctor_ujian = config_item('max_day_isi_kesediaan_proctor');
		set_warning(sprintf(
			"Maksimal pengisian kesediaan proctor ujian adalah %s hari sebelum ujian pertama.",
			$min_hari_proctor_ujian
		));
		$this->load->view('proctor/dashboard', ['data' => $data]);
	}

	public function show_kesediaan($id_kegiatan)
    {
        $this->redirect_if_not_active();
		$callback = base_url('proctor');
		load_data_class('Proctor');
		$me = new D_Proctor($_SESSION['isProctor']['id']);

		$this->load->model('m_kegiatan');
		if ($this->m_kegiatan->is_id_kegiatan_exists($id_kegiatan) === FALSE)
		{
			set_warning('Kegiatan sertifikasi tidak dapat ditemukan.');
			redirect($callback);
		}
		load_data_class('Kegiatan');
		$kegiatan = new D_Kegiatan($id_kegiatan);

		if (empty($this->filter_kegiatan_sesuai_sertifikasi_proctor([$kegiatan], $me)))
		{
			set_warning('Kegiatan sertifikasi tidak sesuai dengan sertifikasi Anda.');
			redirect($callback);
		}

		$kegiatan->load_kelompok_training();
		$kegiatan->load_kelompok_ujian();

		$min_hari_pengisian_proctor_training = config_item('max_day_isi_kesediaan_trainer');
		$min_tgl_training = DateTime::createFromFormat('Y-m-d', "2099-12-31");
		foreach($kegiatan->list_kelompok_training as $k){
			$min_tgl_training = min(
				$min_tgl_training,
				clone $k->mulai_training
			);
		}
		$jarak_proctor_training = new DateInterval('P'.(string)$min_hari_pengisian_proctor_training.'D');
		$min_tgl_training->sub($jarak_proctor_training)->setTime(18,0,0);
		$sekarang = new DateTime();
		if ($sekarang >= $min_tgl_training)
		{
			set_warning(sprintf(
				'Kesediaan proctor training sudah tidak dapat diisi. Batas pengisian adalah %s hari sebelum training pertama, yaitu  %s %s WIB.',
				$min_hari_pengisian_proctor_training,
				tgl_indo($min_tgl_training->format('Y-m-d'), 'Y-m-d'),
				$min_tgl_training->format('H:i:s')
			));
		}

		$min_hari_pengisian_proctor_ujian = config_item('max_day_isi_kesediaan_proctor');
		$min_tgl_ujian = DateTime::createFromFormat('Y-m-d', "2099-12-31");
		foreach($kegiatan->list_kelompok_ujian as $k){
			$min_tgl_ujian = min(
				$min_tgl_ujian,
				clone $k->mulai_ujian
			);
		}
		$jarak_proctor_ujian = new DateInterval('P'.(string)$min_hari_pengisian_proctor_ujian.'D');
		$min_tgl_ujian->sub($jarak_proctor_ujian)->setTime(18,0,0);
		if ($sekarang >= $min_tgl_ujian)
		{
			set_warning(sprintf(
				'Kesediaan proctor ujian sudah tidak dapat diisi. Batas pengisian adalah %s hari sebelum training pertama, yaitu  %s %s WIB.',
				$min_hari_pengisian_proctor_ujian,
				tgl_indo($min_tgl_ujian->format('Y-m-d'), 'Y-m-d'),
				$min_tgl_ujian->format('H:i:s')
			));
		}

		if ($sekarang >= $min_tgl_training && $sekarang >= $min_tgl_ujian)
		{
			redirect($callback);
		}

		foreach ($kegiatan->list_kelompok_training as $kelompok)
		{
			$kelompok->load_kesediaan_proctor_training();
		}
		foreach ($kegiatan->list_kelompok_ujian as $kelompok)
		{
			$kelompok->load_kesediaan_proctor_ujian();
		}

        $data = [
            'kegiatan' => $kegiatan,
			'me' => $me,
            'batas_proctor_training' => $min_tgl_training,
			'jarak_proctor_training' => $jarak_proctor_training,
			'batas_proctor_ujian' => $min_tgl_ujian,
			'jarak_proctor_ujian' => $jarak_proctor_ujian
        ];
		set_warning(sprintf(
			"Maksimal pengisian kesediaan proctor training adalah %s hari sebelum training pertama.",
			$min_hari_pengisian_proctor_training
		));
		set_warning(sprintf(
			"Maksimal pengisian kesediaan proctor ujian adalah %s hari sebelum ujian pertama.",
			$min_hari_pengisian_proctor_ujian
		));
        $this->load->view('proctor/kesediaan', ['data' => $data]);
    }

    public function update_kesediaan_t($id_kegiatan)
    {
        $this->redirect_if_not_logged_in();
		load_data_class('Proctor');
		$me = new D_Proctor($_SESSION['isProctor']['id']);

		$this->load->model('m_kegiatan');
        if ($this->m_kegiatan->is_id_kegiatan_exists($id_kegiatan) === FALSE)
        {
            set_warning('Kegiatan sertifikasi tidak dapat ditemukan.');
            redirect(base_url('proctor'));
        }
        load_data_class('Kegiatan');
        $kegiatan = new D_Kegiatan($id_kegiatan);
        $kegiatan_sesuai_sertifikasi = $this->filter_kegiatan_sesuai_sertifikasi_proctor([$kegiatan], $me);

		if (empty($kegiatan_sesuai_sertifikasi))
		{
			set_warning('Kegiatan sertifikasi tidak sesuai dengan sertifikasi Anda.');
			redirect(base_url('proctor'));
		}
		unset($kegiatan_sesuai_sertifikasi);

		$kegiatan->load_kelompok_training();

		if (empty($kegiatan->list_kelompok_training))
		{
			set_warning('Tidak ditemukan kelompok training di kegiatan ini.');
			redirect(base_url('proctor'));
		}

		$min_hari_pengisian_proctor_training = config_item('max_day_isi_kesediaan_trainer');
		$min_tgl_training = DateTime::createFromFormat('Y-m-d', "2099-12-31");
		foreach($kegiatan->list_kelompok_training as $k){
			$min_tgl_training = min(
				$min_tgl_training,
				clone $k->mulai_training
			);
		}
		$jarak_proctor_training = new DateInterval('P'.(string)$min_hari_pengisian_proctor_training.'D');
		$min_tgl_training->sub($jarak_proctor_training)->setTime(18,0,0);
		$sekarang = new DateTime();
		if ($sekarang >= $min_tgl_training)
		{
			set_warning(sprintf(
				'Kesediaan proctor training sudah tidak dapat diisi. Batas pengisian adalah %s hari sebelum training pertama, yaitu  %s %s WIB.',
				$min_hari_pengisian_proctor_training,
				tgl_indo($min_tgl_training->format('Y-m-d'), 'Y-m-d'),
				$min_tgl_training->format('H:i:s')
			));
		}

        $list_kesediaan_t = $this->input->post('bersedia_t');
        if ($list_kesediaan_t !== 'null' && !is_array($list_kesediaan_t))
        {
            set_warning('Input kelompok anda tidak dapat diproses.');
            redirect(base_url('proctor'));
        }
        if ($list_kesediaan_t === 'null') $list_kesediaan_t = [];

        foreach($list_kesediaan_t as $k_l => $l)
        {
            if (!ctype_digit($l)) break;
            $exists = array_filter(
            	$kegiatan->list_kelompok_training,
				function ($kelompok) use ($l){
            		return (int)$l === (int)$kelompok->id;
				}
			);
            if (empty($exists)) unset($list_kesediaan_t[$k_l]);
        }

		$this->load->model('m_proctor');
        if ($this->m_proctor->update_kesediaan_proctor_training($me, $list_kesediaan_t) === FALSE)
        {
            set_warning('Terjadi kesalahan dalam memproses data kesediaan anda.');
            redirect(base_url('proctor'));
        }
        set_warning('Sukses mengupdate data kesediaan proctor training.');
        redirect(base_url('proctor/kesediaan/'.$id_kegiatan));
    }

	public function update_kesediaan_u($id_kegiatan)
	{
		$this->redirect_if_not_logged_in();
		load_data_class('Proctor');
		$me = new D_Proctor($_SESSION['isProctor']['id']);

		$this->load->model('m_kegiatan');
		if ($this->m_kegiatan->is_id_kegiatan_exists($id_kegiatan) === FALSE)
		{
			set_warning('Kegiatan sertifikasi tidak dapat ditemukan.');
			redirect(base_url('proctor'));
		}
		load_data_class('Kegiatan');
		$kegiatan = new D_Kegiatan($id_kegiatan);
		$kegiatan_sesuai_sertifikasi = $this->filter_kegiatan_sesuai_sertifikasi_proctor([$kegiatan], $me);

		if (empty($kegiatan_sesuai_sertifikasi))
		{
			set_warning('Kegiatan sertifikasi tidak sesuai dengan sertifikasi Anda.');
			redirect(base_url('proctor'));
		}
		unset($kegiatan_sesuai_sertifikasi);

		$kegiatan->load_kelompok_ujian();

		if (empty($kegiatan->list_kelompok_ujian))
		{
			set_warning('Tidak ditemukan kelompok ujian di kegiatan ini.');
			redirect(base_url('proctor'));
		}

		$min_hari_pengisian_proctor_ujian = config_item('max_day_isi_kesediaan_proctor');
		$min_tgl_ujian = DateTime::createFromFormat('Y-m-d', "2099-12-31");
		foreach($kegiatan->list_kelompok_ujian as $k){
			$min_tgl_ujian = min(
				$min_tgl_ujian,
				clone $k->mulai_ujian
			);
		}
		$jarak_proctor_ujian = new DateInterval('P'.(string)$min_hari_pengisian_proctor_ujian.'D');
		$min_tgl_ujian->sub($jarak_proctor_ujian)->setTime(18,0,0);
		$sekarang = new DateTime();
		if ($sekarang >= $min_tgl_ujian)
		{
			set_warning(sprintf(
				'Kesediaan proctor ujian sudah tidak dapat diisi. Batas pengisian adalah %s hari sebelum ujian pertama, yaitu  %s %s WIB.',
				$min_hari_pengisian_proctor_ujian,
				tgl_indo($min_tgl_ujian->format('Y-m-d'), 'Y-m-d'),
				$min_tgl_ujian->format('H:i:s')
			));
		}

		$list_kesediaan_u = $this->input->post('bersedia_u');
		if ($list_kesediaan_u !== 'null' && !is_array($list_kesediaan_u))
		{
			set_warning('Input kelompok anda tidak dapat diproses.');
			redirect(base_url('proctor'));
		}
		if ($list_kesediaan_u === 'null') $list_kesediaan_u = [];

		foreach($list_kesediaan_u as $k_l => $l)
		{
			if (!ctype_digit($l)) break;
			$exists = array_filter(
				$kegiatan->list_kelompok_ujian,
				function ($kelompok) use ($l){
					return (int)$l === (int)$kelompok->id;
				}
			);
			if (empty($exists)) unset($list_kesediaan_u[$k_l]);
		}

		$this->load->model('m_proctor');
		if ($this->m_proctor->update_kesediaan_proctor_ujian($me, $list_kesediaan_u) === FALSE)
		{
			set_warning('Terjadi kesalahan dalam memproses data kesediaan anda.');
			redirect(base_url('proctor'));
		}
        set_warning('Sukses mengupdate data kesediaan proctor ujian.');
		redirect(base_url('proctor/kesediaan/'.$id_kegiatan));
	}

    public function show_kelompok()
    {
        $this->redirect_if_not_active();
		load_data_class('Proctor');
		$me = new D_Proctor($_SESSION['isProctor']['id']);

		$this->load->model('m_kegiatan');
		$list_kegiatan_akan_dilaksanakan = $this->filter_kegiatan_diikuti_proctor(
			$this->m_kegiatan->get_kegiatan_before_pelaksanaan(),
			$me
		);
		$list_kegiatan_sedang_dilaksanakan = $this->filter_kegiatan_diikuti_proctor(
			$this->m_kegiatan->get_kegiatan_in_pelaksanaan(),
			$me
		);

		/** @var D_Kegiatan[] $list_kegiatan */
		$list_kegiatan = [];
		foreach($list_kegiatan_akan_dilaksanakan as $kegiatan)
		{
			$list_kegiatan[] = $kegiatan;
		}
		foreach($list_kegiatan_sedang_dilaksanakan as $kegiatan)
		{
			$list_kegiatan[] = $kegiatan;
		}

		$id_kegiatan = $this->input->get('id_kegiatan');
		$selected_kegiatan = NULL;
		if (ctype_digit($id_kegiatan))
		{
			$selected_kegiatan = array_filter($list_kegiatan, function ($keg) use ($id_kegiatan){
				return (int)$keg->id === (int)$id_kegiatan;
			});
			/** @var D_Kegiatan $selected_kegiatan */
			if (!empty($selected_kegiatan)) $selected_kegiatan = reset($selected_kegiatan);
		}
		if (!empty($selected_kegiatan))
		{
			$selected_kegiatan->load_kelompok_training();
			$selected_kegiatan->load_kelompok_ujian();
		}

        $data = [
            'list_kegiatan' => $list_kegiatan,
            'selected_kegiatan' => $selected_kegiatan,
			'me' => $me
        ];
        $this->load->view('proctor/kelompok', ['data' => $data]);
    }

	public function show_absensi_training($id_kelompok)
	{
		$this->redirect_if_not_active();
		load_data_class('Proctor');
		$me = new D_Proctor($_SESSION['isProctor']['id']);

		$this->load->model('m_kelompok_t');
		if ($this->m_kelompok_t->is_id_exists($id_kelompok) === FALSE)
		{
			set_warning('Kelompok tidak ditemukan.');
			redirect(base_url('proctor/kelompok'));
		}
		load_data_class('Kelompok_T');
		$kelompok = new D_Kelompok_T($id_kelompok);
		if ((int)$kelompok->id_proctor_training !== (int)$me->id)
		{
			set_warning('Anda tidak termasuk proctor training di kelompok ini.');
			redirect(base_url('proctor/kelompok'));
		}
		$kelompok->load_list_peserta();
		load_data_class('Kegiatan');
		$kegiatan = new D_Kegiatan($kelompok->id_kegiatan);
		$data = [
			'me' => $me,
			'kegiatan' => $kegiatan,
			'kelompok' => $kelompok
		];
		$this->load->view('proctor/absensi_t', ['data' => $data]);
    }

	public function update_absensi_training($id_kelompok)
	{
		$this->redirect_if_not_active();
		load_data_class('Proctor');
		$me = new D_Proctor($_SESSION['isProctor']['id']);

		$this->load->model('m_kelompok_t');
		if ($this->m_kelompok_t->is_id_exists($id_kelompok) === FALSE)
		{
			set_warning('Kelompok tidak ditemukan.');
			redirect(base_url('proctor/kelompok'));
		}
		load_data_class('Kelompok_T');
		$kelompok = new D_Kelompok_T($id_kelompok);

		if ( empty($kelompok->id_proctor_training) || (int)$kelompok->id_proctor_training !== (int)$me->id)
		{
			set_warning('Anda tidak termasuk proctor training di kelompok ini.');
			redirect(base_url('proctor/kelompok'));
		}

		$sekarang = new DateTime();
		$terakhir_absensi_t = clone $kelompok->selesai_training;
		$max_jam_absensi = config_item('toleransi_absensi_training');
		$jarak_absen_setelah_training = new DateInterval('PT'.$max_jam_absensi.'H');
		$terakhir_absensi_t->add($jarak_absen_setelah_training);
		if ($sekarang < $kelompok->mulai_training)
		{
			set_warning('Data absensi training tidak dapat diupdate, karena training belum dimulai.');
			redirect(base_url('proctor/kelompok'));
		}
		if ($sekarang > $terakhir_absensi_t)
		{
			set_warning('Data absensi training tidak dapat diupdate, karena sudah melewati waktu training.');
			redirect(base_url('proctor/kelompok'));
		}
		$kelompok->beritaacara_t_sesi1 = $this->input->post('beritaacara_t_sesi1');
		$kelompok->beritaacara_t_sesi2 = $this->input->post('beritaacara_t_sesi2');
		$a = $this->m_kelompok_t->update_kelompok($kelompok);

		redirect(base_url('proctor/kelompok_t/absensi/'.$id_kelompok));
	}

    public function show_absensi($id_kelompok)
    {
        $this->redirect_if_not_active();
		load_data_class('Proctor');
		$me = new D_Proctor($_SESSION['isProctor']['id']);
		$this->load->model('m_kelompok_u');
		if ($this->m_kelompok_u->is_id_exists($id_kelompok) === FALSE)
        {
            set_warning('Kelompok tidak ditemukan.');
            redirect(base_url('proctor/kelompok'));
        }
        load_data_class('Kelompok_U');
		$kelompok = new D_Kelompok_U($id_kelompok);

		if (empty($kelompok->id_proctor_ujian) || (int)$kelompok->id_proctor_ujian !== (int)$me->id)
        {
            set_warning('Anda tidak termasuk proctor ujian di kelompok ini.');
            redirect(base_url('proctor/kelompok'));
        }
		$kelompok->load_list_peserta();
		load_data_class('Kegiatan');
		$kegiatan = new D_Kegiatan($kelompok->id_kegiatan);
        $data = [
            'me' => $me,
            'kegiatan' => $kegiatan,
            'kelompok' => $kelompok
        ];
        $this->load->view('proctor/absensi', ['data' => $data]);
    }

    public function update_absensi($id_kelompok)
    {
        $this->redirect_if_not_active();

		load_data_class('Proctor');
		$me = new D_Proctor($_SESSION['isProctor']['id']);
		$this->load->model('m_kelompok_u');
		if ($this->m_kelompok_u->is_id_exists($id_kelompok) === FALSE)
		{
			set_warning('Kelompok tidak ditemukan.');
			redirect(base_url('proctor/kelompok'));
		}
		load_data_class('Kelompok_U');
		$kelompok = new D_Kelompok_U($id_kelompok);

		if (empty($kelompok->id_proctor_ujian) || (int)$kelompok->id_proctor_ujian !== (int)$me->id)
		{
			set_warning('Anda tidak termasuk proctor ujian di kelompok ini.');
			redirect(base_url('proctor/kelompok'));
		}

        // cek apakah proctor masih bisa update absensi
        $sekarang = new DateTime();
        $terakhir_absensi = clone $kelompok->selesai_ujian;
        $jarak_absen_setelah_training = new DateInterval('PT'.config_item('toleransi_absensi_ujian').'H'); // 1 jam
        $terakhir_absensi->add($jarak_absen_setelah_training);
        if ($sekarang < $kelompok->mulai_ujian)
        {
            set_warning('Absensi ujian tidak dapat diupdate karena belum mulai ujian.');
            redirect(base_url('proctor/kelompok'));
        }
		if ($sekarang > $terakhir_absensi)
		{
			set_warning('Absensi ujian tidak dapat diupdate karena sudah melewati batas.');
			redirect(base_url('proctor/kelompok'));
		}

		$kelompok->load_list_peserta();

		$id = [];
		$id_hadir_ujian = $this->input->post('ujian');
		if (!empty($id_hadir_ujian) && is_array($id_hadir_ujian))
		{
			foreach($id_hadir_ujian as $id_ujian)
			{
				if (ctype_digit($id_ujian))
					$id[] = (int)$id_ujian;
			}
		}
		$array_absensi = [];
		foreach($kelompok->list_peserta as $p)
		{
			$array_absensi[] = [
				$p->id,
				in_array((int)$p->id, $id)
			];
		}
		$kelompok->beritaacara_ujian = $this->input->post('beritaacara_ujian');
        $a = $this->m_kelompok_u->update_absensi($array_absensi);
        $a = $this->m_kelompok_u->update_kelompok($kelompok);
        redirect(base_url('proctor/kelompok_u/absensi/'.$id_kelompok));
    }

	public function show_history()
	{
		$this->redirect_if_not_active();
		load_data_class('Proctor');
		$me = new D_Proctor($_SESSION['isProctor']['id']);
		$this->load->model('m_proctor');
		$list_kegiatan = $this->m_proctor->get_list_kegiatan_history_proctor($me);
		foreach($list_kegiatan as $kegiatan)
		{
			$kegiatan->load_sertifikasi();
			$kegiatan->load_kelompok_training();
			$kegiatan->load_kelompok_ujian();
			$kegiatan->load_list_peserta();
		}

		$data = [];
		$data['list_kegiatan'] = $list_kegiatan;
		$data['me'] = $me;
		$this->load->view('proctor/history', ['data' => $data]);
	}

	public function show_detail_history($id_kegiatan)
	{
		$this->redirect_if_not_active();
		load_data_class('Proctor');
		$me = new D_Proctor($_SESSION['isProctor']['id']);
		$this->load->model('m_proctor');
		$list_kegiatan = $this->m_proctor->get_list_kegiatan_history_proctor($me);
		$selected_kegiatan = array_filter($list_kegiatan, function ($keg) use ($id_kegiatan){
			return (int)$keg->id === (int)$id_kegiatan;
		});
		if (empty($selected_kegiatan))
		{
			set_warning('Kegiatan tidak ditemukan.');
			redirect(base_url('proctor/history'));
		}
		/** @var D_Kegiatan $selected_kegiatan */
		$selected_kegiatan = reset($selected_kegiatan);
		$selected_kegiatan->load_list_program();
		$selected_kegiatan->load_kelompok_training();
		$selected_kegiatan->load_kelompok_ujian();

		$sebagai_proctor_training = FALSE;
		foreach ($selected_kegiatan->list_kelompok_training as $kelompok) {
			if ((int)$kelompok->id_proctor_training === (int)$me->id)
			{
				$sebagai_proctor_training = TRUE;
				$kelompok->load_list_peserta();
			}
		}

		$sebagai_proctor_ujian = FALSE;
		foreach ($selected_kegiatan->list_kelompok_ujian as $kelompok) {
			if ((int)$kelompok->id_proctor_ujian === (int)$me->id)
			{
				$sebagai_proctor_ujian = TRUE;
				$kelompok->load_list_peserta();
			}
		}

		$data = [
			'selected_kegiatan' => $selected_kegiatan,
			'me' => $me,
			'sebagai_proctor_training' => $sebagai_proctor_training,
			'sebagai_proctor_ujian' => $sebagai_proctor_ujian
		];
		$this->load->view('proctor/detail_history', ['data' => $data]);
	}
}

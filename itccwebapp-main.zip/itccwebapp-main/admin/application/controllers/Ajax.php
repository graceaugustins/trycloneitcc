<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @property M_trainer $m_trainer
 * @property M_sertifikasi $m_sertifikasi
 * @property M_program $m_program
 * @property M_proctor $m_proctor
 * @property M_kegiatan $m_kegiatan
 * @property M_kelompok_t $m_kelompok_t
 * @property M_kelompok_u $m_kelompok_u
 * @property M_user $m_user
 * @property CI_Input $input
 * @property System_functions $system_functions
 */
class Ajax extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        
        $this->load->helper('admin_helper');
    }

    private function block_if_not_logged_in($type): bool
    {
        $valid = FALSE;
        foreach($type as $t)
        {
            if ($t === 'admin' && isset($_SESSION['admin'])) $valid = TRUE;
            if ($t === 'trainer' && isset($_SESSION['isTrainer'])) $valid = TRUE;
            if ($t === 'proctor' && isset($_SESSION['isProctor'])) $valid = TRUE;
        }
        if (!$valid)
        {
            $this->reply('fail', 'ERR_NOT_PERMITTED');
            return TRUE;
        }
        return FALSE;
    }

    // $this->reply('ok', 'SUCCESS', ['data'=>123])
    // $this->reply('fail', 'ERR_NOT_PERMITTED', ['data'=>123]
    private function reply($status, $message, $data = [])
    {
    	$this->output->set_content_type('application/json')
	        ->set_output(json_encode(html_escape([
    			'status' => strtolower((string)$status),
    			'message' => strtoupper((string)$message),
    			'data' => $data
    		])));
    }

	private function reply_success($data = [])
	{
		$this->reply('ok', 'SUCCESS', $data);
	}

	private function reply_not_permitted()
	{
		$this->reply('fail', 'ERR_NOT_PERMITTED');
	}

	private function reply_bad_parameter()
	{
		$this->reply('fail', 'ERR_BAD_PARAMETER');
	}

	private function reply_fail_to_process($reasons = [])
	{
		$this->reply('fail', 'ERR_FAILED_TO_PROCESS', $reasons);
	}

    public function get_sertifikasi()
    {
    	if ($this->block_if_not_logged_in(['admin'])) return;

        $this->load->model('sertifikasi_model');
    	$this->reply('ok', 'SUCCESS', $this->sertifikasi_model->get_sertifikasi());
    }

    public function set_bukti_bayar()
    {
        if ($this->block_if_not_logged_in(['admin'])) return;
        if (!admin_capable(Permissions::EDIT_KEGIATAN_SERTIFIKASI))
        {
            $this->reply_not_permitted(); return;
        }
        $id = $this->input->post('id');
        $value =$this->input->post('value');
        if (!ctype_digit($id) || !in_array($value, ['pending','reject', 'accept']))
        {
            $this->reply_bad_parameter(); return;
        }
        $this->load->model('m_kegiatan');
        if ($this->m_kegiatan->set_approve_bukti_bayar($id, $value) === FALSE)
        {
            $this->reply_fail_to_process(); return;
        }
        $this->reply_success();
    }

    public function approve_registrasi()
    {
        if ($this->block_if_not_logged_in(['admin'])) return;
        if (!admin_capable(Permissions::EDIT_KEGIATAN_SERTIFIKASI))
        {
            $this->reply_not_permitted(); return;
        }
        $id = $this->input->post('id');
        $value =$this->input->post('value');
        if (!ctype_digit($id) || !in_array($value, ['true','false']))
        {
            $this->reply_bad_parameter(); return;
        }
        $value = ($value === 'true');
        $this->load->model('m_kegiatan');
        if ($this->m_kegiatan->set_approve_registrasi($id, $value) === FALSE)
        {
            $this->reply_fail_to_process(); return;
        }
        if ($value)
        {
            load_data_class('Kegiatan');
            $pendaftaran = new D_Pendaftaran_Kegiatan($id);
            if (empty($pendaftaran->id))
            {
                $this->reply_fail_to_process(['ID not found in db']);
                return;
            }
            $pendaftaran->kegiatan = new D_Kegiatan($pendaftaran->id_kegiatan);
            $this->load->library('system_functions');
            try {
                $this->system_functions->send_email(
                    'email/done_approve_registrasi',
                    $pendaftaran->email_user,
                    'Registrasi diapprove: '. $pendaftaran->kegiatan->nama_kegiatan,
                    [
                        'nama_kegiatan' => $pendaftaran->kegiatan->nama_kegiatan,
                        'link_grup' => $pendaftaran->kegiatan->link_grup,
                        'link' => base_url('sertifikasi/ongoing')
                    ]
                );
            } catch (Exception $e){
                $this->reply_fail_to_process([$e]); return;
            }
        }
        $this->reply_success();
    }

    public function get_data_mhs()
    {
        if ($this->block_if_not_logged_in(['admin'])) return;
        $first_id = $this->input->post('first_id');
        $last_id = $this->input->post('last_id');
        $count = $this->input->post('count');
        $direction = $this->input->post('direction');

        $angkatan = $this->input->post('angkatan');
		$fakultas = $this->input->post('fakultas');
        $jurusan = $this->input->post('jurusan');
        $nim = $this->input->post('nim');
        $email = $this->input->post('email');
        $nama_depan = $this->input->post('nama_depan');
        $nama_belakang = $this->input->post('nama_belakang');
        $aktif = $this->input->post('aktif');

        $param = [];
        if (!ctype_digit($count) || !in_array((int)$count, [10,25,50,100])) $count = 50;
        if (!ctype_digit($first_id)) $first_id = 0;
        if (!ctype_digit($last_id)) $last_id = 0;
        if (!in_array($direction, ['next', 'previous']))
            $direction = 'next';

        if (ctype_digit($angkatan) && strlen($angkatan) === 4)
        {
            $param['angkatan'] = $angkatan;
        }
		if ($fakultas !== 'all' && in_array($fakultas, array_keys(config_item('FAKULTAS'))))
		{
			$param['jurusan'] = config_item('FAKULTAS')[$fakultas];
		}
        if ($jurusan !== 'all' && in_array($jurusan, array_keys(config_item('JURUSAN'))))
        {
            $param['jurusan'] = [$jurusan];
        }
        if (ctype_digit($nim) && strlen($nim) <=9)
        {
            $param['nim'] = $nim;
        }
        if (trim($email) !== '')
        {
            $param['email'] = $email;
        }
        if (trim($nama_depan) !== '')
        {
            $param['nama_depan'] = $nama_depan;
        }
        if (trim($nama_belakang) !== '')
        {
            $param['nama_belakang'] = $nama_belakang;
        }
        if (in_array($aktif, ['true', 'false']))
        {
            $param['aktif'] = ($aktif === 'true') ? 'y' : 'n';
        }
        $this->load->model('users_model');
        $data = $this->users_model->get_user_mhs($first_id, $last_id, $count, $direction, $param);
        foreach($data['data'] as $key=>$val)
        {
            $data['data'][$key]['file_fotoprofil'] = base_url(config_item('UPLOAD_FOTO_PROFIL')['upload_path'].$val['file_fotoprofil']);
        }
        $this->reply_success($data);
    }

    public function get_data_umum()
    {
        if ($this->block_if_not_logged_in(['admin'])) return;
        $first_id = $this->input->post('first_id');
        $last_id = $this->input->post('last_id');
        $count = $this->input->post('count');
        $direction = $this->input->post('direction');

        $email = $this->input->post('email');
        $nama_depan = $this->input->post('nama_depan');
        $nama_belakang = $this->input->post('nama_belakang');
        $aktif = $this->input->post('aktif');

        $param = [];
        if (!ctype_digit($count) || !in_array((int)$count, [10,25,50,100])) $count = 50;
        if (!ctype_digit($first_id)) $first_id = 0;
        if (!ctype_digit($last_id)) $last_id = 0;
        if (!in_array($direction, ['next', 'previous']))
            $direction = 'next';

        if (trim($email) !== '')
        {
            $param['email'] = $email;
        }
        if (trim($nama_depan) !== '')
        {
            $param['nama_depan'] = $nama_depan;
        }
        if (trim($nama_belakang) !== '')
        {
            $param['nama_belakang'] = $nama_belakang;
        }
        if (in_array($aktif, ['true', 'false']))
        {
            $param['aktif'] = ($aktif === 'true') ? 'y' : 'n';
        }
        $this->load->model('users_model');
        $data = $this->users_model->get_user_umum($first_id, $last_id, $count, $direction, $param);
        foreach($data['data'] as $key=>$val)
        {
            $data['data'][$key]['file_fotoprofil'] = base_url(config_item('UPLOAD_FOTO_PROFIL')['upload_path'].$val['file_fotoprofil']);
        }
        $this->reply_success($data);
    }

	public function get_data_itpln()
	{
		if ($this->block_if_not_logged_in(['admin'])) return;
		$first_id = $this->input->post('first_id');
		$last_id = $this->input->post('last_id');
		$count = $this->input->post('count');
		$direction = $this->input->post('direction');

		$email = $this->input->post('email');
		$nama_depan = $this->input->post('nama_depan');
		$nama_belakang = $this->input->post('nama_belakang');
		$id_bidang = $this->input->post('id_bidang');
		$id_jabatan = $this->input->post('id_jabatan');
		$nik = $this->input->post('nik');
		$aktif = $this->input->post('aktif');

		$param = [];
		if (!ctype_digit($count) || !in_array((int)$count, [10,25,50,100])) $count = 50;
		if (!ctype_digit($first_id)) $first_id = 0;
		if (!ctype_digit($last_id)) $last_id = 0;
		if (!in_array($direction, ['next', 'previous']))
			$direction = 'next';

		if (trim($email) !== '')
		{
			$param['email'] = $email;
		}
		if (trim($nama_depan) !== '')
		{
			$param['nama_depan'] = $nama_depan;
		}
		if (trim($nama_belakang) !== '')
		{
			$param['nama_belakang'] = $nama_belakang;
		}
		if (in_array($aktif, ['true', 'false']))
		{
			$param['aktif'] = ($aktif === 'true') ? 'y' : 'n';
		}
		if (ctype_digit($id_jabatan))
			$param['id_jabatan'] = $id_jabatan;
		elseif (ctype_digit($id_bidang))
			$param['id_bidang'] = $id_bidang;

		if(ctype_digit($nik))
			$param['nik'] = $nik;

		$this->load->model('users_model');
		$data = $this->users_model->get_user_itpln($first_id, $last_id, $count, $direction, $param);
		foreach($data['data'] as $key=>$val)
		{
			$data['data'][$key]['file_fotoprofil'] = base_url(config_item('UPLOAD_FOTO_PROFIL')['upload_path'].$val['file_fotoprofil']);
		}
        $this->reply_success($data);
	}

	public function get_instansi()
	{
		// tidak ada cek tipe login, karena bisa diakses semuanya
		$this->load->model('users_model');
        $data = $this->users_model->get_instansi();
        $this->reply_success($data);
	}

    public function ubah_kelompok_peserta($tipe)
    {
        if ($this->block_if_not_logged_in(['admin'])) return;
        if (!admin_capable(Permissions::EDIT_KEGIATAN_SERTIFIKASI))
        {
            $this->reply('fail', 'ERR_NOT_PERMITTED');
            return;
        }
        $id = $this->input->post('id');
        $id_kelompok_new =$this->input->post('id_kelompok');
        if (!ctype_digit($id) || ($id_kelompok_new !== 'null' && !ctype_digit($id_kelompok_new)))
        {
            $this->reply('fail', 'ERR_BAD_PARAMETER');
            return;
        }

        $this->load->model('m_kegiatan');
		$this->load->model('m_user');
        if ($this->m_kegiatan->is_id_pendaftaran_exists($id) === FALSE)
		{
			$this->reply('fail', 'ERR_DATA_NOT_FOUND');
			return;
		}
        load_data_class('User');
        $pendaftaran = new D_Kegiatan_User($id);
        if ($tipe === 't')
		{
			// hanya ubah kalau berbeda
			if (
				(empty($pendaftaran->id_kelompok_t) && $id_kelompok_new !== 'null') ||
				(!empty($pendaftaran->id_kelompok_t) && $id_kelompok_new === 'null') ||
				(int)$pendaftaran->id_kelompok_t !== (int)$id_kelompok_new
			)
			{
				load_data_class('Kelompok_T');
				$this->load->model('m_kelompok_t');
				$pendaftaran_new = clone $pendaftaran;
				$pendaftaran->load_kelompok_t();
				if ($id_kelompok_new !== 'null')
				{
					if ($this->m_kelompok_t->is_id_exists($id_kelompok_new) === FALSE)
					{
						$this->reply('fail', 'NEW_KELOMPOK_NOT_FOUND');
						return;
					}
					$kelompok_new = new D_Kelompok_T($id_kelompok_new);
					if ((int)$kelompok_new->id_program !== (int)$pendaftaran->id_program)
					{
						$this->reply('fail', 'NEW_KELOMPOK_WRONG_PROGRAM');
						return;
					}
					if ($kelompok_new->jumlah_peserta+1 > $kelompok_new->max_peserta_training)
					{
						$this->reply('fail', 'NEW_KELOMPOK_CURRENTLY_FULL');
						return;
					}
					$pendaftaran_new->id_kelompok_t = $id_kelompok_new;
				}
				else
				{
					$pendaftaran_new->id_kelompok_t = NULL;
				}
				$pendaftaran_new->load_kelompok_t();
				if ($this->m_kegiatan->update_pendaftaran($pendaftaran_new) === FALSE)
				{
					$this->reply('fail', 'ERR_FAILED_UPDATE');
					return;
				}

				// alert ke user
				$this->load->model('users_model');
				$this->users_model->send_info(
					$pendaftaran->id_user,
					sprintf(
						"Kelompok training anda telah diubah admin, dari '%s' menjadi '%s'.",

						($pendaftaran->id_kelompok_t === NULL)? 'Belum memilih' : $pendaftaran->kelompok_t->nama_kelompok,
						($pendaftaran_new->id_kelompok_t === NULL)? 'Belum memilih' : $pendaftaran_new->kelompok_t->nama_kelompok
					)
				);
			}
		}
		elseif ($tipe === 'u')
		{
			// hanya ubah kalau berbeda
			if (
				(empty($pendaftaran->id_kelompok_u) && $id_kelompok_new !== 'null') ||
				(!empty($pendaftaran->id_kelompok_u) && $id_kelompok_new === 'null') ||
				(int)$pendaftaran->id_kelompok_u !== (int)$id_kelompok_new
			)
			{
				load_data_class('Kelompok_U');
				$this->load->model('m_kelompok_u');
				$pendaftaran_new = clone $pendaftaran;
				$pendaftaran->load_kelompok_u();
				if ($id_kelompok_new !== 'null')
				{
					if ($this->m_kelompok_u->is_id_exists($id_kelompok_new) === FALSE)
					{
						$this->reply('fail', 'NEW_KELOMPOK_NOT_FOUND');
						return;
					}
					$kelompok_new = new D_Kelompok_U($id_kelompok_new);
					if ((int)$kelompok_new->id_program !== (int)$pendaftaran->id_program)
					{
						$this->reply('fail', 'NEW_KELOMPOK_WRONG_PROGRAM');
						return;
					}
					if ($kelompok_new->jumlah_peserta+1 > $kelompok_new->max_peserta_ujian)
					{
						$this->reply('fail', 'NEW_KELOMPOK_IS_FULL');
						return;
					}
					$pendaftaran_new->id_kelompok_u = $id_kelompok_new;
				}
				else
				{
					$pendaftaran_new->id_kelompok_u = NULL;
				}
				$pendaftaran_new->load_kelompok_u();
				if ($this->m_kegiatan->update_pendaftaran($pendaftaran_new) === FALSE)
				{
					$this->reply('fail', 'ERR_FAILED_UPDATE');
					return;
				}

				// alert ke user
				$this->load->model('users_model');
				$this->users_model->send_info(
					$pendaftaran->id_user,
					sprintf(
						"Kelompok ujian anda telah diubah admin, dari '%s' menjadi '%s'.",

						($pendaftaran->id_kelompok_u === NULL)? 'Belum memilih' : $pendaftaran->kelompok_u->nama_kelompok,
						($pendaftaran_new->id_kelompok_u === NULL)? 'Belum memilih' : $pendaftaran_new->kelompok_u->nama_kelompok
					)
				);
			}
		}
        $this->reply_success();
    }

	public function get_statistik_sertifikasi_trainer()
	{
		if ($this->block_if_not_logged_in(['trainer'])) return;
		$this->load->model('trainer_model');
		$statistik_lulus = $this->trainer_model->get_jumlah_peserta_lulus($_SESSION['isTrainer'], 'sertifikasi');
		$statistik_tidaklulus = $this->trainer_model->get_jumlah_peserta_tidaklulus($_SESSION['isTrainer'], 'sertifikasi');
		$statistik_pending = $this->trainer_model->get_jumlah_peserta_pending($_SESSION['isTrainer'], 'sertifikasi');
		$result = $statistik_lulus;
		foreach($result as $k_result => $r)
		{
			$id = (int)$r['id'];
			// satukan data tidak lulus
			$result[$k_result]['jumlah_tidaklulus'] = 0;
			foreach($statistik_tidaklulus as $tidaklulus)
			{
				if ($id === (int)$tidaklulus['id'])
					$result[$k_result]['jumlah_tidaklulus'] = (int)$tidaklulus['jumlah_tidaklulus'];
			}

			// satukan data pending
			$result[$k_result]['jumlah_pending'] = 0;
			foreach($statistik_pending as $pending)
			{
				if ($id === (int)$pending['id'])
					$result[$k_result]['jumlah_pending'] = (int)$pending['jumlah_pending'];
			}
		}
		$this->reply_success($result);
    }

	public function get_statistik_program_trainer()
	{
		if ($this->block_if_not_logged_in(['trainer'])) return;
		$this->load->model('trainer_model');
		$statistik_lulus = $this->trainer_model->get_jumlah_peserta_lulus($_SESSION['isTrainer'], 'program');
		$statistik_tidaklulus = $this->trainer_model->get_jumlah_peserta_tidaklulus($_SESSION['isTrainer'], 'program');
		$statistik_pending = $this->trainer_model->get_jumlah_peserta_pending($_SESSION['isTrainer'], 'program');
		$result = $statistik_lulus;
		foreach($result as $id_sertif => $list_program)
		{
			// satukan data tidak lulus
			if (isset($statistik_tidaklulus[$id_sertif]))
			{
				foreach ($list_program as $k_r => $program )
				{
					$result[$id_sertif][$k_r]['jumlah_tidaklulus'] = 0;
					foreach($statistik_tidaklulus[$id_sertif] as $tidaklulus)
					{
						if ((int)$tidaklulus['id'] === (int)$program['id'])
							$result[$id_sertif][$k_r]['jumlah_tidaklulus'] = (int)$tidaklulus['jumlah_tidaklulus'];
					}
				}

			}

			// satukan data pending
			if (isset($statistik_pending[$id_sertif]))
			{
				foreach ($list_program as $k_r => $program )
				{
					$result[$id_sertif][$k_r]['jumlah_pending'] = 0;
					foreach($statistik_pending[$id_sertif] as $pending)
					{
						if ((int)$pending['id'] === (int)$program['id'])
							$result[$id_sertif][$k_r]['jumlah_pending'] = (int)$pending['jumlah_pending'];
					}
				}

			}
		}
		// hapus index
		$new_result = [];
		foreach($result as $r)
			$new_result[] = $r;
		$result = $new_result;
        $this->reply_success($result);
	}

	public function get_statistik_sertifikasi_proctor()
	{
		if ($this->block_if_not_logged_in(['proctor'])) return;
		$this->load->model('proctor_model');
		$statistik_lulus = $this->proctor_model->get_jumlah_peserta_lulus($_SESSION['isProctor'], 'sertifikasi');
		$statistik_tidaklulus = $this->proctor_model->get_jumlah_peserta_tidaklulus($_SESSION['isProctor'], 'sertifikasi');
		$statistik_pending = $this->proctor_model->get_jumlah_peserta_pending($_SESSION['isProctor'], 'sertifikasi');
		$result = $statistik_lulus;
		foreach($result as $k_result => $r)
		{
			$id = (int)$r['id'];
			// satukan data tidak lulus
			$result[$k_result]['jumlah_tidaklulus'] = 0;
			foreach($statistik_tidaklulus as $tidaklulus)
			{
				if ($id === (int)$tidaklulus['id'])
					$result[$k_result]['jumlah_tidaklulus'] = (int)$tidaklulus['jumlah_tidaklulus'];
			}

			// satukan data pending
			$result[$k_result]['jumlah_pending'] = 0;
			foreach($statistik_pending as $pending)
			{
				if ($id === (int)$pending['id'])
					$result[$k_result]['jumlah_pending'] = (int)$pending['jumlah_pending'];
			}
		}
        $this->reply_success($result);
	}
}

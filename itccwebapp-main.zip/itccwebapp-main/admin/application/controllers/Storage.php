<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Storage extends CI_Controller {

    /*
     * cth : BASE_URL/storage?type=upload_bukti_bayar&file_name=e809d252a0210d2233364096610eeece.png
     * */

    public function get_file()
    {
        $type = $this->input->get('type');
        $file_name = $this->input->get('file_name');
        if (empty($type) || empty($file_name)) return;
        if (!isset($this->config->item(strtoupper($type))['users'])) return;
        $users = explode('|',$this->config->item(strtoupper($type))['users']);
        $enable = FALSE;
        if (in_array('user', $users) && isset($_SESSION['user'])) $enable = TRUE;
        if (in_array('admin', $users) && isset($_SESSION['admin'])) $enable = TRUE;
        if (in_array('trainer', $users) && isset($_SESSION['isTrainer'])) $enable = TRUE;
        if (in_array('proctor', $users) && isset($_SESSION['isProctor'])) $enable = TRUE;
        if (!$enable) return;

        $dangerous_chars = array(" ", '"', "'", "&", "/", "\\", "?", "#");
        // every forbidden character is replaced by an underscore
        $file_name = str_replace($dangerous_chars, '_', $file_name);

        $file_path = $this->config->item(strtoupper($type))['upload_path'].$file_name;
        if (!file_exists($file_path)) redirect(base_url('error?message=ERROR_PRIVATE_FILE_NOT_EXISTS'));
        $extensions = explode('|', $this->config->item(strtoupper($type))['allowed_types']);
        $ext = pathinfo($file_path, PATHINFO_EXTENSION);
        if (!in_array($ext, $extensions)) return;
        $this->load->helper('file');
        $mime = get_mime_by_extension($file_name);
        $this->output->set_header('Content-Disposition: filename="'.$file_name.'"')
            ->set_content_type($mime)
            ->set_output(file_get_contents($file_path));
    }

}

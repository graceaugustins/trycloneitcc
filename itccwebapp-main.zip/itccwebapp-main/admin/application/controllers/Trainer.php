<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @property M_trainer $m_trainer
 * @property M_sertifikasi $m_sertifikasi
 * @property M_program $m_program
 * @property M_proctor $m_proctor
 * @property M_kegiatan $m_kegiatan
 * @property M_kelompok_t $m_kelompok_t
 * @property M_kelompok_u $m_kelompok_u
 * @property CI_Input $input
 * @property Trainer_model $trainer_model
 */
class Trainer extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if (!isset($_SESSION['warning']))
			$_SESSION['warning'] = [];
		if (!empty($_SESSION['isTrainer']))
        {
            $this->load->model('trainer_model');
            $trainer = $this->trainer_model->get_trainer($_SESSION['isTrainer']['id']);
            if (empty($trainer)) unset($_SESSION['isTrainer']);
            else $_SESSION['isTrainer'] = reset($trainer);
        }
	}

	public function show_login()
	{
		$data = [];
		$data['next'] = base_url('trainer');
		// cek variabel get next (dari halaman lain)
		if (!empty($this->input->get('next')))
		{
			$get = explode('?', $this->input->get('next'));
			$data['next'] = base_url($get[0]);
		}
		$this->load->view('trainer/login', $data);
	}

	// Proses lanjutan login
	// setelah MSauth
	public function proses_login()
	{
		// Kalau akun valid dan
		// mengunjungi url ini lagi, redirect
		if (isset($_SESSION['isTrainer']))
		{
			$next = isset($_SESSION['next']) ? $_SESSION['next'] : base_url('trainer');
			redirect($next);
		}
		$this->load->library('user_token');
		$email = trim(strtolower($this->user_token->getEmail()));
		// Email ada : auth berhasil tapi tidak valid
		// Email tidak ada : belum auth dan tidak valid
		if (empty($email)) redirect(base_url("trainer/login"));

		// Cek valid email
		$this->load->model('trainers_model');

		// Kalau bukan superadmin, cek apakah trainer
		// atau bukan
		if (!$this->trainers_model->is_trainer($email))
		{
			redirect(base_url("trainer/login"));
			return;
		}
		// ambil detail trainer
		$_SESSION['isTrainer'] = $this->trainers_model->get_detail($email);
		$next = isset($_SESSION['next']) ? $_SESSION['next'] : base_url('trainer');
		redirect($next);
	}

	public function logout()
	{
		$_SESSION = [];
		session_destroy();
		redirect(base_url('msauth/signout'));
	}

    private function redirect_if_not_logged_in()
    {
        if (empty($_SESSION['isTrainer']))
        {
            clear_warning();
            redirect(base_url('trainer/login?next='.$this->uri->uri_string()));
        }
	}

    private function redirect_if_not_active()
    {
        $this->redirect_if_not_logged_in();
        if ($_SESSION['isTrainer']['aktif'] === FALSE)
            redirect(base_url('trainer/not_active'));
    }

    public function show_not_active()
    {
        $this->redirect_if_not_logged_in();
        if ($_SESSION['isTrainer']['aktif'] === FALSE)
            $this->load->view('trainer/not_active');
        else redirect(base_url('trainer'));
    }

    public function show_profile()
    {
        $this->redirect_if_not_active();
		load_data_class('Trainer');
		$me = new D_Trainer($_SESSION['isTrainer']['id']);
		$me->load_list_program();
        $data = [
            'me' => $me
        ];
        $this->load->view('trainer/profile', ['data' => $data]);
    }

    public function update_profile()
    {
        $this->redirect_if_not_active();

		load_data_class('Trainer');
		$me = new D_Trainer($_SESSION['isTrainer']['id']);
		$new_me = new D_Trainer($_SESSION['isTrainer']['id']);

		$new_me->nama_lengkap = $this->input->post('nama');
		$new_me->no_telepon = $this->input->post('no_telepon');

        if (isset($_FILES['file_foto']) && trim($_FILES['file_foto']['name']) !== '')
        {
        	if ($new_me->upload_profil('file_foto') === FALSE)
			{
				set_warning('Gagal mengupload foto profil.');
			}
        }

        $this->load->model('m_trainer');
        if ($this->m_trainer->update_trainer($new_me, [], FALSE) === FALSE)
		{
			if ($new_me->file_foto !== $me->file_foto) $new_me->hapus_profil();
			set_warning('Gagal mengupdate data profil trainer yang baru.');
			redirect(base_url('trainer'));
		}
		if ($new_me->file_foto !== $me->file_foto)
			$me->hapus_profil();
        redirect(base_url('trainer/profile'));
    }

	/**
	 * filter kegiatan yang programnya sesuai dengan trainer
	 * @param D_Kegiatan[] $array_kegiatan
	 * @return D_Kegiatan[]
	 * */
    private function filter_kegiatan_sesuai_program_trainer(array $array_kegiatan, D_Trainer $trainer): array
	{
		$trainer->load_list_program();
        $id_program = [];
        foreach($trainer->list_sertifikasi as $s)
		{
			foreach ($s->list_program as $p)
			{
				$id_program[] = (int)$p->id;
			}
		}

        // cek apakah program kegiatan masuk di trainer
        foreach($array_kegiatan as $k_keg => $keg)
        {
        	$keg->load_list_program();
            $program = array_filter($keg->program_kegiatan, function($p) use ($id_program){
                return in_array((int)$p->id_program, $id_program);
            });
            if (empty($program))
                unset($array_kegiatan[$k_keg]);
        }
        return $array_kegiatan;
    }

	/**
	 * filter kegiatan apakah trainer berpartisipasi atau tidak
	 * (sebagai trainer sesi 1 atau sesi 2)
	 * @param D_Kegiatan[] $array_kegiatan
	 * @return D_Kegiatan[]
	 * */
	private function filter_kegiatan_diikuti_trainer(array $array_kegiatan, D_Trainer $trainer): array
	{
		foreach ($array_kegiatan as $k_k => $k)
		{
			$k->load_kelompok_training();

			$id_trainer = (int)$trainer->id;
			$trainer_di_kelompok = array_filter($k->list_kelompok_training, function($kelompok_t) use ($id_trainer){
				$trainer_di_sesi1 = FALSE;
				if (!empty($kelompok_t->id_trainer_sesi1))
					$trainer_di_sesi1 = ((int)$kelompok_t->id_trainer_sesi1 === $id_trainer);
				$trainer_di_sesi2 = FALSE;
				if (!empty($kelompok_t->id_trainer_sesi2))
					$trainer_di_sesi2 = ((int)$kelompok_t->id_trainer_sesi2 === $id_trainer);
				return $trainer_di_sesi1 || $trainer_di_sesi2;
			});
			if (empty($trainer_di_kelompok))
				unset($array_kegiatan[$k_k]);
		}
		return $array_kegiatan;
    }

	/**
	 * filter kelompok training, mana yang sesuai dengan program trainer
	 * @param D_Kelompok_T[] $array_kelompok
	 * @return D_Kelompok_T[]
	 * */
	private function filter_kelompok_training_sesuai_program_trainer(array $array_kelompok, D_Trainer $trainer): array
	{
		$trainer->load_list_program();
		$id_program = [];
		foreach($trainer->list_sertifikasi as $s)
		{
			foreach ($s->list_program as $p)
			{
				$id_program[] = (int)$p->id;
			}
		}

		foreach($array_kelompok as $k_kelompok => $kelompok)
		{
			if (!in_array((int)$kelompok->id_program, $id_program))
			{
				unset($array_kelompok[$k_kelompok]);
			}
		}
		return $array_kelompok;
    }

	public function show_dashboard()
	{
        $this->redirect_if_not_active();
		load_data_class('Trainer');
		$me = new D_Trainer($_SESSION['isTrainer']['id']);

		$this->load->model('m_kegiatan');
		$list_kegiatan_akan_dilaksanakan = $this->filter_kegiatan_sesuai_program_trainer(
			$this->m_kegiatan->get_kegiatan_before_pelaksanaan(),
			$me
		);
		foreach ($list_kegiatan_akan_dilaksanakan as $kegiatan)
		{
			$kegiatan->load_sertifikasi();
			$kegiatan->load_list_program();
			$kegiatan->load_kelompok_training();
			$kegiatan->load_kelompok_ujian();
		}
		$list_kegiatan_sedang_dilaksanakan = $this->filter_kegiatan_diikuti_trainer(
			$this->m_kegiatan->get_kegiatan_in_pelaksanaan(),
			$me
		);
		foreach ($list_kegiatan_sedang_dilaksanakan as $kegiatan)
		{
			$kegiatan->load_sertifikasi();
			$kegiatan->load_list_program();
			$kegiatan->load_kelompok_training();
			$kegiatan->load_kelompok_ujian();
		}
        $data = [
            'list_kegiatan_akan_dilaksanakan' => $list_kegiatan_akan_dilaksanakan,
			'list_kegiatan_sedang_dilaksanakan' => $list_kegiatan_sedang_dilaksanakan
        ];
        
		$min_hari = $this->config->item('max_day_isi_kesediaan_trainer');
        set_warning(sprintf(
        	"Maksimal pengisian kesediaan trainer adalah %s hari sebelum training pertama.",
			$min_hari
		));
		$this->load->view('trainer/dashboard', ['data' => $data]);
	}

	public function show_kesediaan($id_kegiatan)
    {
        $this->redirect_if_not_active();
		$callback = base_url('trainer');
		load_data_class('Trainer');
		$me = new D_Trainer($_SESSION['isTrainer']['id']);

		$this->load->model('m_kegiatan');
		if ($this->m_kegiatan->is_id_kegiatan_exists($id_kegiatan) === FALSE)
		{
			set_warning('Kegiatan sertifikasi tidak dapat ditemukan.');
			redirect($callback);
		}
		load_data_class('Kegiatan');
		$kegiatan = new D_Kegiatan($id_kegiatan);

		if (empty($this->filter_kegiatan_sesuai_program_trainer([$kegiatan], $me)))
		{
			set_warning('Kegiatan sertifikasi tidak sesuai dengan program Anda.');
			redirect($callback);
		}

		$kegiatan->load_kelompok_training();
		if (count($kegiatan->list_kelompok_training) === 0)
		{
			set_warning('Belum ada kelompok di kegiatan ini.');
			redirect($callback);
		}

        // cek apakah masih bisa isi kesediaan
        // maks. x hari sebelum hari pelaksanaan (training pertama)
		$min_hari_pengisian = config_item('max_day_isi_kesediaan_trainer');
        $min_tgl = DateTime::createFromFormat('Y-m-d', "2099-12-31");
        foreach($kegiatan->list_kelompok_training as $k){
            $min_tgl = min(
                $min_tgl,
                clone $k->mulai_training
            );
        }
        $jarak = new DateInterval('P'.(string)$min_hari_pengisian.'D');
        $min_tgl->sub($jarak)->setTime(18,0,0);
        $sekarang = new DateTime();
        if ($sekarang >= $min_tgl)
        {
            set_warning(sprintf(
            	'Kesediaan trainer sudah tidak dapat diisi. Batas pengisian adalah %s hari sebelum training pertama, yaitu  %s %s WIB.',
				$min_hari_pengisian,
				tgl_indo($min_tgl->format('Y-m-d'), 'Y-m-d'),
				$min_tgl->format('H:i:s')
			));
			redirect($callback);
        }

		$list_kelompok_sesuai = $this->filter_kelompok_training_sesuai_program_trainer(
			$kegiatan->list_kelompok_training, $me
		);

        foreach($list_kelompok_sesuai as $k)
		{
			$k->load_kesediaan_trainer();
		}

        $data = [
            'kegiatan' => $kegiatan,
            'list_kelompok_sesuai' => $list_kelompok_sesuai,
            'batas' => $min_tgl,
			'me' => $me
        ];
		$min_hari = config_item('max_day_isi_kesediaan_trainer');
		set_warning(sprintf(
			"Maksimal pengisian kesediaan trainer adalah %s hari sebelum training pertama.",
			$min_hari
		));
        $this->load->view('trainer/kesediaan', ['data' => $data]);
    }

    public function update_kesediaan($id_kegiatan)
    {
        $this->redirect_if_not_active();

		$callback = base_url('trainer');
		load_data_class('Trainer');
		$me = new D_Trainer($_SESSION['isTrainer']['id']);

		$this->load->model('m_kegiatan');
		if ($this->m_kegiatan->is_id_kegiatan_exists($id_kegiatan) === FALSE)
		{
			set_warning('Kegiatan sertifikasi tidak dapat ditemukan.');
			redirect($callback);
		}

		load_data_class('Kegiatan');
		$kegiatan = new D_Kegiatan($id_kegiatan);
        $kegiatan->load_kelompok_training();

        if (empty($kegiatan->list_kelompok_training))
        {
            set_warning('Tidak ditemukan kelompok training di kegiatan ini.');
            redirect(base_url('trainer'));
        }

		// cek apakah masih bisa isi kesediaan
		// maks. x hari sebelum hari pelaksanaan (training pertama)
		$min_hari_pengisian = config_item('max_day_isi_kesediaan_trainer');
		$min_tgl = DateTime::createFromFormat('Y-m-d', "2099-12-31");
		foreach($kegiatan->list_kelompok_training as $k){
			$min_tgl = min(
				$min_tgl,
				$k->mulai_training
			);
		}
		$jarak = new DateInterval('P'.(string)$min_hari_pengisian.'D');
		$min_tgl->sub($jarak)->setTime(18,0,0);
		$sekarang = new DateTime();
		if ($sekarang >= $min_tgl)
		{
			set_warning(sprintf(
				'Kesediaan trainer sudah tidak dapat diisi. Batas pengisian adalah %s hari sebelum training pertama, yaitu  %s %s WIB.',
				$min_hari_pengisian,
				tgl_indo($min_tgl->format('Y-m-d'), 'Y-m-d'),
				$min_tgl->format('H:i:s')
			));
			redirect($callback);
		}

		$list_kelompok_bersedia = $this->input->post('bersedia');
        if ($list_kelompok_bersedia !== 'null' && !is_array($list_kelompok_bersedia))
        {
            set_warning('Input kelompok anda tidak dapat diproses.');
			redirect($callback);
        }
        if ($list_kelompok_bersedia === 'null') $list_kelompok_bersedia = [];

		$kelompok_sesuai_trainer = $this->filter_kelompok_training_sesuai_program_trainer(
			$kegiatan->list_kelompok_training, $me
		);

        // filter id kelompok yang disubmit harus exists
        foreach($list_kelompok_bersedia as $k_l => $l)
        {
            if (!ctype_digit($l)) break;
            $exists = array_filter($kelompok_sesuai_trainer, function ($kelompok) use ($l){
            	return (int)$kelompok->id === (int)$l;
			});
            if (empty($exists)) unset($list_kelompok_bersedia[$k_l]);
        }
        $this->load->model('m_trainer');
        if ($this->m_trainer->update_kesediaan_trainer($me, $list_kelompok_bersedia) === FALSE)
        {
            set_warning('Terjadi kesalahan dalam memproses data kesediaan anda.');
            redirect($callback);
        }
		set_warning('Sukses mengupdate data kesediaan trainer.');
        redirect(base_url('trainer/kesediaan/'.$id_kegiatan));
    }

    public function show_materi_training()
    {
        $this->redirect_if_not_active();

		load_data_class('Trainer');
		$me = new D_Trainer($_SESSION['isTrainer']['id']);
        $me->load_materi();
        $me->load_list_program();
        $data = [
            'me' => $me
        ];
        $this->load->view('trainer/materi', ['data' => $data]);
    }

    public function upload_materi_training()
    {
        $this->redirect_if_not_active();
		load_data_class('Trainer');
		$me = new D_Trainer($_SESSION['isTrainer']['id']);
        $me->load_list_program();

		$new_materi = new D_Materi_Trainer();
        $new_materi->id_trainer = $me->id;
        $new_materi->id_program = $this->input->post('id_program');
        $new_materi->deskripsi = $this->input->post('deskripsi');

        $id_program = $new_materi->id_program;
        $selected_id_program = array_filter($me->list_sertifikasi, function($sertifikasi) use($id_program){
        	$exists = FALSE;
            foreach($sertifikasi->list_program as $p)
			{
				if ((int)$id_program === (int)$p->id) $exists = TRUE;
			}
            return $exists;
        });

        $callback = base_url('trainer/materi');
        if (empty($selected_id_program))
        {
            set_warning('Program sertifikasi tidak cocok dengan profil Anda.');
            redirect($callback);
        }

        if (isset($_FILES['materi']) && trim($_FILES['materi']['name']) !== '')
        {
            if ($new_materi->upload_materi('materi') === FALSE)
            {
                set_warning('Gagal mengupload materi training.');
				redirect($callback);
            }
        }

        $this->load->model('m_trainer');
        if($this->m_trainer->add_new_materi($me, $new_materi) === FALSE)
        {
            $new_materi->hapus_file();
            set_warning('Gagal menyimpan data materi training di database.');
			redirect($callback);
        }
		redirect($callback);
    }

    public function update_materi_training()
    {
        $this->redirect_if_not_active();
		load_data_class('Trainer');
		$me = new D_Trainer($_SESSION['isTrainer']['id']);
		$me->load_materi();

		$callback = base_url('trainer/materi');
		$id_materi = $this->input->post('id');
		if (!ctype_digit($id_materi))
		{
			set_warning('Materi tidak valid.');
			redirect($callback);
		}

		$selected_materi = array_filter($me->list_materi, function ($materi) use ($id_materi){
			return (int)$materi->id === (int)$id_materi;
		});

        if (empty($selected_materi))
        {
            set_warning('Materi tidak ditemukan.');
			redirect($callback);
        }
        /** @var D_Materi_Trainer $selected_materi */
		$selected_materi = reset($selected_materi);
		$selected_materi->deskripsi = $this->input->post('deskripsi');

		$this->load->model('m_trainer');
        if ($this->m_trainer->update_materi($selected_materi) === FALSE)
        {
            set_warning('Gagal mengupdate deskripsi materi training.');
			redirect($callback);
        }
		redirect($callback);
    }

    public function hapus_materi_training()
    {
        $this->redirect_if_not_active();
        $callback = base_url('trainer/materi');
        $id_materi = $this->input->post('id');
        if (!ctype_digit($id_materi))
        {
            set_warning('Materi tidak valid.');
            redirect($callback);
        }

		load_data_class('Trainer');
		$me = new D_Trainer($_SESSION['isTrainer']['id']);
		$me->load_materi();

		$selected_materi = array_filter($me->list_materi, function ($materi) use ($id_materi){
			return (int)$materi->id === (int)$id_materi;
		});

		if (empty($selected_materi))
		{
			set_warning('Materi tidak ditemukan.');
			redirect($callback);
		}

		/** @var D_Materi_Trainer $selected_materi */
        $selected_materi = reset($selected_materi);

        $this->load->model('m_trainer');
        if ($this->m_trainer->delete_materi($selected_materi) === FALSE)
        {
            set_warning('Gagal menghapus materi training.');
			redirect($callback);
        }
		redirect($callback);
    }

    public function show_kelompok()
    {
        $this->redirect_if_not_active();
		load_data_class('Trainer');
		$me = new D_Trainer($_SESSION['isTrainer']['id']);

		$this->load->model('m_kegiatan');
		$list_kegiatan_akan_dilaksanakan = $this->filter_kegiatan_diikuti_trainer(
			$this->m_kegiatan->get_kegiatan_before_pelaksanaan(),
			$me
		);
		$list_kegiatan_sedang_dilaksanakan = $this->filter_kegiatan_diikuti_trainer(
			$this->m_kegiatan->get_kegiatan_in_pelaksanaan(),
			$me
		);

		/** @var D_Kegiatan[] $list_kegiatan */
		$list_kegiatan = [];
		foreach($list_kegiatan_akan_dilaksanakan as $kegiatan)
		{
			$list_kegiatan[] = $kegiatan;
		}
		foreach($list_kegiatan_sedang_dilaksanakan as $kegiatan)
		{
			$list_kegiatan[] = $kegiatan;
		}

		$id_kegiatan = $this->input->get('id_kegiatan');
		$selected_kegiatan = NULL;
		if (ctype_digit($id_kegiatan))
		{
			$selected_kegiatan = array_filter($list_kegiatan, function ($keg) use ($id_kegiatan){
				return (int)$keg->id === (int)$id_kegiatan;
			});
			/** @var D_Kegiatan $selected_kegiatan */
			if (!empty($selected_kegiatan)) $selected_kegiatan = reset($selected_kegiatan);
		}
		if (!empty($selected_kegiatan))
		{
			$selected_kegiatan->load_kelompok_training();
		}
        $data = [
            'kegiatan' => $list_kegiatan,
			'selected_kegiatan' => $selected_kegiatan,
			'me' =>$me
        ];
        $this->load->view('trainer/kelompok', ['data' => $data]);
    }

    public function show_absensi($id_kelompok)
    {
        $this->redirect_if_not_active();
        $callback = base_url('trainer/kelompok');
		load_data_class('Trainer');
		$me = new D_Trainer($_SESSION['isTrainer']['id']);
		$this->load->model('m_kelompok_t');
		if ($this->m_kelompok_t->is_id_exists($id_kelompok) === FALSE)
		{
			set_warning('Kelompok tidak ditemukan.');
			redirect($callback);
		}
		load_data_class('Kelompok_T');
		$kelompok = new D_Kelompok_T($id_kelompok);
		$callback = base_url('trainer/kelompok?id_kegiatan='.$kelompok->id_kegiatan);
        $trainer_exists = FALSE;
        if (!empty($kelompok->id_trainer_sesi1) && (int)$kelompok->id_trainer_sesi1 === (int)$me->id)
            $trainer_exists = TRUE;
		if (!empty($kelompok->id_trainer_sesi2) && (int)$kelompok->id_trainer_sesi2 === (int)$me->id)
            $trainer_exists = TRUE;
        if (!$trainer_exists)
        {
            set_warning('Anda tidak termasuk di kelompok ini.');
			redirect($callback);
        }
        load_data_class('Kegiatan');
        $kegiatan = new D_Kegiatan($kelompok->id_kegiatan);
        $kelompok->load_list_peserta();
        $data = [
            'me' => $me,
            'kegiatan' => $kegiatan,
            'kelompok' => $kelompok
        ];
        $this->load->view('trainer/absensi', ['data' => $data]);
    }

    public function update_absensi($id_kelompok)
    {
        $this->redirect_if_not_active();

		$callback = base_url('trainer/kelompok');
		load_data_class('Trainer');
		$me = new D_Trainer($_SESSION['isTrainer']['id']);
		$this->load->model('m_kelompok_t');
		if ($this->m_kelompok_t->is_id_exists($id_kelompok) === FALSE)
        {
            set_warning('Kelompok tidak ditemukan.');
            redirect($callback);
        }
		load_data_class('Kelompok_T');
		$kelompok = new D_Kelompok_T($id_kelompok);
        if ($kelompok->masih_bisa_isi_absensi() === FALSE)
        {
            set_warning('Absensi training tidak dapat diupdate karena sudah melewati waktu pengisian.');
			redirect($callback);
        }
		$kelompok->load_list_peserta();

        // cek apakah trainer masuk di kelompok ini
        $trainer_sesi1 = !empty($kelompok->id_trainer_sesi1) && (int)$kelompok->id_trainer_sesi1 === (int)$me->id;
        $trainer_sesi2 = !empty($kelompok->id_trainer_sesi2) && (int)$kelompok->id_trainer_sesi2 === (int)$me->id;
        if ($trainer_sesi1)
        {
            $id = [];
            $id_hadir_sesi1 = $this->input->post('sesi1');
            if (!empty($id_hadir_sesi1) && is_array($id_hadir_sesi1))
            {
                foreach($id_hadir_sesi1 as $id_1)
                {
                    if (ctype_digit($id_1))
                        $id[] = (int)$id_1;
                }
            }
            $id_kehadiran_new = [];
            foreach($kelompok->list_peserta as $p)
            {
                $id_kehadiran_new[] = [
					$p->id, in_array((int)$p->id, $id)
				];
            }
            $a = $this->m_kelompok_t->update_absensi_sesi1($id_kehadiran_new);
            $kelompok->beritaacara_t_sesi1 = $this->input->post('beritaacara_t_sesi1');
        }
        if ($trainer_sesi2)
        {
            $id = [];
            $id_hadir_sesi2 = $this->input->post('sesi2');
            if (!empty($id_hadir_sesi2) && is_array($id_hadir_sesi2))
            {
                foreach($id_hadir_sesi2 as $id_2)
                {
                    if (ctype_digit($id_2))
                        $id[] = (int)$id_2;
                }
            }
			$id_kehadiran_new = [];
			foreach($kelompok->list_peserta as $p)
			{
				$id_kehadiran_new[] = [
					$p->id, in_array((int)$p->id, $id)
				];
			}
			$a = $this->m_kelompok_t->update_absensi_sesi2($id_kehadiran_new);
			$kelompok->beritaacara_t_sesi2 = $this->input->post('beritaacara_t_sesi2');
        }
		$a = $this->m_kelompok_t->update_kelompok($kelompok);
		set_warning('Berhasil mengupdate data absensi: '.$kelompok->nama_kelompok);
        redirect(base_url('trainer/kelompok/absensi/'.$id_kelompok));
    }

	public function show_history()
	{
		$this->redirect_if_not_active();
		load_data_class('Trainer');
		$me = new D_Trainer($_SESSION['isTrainer']['id']);
		$this->load->model('m_trainer');
		$list_kegiatan = $this->m_trainer->get_list_kegiatan_history_trainer($me);
		foreach ($list_kegiatan as $kegiatan)
		{
			$kegiatan->load_sertifikasi();
			$kegiatan->load_kelompok_training();
			foreach($kegiatan->list_kelompok_training as $kelompok)
			{
				$kelompok->load_list_peserta();
			}
		}
		$data = [];
		$data['list_kegiatan'] = $list_kegiatan;
		$data['me'] = $me;
		$this->load->view('trainer/history', ['data' => $data]);
    }

	public function show_detail_history($id_kegiatan)
	{
		$this->redirect_if_not_active();

		$this->load->model('m_trainer');
		load_data_class('Trainer');
		$me = new D_Trainer($_SESSION['isTrainer']['id']);

		$this->load->model('m_trainer');
		$list_kegiatan = $this->m_trainer->get_list_kegiatan_history_trainer($me);

		$selected_kegiatan = array_filter(
			$list_kegiatan,
			function ($kegiatan) use ($id_kegiatan){
				return (int)$kegiatan->id === (int)$id_kegiatan;
			}
		);
		if (empty($selected_kegiatan))
		{
			set_warning('Kegiatan tidak ditemukan.');
			redirect(base_url('trainer/history'));
		}
		/** @var D_Kegiatan $selected_kegiatan */
		$selected_kegiatan = reset($selected_kegiatan);
		$selected_kegiatan->load_kelompok_training();
		$selected_kegiatan->load_kelompok_ujian();
		foreach ($selected_kegiatan->list_kelompok_training as $kelompok) {
			$kelompok->load_list_peserta();
		}
		$selected_kegiatan->load_list_program();
		$data = [
			'selected_kegiatan' => $selected_kegiatan,
			'me' => $me
		];
		$this->load->view('trainer/detail_history', ['data' => $data]);
    }
}

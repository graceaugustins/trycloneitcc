<?php defined('BASEPATH') OR exit('No direct script access allowed');

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

/**
 * @property M_trainer $m_trainer
 * @property M_sertifikasi $m_sertifikasi
 * @property M_program $m_program
 * @property M_proctor $m_proctor
 * @property M_kegiatan $m_kegiatan
 * @property M_kelompok_t $m_kelompok_t
 * @property M_kelompok_u $m_kelompok_u
 * @property M_user $m_user
 * @property M_role $m_role
 * @property M_administrator $m_administrator
 * @property CI_Input $input
 * @property CI_URI $uri
 * @property M_history $m_history
 * @property User_token $user_token
 * @property Users_model $users_model
 * @property Config_model $config_model
 * @property CI_Encryption $encryption
 * @property System_functions $system_functions
 */
class Admin extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('admin');
		if (!isset($_SESSION['warning']))
			$_SESSION['warning'] = [];
	}

	public function test()
    {

    }

    private function redirect_if_not_logged_in()
    {
        if (!isset($_SESSION['admin']))
        {
            clear_warning();
            redirect(base_url('admin/login?next='.$this->uri->uri_string()));
        }
    }

    private function redirect_if_not_capable($capability, $message, $path)
    {
        if (!admin_capable($capability))
        {
            if (!empty($message))
                set_warning($message);
            redirect(base_url($path));
        }
    }

	public function show_login()
	{
		$data = [];
		$data['next'] = base_url('admin');
		
		// cek variabel get next (dari halaman lain)
		if (!empty($this->input->get('next')))
		{
			$get = explode('?', $this->input->get('next'));
			$data['next'] = base_url($get[0]);
		}

		$this->load->view('admin/login', $data);
	}

	// Proses lanjutan login
	// setelah MSauth
	public function proses_login()
	{
        $next = isset($_SESSION['next']) ? $_SESSION['next'] : '';
        unset($_SESSION['next']);

		// Kalau akun valid dan
		// mengunjungi url ini lagi, redirect
		if (isset($_SESSION['admin']))
		{
		    if ($next === '') $next = base_url('admin');
			redirect($next);
		}
		$this->load->library('user_token');
		$email = trim(strtolower($this->user_token->getEmail()));

		// Email ada : auth berhasil tapi tidak valid
		// Email tidak ada : belum auth dan tidak valid
		if (empty($email)) redirect(base_url("admin/login"));

		// Cek valid email
		// Apakah email ini superadmin
		$this->load->model('m_administrator');
		if($this->m_administrator->is_superadmin($email))
		{
			$_SESSION['admin'] = [
				'email' =>$email,
				'nama_lengkap' => 'SuperAdmin',
				'isSuperAdmin' => TRUE,
				'role' => 'Super Admin'
			];
            // catat login history
            $this->load->model('m_history');
            $this->m_history->login($_SESSION['admin']['email'], $_SESSION['admin']['role']);
            if ($next === '') $next = base_url('admin');
			redirect($next);
			return;
		}

		// Kalau bukan superadmin, cek apakah admin
		// atau bukan
		if (!$this->m_administrator->does_email_already_exists($email))
		{
			redirect(base_url("admin/login"));
			return;
		}

		// ambil detail admin
		$_SESSION['admin'] = $this->m_administrator->get_detail_admin($email);

		// catat login history
        $this->load->model('m_history');
        $this->m_history->login($_SESSION['admin']['email'], $_SESSION['admin']['role']);

        if ($next === '') $next = base_url('admin');
		redirect($next);
	}

	public function logout()
	{
        // catat login history
        $this->load->model('m_history');
        $this->m_history->logout($_SESSION['admin']['email'], $_SESSION['admin']['role']);
		$_SESSION = [];
		session_destroy();
		redirect(base_url('msauth/signout'));
	}

	public function show_dashboard()
	{
        // cek permission admin
        $this->redirect_if_not_logged_in();

		$this->load->model("m_kegiatan");

		$list_kegiatan_in_registrasi = $this->m_kegiatan->get_kegiatan_in_registrasi();
		$list_kegiatan_before_pelaksanaan = $this->m_kegiatan->get_kegiatan_before_pelaksanaan();
		$list_kegiatan_in_pelaksanaan = $this->m_kegiatan->get_kegiatan_in_pelaksanaan();
		foreach ($list_kegiatan_in_registrasi as $kegiatan) {
			$kegiatan->load_sertifikasi();
			$kegiatan->load_kelompok_training();
			$kegiatan->load_kelompok_ujian();
		}
		foreach ($list_kegiatan_before_pelaksanaan as $kegiatan) {
			$kegiatan->load_sertifikasi();
			$kegiatan->load_kelompok_training();
			$kegiatan->load_kelompok_ujian();
		}
		foreach ($list_kegiatan_in_pelaksanaan as $kegiatan) {
			$kegiatan->load_sertifikasi();
			$kegiatan->load_kelompok_training();
			$kegiatan->load_kelompok_ujian();
		}

		$data = [
			'list_kegiatan_in_registrasi' => $list_kegiatan_in_registrasi,
			'list_kegiatan_before_pelaksanaan' => $list_kegiatan_before_pelaksanaan,
			'list_kegiatan_in_pelaksanaan' => $list_kegiatan_in_pelaksanaan
		];
		$this->load->view('admin/dashboard', ['data' => $data]);
	}

	// Page daftar role dan capabilities
	public function show_roles()
	{
        // cek permission admin
        $this->redirect_if_not_logged_in();
        $this->redirect_if_not_capable(
            Permissions::LIHAT_LIST_HAK_AKSES,
            'Anda tidak diizinkan untuk melihat daftar role dan capability.',
            'admin'
        );

		// ambil data hak akses
        $this->load->model('m_role');
        $all_roles = $this->m_role->get_all_roles();
		$data = [];
        $data['all_roles'] = $all_roles;
        if (ctype_digit($this->input->get('id_role')))
        {
            $id_role = (int)$this->input->get('id_role');
            $filter_roles = array_filter($all_roles, function($role) use ($id_role){
                return (int)$role->id === $id_role;
            });
            $selected_role = reset($filter_roles);
            $selected_role->load_capabilities();
            $data['selected_role'] = $selected_role;
        }

		$this->load->view('admin/roles', ['data' => $data]);
	}

	public function add_role()
	{
	    $this->redirect_if_not_capable(
	        Permissions::TAMBAH_LIST_HAK_AKSES,
            'Anda tidak diizinkan untuk menambah role dan capability baru.',
            'admin/roles'
        );
        load_data_class('Role');
        $new_role = new D_Role();
        $new_role->nama_role = $this->input->post('role_name');

        $error_validation = $new_role->validate_data(General_Constants::MODE_OPERATION_CREATE);
        foreach($error_validation as $error_message)
        {
            set_warning($error_message);
        }

		$this->load->model('m_role');
		if ($this->m_role->add_new_role($new_role) === FALSE)
		{
			set_warning('Gagal dalam menambah role baru.');
			redirect(base_url('admin/roles'));
		}
        set_warning('Berhasil menambahkan role: '. $new_role->nama_role);
		redirect(base_url('admin/roles?id_role='.$new_role->id));
	}

	public function update_cap_role()
	{
	    $this->redirect_if_not_capable(
            Permissions::EDIT_LIST_HAK_AKSES,
            'Anda tidak diizinkan untuk mengupdate data role dan capability.',
            'admin/roles'
        );

		$id_role = $this->input->post('id_role');
		// validasi data
		if (!ctype_digit($id_role))
		{
			set_warning('Parameter role tidak valid.');
			redirect(base_url('admin/roles'));
		}
		$id_role = (int)$id_role;
        $this->load->model('m_role');
        if ($this->m_role->does_id_already_exists($id_role) === FALSE)
        {
			set_warning('Role tidak ditemukan.');
			redirect(base_url('admin/roles'));
		}
        if (!is_array($this->input->post('cap')))
        {
            set_warning('Parameter capability tidak valid.');
            redirect(base_url('admin/roles'));
        }
        load_data_class('Role');
        $role = new D_Role($id_role);
        $role->load_capabilities();
		$new_cap = [];

		foreach ($this->input->post('cap') as $id_capability => $eligible)
		{
			$exists = FALSE;
			foreach($role->capabilities as $c)
			    if ((int)$c->id === (int)$id_capability)
			        $exists = TRUE;
			if ($eligible === 'y' && $exists)
			    $new_cap[] = (int)$id_capability;
		}

		if ($this->m_role->set_new_capability($role, $new_cap) === FALSE)
		{
			set_warning('Gagal update capability.');
			redirect(base_url('admin/roles'));
		}
        set_warning('Berhasil update capability.');
		redirect(base_url('admin/roles?id_role='.$id_role));
	}

	public function update_role()
	{
	    $this->redirect_if_not_capable(
            Permissions::EDIT_LIST_HAK_AKSES,
            'Anda tidak diizinkan untuk mengupdate data role dan capability.',
            'admin/roles'
        );
        $id_role = $this->input->post('id_role');
		if (!ctype_digit($id_role))
		{
			set_warning('Parameter role tidak valid.');
			redirect(base_url('admin/roles'));
		}
        $id_role = (int)$id_role;
        $this->load->model("m_role");
        if ($this->m_role->does_id_already_exists($id_role) === FALSE)
        {
            set_warning('Role tidak ditemukan.');
            redirect(base_url('admin/roles'));
        }
        load_data_class('Role');
        $updated_role = new D_Role();
        $updated_role->id = $id_role;
        $updated_role->nama_role = $this->input->post('nama_role');

        foreach ($updated_role->validate_data(General_Constants::MODE_OPERATION_UPDATE) as $error_message)
        {
            set_warning($error_message);
        }

		$this->load->model('m_role');
		if ($this->m_role->update_role($updated_role) === FALSE)
		{
			set_warning('Gagal mengubah data role.');
			redirect(base_url('admin/roles'));
		}
        set_warning("Sukses mengubah data role.");
		redirect(base_url('admin/roles?id_role='.$id_role));
	}

	public function delete_role()
	{
	    $this->redirect_if_not_capable(
            Permissions::HAPUS_LIST_HAK_AKSES,
            'Anda tidak diizinkan untuk menghapus role dan capability.',
            'admin/roles'
        );
        $id_role = $this->input->post('id_role');
        if (!ctype_digit($id_role))
        {
            set_warning('Parameter role tidak ditemukan.');
            redirect(base_url('admin/roles'));
        }
        $id_role = (int)$id_role;
		$this->load->model('m_role');
		if ($this->m_role->does_id_already_exists($id_role) === FALSE)
		{
			set_warning('Role tidak dapat ditemukan.');
			redirect(base_url('admin/roles'));
		}
        load_data_class('Role');
        $role = new D_Role($id_role);
        foreach ($role->validate_data(General_Constants::MODE_OPERATION_DELETE) as $error)
        {
            set_warning($error);
        }
		if ($this->m_role->delete_role($role) === FALSE)
		{
			set_warning('Gagal dalam menghapus role.');
			redirect(base_url('admin/roles'));
		}
		set_warning('Role beserta capabilitiesnya berhasil dihapus.');
		redirect(base_url('admin/roles'));
	}

	public function show_administrators()
	{
        // cek permission admin
        $this->redirect_if_not_logged_in();
        $this->redirect_if_not_capable(
            Permissions::LIHAT_LIST_ADMINISTRATOR,
            'Anda tidak diizinkan untuk melihat daftar administrator.',
            'admin'
        );

		// ambil data administrator & roles
		$this->load->model('m_role');
		$all_roles = $this->m_role->get_all_roles();

		$this->load->model('m_administrator');
		$all_administrators = $this->m_administrator->get_all_administrator();
		$data = [
			'roles' => $all_roles,
			'administrators' => $all_administrators
		];
		$this->load->view('admin/administrators', ['data'=>$data]);
	}

	public function add_administrator()
	{
	    $this->redirect_if_not_capable(
            Permissions::TAMBAH_LIST_ADMINISTRATOR,
            'Anda tidak diizinkan untuk menambah administrator baru.',
            'admin/administrators'
        );

        load_data_class('Administrator');
        $admin = new D_Administrator();
        $admin->email = $this->input->post('email');
        $admin->nama = $this->input->post('nama');
        $admin->id_role = $this->input->post('id_role');

        $admin->validate_data(General_Constants::MODE_OPERATION_CREATE);
        foreach ($admin->last_create_validation_errors as $error)
        {
            set_warning($error);
        }

        $this->load->model('m_administrator');
		if ($this->m_administrator->add_new_administrator($admin) === FALSE)
		{
			set_warning('Gagal menambahkan administrator baru');
			redirect(base_url('admin/administrators'));
		}
        set_warning('Sukses menambahkan administrator baru: '.$admin->nama);
		redirect(base_url('admin/administrators'));
	}

	public function update_administrator()
	{
	    $this->redirect_if_not_capable(
            Permissions::EDIT_LIST_ADMINISTRATOR,
            'Anda tidak diizinkan untuk mengubah data administrator.',
            'admin/administrators'
        );

        $id_admin = $this->input->post('id');
		if (!ctype_digit($id_admin))
		{
			set_warning('ID administrator tidak valid.');
			redirect(base_url('admin/administrators'));
		}
        $id_admin = (int)$id_admin;
        load_data_class('Administrator');
        $updated_admin = new D_Administrator();
        $updated_admin->id = $id_admin;
        $updated_admin->email = $this->input->post('email');
        $updated_admin->nama = $this->input->post('nama');
		$updated_admin->id_role = $this->input->post('id_role');

        $updated_admin->validate_data(General_Constants::MODE_OPERATION_UPDATE);
        foreach($updated_admin->last_update_validation_errors as $error)
        {
            set_warning($error);
        }

        $this->load->model('m_administrator');
		if ($this->m_administrator->update_administrator($updated_admin) === FALSE)
		{
			set_warning('Gagal update data administrator.');
			redirect(base_url('admin/administrators'));
		}
        set_warning('Sukses update data administrator: '.$updated_admin->nama);
		redirect(base_url('admin/administrators'));
	}

	public function delete_administrator()
	{
	    $this->redirect_if_not_capable(
            Permissions::HAPUS_LIST_ADMINISTRATOR,
            'Anda tidak diizinkan untuk menghapus data administrator.',
            'admin/administrators'
        );

        load_data_class('Administrator');
        $admin = new D_Administrator();
        $admin->id = $this->input->post('id');

        $admin->validate_data(General_Constants::MODE_OPERATION_DELETE);
        foreach($admin->last_delete_validation_errors as $error)
        {
            set_warning($error);
        }

		$this->load->model('m_administrator');
		if ($this->m_administrator->delete_administrator($admin) === FALSE)
            set_warning('Gagal menghapus data administrator.');
        else set_warning('Sukses menghapus data administrator.');
		redirect(base_url('admin/administrators'));
	}

	public function show_trainer()
	{
        // cek permission admin
        $this->redirect_if_not_logged_in();
        $this->redirect_if_not_capable(
            Permissions::LIHAT_LIST_TRAINER,
            'Anda tidak diizinkan untuk melihat daftar trainer.',
            'admin'
        );
		$this->load->model('m_trainer');
		$this->load->model('m_sertifikasi');

		$list_trainer_aktif = $this->m_trainer->get_list_trainer_aktif();
		$list_trainer_nonaktif = $this->m_trainer->get_list_trainer_nonaktif();

		$list_sertifikasi = $this->m_sertifikasi->get_list_sertifikasi();
		foreach ($list_sertifikasi as $sertif)
		{
			$sertif->load_list_program();
		}
		foreach($list_trainer_aktif as $trainer)
		{
			$trainer->load_list_program();
			$trainer->load_performance();
		}
		foreach($list_trainer_nonaktif as $trainer)
		{
			$trainer->load_list_program();
			$trainer->load_performance();
		}

		// get data total statistik trainer
		$view_sertif_performance = $this->input->get('view_sertif_performance');
		if (!ctype_digit($view_sertif_performance)) {
			$view_sertif_performance = "all";
		}

		$data = [
			'view_sertif_performance' => $view_sertif_performance,
			'trainer_aktif' => $list_trainer_aktif,
			'trainer_nonaktif' => $list_trainer_nonaktif,
			'sertifikasi' => $list_sertifikasi
		];
		$this->load->view('admin/trainer', ['data'=>$data]);
	}

	public function add_trainer()
	{
		$this->redirect_if_not_capable(
            Permissions::TAMBAH_LIST_TRAINER,
            'Anda tidak diizinkan untuk menambah trainer baru.',
            'admin/trainer'
        );
		$callback = base_url('admin/trainer');
		load_data_class('Trainer');
		$trainer = new D_Trainer();
		$trainer->email = $this->input->post('email');
		$trainer->nama_lengkap = $this->input->post('nama_lengkap');
        $trainer->no_telepon = $this->input->post('nomor_telepon');

		// cek apakah ada parameter upload foto,
		// jika ada, proses upload foto. Jika tidak,
		// pakai foto default.jpg
		if (isset($_FILES['foto']) && trim($_FILES['foto']['name']) !== '')
		{
			if ($trainer->upload_profil('foto') === FALSE)
			{
				set_warning('Trainer baru menggunakan profil default, karena foto profil yang diberikan gagal disimpan.');
			}
		}

		$trainer->validate_data(General_Constants::MODE_OPERATION_CREATE);
		foreach($trainer->last_create_validation_errors as $error)
		{
			set_warning($error);
		}

		// jika gagal simpan data trainer, namun foto profil berhasil diupload,
		// hapus foto profil
		if ($this->m_trainer->add_new_trainer($trainer) === FALSE)
		{
			set_warning('Gagal menambahkan trainer.');
			$trainer->hapus_profil();
		}
		set_warning('Sukses menambahkan trainer: '.$trainer->nama_lengkap);
		redirect($callback);
	}

	public function update_trainer()
	{
	    $this->redirect_if_not_capable(
            Permissions::EDIT_LIST_TRAINER,
            'Anda tidak diizinkan untuk mengubah data trainer.',
            'admin/trainer'
        );
		$callback = base_url('admin/trainer');
        $id = $this->input->post('id');
		if (!ctype_digit($id))
		{
			set_warning('ID trainer tidak valid.');
			redirect($callback);
		}
		load_data_class('Trainer');
		$existing_trainer = new D_Trainer($id);
		if (empty($existing_trainer->id))
		{
			set_warning('Trainer tidak ditemukan.');
			redirect($callback);
		}
		$updated_trainer = new D_Trainer();
		$updated_trainer->id = $existing_trainer->id;
		$updated_trainer->email = $this->input->post('email');
		$updated_trainer->nama_lengkap = $this->input->post('nama_lengkap');
        $updated_trainer->no_telepon = $this->input->post('nomor_telepon');

		$id_program = [];
		if ($this->input->post('id_program') !== NULL)
		{
		    if (!is_array($this->input->post('id_program')))
            {
                set_warning('Format program tidak valid.');
				redirect($callback);
            }
			foreach($this->input->post('id_program') as $i_p)
			{
				if (ctype_digit($i_p) || is_numeric($i_p))
                {
					$id_program[] = (int)$i_p;
                }
			}
		}
		$id_program = array_unique($id_program);
		$id_program_valid = [];
		$this->load->model('m_program');
		foreach ($id_program as $id_p)
		{
			if ($this->m_program->is_program_exists($id_p))
				$id_program_valid[] = $id_p;
		}

		// Cek apakah foto profil diganti juga
		if (!empty($this->input->post('ganti_profil')))
		{
			if (isset($_FILES['foto']) && trim($_FILES['foto']['name']) !== '')
			{
				if ($updated_trainer->upload_profil('foto') === FALSE)
				{
					set_warning('Gagal mengupload profil trainer.');
				}
			}
		}
		else $updated_trainer->file_foto = $existing_trainer->file_foto;

		$updated_trainer->validate_data(General_Constants::MODE_OPERATION_UPDATE);
		foreach($updated_trainer->last_update_validation_errors as $error)
		{
			set_warning($error);
		}

		$this->load->model('m_trainer');
		if ($this->m_trainer->update_trainer($updated_trainer, $id_program_valid) === FALSE)
		{
			set_warning('Gagal mengubah data trainer.');
			redirect($callback);
		}

		// hapus file foto sebelumnya, jika diupdate
		if ($updated_trainer->file_foto !== $existing_trainer->file_foto)
			$existing_trainer->hapus_profil();

		set_warning('Sukses mengubah data trainer: '.$updated_trainer->nama_lengkap);
		redirect($callback);
	}

	public function delete_trainer()
	{
	    $this->redirect_if_not_capable(
            Permissions::HAPUS_LIST_TRAINER,
            'Anda tidak diizinkan untuk menghapus trainer.',
            'admin/trainer'
        );
        $id = $this->input->post('id');
        $callback = base_url('admin/trainer');
		if (!ctype_digit($id))
		{
			set_warning('ID trainer tidak valid.');
			redirect($callback);
		}
		load_data_class('Trainer');
		$trainer = new D_Trainer($id);
		if (empty($trainer->id))
		{
			set_warning('Trainer tidak ditemukan.');
			redirect($callback);
		}
		$this->load->model('m_trainer');
		if ($trainer->pernah_partisipasi())
		{
			$trainer->aktif = FALSE;
			if ($this->m_trainer->update_trainer($trainer, [], FALSE) === FALSE)
			{
				set_warning('Gagal dalam menonaktifkan trainer.');
				redirect($callback);
			}
			set_warning('Trainer dinonaktifkan karena sudah pernah berpartisipasi di sertifikasi.');
			redirect($callback);
		}
		$trainer->validate_data(General_Constants::MODE_OPERATION_DELETE);
		foreach($trainer->last_delete_validation_errors as $error)
		{
			set_warning($error);
		}
		if ($this->m_trainer->delete_trainer($trainer) === FALSE)
		{
			set_warning('Gagal menghapus trainer.');
			redirect($callback);
		}
		$trainer->hapus_profil();
		set_warning('Sukses menghapus trainer: '.$trainer->nama_lengkap);
		redirect($callback);
	}

	public function set_trainer_aktif()
	{
	    $this->redirect_if_not_capable(
            Permissions::EDIT_LIST_TRAINER,
            'Anda tidak diizinkan untuk mengubah data trainer.',
            'admin/trainer'
        );
		$callback = base_url('admin/trainer');
        $id = $this->input->post('id');
		if (!ctype_digit($id))
		{
			set_warning('ID trainer tidak valid.');
			redirect($callback);
		}

		load_data_class('Trainer');
		$trainer = new D_Trainer($id);
		if (empty($trainer->id))
		{
			set_warning('Trainer tidak ditemukan.');
			redirect($callback);
		}
		if ($trainer->aktif)
		{
			set_warning('Trainer sudah aktif sebelumnya.');
			redirect($callback);
		}
		$trainer->aktif = TRUE;
		$trainer->validate_data(General_Constants::MODE_OPERATION_UPDATE);
		foreach($trainer->last_delete_validation_errors as $error)
		{
			set_warning($error);
		}
		$this->load->model('m_trainer');
		if ($this->m_trainer->update_trainer($trainer, [], FALSE) === FALSE)
			set_warning('Gagal mengaktifkan trainer.');
		else set_warning('Sukses mengaktifkan trainer: '.$trainer->nama_lengkap);
		redirect($callback);
	}

	public function show_proctor()
	{
	    $this->redirect_if_not_logged_in();
	    $this->redirect_if_not_capable(
            Permissions::LIHAT_LIST_PROCTOR,
            'Anda tidak diizinkan untuk melihat daftar proctor.',
            'admin'
        );
		$this->load->model('m_sertifikasi'); // untuk get list sertifikasi
		$this->load->model('m_proctor');
		$list_sertifikasi = $this->m_sertifikasi->get_list_sertifikasi();
		$list_proctor_aktif = $this->m_proctor->get_list_proctor_aktif();
		$list_proctor_nonaktif = $this->m_proctor->get_list_proctor_nonaktif();
		foreach ($list_proctor_aktif as $p)
		{
			$p->load_list_sertifikasi();
		}
		foreach ($list_proctor_nonaktif as $p)
		{
			$p->load_list_sertifikasi();
		}
		$data = [
			'proctor_aktif' => $list_proctor_aktif,
			'proctor_nonaktif' => $list_proctor_nonaktif,
			'sertifikasi' => $list_sertifikasi
		];
		$this->load->view('admin/proctor', [ 'data' => $data]);
	}

	public function add_proctor()
	{
	    $this->redirect_if_not_capable(
            Permissions::TAMBAH_LIST_PROCTOR,
            'Anda tidak diizinkan untuk menambah proctor baru.',
            'admin/proctor'
        );
	    $callback = base_url('admin/proctor');
		load_data_class('Proctor');
		$proctor = new D_Proctor();
		$proctor->email = $this->input->post('email');
		$proctor->nama_lengkap = $this->input->post('nama_lengkap');
		$proctor->no_telepon = $this->input->post('nomor_telepon');

		if (isset($_FILES['foto']) && trim($_FILES['foto']['name']) !== '')
		{
			if($proctor->upload_profil('foto') === FALSE)
			{
				set_warning('Proctor baru menggunakan profil default, karena foto profil yang diberikan gagal disimpan.');
			}
		}

		$proctor->validate_data(General_Constants::MODE_OPERATION_CREATE);
		foreach($proctor->last_create_validation_errors as $error)
		{
			set_warning($error);
		}

		if ($this->m_proctor->add_new_proctor($proctor) === FALSE)
		{
			set_warning('Gagal dalam menambahkan proctor.');
			$proctor->hapus_profil();
		}
		set_warning('Sukses menambahkan proctor: '.$proctor->nama_lengkap);
		redirect($callback);
	}

	public function update_proctor()
	{
	    $this->redirect_if_not_capable(
            Permissions::EDIT_LIST_PROCTOR,
            'Anda tidak diizinkan untuk mengubah data proctor.',
            'admin/proctor'
        );
		$callback = base_url('admin/proctor');
        $id = $this->input->post('id');

		if (!ctype_digit($id))
		{
			set_warning('ID proctor tidak valid.');
			redirect($callback);
		}
		load_data_class('Proctor');
        $existing_proctor = new D_Proctor($id);
		if (empty($existing_proctor->id))
		{
			set_warning('Proctor tidak ditemukan.');
			redirect($callback);
		}
        $updated_proctor = new D_Proctor();
        $updated_proctor->id = $existing_proctor->id;
        $updated_proctor->email = $this->input->post('email');
		$updated_proctor->nama_lengkap = $this->input->post('nama_lengkap');
		$updated_proctor->no_telepon = $this->input->post('nomor_telepon');

		// Jika ada parameter sertifikasi
		$list_id_sertifikasi_valid = [];
		$list_id_sertifikasi = [];
		if (!empty($this->input->post('sertif')))
		{
		    if (!is_array($this->input->post('sertif')))
            {
                set_warning('Gagal mengganti sertifikasi proctor.');
				redirect($callback);
            }
			$list_id_sertifikasi = $this->input->post('sertif');
			$this->load->model('m_sertifikasi');
            $list_sertifikasi = $this->m_sertifikasi->get_list_sertifikasi();

			foreach ($list_id_sertifikasi as $id_sertif)
			{
				if (ctype_digit($id_sertif))
                {
                    $selected_sertifikasi = array_filter($list_sertifikasi, function ($sertif) use ($id_sertif){
                    	return (int)$sertif->id === (int)$id_sertif;
					});
                    if (count($selected_sertifikasi) > 0) $list_id_sertifikasi_valid[] = $id_sertif;
                }
			}
			$list_id_sertifikasi_valid = array_unique($list_id_sertifikasi_valid);
		}

		if (!empty($this->input->post('ganti_profil')))
		{
			if (isset($_FILES['foto']) && trim($_FILES['foto']['name']) !== '')
			{
				if($updated_proctor->upload_profil('foto') === FALSE)
				{
					set_warning('Gagal mengupload profil proctor.');
				}
			}
		}
		else $updated_proctor->file_foto = $existing_proctor->file_foto;

		$updated_proctor->validate_data(General_Constants::MODE_OPERATION_UPDATE);
		foreach($updated_proctor->last_update_validation_errors as $error)
		{
			set_warning($error);
		}
		$this->load->model('m_proctor');
		if ($this->m_proctor->update_proctor($updated_proctor, $list_id_sertifikasi_valid) === FALSE)
		{
			if ($updated_proctor->file_foto !== $existing_proctor->file_foto)
				$updated_proctor->hapus_profil();
			set_warning('Gagal mengubah data proctor.');
			redirect($callback);
		}

		if ($updated_proctor->file_foto !== $existing_proctor->file_foto)
			$existing_proctor->hapus_profil();

		set_warning('Sukses mengubah data proctor: '.$existing_proctor->nama_lengkap);
		redirect($callback);
	}

	public function delete_proctor()
	{
	    $this->redirect_if_not_capable(
            Permissions::HAPUS_LIST_PROCTOR,
            'Anda tidak diizinkan untuk menghapus proctor.',
            'admin/proctor'
        );
		$callback = base_url('admin/proctor');
        $id = $this->input->post('id');

		if (!ctype_digit($id))
		{
			set_warning('Proctor tidak valid.');
			redirect($callback);
		}
		load_data_class('Proctor');
		$proctor = new D_Proctor($id);
		if (empty($proctor->id))
		{
			set_warning('Proctor tidak ditemukan.');
			redirect($callback);
		}

		$this->load->model('m_proctor');
		if ($proctor->pernah_partisipasi())
		{
			$proctor->aktif = FALSE;
			if ($this->m_proctor->update_proctor($proctor, [], FALSE) === FALSE)
			{
				set_warning('Gagal dalam menonaktifkan proctor.');
				redirect($callback);
			}
			set_warning('Proctor dinonaktifkan karena sudah pernah berpartisipasi di sertifikasi.');
			redirect($callback);
		}

		$proctor->validate_data(General_Constants::MODE_OPERATION_DELETE);
		foreach($proctor->last_delete_validation_errors as $error)
		{
			set_warning($error);
		}

		if ($this->m_proctor->delete_proctor($proctor) === FALSE)
			set_warning('Gagal dalam menghapus proctor.');
		$proctor->hapus_profil();
		redirect($callback);
	}

	public function set_proctor_aktif()
	{
	    $this->redirect_if_not_capable(
            Permissions::EDIT_LIST_PROCTOR,
            'Anda tidak diizinkan untuk mengubah data proctor.',
            'admin/proctor'
        );
	    $callback = base_url('admin/proctor');
        $id = $this->input->post('id');

		if (!ctype_digit($id))
		{
			set_warning('Proctor tidak valid.');
			redirect($callback);
		}
		load_data_class('Proctor');
		$proctor = new D_Proctor($id);
		if (empty($proctor->id))
		{
			set_warning('Proctor tidak ditemukan.');
			redirect($callback);
		}
		if ($proctor->aktif)
		{
			set_warning('Proctor sudah aktif sebelumnya.');
			redirect($callback);
		}
		$proctor->aktif = TRUE;
		$proctor->validate_data(General_Constants::MODE_OPERATION_UPDATE);
		foreach($proctor->last_delete_validation_errors as $error)
		{
			set_warning($error);
		}
		$this->load->model('m_proctor');
		if ($this->m_proctor->update_proctor($proctor, [], FALSE) === FALSE)
			set_warning('Gagal dalam mengaktifkan proctor.');
		else set_warning('Sukses mengaktifkan proctor: '.$proctor->nama_lengkap);
		redirect($callback);
	}

	public function show_program_sertif()
	{
        // cek permission admin
        $this->redirect_if_not_logged_in();
        $this->redirect_if_not_capable(
            'lihat_list_sertifikasi',
            'Anda tidak diizinkan untuk melihat daftar program sertifikasi.',
            'admin'
        );

        $this->load->model('m_sertifikasi');
        $list_sertifikasi = $this->m_sertifikasi->get_list_sertifikasi();

		$data = [
			'sertifikasi' => $list_sertifikasi,
			'control' => [
				'active_tab' => 'sertifikasi'
			]
		];

		// ada parameter id_sertif
		$id_sertif = $this->input->get('id_sertif');
		if (ctype_digit($id_sertif))
		{
			$data['control']['active_tab'] = 'program';
			$id_sertif = (int)$id_sertif;
            $selected_sertif = array_filter($list_sertifikasi, function($sertif) use ($id_sertif){
            	return $id_sertif === (int)$sertif->id;
			});
            if (count($selected_sertif) === 0)
			{
				set_warning('Sertifikasi tidak ditemukan.');
				redirect(base_url('admin/sertifikasi/program'));
			}
            $selected_sertif = reset($selected_sertif);
            $selected_sertif->load_list_program();
			$data['selected_sertif'] = $selected_sertif;
		}
		$this->load->view('admin/program_sertifikasi', [ 'data' => $data]);
	}

	public function add_sertif()
	{
	    $this->redirect_if_not_capable(
            'tambah_list_sertifikasi',
            'Anda tidak diizinkan untuk menambah sertifikasi baru.',
            'admin/sertifikasi/program'
        );

	    load_data_class('Sertifikasi');
	    $sertif = new D_Sertifikasi();
	    $sertif->nama = $this->input->post('nama_sertif');
		$sertif->deskripsi = $this->input->post('deskripsi');
		$sertif->link_template_sertifikat = $this->input->post('link_template_sertifikat');

		// upload logo sertifikasi
		if (empty($_FILES['foto']) || trim($_FILES['foto']['name']) === '')
		{
			set_warning('Logo sertifikasi wajib diberikan.');
			redirect(base_url('admin/sertifikasi/program'));
		}
		if($sertif->upload_logo('foto') === FALSE)
		{
			set_warning('Gagal memproses logo sertifikasi.');
			redirect(base_url('admin/sertifikasi/program'));
		}
		$this->load->model('m_sertifikasi');
		if ($this->m_sertifikasi->add_new_sertif($sertif) === FALSE)
		{
			set_warning('Gagal manambahkan sertifikasi.');
			// karena gagal, hapus logo yang sudah terlanjur diupload
			$sertif->hapus_logo();
		}
		redirect(base_url('admin/sertifikasi/program'));
	}

	public function add_program_sertif()
	{
	    $this->redirect_if_not_capable(
            'tambah_list_sertifikasi',
            'Anda tidak diizinkan untuk menambah sertifikasi maupun program baru.',
            'admin/sertifikasi/program'
        );
	    $callback = base_url('admin/sertifikasi/program');

		$this->load->model('m_sertifikasi');
        $id_sertif = $this->input->post('id_sertif');
		if (empty($id_sertif) || $this->m_sertifikasi->is_sertif_exists($id_sertif) === FALSE)
		{
			set_warning('Sertifikasi tidak valid.');
			redirect($callback);
		}

		load_data_class('Program');
		$program = new D_Program();
		$program->id_sertif = $id_sertif;
        $program->nama_program = $this->input->post('nama_program');
		$program->link_assesment = $this->input->post('link_assesment');
        $program->min_skor = $this->input->post('min_skor');
		$program->max_skor = $this->input->post('max_skor');

		$callback = base_url('admin/sertifikasi/program?id_sertif='.$id_sertif);
		if (!isset($_FILES['logo']) || trim($_FILES['logo']['name']) === '')
		{
			set_warning('Logo program sertifikasi tidak valid.');
			redirect($callback);
		}

		if($program->upload_logo('logo') === FALSE)
        {
            set_warning('Gagal mengupload logo program.');
			redirect($callback);
        }

		if (isset($_FILES['modul']) && trim($_FILES['modul']['name']) !== '')
		{
			if ($program->upload_modul('modul') ===  FALSE)
			{
				set_warning('Gagal dalam mengupload file modul program.');
				// hapus logo yang sudah terupload
				$program->hapus_logo();
				redirect($callback);
			}
		}

		$this->load->model('m_program');
		if ($this->m_program->add_new_program($program) === FALSE)
		{
			set_warning('Gagal dalam menyimpan data program di database.');
			// hapus logo dan modul yang sudah terupload
			$program->hapus_logo();
			if (!empty($program->file_modul)) $program->hapus_modul();
			redirect($callback);
		}
		redirect($callback);
	}

	public function update_sertifikasi()
	{
	    $this->redirect_if_not_capable(
            'edit_list_sertifikasi',
            'Anda tidak diizinkan untuk mengubah data sertifikasi.',
            'admin/sertifikasi/program'
        );
		$id = $this->input->post('id');

		// cek apakah sertifikasi betulan ada
		$this->load->model('m_sertifikasi');
		if (
			empty($id) ||
			$this->m_sertifikasi->is_sertif_exists($id) === FALSE
		)
		{
			set_warning('Sertifikasi tidak ditemukan.');
			redirect(base_url('admin/sertifikasi/program'));
		}

		load_data_class('Sertifikasi');
		$existing_sertif = new D_Sertifikasi($id);
		$updated_sertif = new D_Sertifikasi();
		$updated_sertif->id = $existing_sertif->id;
		$updated_sertif->nama = $this->input->post('nama');
        $updated_sertif->deskripsi = $this->input->post('deskripsi');
		$updated_sertif->link_template_sertifikat = $this->input->post('link_template_sertifikat');

		$upload_berhasil = FALSE;
		if (isset($_FILES['logo']) && trim($_FILES['logo']['name']) !== '')
		{
			$upload_berhasil = $updated_sertif->upload_logo('logo');
			if ($upload_berhasil === FALSE)
			{
				set_warning('Logo tidak diubah karena gagal dalam mengupload logo baru.');
				$updated_sertif->file_logo = $existing_sertif->file_logo;
			}
		}
		else $updated_sertif->file_logo = $existing_sertif->file_logo;

		if ($this->m_sertifikasi->update_sertif($updated_sertif) === FALSE)
		{
			set_warning('Gagal dalam mengubah data sertifikasi');
			// hapus file yang terlanjur diupload
			if( $upload_berhasil ) $updated_sertif->hapus_logo();
			redirect(base_url('admin/sertifikasi/program'));
		}
		// hapus file lama
		if( $upload_berhasil ) $existing_sertif->hapus_logo();
		redirect(base_url('admin/sertifikasi/program'));
	}

	public function delete_sertifikasi()
	{
	    $this->redirect_if_not_capable(
            'hapus_list_sertifikasi',
            'Anda tidak diizinkan untuk menghapus data sertifikasi dan program.',
            'admin/sertifikasi/program'
        );
		load_data_class('Sertifikasi');
		$this->load->model('m_sertifikasi');

		load_data_class('Program');
		$this->load->model('m_program');

		$id = $this->input->post('id');
		if (empty($id) || $this->m_sertifikasi->is_sertif_exists($id) === FALSE)
		{
			set_warning('Sertifikasi tidak ditemukan.');
			redirect(base_url('admin/sertifikasi/program'));
		}
		$sertif = new D_Sertifikasi($id);
		if ($sertif->pernah_diadakan_kegiatan() === FALSE)
		{
			$sertif->load_list_program();
			if ($this->m_sertifikasi->delete_sertif($sertif) === FALSE)
			{
				set_warning('Gagal menghapus sertifikasi dan program.');
				redirect(base_url('admin/sertifikasi/program'));
			}
			$sertif->hapus_logo();
			foreach($sertif->list_program as $program)
			{
				$program->hapus_logo();
				$program->hapus_modul();
			}
			set_warning('Sertifikasi dan program berhasil dihapus.');
			redirect(base_url('admin/sertifikasi/program'));
		}
		set_warning('Sertifikasi tidak dapat dihapus, karena sudah pernah diadakan.');
		redirect(base_url('admin/sertifikasi/program'));
	}

	public function update_program()
	{
	    $this->redirect_if_not_capable(
            'edit_list_sertifikasi',
            'Anda tidak diizinkan untuk mengubah data sertifikasi dan program.',
            'admin/sertifikasi/program'
        );
		$callback = base_url('admin/sertifikasi/program');
        $id_program = $this->input->post('id');
        $this->load->model('m_program');
		if (!ctype_digit($id_program) || $this->m_program->is_program_exists($id_program) === FALSE)
		{
			set_warning('Program tidak valid.');
			redirect($callback);
		}

		load_data_class('Program');
		$existing_program = new D_Program($id_program);

		$updated_program = new D_Program();
		$updated_program->id = $existing_program->id;
		$updated_program->id_sertif = $existing_program->id_sertif;
		$updated_program->nama_program = $this->input->post('nama_program');
		$updated_program->link_assesment = $this->input->post('link_assesment');
		$updated_program->min_skor = $this->input->post('min_skor');
		$updated_program->max_skor = $this->input->post('max_skor');

		$callback = base_url('admin/sertifikasi/program?id_sertif='.$existing_program->id_sertif);
		// cek apakah modul diberikan atau tidak
		if (!empty($this->input->post('ubah_modul')) && isset($_FILES['modul']) && trim($_FILES['modul']['name']) !== '')
		{
			if ($updated_program->upload_modul('modul') === FALSE)
            {
				$updated_program->file_modul = $existing_program->file_modul;
                set_warning('Gagal dalam mengupload file modul program.');
                redirect($callback);
            }
		}
		else $updated_program->file_modul = $existing_program->file_modul;
		// cek apakah logo diberikan atau tidak
		if (!empty($this->input->post('ubah_logo')) && isset($_FILES['logo']) && trim($_FILES['logo']['name']) !== '')
		{
			if ($updated_program->upload_logo('logo') === FALSE)
            {
            	$updated_program->file_logo = $existing_program->file_logo;
                set_warning('Gagal dalam mengupload file logo program.');
				redirect($callback);
            }
		}
		else $updated_program->file_logo = $existing_program->file_logo;

		if ($this->m_program->update_program($updated_program) === FALSE)
		{
			set_warning('Gagal dalam menyimpan data di database.');
			// cek apakah file modul dan file logo sudah terlanjur diupload
			if ($updated_program->file_modul !== $existing_program->file_modul)
				$updated_program->hapus_modul();
			if ($updated_program->file_logo !== $existing_program->file_logo)
				$updated_program->hapus_logo();
			redirect($callback);
		}
		// cek hapus file lama
		if ($updated_program->file_modul !== $existing_program->file_modul)
			$existing_program->hapus_modul();
		if ($updated_program->file_logo !== $existing_program->file_logo)
			$existing_program->hapus_logo();
		redirect($callback);
	}

	public function delete_program()
	{
	    $this->redirect_if_not_capable(
            'hapus_list_sertifikasi',
            'Anda tidak diizinkan untuk menghapus program sertifikasi.',
            'admin/sertifikasi/program'
        );

		$callback = base_url('admin/sertifikasi/program');
		$this->load->model('m_program');
        $id = $this->input->post('id');
		if (!ctype_digit($id) || $this->m_program->is_program_exists($id) === FALSE)
		{
			set_warning('Program tidak valid.');
			redirect($callback);
		}
		load_data_class('Program');
		$program = new D_Program($id);

		$callback = base_url('admin/sertifikasi/program?id_sertif='.$program->id_sertif);
		if ($program->pernah_diadakan_kegiatan() === FALSE)
		{
			if ($this->m_program->delete_program($program) === FALSE)
			{
				set_warning('Gagal dalam menghapus program.');
				redirect($callback);
			}
			// hapus file modul dan logo
			$program->hapus_modul();
			$program->hapus_logo();
			redirect($callback);
		}
		set_warning('Program tidak dihapus karena sudah pernah diadakan kegiatan.');
		redirect($callback);
	}

	public function show_all_kegiatan()
	{
		$this->redirect_if_not_logged_in();
        $this->redirect_if_not_capable(
            'lihat_kegiatan_sertifikasi',
            'Anda tidak diizinkan untuk melihat daftar kegiatan sertifikasi.',
            'admin'
        );
		$this->load->model("m_kegiatan");
		$list_kegiatan_before_registrasi = $this->m_kegiatan->get_kegiatan_before_registrasi();
		$list_kegiatan_in_registrasi = $this->m_kegiatan->get_kegiatan_in_registrasi();
		$list_kegiatan_before_pelaksanaan = $this->m_kegiatan->get_kegiatan_before_pelaksanaan();
		$list_kegiatan_in_pelaksanaan = $this->m_kegiatan->get_kegiatan_in_pelaksanaan();
		$list_kegiatan_after_pelaksanaan = $this->m_kegiatan->get_kegiatan_after_pelaksanaan();

		foreach ($list_kegiatan_before_registrasi as $kegiatan) {
			$kegiatan->load_sertifikasi();
		}
		foreach ($list_kegiatan_in_registrasi as $kegiatan) {
			$kegiatan->load_sertifikasi();
			$kegiatan->load_kelompok_training();
			$kegiatan->load_kelompok_ujian();
		}
		foreach ($list_kegiatan_before_pelaksanaan as $kegiatan) {
			$kegiatan->load_sertifikasi();
			$kegiatan->load_kelompok_training();
			$kegiatan->load_kelompok_ujian();
		}
		foreach ($list_kegiatan_in_pelaksanaan as $kegiatan) {
			$kegiatan->load_sertifikasi();
			$kegiatan->load_kelompok_training();
			$kegiatan->load_kelompok_ujian();
		}
		foreach ($list_kegiatan_after_pelaksanaan as $kegiatan) {
			$kegiatan->load_sertifikasi();
			$kegiatan->load_kelompok_training();
			$kegiatan->load_kelompok_ujian();
		}

		$data = [
		    'list_kegiatan_before_registrasi' => $list_kegiatan_before_registrasi,
			'list_kegiatan_in_registrasi' => $list_kegiatan_in_registrasi,
			'list_kegiatan_before_pelaksanaan' => $list_kegiatan_before_pelaksanaan,
			'list_kegiatan_in_pelaksanaan' => $list_kegiatan_in_pelaksanaan,
			'list_kegiatan_after_pelaksanaan' => $list_kegiatan_after_pelaksanaan
        ];

		$this->load->view('admin/kegiatan_sertifikasi', ['data' => $data]);
	}

	public function show_add_kegiatan()
	{
		$this->redirect_if_not_capable(
            Permissions::TAMBAH_KEGIATAN_SERTIFIKASI,
            'Anda tidak diizinkan untuk menambah entry kegiatan sertifikasi.',
            'admin/sertifikasi/kegiatan'
        );
		$this->load->model('m_sertifikasi');
		$list_sertifikasi = $this->m_sertifikasi->get_list_sertifikasi();
		foreach ($list_sertifikasi as $s)
		{
			$s->load_list_program();
		}
		$data = [
			'list_sertifikasi' => $list_sertifikasi
		];
		$this->load->view('admin/add_kegiatan', ['data'=>$data]);
	}

	public function add_kegiatan()
    {
        // cek permission admin
        $this->redirect_if_not_capable(
            Permissions::TAMBAH_KEGIATAN_SERTIFIKASI,
            'Anda tidak diizinkan untuk menambah kegiatan sertifikasi.',
            'admin/sertifikasi/kegiatan/add_kegiatan'
        );
		$callback_fail = base_url('admin/sertifikasi/kegiatan/add_kegiatan');

        load_data_class('Kegiatan');
        $kegiatan = new D_Kegiatan();
        $kegiatan->nama_kegiatan = $this->input->post('nama_kegiatan');
		$kegiatan->biaya_t_u = $this->input->post('biaya_t_u');
		$kegiatan->biaya_u = $this->input->post('biaya_u');

		$kegiatan->dibuka_untuk = $this->input->post('dibuka_untuk');
		$kegiatan->id_sertifikasi = $this->input->post('id_sertifikasi');

        // id program harus dalam bentuk array, dan tidak boleh kosong
        $list_id_program = $this->input->post('id_program');
        if (!is_array($list_id_program))
        {
            set_warning('Program sertifikasi yang dipilih tidak valid.');
            redirect($callback_fail);
        }
        foreach($list_id_program as $id)
		{
			if (!ctype_digit($id))
			{
				set_warning('Program sertifikasi yang dipilih tidak valid.');
				redirect($callback_fail);
			}
		}
		foreach($list_id_program as $k_id => $id)
		{
			$list_id_program[$k_id] = (int)$id;
		}
		$list_id_program = array_unique($list_id_program);

        $kegiatan->load_sertifikasi();
        $kegiatan->sertifikasi->load_list_program();
        /**
		 * @var D_Program $program
         * */
		$id_program = [];
        foreach($kegiatan->sertifikasi->list_program as $program)
		{
			$id_program[] = (int)$program->id;
		}
		foreach($list_id_program as $selected_id)
		{
			if (!in_array( $selected_id, $id_program))
			{
				set_warning('Program sertifikasi yang dipilih tidak valid.');
				redirect($callback_fail);
			}
		}

		$kegiatan->program_kegiatan = [];
		foreach($list_id_program as $selected_id)
		{
			$program_kegiatan = new D_Program_Kegiatan();
			$program_kegiatan->id_program = $selected_id;
			$kegiatan->program_kegiatan[] = $program_kegiatan;
		}

		$kegiatan->registrasi_dibuka = !empty($this->input->post('pendaftaran_dibuka'));
		$kegiatan->deskripsi = $this->input->post('deskripsi');
		$kegiatan->keterangan_training = $this->input->post('keterangan_training');
		$kegiatan->keterangan_ujian = $this->input->post('keterangan_ujian');

		$tanggal_awal_registrasi = $this->input->post('awal_regis_date');
		$waktu_awal_registrasi = $this->input->post('awal_regis_time');
        if (valid_date_time($tanggal_awal_registrasi, 'Y-m-d') &&
            valid_date_time($waktu_awal_registrasi, 'H:i:s'))
        {
			$kegiatan->awal_registrasi = DateTime::createFromFormat(
				'Y-m-d H:i:s',
				$tanggal_awal_registrasi.' '.$waktu_awal_registrasi
			);
        }

		$tanggal_akhir_registrasi = $this->input->post('selesai_regis_date');
		$waktu_akhir_registrasi = $this->input->post('selesai_regis_time');
		if (valid_date_time($tanggal_akhir_registrasi, 'Y-m-d') &&
			valid_date_time($waktu_akhir_registrasi, 'H:i:s'))
		{
			$kegiatan->akhir_registrasi = DateTime::createFromFormat(
				'Y-m-d H:i:s',
				$tanggal_akhir_registrasi.' '.$waktu_akhir_registrasi
			);
		}

        // date awal persiapan
        $awal_persiapan = $this->input->post('awal_persiapan');
        if (!valid_date_time($awal_persiapan, 'Y-m-d'))
        {
            set_warning('Tanggal awal persiapan tidak valid.');
			redirect($callback_fail);
        }
        $kegiatan->awal_persiapan = DateTime::createFromFormat('Y-m-d', $awal_persiapan);

        // date akhir persiapan
        $akhir_persiapan = $this->input->post('selesai_persiapan');
        if (!valid_date_time($akhir_persiapan, 'Y-m-d'))
        {
            set_warning('Tanggal akhir persiapan tidak valid.');
			redirect($callback_fail);
        }
		$kegiatan->akhir_persiapan = DateTime::createFromFormat('Y-m-d', $akhir_persiapan);

        $awal_pelaporan = $this->input->post('awal_pelaporan');
        if (!valid_date_time($awal_pelaporan, 'Y-m-d'))
        {
            set_warning('Tanggal awal pelaporan tidak valid.');
			redirect($callback_fail);
        }
		$kegiatan->awal_pelaporan = DateTime::createFromFormat('Y-m-d', $awal_pelaporan);

        $akhir_pelaporan = $this->input->post('selesai_pelaporan');
        if (!valid_date_time($akhir_pelaporan, 'Y-m-d'))
        {
            set_warning('Tanggal akhir pelaporan tidak valid.');
			redirect($callback_fail);
        }
		$kegiatan->akhir_pelaporan = DateTime::createFromFormat('Y-m-d', $akhir_pelaporan);

		if ($kegiatan->dibuka_untuk !== General_Constants::ITPLN)
		{
			// batas upload bukti bayar
			if (!($kegiatan->biaya_t_u === 0 && $kegiatan->biaya_u === 0))
			{
				$batas_upload_bukti_bayar = [
					'date' => $this->input->post('batas_upload_bukti_bayar_date'),
					'time' => $this->input->post('batas_upload_bukti_bayar_time')
				];
				if (
					!valid_date_time($batas_upload_bukti_bayar['date'], 'Y-m-d') ||
					!valid_date_time($batas_upload_bukti_bayar['time'], 'H:i:s')
				)
				{
					set_warning('Tanggal dan waktu batas upload bukti bayar tidak valid.');
					redirect($callback_fail);
				}

				$kegiatan->batas_upload_bukti_bayar = DateTime::createFromFormat(
					'Y-m-d H:i:s',
					$batas_upload_bukti_bayar['date'].' '.$batas_upload_bukti_bayar['time']
				);
			}

			// kriteria peserta
			$kriteria_peserta = $this->input->post('kriteria_peserta');
			if (empty($kriteria_peserta)) $kriteria_peserta = json_encode([]);
			$kegiatan->kriteria_registrasi = new D_Kriteria_Registrasi($kriteria_peserta, $kegiatan->dibuka_untuk);

			// kriteria peserta yang boleh ujian saja
			$kriteria_peserta_boleh_ujian_saja = $this->input->post('kriteria_peserta_boleh_ujian_saja');
			if (empty($kriteria_peserta_boleh_ujian_saja)) $kriteria_peserta_boleh_ujian_saja = json_encode([]);
			$kegiatan->kriteria_peserta_boleh_ujian_saja = new D_Kriteria_Peserta_Ujian_Saja($kriteria_peserta_boleh_ujian_saja, $kegiatan->dibuka_untuk);

			// kriteria diskon peserta
			$kriteria_diskon = $this->input->post('kriteria_diskon');
			if (empty($kriteria_diskon)) $kriteria_diskon = json_encode([]);
			$kegiatan->kriteria_diskon = new D_Kriteria_Diskon($kriteria_diskon, $kegiatan->dibuka_untuk);
		}

		$kegiatan->link_grup = $this->input->post('link_grup');

        $callback_fail = base_url('admin/sertifikasi/kegiatan/add_kegiatan');
        $this->load->model('m_kegiatan');
        if ($this->m_kegiatan->add_new_kegiatan($kegiatan) === FALSE)
        {
            set_warning('Terjadi kesalahan dalam menambahkan kegiatan.');
			redirect($callback_fail);
        }
        redirect(base_url("admin/sertifikasi/kegiatan/".$kegiatan->id."/detail"));
    }

    public function show_detail_kegiatan($id)
    {
        $this->redirect_if_not_logged_in();
        $this->redirect_if_not_capable(
            Permissions::LIHAT_KEGIATAN_SERTIFIKASI,
            'Anda tidak diizinkan untuk melihat detail kegiatan sertifikasi.',
            'admin');
        $callback_error = base_url('admin/sertifikasi/kegiatan');
        $this->load->model("m_kegiatan");
		if ($this->m_kegiatan->is_id_kegiatan_exists($id) === FALSE)
		{
			set_warning('Kegiatan sertifikasi tidak dapat ditemukan.');
			redirect($callback_error);
		}
		$list_kegiatan_aktif = $this->m_kegiatan->get_kegiatan_active();
		$selected_kegiatan = array_filter($list_kegiatan_aktif, function($keg) use ($id){
			return (int)$id === (int)$keg->id;
		});
		if (empty($selected_kegiatan))
		{
			set_warning('Anda hanya dapat melihat detail kegiatan yang masih dilaksanakan.');
			redirect($callback_error);
		}
		/** @var D_Kegiatan $selected_kegiatan */
		$selected_kegiatan = reset($selected_kegiatan);
        $kegiatan = $selected_kegiatan;

        $kegiatan->load_sertifikasi();
        $kegiatan->sertifikasi->load_list_program();
        $kegiatan->load_list_program();
        $kegiatan->load_kelompok_training();
        $kegiatan->load_kelompok_ujian();
        $kegiatan->load_list_pendaftaran();
        $kegiatan->load_list_klaim_dana();
		if ($kegiatan->dibuka_untuk === General_Constants::ITPLN)
		{
			$kegiatan->load_list_peserta_kegiatan_itpln();
		}
        if (admin_capable(Permissions::LIHAT_KEUANGAN_KEGIATAN_SERTIFIKASI))
		{
			$kegiatan->load_list_pembayaran();
		}
        $kegiatan->load_list_peserta();

        $data = [
            'kegiatan' => $kegiatan,
			'history' => FALSE
        ];

         $this->load->view('admin/detail_kegiatan', ['data' => $data]);
    }

	public function ubah_data_registrasi($id_kegiatan)
	{
		$this->redirect_if_not_capable(
			Permissions::EDIT_KEGIATAN_SERTIFIKASI,
			'Anda tidak diizinkan untuk mengubah detail kegiatan sertifikasi.',
			'admin');
		$callback_error = base_url('admin/sertifikasi/kegiatan');
		$this->load->model("m_kegiatan");
		if ($this->m_kegiatan->is_id_kegiatan_exists($id_kegiatan) === FALSE)
		{
			set_warning('Kegiatan sertifikasi tidak dapat ditemukan.');
			redirect($callback_error);
		}
		$callback_error = base_url('admin/sertifikasi/kegiatan/'.$id_kegiatan.'/detail?tab=registrasi');
		$id_pendaftaran = $this->input->post('id');
		if (!ctype_digit($id_pendaftaran) || $this->m_kegiatan->is_id_pendaftaran_exists($id_pendaftaran) === FALSE)
		{
			set_warning('Data registrasi tidak dapat ditemukan.');
			redirect($callback_error);
		}
		load_data_class('Kegiatan');
		$existing_pendaftaran = new D_Pendaftaran_Kegiatan($id_pendaftaran);
		$pendaftaran = clone $existing_pendaftaran;
		$pendaftaran->jenis = $this->input->post('jenis');
		$pendaftaran->id_program_kegiatan = $this->input->post('id_program_kegiatan');
		$pendaftaran->diskon = $this->input->post('diskon');
		// jika program user diubah, maka kelompoknya otomatis diubah ke NULL
		if ($this->m_kegiatan->update_registrasi($pendaftaran, (int)$existing_pendaftaran->id_program_kegiatan !== (int)$pendaftaran->id_program_kegiatan) === FALSE)
		{
			set_warning('Gagal update data registrasi1.');
		}
		redirect($callback_error);
    }

	public function hapus_data_registrasi()
	{
		$this->redirect_if_not_capable(
			Permissions::EDIT_KEGIATAN_SERTIFIKASI,
			'Anda tidak diizinkan untuk mengubah data kegiatan sertifikasi.',
			'admin');
		$callback_error = base_url('admin/sertifikasi/kegiatan');
		$id_pendaftaran = $this->input->post('id');
		$this->load->model('m_kegiatan');
		if (!ctype_digit($id_pendaftaran) || $this->m_kegiatan->is_id_pendaftaran_exists($id_pendaftaran) === FALSE)
		{
			set_warning('Data pendaftaran tidak dapat ditemukan.');
			redirect($callback_error);
		}
		load_data_class('Kegiatan');
		$pendaftaran = new D_Pendaftaran_Kegiatan($id_pendaftaran);
		$callback_error = base_url('admin/sertifikasi/kegiatan/'.$pendaftaran->id_kegiatan.'/detail?tab=registrasi');
		if ($pendaftaran->approved)
		{
			set_warning('Data registrasi tidak dapat dihapus, karena sudah di approved.');
			redirect($callback_error);
		}
		if ($pendaftaran->pernah_upload_bukti_bayar())
		{
			set_warning('Data registrasi tidak dapat dihapus, karena user sudah upload bukti bayar.');
			redirect($callback_error);
		}
		if ($pendaftaran->ada_sertifikat_keikutsertaan())
		{
			set_warning('Data registrasi tidak dapat dihapus, karena sudah ada sertifikat keikutsertaan.');
			redirect($callback_error);
		}
		if ($this->m_kegiatan->hapus_data_registrasi($pendaftaran) === FALSE)
		{
			set_warning('Gagal menghapus data registrasi.');
			redirect($callback_error);
		}
		redirect($callback_error);
    }

	public function tambah_peserta_kegiatan($id_kegiatan)
	{
		$this->redirect_if_not_capable(
			Permissions::EDIT_KEGIATAN_SERTIFIKASI,
			'Anda tidak diizinkan untuk mengubah detail kegiatan sertifikasi.',
			'admin');
		$callback_error = base_url('admin/sertifikasi/kegiatan');
		$this->load->model("m_kegiatan");
		if ($this->m_kegiatan->is_id_kegiatan_exists($id_kegiatan) === FALSE)
		{
			set_warning('Kegiatan sertifikasi tidak dapat ditemukan.');
			redirect($callback_error);
		}
		$callback_error = base_url('admin/sertifikasi/kegiatan/'.$id_kegiatan.'/detail?tab=peserta');
		load_data_class('Kegiatan');
		$kegiatan = new D_Kegiatan($id_kegiatan);
		$kegiatan->load_list_program();
		if ($kegiatan->dibuka_untuk === General_Constants::ITPLN)
		{
			// tambahkan list email dan program peserta
			if (!empty($_FILES['file_list_peserta']) && $_FILES['file_list_peserta']['error'] === UPLOAD_ERR_OK)
			{
				$fh = fopen($_FILES['file_list_peserta']['tmp_name'], 'r+');
				$lines = [];
				while( ($row = fgetcsv($fh)) !== FALSE ) {
					$lines[] = $row;
				}
				fclose($fh);
				$kegiatan->load_list_peserta_kegiatan_itpln();
				$list_peserta = [];
				foreach($lines as $no => $row_peserta)
				{
					$peserta = new D_Peserta_Kegiatan_ITPLN();
					$email = $row_peserta[0];
					$nama_program = $row_peserta[1];
					$email = trim(strtolower($email));
					$email = utf8_decode(str_replace("\xEF\xBB\xBF",'',$email));
					if (filter_var($email, FILTER_VALIDATE_EMAIL) === FALSE)
					{
						var_dump($email);
						set_warning('Email tidak valid (baris '.$no.').');
						return;
						// redirect($callback_error);
					}
					$peserta->email = $email;
					if (!is_string($nama_program))
					{
						set_warning('Nama program tidak valid (baris '.$no.').');
						redirect($callback_error);
					}
					$nama_program = trim(strtolower($nama_program));
					$nama_program = utf8_decode(str_replace("\xEF\xBB\xBF",'',$nama_program));
					$nama_program_valid = FALSE;
					foreach($kegiatan->program_kegiatan as $program)
					{
						if (trim(strtolower($program->nama_program)) === $nama_program)
						{
							$peserta->id_program_kegiatan = $program->id_program_kegiatan;
							$nama_program_valid = TRUE;
							break;
						}
					}
					if (!$nama_program_valid)
					{
						set_warning('Nama program tidak valid (baris '.$no.').');
						redirect($callback_error);
					}
					$email_already_exists = FALSE;
					foreach($kegiatan->list_peserta_kegiatan_itpln as $p)
					{
						if (trim(strtolower($p->email)) === $email)
							$email_already_exists = TRUE;
					}
					if (!$email_already_exists) $list_peserta[] = $peserta;
				}
				if ($kegiatan->append_list_peserta_kegiatan_itpln($list_peserta) === FALSE)
				{
					set_warning('Terjadi kesalahan dalam memproses file peserta kegiatan.');
				}
				redirect($callback_error);
			}
		}
		elseif($kegiatan->dibuka_untuk === General_Constants::UMUM)
		{
			$array_email = $this->input->post('email');
			$array_jenis = $this->input->post('jenis');
			$array_id_program_kegiatan = $this->input->post('id_program_kegiatan');
			if (!is_array($array_email) || !is_array($array_jenis) || !is_array($array_id_program_kegiatan))
			{
				set_warning("Data yang diberikan tidak valid.");
				redirect($callback_error);
			}
			load_data_class('Kegiatan');
			load_data_class('User');
			$this->load->model('m_user');
			$jumlah_pendaftaran = min(count($array_email), count($array_jenis), count($array_id_program_kegiatan));
			for($i= 0; $i < $jumlah_pendaftaran; $i++)
			{
				$pendaftaran = new D_Pendaftaran_Kegiatan();
				$pendaftaran->id_kegiatan = $id_kegiatan;
				$pendaftaran->jenis = $array_jenis[$i];
				$pendaftaran->id_program_kegiatan = $array_id_program_kegiatan[$i];
				$pendaftaran->id_user = $this->m_user->get_id_user_from_email($array_email[$i]);
				if ($this->m_kegiatan->registrasi($pendaftaran) === FALSE)
				{
					set_warning("Gagal registrasi : ".$array_email[$i].".");
				}
			}
		}
		elseif($kegiatan->dibuka_untuk === General_Constants::MAHASISWA)
		{
			$array_email = $this->input->post('email');
			$array_jenis = $this->input->post('jenis');
			$array_id_program_kegiatan = $this->input->post('id_program_kegiatan');
			if (!is_array($array_email) || !is_array($array_jenis) || !is_array($array_id_program_kegiatan))
			{
				set_warning("Data yang diberikan tidak valid.");
				redirect($callback_error);
			}
			load_data_class('Kegiatan');
			load_data_class('User');
			$this->load->model('m_user');
			$jumlah_pendaftaran = min(count($array_email), count($array_jenis), count($array_id_program_kegiatan));
			for($i= 0; $i < $jumlah_pendaftaran; $i++)
			{
				$pendaftaran = new D_Pendaftaran_Kegiatan();
				$pendaftaran->id_kegiatan = $id_kegiatan;
				$pendaftaran->jenis = $array_jenis[$i];
				$pendaftaran->id_program_kegiatan = $array_id_program_kegiatan[$i];
				$pendaftaran->id_user = $this->m_user->get_id_user_from_email($array_email[$i]);
				if ($this->m_kegiatan->registrasi($pendaftaran) === FALSE)
				{
					set_warning("Gagal registrasi : ".$array_email[$i].".");
				}
			}
		}
		redirect($callback_error);
	}

	public function download_csv_program_kegiatan($id_kegiatan)
	{
		$this->redirect_if_not_logged_in();
		$this->redirect_if_not_capable(
			Permissions::LIHAT_KEGIATAN_SERTIFIKASI,
			'Anda tidak diizinkan untuk melihat detail kegiatan sertifikasi.',
			'admin');

		$callback_error = base_url('admin/sertifikasi/kegiatan');
		$this->load->model("m_kegiatan");
		if ($this->m_kegiatan->is_id_kegiatan_exists($id_kegiatan) === FALSE)
		{
			set_warning('Kegiatan sertifikasi tidak dapat ditemukan.');
			redirect($callback_error);
		}
		load_data_class('Kegiatan');
		$kegiatan = new D_Kegiatan($id_kegiatan);
		$kegiatan->load_list_program();

		// file name
		$filename = 'list_program_'.$kegiatan->nama_kegiatan.'.csv';
		header("Content-type: application/csv");
		header('Content-Description: File Transfer');
		header("Content-Disposition: attachment; filename=$filename");
		// file creation
		$file = fopen('php://output', 'w');
		foreach ($kegiatan->program_kegiatan as $program)
		{
			fputcsv($file, [$program->nama_program]);
		}
		fclose($file);
		exit;
    }

	public function download_peserta_kegiatan($id_kegiatan)
    {
        $this->redirect_if_not_capable(
            Permissions::LIHAT_KEGIATAN_SERTIFIKASI,
            'Anda tidak diizinkan untuk melihat detail kegiatan sertifikasi.',
            'admin/sertifikasi/kegiatan'
        );
		$this->load->model('m_kegiatan');
		if ($this->m_kegiatan->is_id_kegiatan_exists($id_kegiatan) === FALSE)
        {
            set_warning('Kegiatan sertifikasi tidak dapat ditemukan.');
            redirect(base_url('admin/sertifikasi/kegiatan'));
        }
		load_data_class('Kegiatan');
		$kegiatan = new D_Kegiatan($id_kegiatan);
        $filename = 'peserta_'.$kegiatan->nama_kegiatan.'_update_'.time().'.xlsx';

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        if ($kegiatan->dibuka_untuk === General_Constants::MAHASISWA)
        {
            $sheet->setCellValue('A1', 'Email');
            $sheet->setCellValue('B1', 'Angkatan');
            $sheet->setCellValue('C1', 'Jurusan');
            $sheet->setCellValue('D1', 'NIM');
            $sheet->setCellValue('E1', 'Nama Lengkap');
            $sheet->setCellValue('F1', 'Kelompok Training');
			$sheet->setCellValue('G1', 'Kelompok Ujian');
            $sheet->setCellValue('H1', 'Absensi Training 1');
            $sheet->setCellValue('I1', 'Absensi Training 2');
            $sheet->setCellValue('J1', 'Absensi Ujian');
            $sheet->setCellValue('K1', 'Skor Ujian');
            $sheet->setCellValue('L1', 'Status');
        }
        elseif ($kegiatan->dibuka_untuk === General_Constants::UMUM)
        {
            $sheet->setCellValue('A1', 'Email');
            $sheet->setCellValue('B1', 'Nama Lengkap');
            $sheet->setCellValue('C1', 'Kelompok Training');
			$sheet->setCellValue('D1', 'Kelompok Ujian');
            $sheet->setCellValue('E1', 'Absensi Training 1');
            $sheet->setCellValue('F1', 'Absensi Training 2');
            $sheet->setCellValue('G1', 'Absensi Ujian');
            $sheet->setCellValue('H1', 'Skor Ujian');
            $sheet->setCellValue('I1', 'Status');
        }
		elseif ($kegiatan->dibuka_untuk === General_Constants::ITPLN)
		{
			$sheet->setCellValue('A1', 'Email');
			$sheet->setCellValue('B1', 'Nama Lengkap');
			$sheet->setCellValue('C1', 'Bidang');
			$sheet->setCellValue('D1', 'Jabatan');
			$sheet->setCellValue('E1', 'Kelompok Training');
			$sheet->setCellValue('F1', 'Kelompok Ujian');
			$sheet->setCellValue('G1', 'Absensi Training 1');
			$sheet->setCellValue('H1', 'Absensi Training 2');
			$sheet->setCellValue('I1', 'Absensi Ujian');
			$sheet->setCellValue('J1', 'Skor Ujian');
			$sheet->setCellValue('K1', 'Status');
		}

        // autofit kolom yang aktif
        foreach ($sheet->getColumnIterator() as $column) {
            $sheet->getColumnDimension($column->getColumnIndex())->setAutoSize(true);
        }
        $kegiatan->load_list_peserta();
        if ($kegiatan->dibuka_untuk === General_Constants::ITPLN) $kegiatan->load_list_peserta_kegiatan_itpln();
        $row = 2;
		if ($kegiatan->dibuka_untuk === General_Constants::MAHASISWA)
		{
			$list_kode_jurusan = array_keys(config_item('JURUSAN'));
			foreach($kegiatan->list_peserta as $peserta)
			{
				$sheet->setCellValue("A$row", $peserta->email_user);
				$sheet->setCellValue("B$row", $peserta->angkatan_user);
				$sheet->setCellValue("C$row", in_array($peserta->jurusan_user, $list_kode_jurusan) ? config_item('JURUSAN')[$peserta->jurusan_user] : $peserta->jurusan_user);
				$sheet->setCellValue("D$row", $peserta->nim_user);
				$sheet->setCellValue("E$row", $peserta->nama_depan_user.' '.$peserta->nama_belakang_user);
				$sheet->setCellValue("F$row", (empty($peserta->id_kelompok_t) ? "-": $peserta->nama_kelompok_t));
				$sheet->setCellValue("G$row", (empty($peserta->id_kelompok_u) ? "-": $peserta->nama_kelompok_u));
				$sheet->setCellValue("H$row", ($peserta->hadir_training_sesi1)? 'Hadir':'Tidak Hadir' );
				$sheet->setCellValue("I$row", ($peserta->hadir_training_sesi2)? 'Hadir':'Tidak Hadir' );
				$sheet->setCellValue("J$row", ($peserta->hadir_ujian)? 'Hadir':'Tidak Hadir' );
				$sheet->setCellValue("K$row", ($peserta->status_kelulusan === General_Constants::STATUS_PENDING)? 'Pending' : $peserta->skor_ujian );
				if ($peserta->status_kelulusan === General_Constants::STATUS_PENDING)
					$sheet->setCellValue("L$row", 'Pending');
				elseif($peserta->status_kelulusan === General_Constants::STATUS_TIDAK_LULUS)
					$sheet->setCellValue("L$row", 'Tidak Lulus');
				elseif($peserta->status_kelulusan === General_Constants::STATUS_LULUS)
					$sheet->setCellValue("L$row", 'Lulus');
				else $sheet->setCellValue("L$row", '-');
				$row+=1;
			}
		}
		elseif ($kegiatan->dibuka_untuk === General_Constants::UMUM)
		{
			foreach($kegiatan->list_peserta as $peserta)
			{
				$sheet->setCellValue("A$row", $peserta->email_user);
				$sheet->setCellValue("B$row", $peserta->nama_depan_user.' '.$peserta->nama_belakang_user);
				$sheet->setCellValue("C$row", (empty($peserta->id_kelompok_t) ? "-": $peserta->nama_kelompok_t));
				$sheet->setCellValue("D$row", (empty($peserta->id_kelompok_t) ? "-": $peserta->nama_kelompok_t));
				$sheet->setCellValue("E$row", ($peserta->hadir_training_sesi1)? 'Hadir':'Tidak Hadir' );
				$sheet->setCellValue("F$row", ($peserta->hadir_training_sesi2)? 'Hadir':'Tidak Hadir' );
				$sheet->setCellValue("G$row", ($peserta->hadir_ujian)? 'Hadir':'Tidak Hadir' );
				$sheet->setCellValue("H$row", ($peserta->status_kelulusan === General_Constants::STATUS_PENDING)? 'Pending' : $peserta->skor_ujian );
				if ($peserta->status_kelulusan === General_Constants::STATUS_PENDING)
					$sheet->setCellValue("I$row", 'Pending');
				elseif ($peserta->status_kelulusan === General_Constants::STATUS_TIDAK_LULUS)
					$sheet->setCellValue("I$row", 'Tidak Lulus');
				elseif($peserta->status_kelulusan === General_Constants::STATUS_LULUS)
					$sheet->setCellValue("I$row", 'Lulus');
				else $sheet->setCellValue("I$row", '-');
				$row+=1;
			}
		}
		elseif ($kegiatan->dibuka_untuk === General_Constants::ITPLN)
		{
			foreach($kegiatan->list_peserta as $peserta)
			{
				$sheet->setCellValue("A$row", $peserta->email_user);
				$sheet->setCellValue("B$row", $peserta->nama_depan_user.' '.$peserta->nama_belakang_user);
				$sheet->setCellValue("C$row", $peserta->nama_bidang);
				$sheet->setCellValue("D$row", $peserta->nama_jabatan);
				$sheet->setCellValue("E$row", (empty($peserta->id_kelompok_t) ? "-": $peserta->nama_kelompok_t));
				$sheet->setCellValue("F$row", (empty($peserta->id_kelompok_u) ? "-": $peserta->nama_kelompok_u));
				$sheet->setCellValue("G$row", ($peserta->hadir_training_sesi1)? 'Hadir':'Tidak Hadir' );
				$sheet->setCellValue("H$row", ($peserta->hadir_training_sesi2)? 'Hadir':'Tidak Hadir' );
				$sheet->setCellValue("I$row", ($peserta->hadir_ujian)? 'Hadir':'Tidak Hadir' );
				$sheet->setCellValue("J$row", ($peserta->status_kelulusan === General_Constants::STATUS_PENDING)? 'Pending' : $peserta->skor_ujian );
				if ($peserta->status_kelulusan === General_Constants::STATUS_PENDING)
					$sheet->setCellValue("K$row", 'Pending');
				elseif ($peserta->status_kelulusan === General_Constants::STATUS_TIDAK_LULUS)
					$sheet->setCellValue("K$row", 'Tidak Lulus');
				elseif($peserta->status_kelulusan === General_Constants::STATUS_LULUS)
					$sheet->setCellValue("K$row", 'Lulus');
				else $sheet->setCellValue("K$row", '-');
				$row+=1;
			}
			// masukkan data yang belum registrasi
			foreach($kegiatan->list_peserta_kegiatan_itpln as $peserta)
			{
				$sheet->setCellValue("A$row", $peserta->email);
				$sheet->setCellValue("B$row", 'Belum Registrasi');
				$sheet->setCellValue("C$row", 'Belum Registrasi');
				$sheet->setCellValue("D$row", 'Belum Registrasi');
				$sheet->setCellValue("E$row", 'Belum Registrasi');
				$sheet->setCellValue("F$row", 'Belum Registrasi');
				$sheet->setCellValue("G$row", 'Belum Registrasi');
				$sheet->setCellValue("H$row", 'Belum Registrasi');
				$sheet->setCellValue("I$row", 'Belum Registrasi');
				$sheet->setCellValue("J$row", 'Belum Registrasi');
				$sheet->setCellValue("K$row", 'Belum Registrasi');
				$row+=1;
			}
		}

        if ($kegiatan->dibuka_untuk === General_Constants::MAHASISWA)
            $spreadsheet->getActiveSheet()->setAutoFilter('A1:L'.($row-1));
        elseif($kegiatan->dibuka_untuk === General_Constants::UMUM)
            $spreadsheet->getActiveSheet()->setAutoFilter('A1:I'.($row-1));
		elseif($kegiatan->dibuka_untuk === General_Constants::ITPLN)
			$spreadsheet->getActiveSheet()->setAutoFilter('A1:K'.($row-1));

        $writer = new Xlsx($spreadsheet);
        header("Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        header('Content-Description: File Transfer');
        header("Content-Disposition: attachment; filename=$filename");
		try {
			$writer->save('php://output');
		} catch (\PhpOffice\PhpSpreadsheet\Writer\Exception $e) {
			{
				set_warning(sprintf(
					"Gagal export data peserta : %s",
					$e->getMessage()
				));
				redirect(base_url('admin/sertifikasi/kegiatan/'.$id_kegiatan.'/detail'));
			}
		}
	}

	public function download_bukti_bayar_kegiatan($id_kegiatan)
	{
		$this->redirect_if_not_capable(
			Permissions::LIHAT_KEGIATAN_SERTIFIKASI,
			'Anda tidak diizinkan untuk melihat detail kegiatan sertifikasi.',
			'admin/sertifikasi/kegiatan'
		);
		$this->load->model('m_kegiatan');
		if ($this->m_kegiatan->is_id_kegiatan_exists($id_kegiatan) === FALSE)
		{
			set_warning('Kegiatan sertifikasi tidak dapat ditemukan.');
			redirect(base_url('admin/sertifikasi/kegiatan'));
		}
		$callback = base_url('admin/sertifikasi/kegiatan/'.$id_kegiatan.'/detail');
		load_data_class('Kegiatan');
		$kegiatan = new D_Kegiatan($id_kegiatan);
		if ($kegiatan->dibuka_untuk === General_Constants::ITPLN)
		{
			set_warning('Kegiatan yang dibuka untuk internal ITPLN tidak memiliki data bukti bayar.');
			redirect($callback);
		}
		$filename = 'bukti_bayar_'.$kegiatan->nama_kegiatan.'_update_'.time().'.xlsx';
		$kegiatan->load_list_pembayaran();
		$spreadsheet = new Spreadsheet();
		$sheet = $spreadsheet->getActiveSheet();
		if ($kegiatan->dibuka_untuk === General_Constants::MAHASISWA)
		{
			$sheet->setCellValue('A1', 'No');
			$sheet->setCellValue('B1', 'NIM');
			$sheet->setCellValue('C1', 'Angkatan');
			$sheet->setCellValue('D1', 'Prodi');
			$sheet->setCellValue('E1', 'Nama Lengkap');
			$sheet->setCellValue('F1', 'Tanggal');
			$sheet->setCellValue('G1', 'Jam');
			$sheet->setCellValue('H1', 'Bank');
			$sheet->setCellValue('I1', 'A.N');
			$sheet->setCellValue('J1', 'Nominal');
			$sheet->setCellValue('K1', 'Keterangan');
		}
		elseif($kegiatan->dibuka_untuk === General_Constants::UMUM)
		{
			$sheet->setCellValue('A1', 'No');
			$sheet->setCellValue('B1', 'Email');
			$sheet->setCellValue('C1', 'Nama Lengkap');
			$sheet->setCellValue('D1', 'Tanggal');
			$sheet->setCellValue('E1', 'Jam (WIB)');
			$sheet->setCellValue('F1', 'Bank');
			$sheet->setCellValue('G1', 'A.N');
			$sheet->setCellValue('H1', 'Nominal');
			$sheet->setCellValue('I1', 'Keterangan');
		}

		// autofit kolom yang aktif
		foreach ($sheet->getColumnIterator() as $column) {
			$sheet->getColumnDimension($column->getColumnIndex())->setAutoSize(true);
		}

		$row = 2;
		if ($kegiatan->dibuka_untuk === General_Constants::MAHASISWA)
		{
			$no = 1;
			$list_kode_jurusan = array_keys(config_item('JURUSAN'));
			foreach($kegiatan->list_pembayaran as $p)
			{
				$sheet->setCellValue("A$row", $no++);
				$sheet->setCellValue("B$row", $p->nim_user);
				$sheet->setCellValue("C$row", $p->angkatan_user);
				$sheet->setCellValue("D$row", in_array($p->jurusan_user, $list_kode_jurusan ) ? config_item('JURUSAN')[$p->jurusan_user] : $p->jurusan_user);
				$sheet->setCellValue("E$row", $p->nama_depan.' '.$p->nama_belakang);
				$sheet->setCellValue("F$row", $p->waktu_transfer->format('d/m/Y'));
				$sheet->setCellValue("G$row", $p->waktu_transfer->format('H:i:s'));
				$sheet->setCellValue("H$row",
					(array_key_exists($p->bank, config_item('LIST_BANK'))) ?
						config_item('LIST_BANK')[$p->bank] :
						strtoupper($p->bank)
				);
				$sheet->setCellValue("I$row", $p->nama_pengirim );
				$sheet->setCellValue("J$row", $p->nominal_dibayar);
				$sheet->setCellValue("K$row", strtoupper($p->status));
				$row+=1;
			}
			$sheet->setAutoFilter('A1:K'.($row-1));
			$sheet->getStyle('J:J')
				->getNumberFormat()
				->setFormatCode('_("Rp"* #,##0.00_);_("$"* \(#,##0.00\);_("$"* "-"??_);_(@_)');
		}
		elseif ($kegiatan->dibuka_untuk === General_Constants::UMUM)
		{
			$no = 1;
			foreach($kegiatan->list_pembayaran as $p)
			{
				$sheet->setCellValue("A$row", $no++);
				$sheet->setCellValue("B$row", $p->email_user);
				$sheet->setCellValue("C$row", $p->nama_depan.' '.$p->nama_belakang);
				$sheet->setCellValue("D$row", $p->waktu_transfer->format('d/m/Y'));
				$sheet->setCellValue("E$row", $p->waktu_transfer->format('H:i:s'));
				$sheet->setCellValue("F$row",
					(array_key_exists($p->bank, config_item('LIST_BANK'))) ?
						config_item('LIST_BANK')[$p->bank] :
						strtoupper($p->bank)
				);
				$sheet->setCellValue("G$row", $p->nama_pengirim );
				$sheet->setCellValue("H$row", $p->nominal_dibayar);
				$sheet->setCellValue("I$row", strtoupper($p->status));
				$row+=1;
			}
			$sheet->setAutoFilter('A1:I'.($row-1));
			$sheet->getStyle('H:H')
				->getNumberFormat()
				->setFormatCode('_("Rp"* #,##0.00_);_("$"* \(#,##0.00\);_("$"* "-"??_);_(@_)');
		}

		$writer = new Xlsx($spreadsheet);
		header("Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		header('Content-Description: File Transfer');
		header("Content-Disposition: attachment; filename=$filename");
		try {
			$writer->save('php://output');
		} catch (\PhpOffice\PhpSpreadsheet\Writer\Exception $e) {
			{
				set_warning(sprintf(
					"Gagal export data bukti bayar : %s",
					$e->getMessage()
				));
				redirect($callback);
			}
		}
	}

	public function download_registrasi_kegiatan($id_kegiatan)
	{
		$this->redirect_if_not_capable(
			Permissions::LIHAT_KEGIATAN_SERTIFIKASI,
			'Anda tidak diizinkan untuk melihat detail kegiatan sertifikasi.',
			'admin/sertifikasi/kegiatan'
		);
		$callback = base_url('admin/sertifikasi/kegiatan');
		$this->load->model('m_kegiatan');
		if ($this->m_kegiatan->is_id_kegiatan_exists($id_kegiatan) === FALSE)
		{
			set_warning('Kegiatan sertifikasi tidak dapat ditemukan.');
			redirect($callback);
		}
		$callback = base_url('admin/sertifikasi/kegiatan/'.$id_kegiatan.'/detail');
		load_data_class('Kegiatan');
		$kegiatan = new D_Kegiatan($id_kegiatan);
		if ($kegiatan->dibuka_untuk === General_Constants::ITPLN)
		{
			set_warning('Kegiatan yang dibuka untuk internal ITPLN tidak memiliki data registrasi.');
			redirect($callback);
		}
		$kegiatan->load_list_pendaftaran();
		$filename = 'registrasi_'.$kegiatan->nama_kegiatan.'_update_'.time().'.xlsx';
		$spreadsheet = new Spreadsheet();
		$sheet = $spreadsheet->getActiveSheet();
		if ($kegiatan->dibuka_untuk === General_Constants::MAHASISWA)
		{
			$sheet->setCellValue('A1', 'No');
			$sheet->setCellValue('B1', 'Timestamp Daftar');
			$sheet->setCellValue('C1', 'Email');
			$sheet->setCellValue('D1', 'Nama');
			$sheet->setCellValue('E1', 'Angkatan');
			$sheet->setCellValue('F1', 'NIM');
			$sheet->setCellValue('G1', 'Jurusan');
			$sheet->setCellValue('H1', 'Program Dipilih');
			$sheet->setCellValue('I1', 'Jenis Sertifikasi');
			$sheet->setCellValue('J1', 'Biaya Sertifikasi');
			$sheet->setCellValue('K1', 'Nominal yang dibayarkan');
			$sheet->setCellValue('L1', 'Status');
		}
		elseif ($kegiatan->dibuka_untuk === General_Constants::UMUM)
		{
			$sheet->setCellValue('A1', 'No');
			$sheet->setCellValue('B1', 'Timestamp Daftar');
			$sheet->setCellValue('C1', 'Email');
			$sheet->setCellValue('D1', 'Nama');
			$sheet->setCellValue('E1', 'Program Dipilih');
			$sheet->setCellValue('F1', 'Jenis Sertifikasi');
			$sheet->setCellValue('G1', 'Biaya Sertifikasi');
			$sheet->setCellValue('H1', 'Nominal yang dibayarkan');
			$sheet->setCellValue('I1', 'Status');
		}

		// autofit kolom yang aktif
		foreach ($sheet->getColumnIterator() as $column) {
			$sheet->getColumnDimension($column->getColumnIndex())->setAutoSize(true);
		}

		$row = 2;
		if ($kegiatan->dibuka_untuk === General_Constants::MAHASISWA)
		{
			$no = 1;
			$list_kode_jurusan = array_keys(config_item('JURUSAN'));
			foreach($kegiatan->list_pendaftaran as $p)
			{
				$biaya_dasar = $kegiatan->biaya_t_u;
				if ($p->jenis === General_Constants::UJIAN_SAJA)
					$biaya_dasar = $kegiatan->biaya_u;
				$biaya_final = $biaya_dasar-$p->diskon;
				if ($biaya_final < 0) $biaya_final = 0;
				$sheet->setCellValue("A$row", $no++);
				$sheet->setCellValue("B$row", $p->waktu);
				$sheet->setCellValue("C$row", $p->email_user);
				$sheet->setCellValue("D$row", $p->nama_lengkap_user);
				$sheet->setCellValue("E$row", $p->angkatan_user);
				$sheet->setCellValue("F$row", $p->nim_user);
				$sheet->setCellValue("G$row", in_array($p->jurusan_user, $list_kode_jurusan ) ? config_item('JURUSAN')[$p->jurusan_user] : $p->jurusan_user );
				$sheet->setCellValue("H$row", $p->program_yang_dipilih);
				$sheet->setCellValue("I$row", ($p->jenis === General_Constants::TRAINING_DAN_UJIAN) ? "Training & Ujian" : "Ujian Saja" );
				$sheet->setCellValue("J$row", ($biaya_final));
				$sheet->setCellValue("K$row", $p->terbayar);
				$sheet->setCellValue("L$row", ($p->approved) ? "APPROVED" : "NOT APPROVED");
				$row+=1;
			}
			$sheet->setAutoFilter('A1:L'.($row-1));
			$sheet->getStyle('J:J')
				->getNumberFormat()
				->setFormatCode('_("Rp"* #,##0.00_);_("Rp"* \(#,##0.00\);_("Rp"* "-"??_);_(@_)');
			$sheet->getStyle('K:K')
				->getNumberFormat()
				->setFormatCode('_("Rp"* #,##0.00_);_("Rp"* \(#,##0.00\);_("Rp"* "-"??_);_(@_)');
		}
		elseif ($kegiatan->dibuka_untuk === General_Constants::UMUM)
		{
			$no = 1;
			foreach($kegiatan->list_pendaftaran as $p)
			{
				$biaya_dasar = $kegiatan->biaya_t_u;
				if ($p->jenis === General_Constants::UJIAN_SAJA)
					$biaya_dasar = $kegiatan->biaya_u;
				$biaya_final = $biaya_dasar-$p->diskon;
				if ($biaya_final < 0) $biaya_final = 0;
				$sheet->setCellValue("A$row", $no++);
				$sheet->setCellValue("B$row", $p->waktu);
				$sheet->setCellValue("C$row", $p->email_user);
				$sheet->setCellValue("D$row", $p->nama_lengkap_user);
				$sheet->setCellValue("E$row", $p->program_yang_dipilih);
				$sheet->setCellValue("F$row", ($p->jenis === General_Constants::TRAINING_DAN_UJIAN) ? "Training & Ujian" : "Ujian Saja" );
				$sheet->setCellValue("G$row", $biaya_final);
				$sheet->setCellValue("H$row", $p->terbayar);
				$sheet->setCellValue("I$row", ($p->approved) ? "APPROVED" : "NOT APPROVED");
				$row+=1;
			}
			$sheet->setAutoFilter('A1:I'.($row-1));
			$sheet->getStyle('G:G')
				->getNumberFormat()
				->setFormatCode('_("Rp"* #,##0.00_);_("$"* \(#,##0.00\);_("Rp"* "-"??_);_(@_)');
			$sheet->getStyle('H:H')
				->getNumberFormat()
				->setFormatCode('_("Rp"* #,##0.00_);_("$"* \(#,##0.00\);_("Rp"* "-"??_);_(@_)');
		}

		$writer = new Xlsx($spreadsheet);
		header("Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		header('Content-Description: File Transfer');
		header("Content-Disposition: attachment; filename=$filename");
		try {
			$writer->save('php://output');
		} catch (\PhpOffice\PhpSpreadsheet\Writer\Exception $e) {
			{
				set_warning(sprintf(
					"Gagal export data registrasi : %s",
					$e->getMessage()
				));
				redirect(base_url('admin/sertifikasi/kegiatan/'.$id_kegiatan.'/detail?tab=registrasi'));
			}
		}
	}

    public function show_update_kegiatan($id)
    {
        $this->redirect_if_not_capable(
            'edit_kegiatan_sertifikasi',
            'Anda tidak diizinkan untuk mengubah data kegiatan sertifikasi.',
            'admin/sertifikasi/kegiatan');
        $this->load->model('m_kegiatan');
        if ($this->m_kegiatan->is_id_kegiatan_exists($id) === FALSE)
		{
			set_warning('Kegiatan sertifikasi tidak dapat ditemukan.');
			redirect(base_url('admin/sertifikasi/kegiatan'));
		}
        load_data_class('Kegiatan');
        $kegiatan = new D_Kegiatan($id);
        $kegiatan->load_sertifikasi();
        $kegiatan->load_list_program();
        $data = [
            'kegiatan' => $kegiatan
        ];
        $this->load->view('admin/update_kegiatan', ['data' => $data]);
    }

    public function update_kegiatan($id)
	{
		$this->redirect_if_not_capable(
			Permissions::EDIT_KEGIATAN_SERTIFIKASI,
			'Anda tidak diizinkan untuk mengubah data kegiatan sertifikasi.',
			'admin/sertifikasi/kegiatan');
		$callback = base_url('admin/sertifikasi/kegiatan');
		$this->load->model('m_kegiatan');
		if ($this->m_kegiatan->is_id_kegiatan_exists($id) === FALSE) {
			set_warning('Kegiatan sertifikasi tidak dapat ditemukan.');
			redirect($callback);
		}
		load_data_class('Kegiatan');
		$existing_kegiatan = new D_Kegiatan($id);
		$updated_kegiatan = clone $existing_kegiatan;
		$kegiatan_dibuka_untuk_itpln = $existing_kegiatan->dibuka_untuk === General_Constants::ITPLN;

		$updated_kegiatan->nama_kegiatan = $this->input->post('nama_kegiatan');
		if (!$kegiatan_dibuka_untuk_itpln) {
			$updated_kegiatan->biaya_t_u = $this->input->post('biaya_t_u');
			$updated_kegiatan->biaya_u = $this->input->post('biaya_u');
		}
		$updated_kegiatan->deskripsi = $this->input->post('deskripsi');
		$updated_kegiatan->keterangan_training = $this->input->post('keterangan_training');
		$updated_kegiatan->keterangan_ujian = $this->input->post('keterangan_ujian');

		if (!$kegiatan_dibuka_untuk_itpln)
		{
			// pendaftaran dibuka
			if ( !empty($this->input->post('pendaftaran_dibuka')) && !$existing_kegiatan->registrasi_dibuka)
				$updated_kegiatan->registrasi_dibuka = TRUE;
			elseif(empty($this->input->post('pendaftaran_dibuka')) && $existing_kegiatan->registrasi_dibuka)
				$updated_kegiatan->registrasi_dibuka = FALSE;

			// datetime awal registrasi
			if (valid_date_time($this->input->post('awal_regis_date'), 'Y-m-d') &&
				valid_date_time($this->input->post('awal_regis_time'), 'H:i:s')
			)
			{
				$awal_registrasi_new = $this->input->post('awal_regis_date').' '.$this->input->post('awal_regis_time');
				$updated_kegiatan->awal_registrasi = DateTime::createFromFormat('Y-m-d H:i:s', $awal_registrasi_new);
			}
			// datetime akhir registrasi
			if (valid_date_time($this->input->post('selesai_regis_date'), 'Y-m-d') &&
				valid_date_time($this->input->post('selesai_regis_time'), 'H:i:s')
			)
			{
				$akhir_registrasi_new = $this->input->post('selesai_regis_date').' '.$this->input->post('selesai_regis_time');
				$updated_kegiatan->akhir_registrasi = DateTime::createFromFormat('Y-m-d H:i:s', $akhir_registrasi_new);
			}
			// clear batas upload bukti bayar
			// kalau biaya t_u dan u 0
			if (is_numeric($updated_kegiatan->biaya_t_u) && (int)$updated_kegiatan->biaya_t_u === 0 &&
				is_numeric($updated_kegiatan->biaya_u) && (int)$updated_kegiatan->biaya_u === 0)
				$updated_kegiatan->batas_upload_bukti_bayar = NULL;
			else
			{
				$batas_upload_bukti_bayar = [
					'date' => $this->input->post('batas_upload_bukti_bayar_date'),
					'time' => $this->input->post('batas_upload_bukti_bayar_time')
				];
				if (
					valid_date_time($batas_upload_bukti_bayar['date'], 'Y-m-d') &&
					valid_date_time($batas_upload_bukti_bayar['time'], 'H:i:s')
				)
				{
					$batas_upload_bukti_bayar = $batas_upload_bukti_bayar['date']. ' '. $batas_upload_bukti_bayar['time'];
					$updated_kegiatan->batas_upload_bukti_bayar = DateTime::createFromFormat('Y-m-d H:i:s', $batas_upload_bukti_bayar);
				}
			}

		}

        // date awal persiapan
        $awal_persiapan_new = $this->input->post('awal_persiapan');
        if (valid_date_time($awal_persiapan_new, 'Y-m-d'))
        {
            $updated_kegiatan->awal_persiapan = DateTime::createFromFormat('Y-m-d', $awal_persiapan_new);
        }
        // date akhir persiapan
        $akhir_persiapan_new = $this->input->post('selesai_persiapan');
        if (valid_date_time($akhir_persiapan_new, 'Y-m-d'))
        {
			$updated_kegiatan->akhir_persiapan = DateTime::createFromFormat('Y-m-d', $akhir_persiapan_new);
        }

        // date awal pelaporan
        $awal_pelaporan_new = $this->input->post('awal_pelaporan');
        if (valid_date_time($awal_pelaporan_new, 'Y-m-d'))
        {
			$updated_kegiatan->awal_pelaporan = DateTime::createFromFormat('Y-m-d', $awal_pelaporan_new);
        }
        // date akhir pelaporan
        $akhir_pelaporan_new = $this->input->post('selesai_pelaporan');
        if (valid_date_time($akhir_pelaporan_new, 'Y-m-d'))
        {
			$updated_kegiatan->akhir_pelaporan = DateTime::createFromFormat('Y-m-d', $akhir_pelaporan_new);
        }

        // validasi link grup
        $updated_kegiatan->link_grup = $this->input->post('link_grup');

		if (!$kegiatan_dibuka_untuk_itpln)
		{
			// kriteria registrasi peserta
			$kriteria_peserta = $this->input->post('kriteria_peserta');
			if (!empty($kriteria_peserta) && valid_json_str($kriteria_peserta))
			{
				$updated_kegiatan->kriteria_registrasi->json_data = $kriteria_peserta;
			}

			// kriteria diskon
			$kriteria_diskon = $this->input->post('kriteria_diskon');
			if (!empty($kriteria_diskon) && valid_json_str($kriteria_diskon))
			{
				$updated_kegiatan->kriteria_diskon->json_data = $kriteria_diskon;
			}

			// kriteria peserta boleh ujian saja
			$kriteria_peserta_boleh_ujian_saja = $this->input->post('kriteria_peserta_boleh_ujian_saja');
			if (!empty($kriteria_peserta_boleh_ujian_saja) && valid_json_str($kriteria_peserta_boleh_ujian_saja))
			{
				$updated_kegiatan->kriteria_peserta_boleh_ujian_saja->json_data = $kriteria_peserta_boleh_ujian_saja;
			}
		}

        if ($this->m_kegiatan->update_kegiatan($updated_kegiatan) === FALSE)
        {
            set_warning('Gagal dalam mengupdate data kegiatan.');
        }
        redirect(base_url('admin/sertifikasi/kegiatan/'.$id.'/ubah'));
    }

	public function update_kriteria_kegiatan($id)
	{
		$this->redirect_if_not_capable(
			Permissions::EDIT_KEGIATAN_SERTIFIKASI,
			'Anda tidak diizinkan untuk mengubah data kegiatan sertifikasi.',
			'admin/sertifikasi/kegiatan');
		$callback = base_url('admin/sertifikasi/kegiatan');
		$this->load->model('m_kegiatan');
		if ($this->m_kegiatan->is_id_kegiatan_exists($id) === FALSE)
		{
			set_warning('Kegiatan sertifikasi tidak dapat ditemukan.');
			redirect($callback);
		}
		load_data_class('Kegiatan');
		$existing_kegiatan = new D_Kegiatan($id);
		$updated_kegiatan = clone $existing_kegiatan;

		// kriteria registrasi peserta
		$kriteria_peserta = $this->input->post('kriteria_peserta');
		if (!empty($kriteria_peserta) && valid_json_str($kriteria_peserta))
		{
			$updated_kegiatan->kriteria_registrasi->json_data = $kriteria_peserta;
		}

		// kriteria diskon
		$kriteria_diskon = $this->input->post('kriteria_diskon');
		if (!empty($kriteria_diskon) && valid_json_str($kriteria_diskon))
		{
			$updated_kegiatan->kriteria_diskon->json_data = $kriteria_diskon;
		}

		// kriteria peserta boleh ujian saja
		$kriteria_peserta_boleh_ujian_saja = $this->input->post('kriteria_peserta_boleh_ujian_saja');
		if (!empty($kriteria_peserta_boleh_ujian_saja) && valid_json_str($kriteria_peserta_boleh_ujian_saja))
		{
			$updated_kegiatan->kriteria_peserta_boleh_ujian_saja->json_data = $kriteria_peserta_boleh_ujian_saja;
		}
		if ($this->m_kegiatan->update_kegiatan($updated_kegiatan) === FALSE)
		{
			set_warning('Gagal dalam mengupdate data kegiatan.');
		}
		redirect(base_url('admin/sertifikasi/kegiatan/'.$id.'/ubah'));
	}

	public function batalkan_kegiatan($id_kegiatan)
	{
		$this->redirect_if_not_capable(
			Permissions::EDIT_KEGIATAN_SERTIFIKASI,
			'Anda tidak diizinkan untuk mengubah data kegiatan sertifikasi.',
			'admin/sertifikasi/kegiatan');
		$callback = base_url('admin/sertifikasi/kegiatan');
		$this->load->model('m_kegiatan');
		if ($this->m_kegiatan->is_id_kegiatan_exists($id_kegiatan) === FALSE)
		{
			set_warning('Kegiatan sertifikasi tidak dapat ditemukan.');
			redirect($callback);
		}
		load_data_class('Kegiatan');
		$existing_kegiatan = new D_Kegiatan($id_kegiatan);
		$updated_kegiatan = clone $existing_kegiatan;

		// keterangan batal kegiatan
		if (!empty($this->input->post('batal')) && !$existing_kegiatan->batal)
		{
			$updated_kegiatan->batal = TRUE;
			$keterangan_batal = $this->input->post('keterangan_batal');
			$updated_kegiatan->keterangan_batal = is_string($keterangan_batal) ? $keterangan_batal : '-';
		}

		if ($this->m_kegiatan->batalkan_kegiatan($updated_kegiatan) === FALSE)
		{
			set_warning('Gagal membatalkan kegiatan sertifikasi.');
			redirect(base_url('admin/sertifikasi/kegiatan/'.$id_kegiatan.'/ubah'));
		}

		// kalau kegiatan batal,
		// redirect ke halaman kegiatan
		if ($updated_kegiatan->batal)
		{
			redirect(base_url('admin/sertifikasi/kegiatan'));
		}
		redirect(base_url('admin/sertifikasi/kegiatan/'.$id_kegiatan.'/ubah'));
    }

    public function tambah_kelompok_t($id_kegiatan)
    {
        $this->redirect_if_not_capable(
            Permissions::EDIT_KEGIATAN_SERTIFIKASI,
            'Anda tidak diizinkan untuk mengubah data kegiatan sertifikasi.',
            'admin/sertifikasi/kegiatan');
        $callback = base_url('admin/sertifikasi/kegiatan');
		$this->load->model("m_kegiatan");
        if ($this->m_kegiatan->is_id_kegiatan_exists($id_kegiatan) === FALSE)
        {
            set_warning('Kegiatan sertifikasi tidak dapat ditemukan.');
            redirect($callback);
        }

		$callback = base_url('admin/sertifikasi/kegiatan/'.$id_kegiatan.'/detail?tab=kelompok-t');
        $param_post = [
            'nama',                 'id_program_kegiatan',
            'tanggal_training',     'waktu_mulai_training',     'waktu_selesai_training',   'lokasi_training',
            'daya_tampung_min_training',
            'daya_tampung_max_training'
        ];
        foreach($param_post as $p)
        {
            if (empty($this->input->post($p)) || !is_array($this->input->post($p)))
            {
                set_warning('Kelompok tidak dapat ditemukan.');
                redirect($callback);
            }
        }
        $count_idx = count($this->input->post($param_post[0]));
        foreach($param_post as $p)
            $count_idx = min($count_idx, count($this->input->post($p)));

        $nama                           = $this->input->post('nama');
        $id_program_kegiatan            = $this->input->post('id_program_kegiatan');

        $tanggal_training               = $this->input->post('tanggal_training');
        $waktu_mulai_training           = $this->input->post('waktu_mulai_training');
        $waktu_selesai_training         = $this->input->post('waktu_selesai_training');
        $lokasi_training                = $this->input->post('lokasi_training');

        $daya_tampung_min_training      = $this->input->post('daya_tampung_min_training');
        $daya_tampung_max_training      = $this->input->post('daya_tampung_max_training');

        load_data_class('Kegiatan');
        load_data_class('Kelompok_T');
        $this->load->model('m_kelompok_t');
        $kegiatan = new D_Kegiatan($id_kegiatan);
        $kegiatan->load_list_program();
        for($i = 0; $i < $count_idx; $i++)
        {
            $id_program = $id_program_kegiatan[$i];
            $selected_program = array_filter($kegiatan->program_kegiatan, function ($prog) use ($id_program){
                return ctype_digit($id_program) && (int)$prog->id_program_kegiatan === (int)$id_program;
            });
            if (
                is_string($nama[$i]) &&
				!empty(trim($nama[$i])) &&

                !empty($selected_program) &&

                valid_date_time($tanggal_training[$i], 'Y-m-d') &&
                valid_date_time($waktu_mulai_training[$i], 'H:i:s') &&
                valid_date_time($waktu_selesai_training[$i], 'H:i:s') &&
                is_string($lokasi_training[$i]) &&
				!empty(trim($lokasi_training[$i])) &&

                ctype_digit($daya_tampung_min_training[$i]) &&
                ctype_digit($daya_tampung_max_training[$i])
            )
            {
            	$mulai_training = DateTime::createFromFormat("Y-m-d H:i:s", $tanggal_training[$i].' '.$waktu_mulai_training[$i]);
            	$selesai_training = DateTime::createFromFormat("Y-m-d H:i:s", $tanggal_training[$i].' '.$waktu_selesai_training[$i]);

				$new = new D_Kelompok_T();
				$new->nama_kelompok = $nama[$i];
				$new->id_kegiatan = $id_kegiatan;
				$new->id_program_kegiatan = $id_program_kegiatan[$i];
				$new->mulai_training = $mulai_training;
				$new->selesai_training = $selesai_training;
				$new->lokasi_training = $lokasi_training[$i];
				$new->min_peserta_training = (int)$daya_tampung_min_training[$i];
				$new->max_peserta_training = (int)$daya_tampung_max_training[$i];

               	$a = $this->m_kelompok_t->add_new_kelompok($new);
            }
        }
		redirect($callback);
    }

	public function tambah_kelompok_u($id_kegiatan)
	{
		$this->redirect_if_not_capable(
			Permissions::EDIT_KEGIATAN_SERTIFIKASI,
			'Anda tidak diizinkan untuk mengubah data kegiatan sertifikasi.',
			'admin/sertifikasi/kegiatan');
		$callback = base_url('admin/sertifikasi/kegiatan');
		$this->load->model("m_kegiatan");
		if ($this->m_kegiatan->is_id_kegiatan_exists($id_kegiatan) === FALSE)
		{
			set_warning('Kegiatan sertifikasi tidak dapat ditemukan.');
			redirect($callback);
		}

		$callback = base_url('admin/sertifikasi/kegiatan/'.$id_kegiatan.'/detail?tab=kelompok-u');
		$param_post = [
			'nama',                 'id_program_kegiatan',
			'tanggal_ujian',     'waktu_mulai_ujian',     'waktu_selesai_ujian',   'lokasi_ujian',
			'daya_tampung_min_ujian',
			'daya_tampung_max_ujian'
		];
		foreach($param_post as $p)
		{
			if (empty($this->input->post($p)) || !is_array($this->input->post($p)))
			{
				set_warning('Kelompok tidak dapat ditemukan.');
				redirect($callback);
			}
		}
		$count_idx = count($this->input->post($param_post[0]));
		foreach($param_post as $p)
			$count_idx = min($count_idx, count($this->input->post($p)));

		$nama                           = $this->input->post('nama');
		$id_program_kegiatan            = $this->input->post('id_program_kegiatan');

		$tanggal_ujian               = $this->input->post('tanggal_ujian');
		$waktu_mulai_ujian           = $this->input->post('waktu_mulai_ujian');
		$waktu_selesai_ujian         = $this->input->post('waktu_selesai_ujian');
		$lokasi_ujian                = $this->input->post('lokasi_ujian');

		$daya_tampung_min_ujian      = $this->input->post('daya_tampung_min_ujian');
		$daya_tampung_max_ujian      = $this->input->post('daya_tampung_max_ujian');

		load_data_class('Kegiatan');
		load_data_class('Kelompok_U');
		$this->load->model('m_kelompok_u');
		$kegiatan = new D_Kegiatan($id_kegiatan);
		$kegiatan->load_list_program();
		for($i = 0; $i < $count_idx; $i++)
		{
			$id_program = $id_program_kegiatan[$i];
			$selected_program = array_filter($kegiatan->program_kegiatan, function ($prog) use ($id_program){
				return ctype_digit($id_program) && (int)$prog->id_program_kegiatan === (int)$id_program;
			});
			if (
				is_string($nama[$i]) &&
				!empty(trim($nama[$i])) &&

				!empty($selected_program) &&

				valid_date_time($tanggal_ujian[$i], 'Y-m-d') &&
				valid_date_time($waktu_mulai_ujian[$i], 'H:i:s') &&
				valid_date_time($waktu_selesai_ujian[$i], 'H:i:s') &&
				is_string($lokasi_ujian[$i]) &&
				!empty(trim($lokasi_ujian[$i])) &&

				ctype_digit($daya_tampung_min_ujian[$i]) &&
				ctype_digit($daya_tampung_max_ujian[$i])
			)
			{
				$mulai_ujian = DateTime::createFromFormat("Y-m-d H:i:s", $tanggal_ujian[$i].' '.$waktu_mulai_ujian[$i]);
				$selesai_ujian = DateTime::createFromFormat("Y-m-d H:i:s", $tanggal_ujian[$i].' '.$waktu_selesai_ujian[$i]);

				$new = new D_Kelompok_U();
				$new->nama_kelompok = $nama[$i];
				$new->id_kegiatan = $id_kegiatan;
				$new->id_program_kegiatan = $id_program_kegiatan[$i];
				$new->mulai_ujian = $mulai_ujian;
				$new->selesai_ujian = $selesai_ujian;
				$new->lokasi_ujian = $lokasi_ujian[$i];
				$new->min_peserta_ujian = (int)$daya_tampung_min_ujian[$i];
				$new->max_peserta_ujian = (int)$daya_tampung_max_ujian[$i];

				$a = $this->m_kelompok_u->add_new_kelompok($new);
			}
		}
		redirect($callback);
	}

    public function update_kelompok_t($id)
    {
        $this->redirect_if_not_capable(
            Permissions::EDIT_KEGIATAN_SERTIFIKASI,
            'Anda tidak diizinkan untuk mengubah data kegiatan sertifikasi.',
            'admin/sertifikasi/kegiatan');

        $callback_uri = base_url('admin/sertifikasi/kegiatan');
        $this->load->model("m_kelompok_t");
        if ($this->m_kelompok_t->is_id_exists($id) === FALSE)
        {
            set_warning('Kelompok tidak dapat ditemukan.');
            redirect($callback_uri);
        }
		$callback_uri = base_url('admin/sertifikasi/kegiatan/kelompok_t/'.$id.'/update');
        load_data_class('Kelompok_T');
        $existing_kelompok = new D_Kelompok_T($id);
        $updated_kelompok = new D_Kelompok_T($id);

        load_data_class('Kegiatan');
        $kegiatan = new D_Kegiatan($existing_kelompok->id_kegiatan);

		$updated_kelompok->nama_kelompok = $this->input->post('nama_kelompok');

        $min_peserta_training = $this->input->post('min_peserta_training');
        if (!ctype_digit($min_peserta_training))
		{
			set_warning('Minimal peserta training harus berupa angka.');
			redirect($callback_uri);
		}
        $updated_kelompok->min_peserta_training = max((int)$min_peserta_training, $existing_kelompok->jumlah_peserta);

		$max_peserta_training = $this->input->post('max_peserta_training');
		if (!ctype_digit($max_peserta_training))
		{
			set_warning('Maksimal peserta training harus berupa angka.');
			redirect($callback_uri);
		}
		$updated_kelompok->max_peserta_training = max((int)$max_peserta_training, $existing_kelompok->jumlah_peserta);

        $tanggal_training = $this->input->post('tanggal_training');
		$waktu_mulai_training = $this->input->post('waktu_mulai_training');
        if (!valid_date_time($tanggal_training, 'Y-m-d') || !valid_date_time($waktu_mulai_training, 'H:i:s'))
		{
			set_warning('Tanggal dan waktu mulai training tidak valid.');
			redirect($callback_uri);
		}
        $updated_kelompok->mulai_training = DateTime::createFromFormat('Y-m-d H:i:s', $tanggal_training.' '.$waktu_mulai_training);

		$waktu_selesai_training = $this->input->post('waktu_selesai_training');
		if (!valid_date_time($waktu_selesai_training, 'H:i:s'))
		{
			set_warning('Tanggal dan waktu selesai training tidak valid.');
			redirect($callback_uri);
		}
		$updated_kelompok->selesai_training = DateTime::createFromFormat('Y-m-d H:i:s', $tanggal_training.' '.$waktu_selesai_training);

        $lokasi_training = $this->input->post('lokasi_training');
        if (!is_string($lokasi_training) || trim($lokasi_training) === '')
		{
			set_warning('Lokasi training tidak boleh kosong.');
			redirect($callback_uri);
		}
        $updated_kelompok->lokasi_training = $lokasi_training;

        $id_trainer_sesi1 = $this->input->post('id_trainer_sesi1');
        if ( $id_trainer_sesi1 === 'none')
        {
            $updated_kelompok->id_trainer_sesi1 = NULL;
        }
        elseif (!ctype_digit($id_trainer_sesi1))
        {
            set_warning('Trainer sesi 1 tidak valid.');
        }
        else
        {
            // cek apakah program kelompok ada di trainer juga
            $id_trainer_sesi1 = (int)$id_trainer_sesi1;
            $this->load->model('m_trainer');
            if ($this->m_trainer->does_id_already_exists($id_trainer_sesi1) === FALSE)
            {
                set_warning('Trainer sesi 1 tidak valid.');
				redirect($callback_uri);
            }
            load_data_class('Trainer');
            $t = new D_Trainer($id_trainer_sesi1);
            $t->load_list_program();

            $id_program = $existing_kelompok->id_program;
			$selected_program = array_filter($t->list_sertifikasi, function ($sertif) use ($id_program){
				$found = FALSE;
				foreach ($sertif->list_program as $program)
				{
					if ((int)$program->id === (int)$id_program) $found = TRUE;
				}
				return $found;
			});
            if (empty($selected_program))
            {
                set_warning('Trainer sesi 1 tidak dapat diupdate karena program tidak sesuai.');
            }
            else{
            	$updated_kelompok->id_trainer_sesi1 = $id_trainer_sesi1;
			}
        }

		$id_trainer_sesi2 = $this->input->post('id_trainer_sesi2');
		if ( $id_trainer_sesi2 === 'none')
		{
			$updated_kelompok->id_trainer_sesi2 = NULL;
		}
		elseif (!ctype_digit($id_trainer_sesi2))
		{
			set_warning('Trainer sesi 2 tidak valid.');
		}
		else
		{
			// cek apakah program kelompok ada di trainer juga
			$id_trainer_sesi2 = (int)$id_trainer_sesi2;
			$this->load->model('m_trainer');
			if ($this->m_trainer->does_id_already_exists($id_trainer_sesi2) === FALSE)
			{
				set_warning('Trainer sesi 2 tidak valid.');
				redirect($callback_uri);
			}
			load_data_class('Trainer');
			$t = new D_Trainer($id_trainer_sesi2);
			$t->load_list_program();

			$id_program = $existing_kelompok->id_program;
			$selected_program = array_filter($t->list_sertifikasi, function ($sertif) use ($id_program){
				$found = FALSE;
				foreach ($sertif->list_program as $program)
				{
					if ((int)$program->id === (int)$id_program) $found = TRUE;
				}
				return $found;
			});
			if (empty($selected_program))
			{
				set_warning('Trainer sesi 2 tidak dapat diupdate karena program tidak sesuai.');
			}
			else{
				$updated_kelompok->id_trainer_sesi2 = $id_trainer_sesi2;
			}
		}

		$id_proctor_training = $this->input->post('id_proctor_training');
		if ( $id_proctor_training === 'none')
		{
			$updated_kelompok->id_proctor_training = NULL;
		}
		elseif (!ctype_digit($id_proctor_training))
		{
			set_warning('Proctor training tidak valid.');
		}
		else
		{
			// cek apakah program kelompok ada di trainer juga
			$id_proctor_training = (int)$id_proctor_training;
			$this->load->model('m_proctor');
			if ($this->m_proctor->does_id_already_exists($id_proctor_training) === FALSE)
			{
				set_warning('Proctor training tidak valid.');
				redirect($callback_uri);
			}
			load_data_class('Proctor');
			$p = new D_Proctor($id_proctor_training);
			$p->load_list_sertifikasi();

			$id_sertifikasi = $kegiatan->id_sertifikasi;
			$selected_sertifikasi = array_filter($p->list_sertifikasi, function ($sertif) use ($id_sertifikasi){
				return (int)$sertif->id === (int)$id_sertifikasi;
			});
			if (empty($selected_sertifikasi))
			{
				set_warning('Proctor training tidak dapat diupdate karena program tidak sesuai.');
			}
			else{
				$updated_kelompok->id_proctor_training = $id_proctor_training;
			}
		}
		if ($this->m_kelompok_t->update_kelompok($updated_kelompok) === FALSE)
		{
			set_warning('Gagal mengupdate data kelompok training.');
			redirect($callback_uri);
		}
		redirect($callback_uri);
    }

	public function update_kelompok_u($id)
	{
		$this->redirect_if_not_capable(
			Permissions::EDIT_KEGIATAN_SERTIFIKASI,
			'Anda tidak diizinkan untuk mengubah data kegiatan sertifikasi.',
			'admin/sertifikasi/kegiatan');

		$callback_uri = base_url('admin/sertifikasi/kegiatan');
		$this->load->model("m_kelompok_u");
		if ($this->m_kelompok_u->is_id_exists($id) === FALSE)
		{
			set_warning('Kelompok tidak dapat ditemukan.');
			redirect($callback_uri);
		}
		$callback_uri = base_url('admin/sertifikasi/kegiatan/kelompok_u/'.$id.'/update');
		load_data_class('Kelompok_U');
		$existing_kelompok = new D_Kelompok_U($id);
		$updated_kelompok = new D_Kelompok_U($id);

		load_data_class('Kegiatan');
		$kegiatan = new D_Kegiatan($existing_kelompok->id_kegiatan);

		$updated_kelompok->nama_kelompok = $this->input->post('nama_kelompok');

		$min_peserta_ujian = $this->input->post('min_peserta_ujian');
		if (!ctype_digit($min_peserta_ujian))
		{
			set_warning('Minimal peserta ujian harus berupa angka.');
			redirect($callback_uri);
		}
		$updated_kelompok->min_peserta_ujian = max((int)$min_peserta_ujian, $existing_kelompok->jumlah_peserta);

		$max_peserta_ujian = $this->input->post('max_peserta_ujian');
		if (!ctype_digit($max_peserta_ujian))
		{
			set_warning('Maksimal peserta ujian harus berupa angka.');
			redirect($callback_uri);
		}
		$updated_kelompok->max_peserta_ujian = max((int)$max_peserta_ujian, $existing_kelompok->jumlah_peserta);

		$tanggal_ujian = $this->input->post('tanggal_ujian');
		$waktu_mulai_ujian = $this->input->post('waktu_mulai_ujian');
		if (!valid_date_time($tanggal_ujian, 'Y-m-d') || !valid_date_time($waktu_mulai_ujian, 'H:i:s'))
		{
			set_warning('Tanggal dan waktu mulai ujian tidak valid.');
			redirect($callback_uri);
		}
		$updated_kelompok->mulai_ujian = DateTime::createFromFormat('Y-m-d H:i:s', $tanggal_ujian.' '.$waktu_mulai_ujian);

		$waktu_selesai_ujian = $this->input->post('waktu_selesai_ujian');
		if (!valid_date_time($waktu_selesai_ujian, 'H:i:s'))
		{
			set_warning('Tanggal dan waktu selesai ujian tidak valid.');
			redirect($callback_uri);
		}
		$updated_kelompok->selesai_ujian = DateTime::createFromFormat('Y-m-d H:i:s', $tanggal_ujian.' '.$waktu_selesai_ujian);

		$lokasi_ujian = $this->input->post('lokasi_ujian');
		if (!is_string($lokasi_ujian) || trim($lokasi_ujian) === '')
		{
			set_warning('Lokasi ujian tidak boleh kosong.');
			redirect($callback_uri);
		}
		$updated_kelompok->lokasi_ujian = $lokasi_ujian;

		$id_proctor_ujian = $this->input->post('id_proctor_ujian');
		if ( $id_proctor_ujian === 'none')
		{
			$updated_kelompok->id_proctor_ujian = NULL;
		}
		elseif (!ctype_digit($id_proctor_ujian))
		{
			set_warning('Proctor ujian tidak valid.');
		}
		else
		{
			// cek apakah program kelompok ada di proctor juga
			$id_proctor_ujian = (int)$id_proctor_ujian;
			$this->load->model('m_proctor');
			if ($this->m_proctor->does_id_already_exists($id_proctor_ujian) === FALSE)
			{
				set_warning('Proctor ujian tidak valid.');
				redirect($callback_uri);
			}
			load_data_class('Proctor');
			$p = new D_Proctor($id_proctor_ujian);
			$p->load_list_sertifikasi();

			$id_sertifikasi = $kegiatan->id_sertifikasi;
			$selected_sertifikasi = array_filter($p->list_sertifikasi, function ($sertif) use ($id_sertifikasi){
				return (int)$sertif->id === (int)$id_sertifikasi;
			});
			if (empty($selected_sertifikasi))
			{
				set_warning('Proctor ujian tidak dapat diupdate karena program tidak sesuai.');
			}
			else{
				$updated_kelompok->id_proctor_ujian = $id_proctor_ujian;
			}
		}
		if ($this->m_kelompok_u->update_kelompok($updated_kelompok) === FALSE)
		{
			set_warning('Gagal mengupdate data kelompok ujian.');
			redirect($callback_uri);
		}
		redirect($callback_uri);
	}

    public function hapus_kelompok_t()
    {
		$this->redirect_if_not_capable(
			Permissions::HAPUS_KEGIATAN_SERTIFIKASI,
			'Anda tidak diizinkan untuk menghapus data kegiatan sertifikasi.',
			'admin/sertifikasi/kegiatan'
		);
		$callback = base_url('admin/sertifikasi/kegiatan');
        $id = $this->input->post('id');

		$this->load->model('m_kelompok_t');
        if (empty($id) || $this->m_kelompok_t->is_id_exists($id) === FALSE)
        {
            set_warning('Kelompok training tidak dapat ditemukan.');
            redirect($callback);
        }

        load_data_class('Kelompok_T');
        $kelompok = new D_Kelompok_T($id);
        if ($this->m_kelompok_t->delete_kelompok($kelompok) === FALSE)
        {
            set_warning('Gagal menghapus kelompok training.');
			redirect($callback);
        }

        $callback = base_url('admin/sertifikasi/kegiatan/'.$kelompok->id_kegiatan.'/detail?tab=kelompok-t');
        redirect($callback);
    }

	public function hapus_kelompok_u()
	{
		$this->redirect_if_not_capable(
			Permissions::HAPUS_KEGIATAN_SERTIFIKASI,
			'Anda tidak diizinkan untuk menghapus data kegiatan sertifikasi.',
			'admin/sertifikasi/kegiatan'
		);

		$callback = base_url('admin/sertifikasi/kegiatan');
		$id = $this->input->post('id');

		$this->load->model('m_kelompok_u');
		if (empty($id) || $this->m_kelompok_u->is_id_exists($id) === FALSE)
		{
			set_warning('Kelompok ujian tidak dapat ditemukan.');
			redirect($callback);
		}

		load_data_class('Kelompok_U');
		$kelompok = new D_Kelompok_U($id);
		if ($this->m_kelompok_u->delete_kelompok($kelompok) === FALSE)
		{
			set_warning('Gagal menghapus kelompok ujian.');
			redirect($callback);
		}

		$callback = base_url('admin/sertifikasi/kegiatan/'.$kelompok->id_kegiatan.'/detail?tab=kelompok-u');
		redirect($callback);
	}

    public function detail_kelompok_t($id_kelompok)
    {
        $this->redirect_if_not_logged_in();
        $this->redirect_if_not_capable(
            'lihat_kegiatan_sertifikasi',
            'Anda tidak diizinkan untuk melihat detail kegiatan sertifikasi.',
            'admin/sertifikasi/kegiatan'
        );
        $callback = base_url('admin/sertifikasi/kegiatan');
        $this->load->model('m_kelompok_t');
        if ($this->m_kelompok_t->is_id_exists($id_kelompok) === FALSE)
        {
            set_warning('Kelompok tidak ditemukan.');
            redirect($callback);
        }
        load_data_class('Kelompok_T');
        $kelompok = new D_Kelompok_T($id_kelompok);
		$kelompok->load_list_peserta();
		load_data_class('Kegiatan');
		$kegiatan = new D_Kegiatan($kelompok->id_kegiatan);
        $data = [
            'kelompok' => $kelompok,
            'kegiatan' => $kegiatan
        ];
        $this->load->view('admin/detail_kelompok_t', ['data' => $data]);
    }

	public function detail_kelompok_u($id_kelompok)
	{
		$this->redirect_if_not_logged_in();
		$this->redirect_if_not_capable(
			'lihat_kegiatan_sertifikasi',
			'Anda tidak diizinkan untuk melihat detail kegiatan sertifikasi.',
			'admin/sertifikasi/kegiatan'
		);
		$callback = base_url('admin/sertifikasi/kegiatan');
		$this->load->model('m_kelompok_u');
		if ($this->m_kelompok_u->is_id_exists($id_kelompok) === FALSE)
		{
			set_warning('Kelompok tidak ditemukan.');
			redirect($callback);
		}
		load_data_class('Kelompok_U');
		$kelompok = new D_Kelompok_U($id_kelompok);
		$kelompok->load_list_peserta();
		load_data_class('Kegiatan');
		$kegiatan = new D_Kegiatan($kelompok->id_kegiatan);
		$data = [
			'kelompok' => $kelompok,
			'kegiatan' => $kegiatan
		];
		$this->load->view('admin/detail_kelompok_u', ['data' => $data]);
	}

	public function show_update_kelompok_t($id_kelompok)
	{
		$this->redirect_if_not_capable(
			'edit_kegiatan_sertifikasi',
			'Anda tidak diizinkan untuk mengubah data kegiatan sertifikasi.',
			'admin/sertifikasi/kegiatan');
		$callback = base_url('admin/sertifikasi/kegiatan');
		$this->load->model('m_kelompok_t');
		if (empty($this->m_kelompok_t->is_id_exists($id_kelompok)))
		{
			set_warning('Kelompok tidak dapat ditemukan.');
			redirect($callback);
		}
		load_data_class('Kelompok_T');
		$kelompok = new D_Kelompok_T($id_kelompok);

		load_data_class('Kegiatan');
		$kegiatan = new D_Kegiatan($kelompok->id_kegiatan);

		$kelompok->load_kesediaan_trainer();
		$kelompok->load_kesediaan_proctor_training();

		// ambil trainer sesuai program kelompok ini
		$this->load->model("m_trainer");
		$list_trainer_aktif = $this->m_trainer->get_list_trainer_aktif();
		$id_program = (int)$kelompok->id_program;
		$list_trainer_sesuai_program = array_filter(
			$list_trainer_aktif,
			function ($trainer) use ($id_program){
				$trainer->load_list_program();
				$found = FALSE;
				foreach($trainer->list_sertifikasi as $sertif)
				{
					foreach($sertif->list_program as $program)
					{
						if ((int)$program->id === $id_program) {
							$found = TRUE;
							break;
						}
					}
				}
				return $found;
			}
		);

		// ambil proctor sesuai sertifikasi
		$this->load->model('m_proctor');
		$list_proctor_aktif = $this->m_proctor->get_list_proctor_aktif();
		$id_sertifikasi = (int)$kegiatan->id_sertifikasi;
		$list_proctor_sesuai_sertif = array_filter(
			$list_proctor_aktif,
			function ($proctor) use ($id_sertifikasi){
				$proctor->load_list_sertifikasi();
				$found = FALSE;
				foreach($proctor->list_sertifikasi as $sertif)
				{
					if ((int)$sertif->id === $id_sertifikasi)
					{
						$found = TRUE;
						break;
					}
				}
				return $found;
			}
		);

		$data = [
			'kelompok' => $kelompok,
			'trainer_sesuai_program' => $list_trainer_sesuai_program,
			'proctor_sesuai_sertif' => $list_proctor_sesuai_sertif
		];

		$this->load->view('admin/update_kelompok_t', ['data' => $data]);
	}

	public function show_update_kelompok_u($id_kelompok)
	{
		$this->redirect_if_not_capable(
			'edit_kegiatan_sertifikasi',
			'Anda tidak diizinkan untuk mengubah data kegiatan sertifikasi.',
			'admin/sertifikasi/kegiatan');
		$callback = base_url('admin/sertifikasi/kegiatan');
		$this->load->model('m_kelompok_u');
		if (empty($this->m_kelompok_u->is_id_exists($id_kelompok)))
		{
			set_warning('Kelompok tidak dapat ditemukan.');
			redirect($callback);
		}
		load_data_class('Kelompok_U');
		$kelompok = new D_Kelompok_U($id_kelompok);

		load_data_class('Kegiatan');
		$kegiatan = new D_Kegiatan($kelompok->id_kegiatan);

		$kelompok->load_kesediaan_proctor_ujian();


		// ambil proctor sesuai sertifikasi
		$this->load->model('m_proctor');
		$list_proctor_aktif = $this->m_proctor->get_list_proctor_aktif();
		$id_sertifikasi = (int)$kegiatan->id_sertifikasi;
		$list_proctor_sesuai_sertif = array_filter(
			$list_proctor_aktif,
			function ($proctor) use ($id_sertifikasi){
				$proctor->load_list_sertifikasi();
				$found = FALSE;
				foreach($proctor->list_sertifikasi as $sertif)
				{
					if ((int)$sertif->id === $id_sertifikasi)
					{
						$found = TRUE;
						break;
					}
				}
				return $found;
			}
		);

		$data = [
			'kelompok' => $kelompok,
			'proctor_sesuai_sertif' => $list_proctor_sesuai_sertif
		];

		$this->load->view('admin/update_kelompok_u', ['data' => $data]);
	}

	public function update_peserta_kelompok_t($id_kelompok)
	{
		$this->redirect_if_not_capable(
			Permissions::EDIT_KEGIATAN_SERTIFIKASI,
			'Anda tidak dapat mengubah data kegiatan sertifikasi',
			'admin/sertifikasi/kegiatan'
		);
		$callback = base_url('admin/sertifikasi/kegiatan');
		$this->load->model('m_kelompok_t');
		if ($this->m_kelompok_t->is_id_exists($id_kelompok) === FALSE)
		{
			set_warning('Kelompok tidak ditemukan.');
			redirect($callback);
		}
		load_data_class('Kelompok_T');
		$kelompok = new D_Kelompok_T($id_kelompok);

		$hadir_t_sesi1 = $this->input->post('t_sesi1');
		$hadir_t_sesi2 = $this->input->post('t_sesi2');
		$kelompok->beritaacara_t_sesi1 = $this->input->post('beritaacara_t_sesi1');
		$kelompok->beritaacara_t_sesi2 = $this->input->post('beritaacara_t_sesi2');
		$kelompok->load_list_peserta();
		$id_kehadiran_t_sesi1 = [];
		if (is_array($hadir_t_sesi1))
		{
			foreach($hadir_t_sesi1 as $id => $hadir)
			{
				if (!is_numeric($id) || !in_array($hadir, ['y', 'n']))
					continue;
				$id_kehadiran_t_sesi1[] = [$id, ($hadir === 'y')];
			}
		}
		$id_kehadiran_t_sesi2 = [];
		if (is_array($hadir_t_sesi2))
		{
			foreach($hadir_t_sesi2 as $id => $hadir)
			{
				if (!is_numeric($id) || !in_array($hadir, ['y', 'n']))
					continue;
				$id_kehadiran_t_sesi2[] = [$id, ($hadir === 'y')];
			}
		}

		$a = $this->m_kelompok_t->update_kelompok($kelompok);
		$a = $this->m_kelompok_t->update_absensi_sesi1($id_kehadiran_t_sesi1);
		$a = $this->m_kelompok_t->update_absensi_sesi2($id_kehadiran_t_sesi2);
		redirect(base_url('admin/sertifikasi/kegiatan/kelompok_t/detail/'.$id_kelompok));
	}

    public function update_peserta_kelompok_u($id_kelompok)
    {
        $this->redirect_if_not_capable(
            'edit_kegiatan_sertifikasi',
            'Anda tidak dapat mengubah data kegiatan sertifikasi',
            'admin/sertifikasi/kegiatan'
        );
        $callback = base_url('admin/sertifikasi/kegiatan');
        $this->load->model('m_kelompok_u');
        if ($this->m_kelompok_u->is_id_exists($id_kelompok) === FALSE)
        {
            set_warning('Kelompok tidak ditemukan.');
            redirect($callback);
        }
        load_data_class('Kelompok_U');
        $kelompok = new D_Kelompok_U($id_kelompok);
        load_data_class('Program');
        $program = new D_Program($kelompok->id_program);

        $hadir_ujian = $this->input->post('hadir_ujian');
        $skor_ujian = $this->input->post('skor_ujian');
		$kelompok->beritaacara_ujian = $this->input->post('beritaacara_ujian');
		$kelompok->load_list_peserta();
		$id_kehadiran_ujian = [];
        if (is_array($hadir_ujian))
        {
            foreach($hadir_ujian as $id => $hadir)
            {
                if (!is_numeric($id) || !in_array($hadir, ['y', 'n']))
                    continue;
                $id_kehadiran_ujian[] = [$id, ($hadir === 'y')];
            }
        }

        $id_skor_ujian = [];
        if (is_array($skor_ujian))
        {
            foreach($skor_ujian as $id => $skor)
            {
                if (!is_numeric($id) || !is_numeric($skor))
                    continue;
                $skor = (int)$skor;
                if (
                	$skor !== -1 &&
					!($skor >= 0 && $skor <= $program->max_skor)
				)
				{
					set_warning("Skor ujian harus dalam range skor sesuai program, atau -1 jika pending.");
					continue;
				}
                $id_skor_ujian[] = [$id, $skor];
            }
        }
        $a = $this->m_kelompok_u->update_kelompok($kelompok);
		$a = $this->m_kelompok_u->update_absensi($id_kehadiran_ujian);
        $a = $this->m_kelompok_u->update_skor_ujian($kelompok, $id_skor_ujian);
        redirect(base_url('admin/sertifikasi/kegiatan/kelompok_u/detail/'.$id_kelompok));
    }

	public function tambah_klaim_kegiatan($id_kegiatan)
	{
		$this->redirect_if_not_capable(
			'edit_keuangan_kegiatan_sertifikasi',
			'Anda tidak dapat mengubah data keuangan kegiatan sertifikasi',
			'admin/sertifikasi/kegiatan'
		);
		$callback = base_url("admin/sertifikasi/kegiatan");
		$this->load->model('m_kegiatan');
		if ($this->m_kegiatan->is_id_kegiatan_exists($id_kegiatan) === FALSE)
		{
			set_warning("Kegiatan tidak dapat ditemukan");
			redirect($callback);
		}
		$callback = base_url("admin/sertifikasi/kegiatan/".$id_kegiatan."/detail");
		load_data_class('Kegiatan');
		$klaim = new D_Klaim_Dana_Kegiatan();
		$klaim->id_kegiatan = $id_kegiatan;
		$klaim->keterangan = $this->input->post('keterangan');
		$klaim->nominal_klaim = $this->input->post('nominal');
		if (isset($_FILES['bukti']) && trim($_FILES['bukti']['name']) !== '')
		{
			if ($klaim->upload_bukti('bukti') === FALSE)
			{
				set_warning('Gagal menyimpan file bukti klaim.');
				redirect($callback);
			}
		}

		if ($this->m_kegiatan->add_new_klaim_dana_kegiatan($klaim) === FALSE)
		{
			set_warning('Gagal menyimpan data klaim.');
			redirect($callback);
		}
		redirect($callback);
    }

	public function ubah_klaim_kegiatan()
	{
		$this->redirect_if_not_capable(
			'edit_keuangan_kegiatan_sertifikasi',
			'Anda tidak dapat mengubah data keuangan kegiatan sertifikasi',
			'admin/sertifikasi/kegiatan'
		);
		$this->load->model('m_kegiatan');
		$id = $this->input->post('id');
		$callback = base_url("admin/sertifikasi/kegiatan");
		if (!ctype_digit($id) || $this->m_kegiatan->is_id_klaim_exists($id) === FALSE)
		{
			set_warning('Data klaim tidak ditemukan.');
			redirect($callback);
		}
		load_data_class('Kegiatan');
		$existing_klaim = new D_Klaim_Dana_Kegiatan($id);
		$updated_klaim = new D_Klaim_Dana_Kegiatan($id);
		$updated_klaim->keterangan = $this->input->post('keterangan');
		$updated_klaim->nominal_klaim = $this->input->post('nominal');

		$callback = base_url("admin/sertifikasi/kegiatan/".$existing_klaim->id_kegiatan."/detail");
		if ( !empty($this->input->post('ganti_file')))
		{
			if (isset($_FILES['bukti']) && trim($_FILES['bukti']['name']) !== '')
			{
				if ($updated_klaim->upload_bukti('bukti') === FALSE)
				{
					set_warning('File bukti klaim tidak diubah dikarenakan terjadi kesalahan dalam menyimpan file.');
				}
			}
			else
			{
				set_warning('File bukti klaim tidak dapat ditemukan.');
				redirect($callback);
			}
		}
		if ($this->m_kegiatan->update_klaim_dana_kegiatan($updated_klaim) === FALSE)
		{
			$updated_klaim->hapus_file_bukti();
			set_warning('Gagal memperbarui data klaim.');
			redirect($callback);
		}
		$existing_klaim->hapus_file_bukti();
		redirect($callback);
    }

	public function hapus_klaim_kegiatan()
	{
		$this->redirect_if_not_capable(
			'edit_keuangan_kegiatan_sertifikasi',
			'Anda tidak dapat mengubah data keuangan kegiatan sertifikasi',
			'admin/sertifikasi/kegiatan'
		);
		$this->load->model('m_kegiatan');
		$id = $this->input->post('id');
		$callback = base_url("admin/sertifikasi/kegiatan");
		if (!ctype_digit($id) || $this->m_kegiatan->is_id_klaim_exists($id) === FALSE)
		{
			set_warning('Data klaim tidak ditemukan.');
			redirect($callback);
		}
		load_data_class('Kegiatan');
		$klaim = new D_Klaim_Dana_Kegiatan($id);
		$callback = base_url("admin/sertifikasi/kegiatan/".$klaim->id_kegiatan."/detail");
		if ($this->m_kegiatan->hapus_klaim_dana_kegiatan($klaim) === FALSE)
		{
			set_warning('Gagal menghapus data klaim.');
			redirect($callback);
		}
		redirect($callback);
    }

    public function show_user_mhs()
    {
        $this->redirect_if_not_logged_in();
        $this->redirect_if_not_capable(
            'lihat_list_user',
            'Anda tidak diizinkan untuk melihat data user.',
            'admin'
        );
        $this->load->view('admin/user_mhs', ['data' => []]);
    }

	public function show_user_itpln()
	{
		$this->redirect_if_not_logged_in();
		$this->redirect_if_not_capable(
			'lihat_list_user',
			'Anda tidak diizinkan untuk melihat data user.',
			'admin'
		);
		$data = [];
		$this->load->model('m_user');
		$list_posisi_jabatan = $this->m_user->get_list_bidang();
		foreach ($list_posisi_jabatan as $bidang) {
			$bidang->load_list_jabatan();
		}
		$data['list_posisi_jabatan'] = $list_posisi_jabatan;
		$this->load->view('admin/user_itpln', ['data' => $data]);
	}

	public function show_bidang_jabatan_itpln()
	{
		$this->redirect_if_not_logged_in();
		$this->redirect_if_not_capable(
			'edit_list_user',
			'Anda tidak diizinkan untuk mengubah data terkait user.',
			'admin'
		);

		$this->load->model('m_user');
		$list_bidang = $this->m_user->get_list_bidang();
		$data = [
			'list_bidang' => $list_bidang
		];
		if (!empty($this->input->get('id_bidang')))
		{
			$id_bidang = $this->input->get('id_bidang');
			if (ctype_digit($id_bidang) && $this->m_user->is_id_bidang_exists($id_bidang))
			{
				load_data_class('User');
				$selected_bidang = new D_Bidang_User_ITPLN($id_bidang);
				$selected_bidang->load_list_jabatan();
				$data['selected_bidang'] = $selected_bidang;
			}
		}
		$this->load->view('admin/bidang_jabatan', ['data' => $data]);
	}

	public function add_new_bidang()
	{
		$this->redirect_if_not_capable(
			Permissions::TAMBAH_LIST_BIDANG_JABATAN,
			'Anda tidak diizinkan untuk menambah data bidang & jabatan.',
			'admin/user/bidang_jabatan'
		);
		load_data_class('User');
		$new_bidang = new D_Bidang_User_ITPLN();
		$new_bidang->nama_bidang = $this->input->post('nama_bidang');
		$this->load->model('m_user');
		if ($this->m_user->add_new_bidang($new_bidang) === FALSE)
		{
			set_warning("Gagal menambahkan bidang.");
			redirect(base_url('admin/user/bidang_jabatan'));
		}
		redirect(base_url('admin/user/bidang_jabatan'));
	}

	public function update_bidang()
	{
		$this->redirect_if_not_capable(
			Permissions::EDIT_LIST_BIDANG_JABATAN,
			'Anda tidak diizinkan untuk mengubah data bidang & jabatan.',
			'admin/user/bidang_jabatan'
		);
		$callback = base_url('admin/user/bidang_jabatan');
		$id_bidang = $this->input->post('id');
		$this->load->model('m_user');
		if (empty($id_bidang) || $this->m_user->is_id_bidang_exists($id_bidang) === FALSE)
		{
			set_warning("Bidang tidak ditemukan.");
			redirect($callback);
		}
		load_data_class('User');
		$bidang = new D_Bidang_User_ITPLN($id_bidang);
		$bidang->nama_bidang = $this->input->post('nama_bidang');
		if ($this->m_user->update_bidang($bidang) === FALSE)
		{
			set_warning("Gagal memperbarui data bidang.");
			redirect($callback);
		}
		redirect($callback);
	}

	public function delete_bidang()
	{
		$this->redirect_if_not_capable(
			Permissions::HAPUS_LIST_BIDANG_JABATAN,
			'Anda tidak diizinkan untuk menghapus data bidang & jabatan.',
			'admin/user/bidang_jabatan'
		);
		$callback = base_url('admin/user/bidang_jabatan');
		$id_bidang = $this->input->post('id');
		$this->load->model('m_user');
		if (empty($id_bidang) || $this->m_user->is_id_bidang_exists($id_bidang) === FALSE)
		{
			set_warning("Bidang tidak ditemukan.");
			redirect($callback);
		}
		load_data_class('User');
		$bidang = new D_Bidang_User_ITPLN($id_bidang);
		if ($this->m_user->hapus_bidang($bidang) === FALSE)
		{
			set_warning("Gagal menghapus bidang.");
			redirect($callback);
		}
		redirect($callback);
	}

	public function add_new_jabatan()
	{
		$this->redirect_if_not_capable(
			Permissions::TAMBAH_LIST_BIDANG_JABATAN,
			'Anda tidak diizinkan untuk menambah data bidang & jabatan.',
			'admin/user/bidang_jabatan'
		);
		load_data_class('User');
		$new_jabatan = new D_Jabatan_User_ITPLN();
		$new_jabatan->nama_jabatan = $this->input->post('nama_jabatan');
		$new_jabatan->id_bidang = $this->input->post('id_bidang');
		$this->load->model('m_user');
		if ($this->m_user->add_new_jabatan($new_jabatan) === FALSE)
		{
			set_warning("Gagal menambahkan jabatan.");
			redirect(base_url('admin/user/bidang_jabatan'));
		}
		redirect(base_url('admin/user/bidang_jabatan?id_bidang='.$new_jabatan->id_bidang));
	}

	public function update_jabatan()
	{
		$this->redirect_if_not_capable(
			Permissions::EDIT_LIST_BIDANG_JABATAN,
			'Anda tidak diizinkan untuk mengubah data bidang & jabatan.',
			'admin/user/bidang_jabatan'
		);
		$callback = base_url('admin/user/bidang_jabatan');
		$id_jabatan = $this->input->post('id');
		$this->load->model('m_user');
		if (empty($id_jabatan) || $this->m_user->is_id_jabatan_exists($id_jabatan) === FALSE)
		{
			set_warning("Jabatan tidak ditemukan.");
			redirect($callback);
		}
		load_data_class('User');
		$jabatan = new D_Jabatan_User_ITPLN($id_jabatan);
		$jabatan->nama_jabatan = $this->input->post('nama_jabatan');
		$callback = base_url('admin/user/bidang_jabatan?id_bidang='.$jabatan->id_bidang);
		if ($this->m_user->update_jabatan($jabatan) === FALSE)
		{
			set_warning("Gagal memperbarui data jabatan.");
			redirect($callback);
		}
		redirect($callback);
	}

	public function delete_jabatan()
	{
		$this->redirect_if_not_capable(
			Permissions::HAPUS_LIST_BIDANG_JABATAN,
			'Anda tidak diizinkan untuk menghapus data bidang & jabatan.',
			'admin/user/bidang_jabatan'
		);
		$callback = base_url('admin/user/bidang_jabatan');
		$id_jabatan = $this->input->post('id');
		$this->load->model('m_user');
		if (empty($id_jabatan) || $this->m_user->is_id_jabatan_exists($id_jabatan) === FALSE)
		{
			set_warning("Jabatan tidak ditemukan.");
			redirect($callback);
		}
		load_data_class('User');
		$jabatan = new D_Jabatan_User_ITPLN($id_jabatan);
		$callback = base_url('admin/user/bidang_jabatan?id_bidang='.$jabatan->id_bidang);
		if ($this->m_user->hapus_jabatan($jabatan) === FALSE)
		{
			set_warning("Gagal menghapus jabatan.");
			redirect($callback);
		}
		redirect($callback);
	}

	public function add_new_user($tipe_user)
	{
		$callback = base_url('admin/user/'.$tipe_user);
		$this->redirect_if_not_capable(
			Permissions::TAMBAH_LIST_USER,
			'Anda tidak diizinkan untuk menambah data terkait user.',
			'admin/user/'.$tipe_user
		);
		if ($tipe_user === General_Constants::MAHASISWA)
		{
			load_data_class('User');
			$user = new D_User();
			$user->email = $this->input->post('email');
			$user->tipe_user = General_Constants::MAHASISWA;
			$user->nama_depan = $this->input->post('nama_depan');
			$user->nama_belakang = $this->input->post('nama_belakang');
			$user->jenis_kelamin = $this->input->post('jenis_kelamin');
			$user->alamat = $this->input->post('alamat');
			$user->no_telepon = $this->input->post('no_telepon');
			$user->id_line = $this->input->post('id_line');
			$user->id_telegram = $this->input->post('id_telegram');
			$user->nim = $this->input->post('nim');
			$user->username_certiport = $this->input->post('username_certiport');
			$user->password_certiport = $this->input->post('password_certiport');

			if (!isset($_FILES['file_fotoprofil']) || trim($_FILES['file_fotoprofil']['name']) === '')
			{
				set_warning("Pas Foto wajib diberikan.");
				redirect($callback);
			}
			elseif($user->upload_profil('file_fotoprofil') === FALSE)
			{
				set_warning("Gagal mengupload Pas Foto.");
				redirect($callback);
			}

			if (!isset($_FILES['file_ktm']) || trim($_FILES['file_ktm']['name']) === '')
			{
				$user->hapus_profil();
				set_warning("KTM wajib diberikan.");
				redirect($callback);
			}
			elseif($user->upload_ktm('file_ktm') === FALSE)
			{
				$user->hapus_profil();
				set_warning("Gagal mengupload KTM.");
				redirect($callback);
			}

			$this->load->model("m_user");
			if ( $this->m_user->add_new_user($user) === FALSE)
			{
				$user->hapus_profil();
				$user->hapus_ktm();
				set_warning("Terjadi kesalahan dalam menambahkan user.");
				redirect($callback);
			}
			redirect($callback);
		}
		elseif($tipe_user === General_Constants::UMUM)
		{
			load_data_class('User');
			$user = new D_User();
			$user->email = $this->input->post('email');
			$user->nama_depan = $this->input->post('nama_depan');
			$user->nama_belakang = $this->input->post('nama_belakang');
			$user->jenis_kelamin = $this->input->post('jenis_kelamin');
			$user->alamat = $this->input->post('alamat');
			$user->no_telepon = $this->input->post('no_telepon');
			$user->nik = $this->input->post('nik');
			$user->username_certiport = $this->input->post('username_certiport');
			$user->password_certiport = $this->input->post('password_certiport');
			$user->password = password_hash(config_item('DEFAULT_PASSWORD_USER_UMUM'), PASSWORD_DEFAULT);

			if (!empty($this->input->post('id_telegram')))
			{
				$user->id_telegram = $this->input->post('id_telegram');
			}

			if (!isset($_FILES['file_fotoprofil']) || trim($_FILES['file_fotoprofil']['name']) === '')
			{
				set_warning("Pas Foto wajib diberikan.");
				redirect($callback);
			}
			elseif($user->upload_profil('file_fotoprofil') === FALSE)
			{
				set_warning("Gagal mengupload Pas Foto.");
				redirect($callback);
			}

			if (!isset($_FILES['file_ktp']) || trim($_FILES['file_ktp']['name']) === '')
			{
				$user->hapus_profil();
				set_warning("KTP wajib diberikan.");
				redirect($callback);
			}
			elseif($user->upload_ktp('file_ktp') === FALSE)
			{
				$user->hapus_profil();
				set_warning("Gagal mengupload KTP.");
				redirect($callback);
			}
			$this->load->model('m_user');
			if ( $this->m_user->add_new_user($user) === FALSE)
			{
				$user->hapus_profil();
				$user->hapus_ktp();
				set_warning("Terjadi kesalahan dalam menambahkan user.");
				redirect($callback);
			}
			redirect($callback);
		}
		elseif ($tipe_user === General_Constants::ITPLN)
		{
			load_data_class('User');
			$user = new D_User();
			$user->email = $this->input->post('email');
			$user->tipe_user = General_Constants::ITPLN;
			$user->nama_depan = $this->input->post('nama_depan');
			$user->nama_belakang = $this->input->post('nama_belakang');
			$user->jenis_kelamin = $this->input->post('jenis_kelamin');
			$user->alamat = $this->input->post('alamat');
			$user->no_telepon = $this->input->post('no_telepon');
			$user->nik = $this->input->post('nik');
			$user->id_jabatan = $this->input->post('id_jabatan');
			$user->username_certiport = $this->input->post('username_certiport');
			$user->password_certiport = $this->input->post('password_certiport');
			if($user->upload_profil('file_fotoprofil') === FALSE)
			{
				set_warning("Gagal mengupload foto profil.");
				redirect($callback);
			}
			$this->load->model("m_user");
			if ($this->m_user->add_new_user($user) === FALSE)
			{
				$user->hapus_profil();
				set_warning("Terjadi kesalahan dalam menambahkan user.");
				redirect($callback);
			}
			redirect($callback);
		}
	}

    public function show_user_umum()
    {
        $this->redirect_if_not_logged_in();
        $this->redirect_if_not_capable(
            'lihat_list_user',
            'Anda tidak diizinkan untuk melihat data user.',
            'admin'
        );
        $this->load->view('admin/user_umum', ['data' => []]);
    }

    public function show_user($id)
    {
        $this->redirect_if_not_logged_in();
        $this->redirect_if_not_capable(
            Permissions::LIHAT_LIST_USER,
            'Anda tidak diizinkan untuk melihat data user.',
            'admin'
        );
        $this->load->model('m_user');
        if ($this->m_user->is_id_user_exists($id) === FALSE)
		{
			set_warning("User tidak ditemukan");
			redirect(base_url('admin'));
		}
        load_data_class('User');
        $user = new D_User($id);
        if ($user->tipe_user === General_Constants::UMUM)
        	$user->load_list_instansi();
        $list_bidang = $this->m_user->get_list_bidang();
        foreach ($list_bidang as $b)
		{
			$b->load_list_jabatan();
		}
        $jabatan_user = NULL;
        if ($user->tipe_user === General_Constants::ITPLN)
		{
			$jabatan_user = new D_Jabatan_User_ITPLN($user->id_jabatan);
		}
        $data = [
            'user' => $user,
			'list_bidang' => $list_bidang,
			'jabatan_user' => $jabatan_user
        ];
        $this->load->view('admin/detail_user', ['data' => $data]);
    }

    public function update_user($id_user)
    {
		$this->redirect_if_not_capable(
			Permissions::EDIT_LIST_USER,
			'Anda tidak diizinkan untuk mengubah data user.',
			'admin'
		);
		$callback = base_url('admin');
        $this->load->model('m_user');
        if($this->m_user->is_id_user_exists($id_user) === FALSE)
        {
            set_warning('User tidak ditemukan.');
            redirect($callback);
        }
        load_data_class('User');
        $existing_user = new D_User($id_user);
        $updated_user = clone $existing_user;
        $updated_user->aktif = (!empty($this->input->post('aktif')) && $this->input->post('aktif') === 'y');
        $updated_user->nama_depan = $this->input->post('nama_depan');
        $updated_user->nama_belakang = $this->input->post('nama_belakang');
        $updated_user->jenis_kelamin = $this->input->post('jenis_kelamin');
        $updated_user->email = $this->input->post('email');
        $updated_user->nim = $this->input->post('nim');
        $updated_user->alamat = $this->input->post('alamat');
        $updated_user->no_telepon = $this->input->post('no_telepon');
        $updated_user->id_line = $this->input->post('id_line');
		$updated_user->id_telegram = $this->input->post('id_telegram');
        $updated_user->username_certiport = $this->input->post('username_certiport');
        $updated_user->password_certiport = $this->input->post('password_certiport');
		$updated_user->nik = $this->input->post('nik');
		$updated_user->nim = $this->input->post('nim');
		$updated_user->id_jabatan = $this->input->post('id_jabatan');

        $new_password = $this->input->post('new_password');
        $new_password2 = $this->input->post('new_password2');
		if (!empty($new_password))
		{
			if ($new_password === $new_password2)
			{
				$updated_user->password = password_hash($new_password, PASSWORD_DEFAULT);
			}
			else{
				set_warning("Konfirmasi kata sandi harus sesuai.");
			}
		}

        if (isset($_FILES['file_fotoprofil']) && trim($_FILES['file_fotoprofil']['name']) !== '')
        {
            if($updated_user->upload_profil('file_fotoprofil') === FALSE)
            {
                set_warning('Gagal mengupload pas foto.');
            }
        }

        if (isset($_FILES['file_ktm']) && trim($_FILES['file_ktm']['name']) !== '')
        {
			if($updated_user->upload_ktm('file_ktm') === FALSE)
			{
				set_warning('Gagal mengupload KTM.');
			}
        }

        if (isset($_FILES['file_ktp']) && trim($_FILES['file_ktp']['name']) !== '')
        {
			if($updated_user->upload_ktp('file_ktp') === FALSE)
			{
				set_warning('Gagal mengupload KTP.');
			}
        }
        if ($this->m_user->update_user($updated_user) === FALSE)
        {
            if ($updated_user->file_fotoprofil !== $existing_user->file_fotoprofil)
            	$updated_user->hapus_profil();
			if ($existing_user->tipe_user === General_Constants::MAHASISWA && $updated_user->file_ktm !== $existing_user->file_ktm)
				$updated_user->hapus_ktm();
			if ($existing_user->tipe_user === General_Constants::UMUM && $updated_user->file_ktp !== $existing_user->file_ktp)
				$updated_user->hapus_ktp();
            set_warning('Gagal dalam mengupdate data user.');
            redirect(base_url('admin/user/'.$id_user));
        }
		if ($updated_user->file_fotoprofil !== $existing_user->file_fotoprofil)
			$existing_user->hapus_profil();
		if ($existing_user->tipe_user === General_Constants::MAHASISWA && $updated_user->file_ktm !== $existing_user->file_ktm)
			$existing_user->hapus_ktm();
		if ($existing_user->tipe_user === General_Constants::UMUM && $updated_user->file_ktp !== $existing_user->file_ktp)
			$existing_user->hapus_ktp();
		redirect(base_url('admin/user/'.$id_user));
    }

    public function show_instansi($id = NULL)
    {
        $this->redirect_if_not_logged_in();
        $this->redirect_if_not_capable(
            'lihat_list_instansi',
            'Anda tidak diizinkan untuk melihat data instansi untuk user umum.',
            'admin'
        );
        $this->load->model('users_model');
        $instansi_all = $this->users_model->get_instansi();
        $data = [
            'instansi_all' => $instansi_all
        ];
        if (!empty($id))
        {
            $data['instansi_selected'] = $this->users_model->get_instansi($id);
        }
        $this->load->view('admin/instansi', ['data' => html_escape($data)]);
    }

    public function tambah_instansi()
    {
        $this->redirect_if_not_capable(
            'tambah_list_instansi',
            'Anda tidak diizinkan untuk menambah instansi baru.',
            'admin/user/instansi'
        );

        $nama = $this->input->post('nama');
        if (!is_string($nama) || trim($nama) === '')
        {
            set_warning('Nama instansi wajib diberikan.');
            redirect(base_url('admin/user/instansi'));
        }
        $nama = trim($nama);

        $no_telepon = $this->input->post('no_telepon');
        if (!ctype_digit($no_telepon))
        {
            set_warning('Nomor telepon instansi tidak valid.');
            redirect(base_url('admin/user/instansi'));
        }

        $alamat = $this->input->post('alamat');
        if (!is_string($alamat) || trim($alamat) === '')
        {
            set_warning('Alamat instansi wajib diberikan.');
            redirect(base_url('admin/user/instansi'));
        }
        $alamat = trim($alamat);

        $this->load->model('users_model');
        $id = $this->users_model->tambah_instansi($nama, $no_telepon, $alamat);
        if ( $id === FALSE)
        {
            set_warning('Gagal dalam menambahkan instansi baru.');
            redirect(base_url('admin/user/instansi'));
        }
        redirect(base_url('admin/user/instansi/'.$id));
    }

    public function update_instansi($id)
    {
        $this->redirect_if_not_capable(
            Permissions::EDIT_LIST_INSTANSI,
            'Anda tidak diizinkan untuk mengubah data instansi untuk user umum.',
            'admin/user/instansi'
        );

        $this->load->model('users_model');
        $instansi = $this->users_model->get_instansi($id);
        if (empty($instansi))
        {
            set_warning('Instansi tidak dapat ditemukan.');
            redirect(base_url('admin/user/instansi'));
        }
        $instansi = reset($instansi);
        $param = [];
        $redirect_uri = base_url('admin/user/instansi/'.$id);

        $nama = $this->input->post('nama');
        if (!is_string($nama) || trim($nama) === '')
        {
            set_warning('Nama instansi wajib diberikan.');
            redirect($redirect_uri);
        }
        $param['nama'] = trim($nama);

        $no_telepon = $this->input->post('no_telepon');
        if (!ctype_digit($no_telepon))
        {
            set_warning('Nomor telepon instansi tidak valid.');
            redirect($redirect_uri);
        }
        $param['no_telepon'] = $no_telepon;

        $alamat = $this->input->post('alamat');
        if (!is_string($alamat) || trim($alamat) === '')
        {
            set_warning('Alamat instansi wajib diberikan.');
            redirect($redirect_uri);
        }
        $param['alamat'] = trim($alamat);

        if ( $this->users_model->update_instansi($id, $param) === FALSE)
        {
            set_warning('Gagal dalam mengubah instansi.');
            redirect($redirect_uri);
        }
        redirect($redirect_uri);
    }

	public function hapus_instansi($id)
	{
		$this->redirect_if_not_capable(
			Permissions::HAPUS_LIST_INSTANSI,
			'Anda tidak diizinkan untuk menghapus data instansi untuk user umum.',
			'admin/user/instansi'
		);
		$redirect_uri = base_url('admin/user/instansi');
		$this->load->model('users_model');
		$instansi = $this->users_model->get_instansi($id);
		if (empty($instansi))
		{
			set_warning('Instansi tidak dapat ditemukan.');
			redirect(base_url('admin/user/instansi'));
		}
		$instansi = reset($instansi);

		if ( $this->users_model->hapus_instansi($id) === FALSE)
		{
			set_warning('Gagal dalam mengubah instansi.');
			redirect($redirect_uri);
		}
		redirect($redirect_uri);
	}

    public function tambah_user_instansi($id_instansi)
    {
        $this->redirect_if_not_capable(
            'edit_list_instansi',
            'Anda tidak diizinkan untuk mengubah data instansi untuk user umum.',
            'admin/user/instansi'
        );

        $this->load->model('users_model');
        $instansi = $this->users_model->get_instansi($id_instansi);
        if (empty($instansi))
        {
            set_warning('Instansi tidak dapat ditemukan.');
            redirect(base_url('admin/user/instansi'));
        }
        $instansi = reset($instansi);
        $redirect_uri = base_url('admin/user/instansi/'.$id_instansi);

        $id_new_users = $this->input->post('id');
        if (!is_array($id_new_users))
        {
            set_warning('User wajib diberikan.');
            redirect($redirect_uri);
        }
        $valid_id = TRUE;
        foreach($id_new_users as $id)
        {
            if (!ctype_digit($id))
                $valid_id = FALSE;
        }
        if (!$valid_id)
        {
            set_warning('User instansi tidak valid.');
            redirect($redirect_uri);
        }
        $param = [
            'users' => $id_new_users
        ];
        if ($this->users_model->update_instansi($id_instansi, $param) === FALSE)
        {
            set_warning('Gagal dalam menambahkan user.');
            redirect($redirect_uri);
        }
        redirect($redirect_uri);
    }

    public function hapus_user_instansi($id_instansi)
    {
        $this->redirect_if_not_capable(
            'edit_list_instansi',
            'Anda tidak diizinkan untuk mengubah data instansi untuk user umum.',
            'admin/user/instansi'
        );

        $this->load->model('users_model');
        $instansi = $this->users_model->get_instansi($id_instansi);
        if (empty($instansi))
        {
            set_warning('Instansi tidak dapat ditemukan.');
            redirect(base_url('admin/user/instansi'));
        }
        $instansi = reset($instansi);
        $redirect_uri = base_url('admin/user/instansi/'.$id_instansi);
        $id = $this->input->post('id');
        if (!ctype_digit($id))
        {
            set_warning('User tidak valid.');
            redirect($redirect_uri);
        }
        $param = [
            'deleted_user' => $id
        ];
        if ($this->users_model->update_instansi($id_instansi, $param) === FALSE)
        {
            set_warning('Gagal dalam menghapus user dari instansi.');
            redirect($redirect_uri);
        }
        redirect($redirect_uri);
    }

    public function show_akun_certiport()
    {
        $this->redirect_if_not_capable(
            'edit_list_user',
            'Anda tidak diizinkan untuk mengubah data user.',
            'admin'
        );
        $this->load->view('admin/akun_certiport', ['data' => []]);
    }

    public function export_bulk_registration_certiport()
    {
        $this->redirect_if_not_capable(
            Permissions::EDIT_LIST_USER,
            'Anda tidak diizinkan untuk mengubah data user.',
            'admin'
        );
        // file name
        $filename = 'bulk_reg_'.time().'.txt';
        header("Content-type: text/plain");
        header('Content-Description: File Transfer');
        header("Content-Disposition: attachment; filename=$filename");
        // get data
        $this->load->model('users_model');
        $data = $this->users_model->get_bulk_registration();

        // file creation
        $file = fopen('php://output', 'w');

        foreach ($data as $key=>$line){
            fputcsv($file,$line, "\t", " ");
        }
        fclose($file);
        exit;
    }

    public function get_template_upload_certiport()
    {
        if (!admin_capable('edit_list_user'))
        {
            set_warning('Anda tidak diizinkan untuk mengubah data user.');
            redirect(base_url('admin'));
        }
        // file name
        $filename = 'template_upload.csv';
        header("Content-type: application/csv");
        header('Content-Description: File Transfer');
        header("Content-Disposition: attachment; filename=$filename");
        // file creation
        $file = fopen('php://output', 'w');
        $header = array("id","email","username","password");
        fputcsv($file, $header);
        fclose($file);
        exit;
    }

    public function upload_certiport_account()
    {
		$this->redirect_if_not_capable(
			Permissions::EDIT_LIST_USER,
			'Anda tidak diizinkan untuk mengubah data user.',
			'admin'
		);
        if (!empty($_FILES['file_akun']) && $_FILES['file_akun']['error'] === UPLOAD_ERR_OK)
        {
            $fh = fopen($_FILES['file_akun']['tmp_name'], 'r+');
            $lines = [];
            while( ($row = fgetcsv($fh)) !== FALSE ) {
                $lines[] = $row;
            }
            fclose($fh);
            if ($lines[0] !== ['id', 'email', 'username', 'password'])
            {
                set_warning('Nama kolom tidak sesuai ketentuan.');
                redirect(base_url('admin/user/certiport'));
            }
            $data = array_splice($lines, 1);
            $this->load->model('m_user');
            if ($this->m_user->set_certiport_bulk($data) === FALSE)
            {
                set_warning('Gagal mengupdate data akun Certiport. Silahkan coba lagi.');
                redirect(base_url('admin/user/certiport'));
            }
            else set_warning('Berhasil mengupdate data akun Certiport.');
        }
        redirect(base_url('admin/user/certiport'));
    }

    public function show_sistem()
    {
        $this->redirect_if_not_logged_in();
        $this->redirect_if_not_capable(
            Permissions::EDIT_KONFIGURASI_SISTEM,
            'Anda tidak diizinkan untuk mengubah konfigurasi sistem.',
            'admin'
        );
        $this->load->model('config_model');
        $timestamp = (string)time();
        $this->load->library('encryption');
        $token = $this->encryption->encrypt($timestamp);
        $link = base_url('admin/sistem/update-system-email?t='.$timestamp.'&key='.urlencode($token));
        $data = [
            'email' =>$this->config_model->get('token_identifier'),
            'link' => $link
        ];
        $this->load->view('admin/sistem', ['data' => $data]);
    }

    public function update_system_email()
    {
        $timestamp = $this->input->get('t');
        $token = $this->input->get('key');
        if (empty($timestamp) || empty($token))
        {
            echo 'Link not valid.';
            return;
        }
        $this->load->library('encryption');
        $plaintext = $this->encryption->decrypt($token);
        if ($plaintext === FALSE || $timestamp !== $plaintext)
        {
            echo 'Link not valid.';
            return;
        }
        // cek timestamp
        $timestamp = (int)$timestamp;
        $now = time();
        if ($now - $timestamp > 180)
        {
            echo 'Link expired.';
            return;
        }
        $this->load->library('system_functions');
        $this->system_functions->create_token();
    }

    public function callback_system_email()
    {
        $this->load->library('system_functions');
        $this->system_functions->callback();
    }

    public function show_history_kegiatan($id_kegiatan = NULL)
    {
        $this->redirect_if_not_logged_in();
        $this->redirect_if_not_capable(
            Permissions::LIHAT_HISTORY_SERTIFIKASI,
            'Anda tidak diizinkan untuk melihat history sertifikasi.',
            'admin'
        );
        $this->load->model("m_kegiatan");
        $list_kegiatan_inactive = $this->m_kegiatan->get_kegiatan_inactive();
        foreach ($list_kegiatan_inactive as $k)
        {
            $k->load_sertifikasi();
        }
        $list_kegiatan_cancelled = $this->m_kegiatan->get_kegiatan_cancelled();
		foreach ($list_kegiatan_cancelled as $k) {
			$k->load_sertifikasi();
        }
		$data = [
			'list_kegiatan_inactive' => $list_kegiatan_inactive,
			'list_kegiatan_cancelled' => $list_kegiatan_cancelled
		];

        // langsung list semua kegiatan kalau id kegiatan tidak valid
        if (!ctype_digit($id_kegiatan))
        {
            $this->load->view('admin/history', ['data'=>$data]);
            return;
        }
        // filter kegiatan
        $id_kegiatan = (int)$id_kegiatan;
        $selected_kegiatan_inactive = array_filter($list_kegiatan_inactive, function($keg) use ($id_kegiatan){
            return ((int)$keg->id === $id_kegiatan);
        });
		$selected_kegiatan_cancelled = array_filter($list_kegiatan_cancelled, function($keg) use ($id_kegiatan){
			return ((int)$keg->id === $id_kegiatan);
		});

        if (empty($selected_kegiatan_inactive) && empty($selected_kegiatan_cancelled))
        {
            set_warning('Kegiatan yang dipilih tidak valid');
            redirect(base_url('admin/sertifikasi/history'));
        }
		/** @var D_Kegiatan $selected_kegiatan */
		$selected_kegiatan = NULL;
        if (!empty($selected_kegiatan_inactive))
		{
			$selected_kegiatan = clone reset($selected_kegiatan_inactive);
		}
		if (!empty($list_kegiatan_cancelled))
		{
			$selected_kegiatan = clone reset($list_kegiatan_cancelled);
		}
		$selected_kegiatan->load_sertifikasi();
		$selected_kegiatan->sertifikasi->load_list_program();
		$selected_kegiatan->load_list_program();
		$selected_kegiatan->load_kelompok_training();
		$selected_kegiatan->load_kelompok_ujian();
		$selected_kegiatan->load_list_pendaftaran();
		$selected_kegiatan->load_list_klaim_dana();

		if ($selected_kegiatan->dibuka_untuk === General_Constants::ITPLN)
		{
			$selected_kegiatan->load_list_peserta_kegiatan_itpln();
		}

		if (admin_capable('lihat_keuangan_kegiatan_sertifikasi'))
		{
			$selected_kegiatan->load_list_pembayaran();
		}
		$selected_kegiatan->load_list_peserta();

		$data = [
			'kegiatan' => $selected_kegiatan,
			'history' => TRUE
		];

		$this->load->view('admin/detail_kegiatan', ['data'=>$data]);
    }

    public function show_history_kelompok_t($id_kelompok)
    {
        $this->redirect_if_not_logged_in();
        $this->redirect_if_not_capable(
            Permissions::LIHAT_HISTORY_SERTIFIKASI,
            'Anda tidak diizinkan untuk melihat history sertifikasi.',
            'admin'
        );
        $callback = base_url('admin/sertifikasi/kegiatan');
        $this->load->model('m_kelompok_t');
        if ($this->m_kelompok_t->is_id_exists($id_kelompok) === FALSE)
        {
            set_warning('Kelompok training tidak ditemukan.');
            redirect($callback);
        }
        load_data_class('Kelompok_T');
        $kelompok = new D_Kelompok_T($id_kelompok);
		load_data_class('Kegiatan');
		$kegiatan = new D_Kegiatan($kelompok->id_kegiatan);
		$kelompok->load_list_peserta();
		$data = [
			'kelompok' => $kelompok,
			'kegiatan' => $kegiatan,
			'history' => TRUE
		];
        $this->load->view('admin/detail_kelompok_t', ['data' => $data]);
    }

	public function show_history_kelompok_u($id_kelompok)
	{
		$this->redirect_if_not_logged_in();
		$this->redirect_if_not_capable(
			Permissions::LIHAT_HISTORY_SERTIFIKASI,
			'Anda tidak diizinkan untuk melihat history sertifikasi.',
			'admin'
		);
		$callback = base_url('admin/sertifikasi/kegiatan');
		$this->load->model('m_kelompok_u');
		if ($this->m_kelompok_u->is_id_exists($id_kelompok) === FALSE)
		{
			set_warning('Kelompok ujian tidak ditemukan.');
			redirect($callback);
		}
		load_data_class('Kelompok_U');
		$kelompok = new D_Kelompok_U($id_kelompok);
		load_data_class('Kegiatan');
		$kegiatan = new D_Kegiatan($kelompok->id_kegiatan);
		$kelompok->load_list_peserta();
		$data = [
			'kelompok' => $kelompok,
			'kegiatan' => $kegiatan,
			'history' => TRUE
		];
		$this->load->view('admin/detail_kelompok_u', ['data' => $data]);
	}

    public function show_history()
    {
        $this->redirect_if_not_logged_in();
        $this->redirect_if_not_capable(
            Permissions::LIHAT_HISTORY_SISTEM,
            'Anda tidak diizinkan untuk melihat history sistem.',
            'admin'
        );

        $this->load->model('m_history');
        $history = $this->m_history->get_history();
        $data = [
            'history' => $history
        ];
        $this->load->view('admin/history_sistem', ['data' => html_escape($data)]);
    }
}

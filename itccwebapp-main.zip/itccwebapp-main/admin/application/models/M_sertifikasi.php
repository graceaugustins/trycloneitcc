<?php defined('BASEPATH') OR exit('No direct script access allowed');
class M_sertifikasi extends CI_Model{

	/**
	 * @return D_Sertifikasi[]
	 */
	public function get_list_sertifikasi(): array
	{
		load_data_class('Sertifikasi');
		$list_result_sertif = $this->db->query(
			"SELECT * FROM sertifikasi"
		)->result_array();
		$list_sertifikasi = [];
		foreach ($list_result_sertif as $data)
		{
			$s = new D_Sertifikasi();
			$s->id = (int)$data['id'];
			$s->nama = $data['nama'];
			$s->deskripsi = $data['deskripsi'];
			$s->file_logo = $data['file_logo'];
			$s->link_template_sertifikat = $data['link_template_sertifikat'];
			$list_sertifikasi[] = $s;
		}
		return $list_sertifikasi;
	}

	public function is_sertif_exists($id): bool
	{
		$jumlah = $this->db->query(
			"SELECT COUNT(1) AS jumlah FROM sertifikasi WHERE id=?",
			[$id]
		)->row_array();
		$jumlah = $jumlah['jumlah'];
		return (int)$jumlah>0;
	}

	public function add_new_sertif(D_Sertifikasi $sertif): bool
	{
		if (!empty($sertif->id)) return FALSE;
		if (!$sertif->validate_data(true)) return FALSE;

		$this->db->trans_start();
		$this->db->query(
			"INSERT INTO sertifikasi (nama, deskripsi, file_logo, link_template_sertifikat) 
			VALUES (?,?,?,?)",
			[
				(string)$sertif->nama,
				(string)$sertif->deskripsi,
				(string)$sertif->file_logo,
				(string)$sertif->link_template_sertifikat
			]
		);
		$sertif->id = $this->db->insert_id();
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function update_sertif(D_Sertifikasi $sertif): bool
	{
		if (empty($sertif->id)) return FALSE;
		if (!$sertif->validate_data()) return FALSE;

		$this->db->trans_start();
		$this->db->query(
			"UPDATE sertifikasi 
			SET nama = ?, deskripsi = ?, file_logo = ?, link_template_sertifikat = ?
			WHERE id = ?",
			[
				(string)$sertif->nama,
				(string)$sertif->deskripsi,
				(string)$sertif->file_logo,
				(string)$sertif->link_template_sertifikat,
				(int)$sertif->id
			]
		);
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function delete_sertif(D_Sertifikasi $sertif): bool
	{
		if (empty($sertif->id)) return FALSE;
		if ($sertif->pernah_diadakan_kegiatan()) return FALSE;
		$this->db->trans_start();
		$this->db->query(
			"DELETE FROM program WHERE id_sertif = ?",
			[
				(int)$sertif->id
			]
		);
		$this->db->query(
			"DELETE FROM sertifikasi WHERE id = ?",
			[
				(int)$sertif->id
			]
		);
		$this->db->trans_complete();
		return $this->db->trans_status();
	}
}

<?php defined('BASEPATH') OR exit('No direct script access allowed');
class M_trainer extends CI_Model{

	/**
	 * @return D_Trainer[]
	 * */
	public function get_list_trainer_aktif(): array
	{
		load_data_class('Trainer');
		$list_data_trainer = $this->db->query(
			"SELECT * FROM trainer WHERE aktif='y'"
		)->result_array();
		$list_trainer = [];
		foreach ($list_data_trainer as $data)
		{
			$data['aktif'] = 'y';

			$t = new D_Trainer();
			$t->surface_fill_from_db($data);
			$list_trainer[] = $t;
		}
		return $list_trainer;
	}

	/**
	 * @return D_Trainer[]
	 * */
	public function get_list_trainer_nonaktif(): array
	{
		load_data_class('Trainer');
		$list_data_trainer = $this->db->query(
			"SELECT * FROM trainer WHERE aktif='n'"
		)->result_array();
		$list_trainer = [];
		foreach ($list_data_trainer as $data)
		{
			$data['aktif'] = 'n';
			$t = new D_Trainer();
			$t->surface_fill_from_db($data);
			$list_trainer[] = $t;
		}
		return $list_trainer;
	}

	public function does_email_already_exists($email) : bool
	{
		$jumlah = $this->db->query(
			"SELECT COUNT(1) AS jumlah FROM trainer WHERE email=?",
			[$email]
		)->row_array();
		$jumlah = $jumlah['jumlah'];
		return (int)$jumlah>0;
	}

	public function get_id_use_email($email): ?int
	{
		if (!is_string($email)) return NULL;
		$id = $this->db->query(
			"SELECT id FROM trainer WHERE email = ? LIMIT 1",
			[$email]
		)->row_array();
		if ($id === NULL) return NULL;
		$id = $id['id'];
		return (int)$id;
	}

	public function does_id_already_exists($id): bool
	{
		$jumlah = $this->db->query(
			"SELECT COUNT(1) AS jumlah FROM trainer WHERE id=?",
			[$id]
		)->row_array();
		$jumlah = $jumlah['jumlah'];
		return (int)$jumlah>0;
	}

	public function add_new_trainer(D_Trainer $trainer): bool
	{
		if (count($trainer->last_create_validation_errors) > 0) return FALSE;

		$this->db->trans_start();
		$this->db->query(
			"INSERT INTO trainer (email, nama_lengkap, no_telepon, file_foto, aktif) VALUES (?,?,?,?,?)",
			[
				(string)$trainer->email,
				(string)$trainer->nama_lengkap,
				(string)$trainer->no_telepon,
				(string)$trainer->file_foto,
				($trainer->aktif) ? 'y' : 'n',
			]
		);
		$trainer->id = (int)$this->db->insert_id();
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function update_trainer(D_Trainer $trainer, $id_program = [], $update_program = TRUE): bool
	{
		if (count($trainer->last_update_validation_errors) > 0) return FALSE;
		$this->db->trans_start();
		$this->db->query(
			"UPDATE trainer 
			SET email = ?, 
			    nama_lengkap = ?, 
			    no_telepon = ?, 
			    file_foto = ?, 
			    aktif = ?
			WHERE id = ?",
			[
				(string)$trainer->email,
				(string)$trainer->nama_lengkap,
				(string)$trainer->no_telepon,
				(string)$trainer->file_foto,
				($trainer->aktif) ? 'y' : 'n',
				$trainer->id
			]
		);
		if ($update_program)
		{
			$this->db->query(
				"DELETE FROM program_trainer
				WHERE id_trainer = ?",
				[
					$trainer->id
				]
			);
			foreach($id_program as $id)
			{
				$this->db->query(
					"INSERT INTO program_trainer (id_trainer, id_program) VALUES (?,?)",
					[
						$trainer->id,
						$id
					]
				);
			}
		}
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function delete_trainer(D_Trainer $trainer): bool
	{
		if (count($trainer->last_delete_validation_errors) > 0) return FALSE;
		$this->db->trans_start();
		$this->db->query(
			"DELETE FROM trainer WHERE id = ?",
			[
				(int)$trainer->id
			]
		);
		$trainer->load_materi();
		$this->db->query(
			"DELETE FROM materi_training WHERE id_trainer = ?",
			[
				(int)$trainer->id
			]
		);
		foreach($trainer->list_materi as $materi)
		{
			$materi->hapus_file();
		}
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function update_kesediaan_trainer(D_Trainer $trainer, array $list_id_kelompok): bool
	{
		foreach($list_id_kelompok as $k => $v)
			$list_id_kelompok[$k] = (int)$v;

		$this->db->trans_start();
		$old_kesediaan = $this->db->query(
			"SELECT id, id_kelompok_t FROM kesediaan_trainer WHERE id_trainer=?",
			[$trainer->id]
		)->result_array();
		$old_id = [];
		foreach($old_kesediaan as $k => $c)
			$old_id[$k] = (int)$c['id_kelompok_t'];
		foreach($old_id as $k => $id)
		{
			// not exists in new
			if (!in_array($id, $list_id_kelompok))
			{
				$this->db->query(
					"DELETE FROM kesediaan_trainer WHERE id=?",
					[$old_kesediaan[$k]['id']]
				);
			}
		}
		foreach($list_id_kelompok as $id)
		{
			// not exists in old
			if (!in_array($id, $old_id))
			{
				$this->db->query(
					"INSERT INTO kesediaan_trainer (id_trainer, id_kelompok_t) VALUES (?,?)",
					[$trainer->id, (int)$id]
				);
			}
		}
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function add_new_materi(D_Trainer $trainer, D_Materi_Trainer $materi): bool
	{
		if (empty($trainer->id)) return FALSE;
		if ($trainer->aktif === FALSE) return FALSE;
		if (!$materi->validate_data(true)) return FALSE;
		$this->db->trans_start();
		$this->db->query(
			"INSERT INTO materi_training
			(
			 id_trainer, 
			 id_program, 
			 nama_file, 
			 deskripsi
			 ) VALUES (?,?,?,?)",
			[
				$trainer->id,
				$materi->id_program,
				$materi->nama_file,
				$materi->deskripsi
			]
		);
		$materi->id = (int)$this->db->insert_id();
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function update_materi(D_Materi_Trainer $materi): bool
	{
		if (empty($materi->id)) return FALSE;
		if (!$materi->validate_data()) return FALSE;
		$this->db->trans_start();
		$this->db->query(
			"UPDATE materi_training SET
			 id_trainer = ?, 
			 id_program = ?, 
			 nama_file = ?, 
			 deskripsi = ?
			WHERE id = ? ",
			[
				$materi->id_trainer,
				$materi->id_program,
				$materi->nama_file,
				$materi->deskripsi,
				$materi->id
			]
		);
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function delete_materi(D_Materi_Trainer $materi): bool
	{
		if (empty($materi->id)) return FALSE;
		$this->db->trans_start();
		$this->db->query(
			"DELETE FROM materi_training WHERE id=?",
			[
				$materi->id
			]
		);
		$this->db->trans_complete();
		$status = $this->db->trans_status();
		if ($status) $materi->hapus_file();
		return $status;
	}

	/**
	 * @return D_Kegiatan[]
	 * */
	public function get_list_kegiatan_history_trainer(D_Trainer $trainer): array
	{
		$list = $this->db->query(
			"SELECT kegiatan.*, COUNT(kelompok_t.id) AS jumlah_kelompok_sesuai_trainer 
			FROM kegiatan
			JOIN kelompok_t ON kelompok_t.id_kegiatan = kegiatan.id
			WHERE kelompok_t.id_trainer_sesi1 = ? OR kelompok_t.id_trainer_sesi2 = ?
			GROUP BY kelompok_t.id_kegiatan, kegiatan.akhir_pelaporan
			ORDER BY kegiatan.akhir_pelaporan DESC",
			[$trainer->id, $trainer->id]
		)->result_array();
		$result = [];
		load_data_class('Kegiatan');
		foreach ($list as $k)
		{
			$kegiatan = new D_Kegiatan();
			$kegiatan->surface_fill_data_from_db_result($k);
			$result[] = $kegiatan;
		}
		return $result;
	}
}

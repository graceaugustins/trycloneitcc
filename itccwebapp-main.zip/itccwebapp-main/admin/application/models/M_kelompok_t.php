<?php defined('BASEPATH') OR exit('No direct script access allowed');
class M_kelompok_t extends CI_Model{

	public function is_id_exists($id): bool
	{
		$jumlah = $this->db->query(
			"SELECT COUNT(1) AS jumlah FROM kelompok_t WHERE id=?",
			[$id]
		)->row_array();
		$jumlah = $jumlah['jumlah'];
		return (int)$jumlah>0;
	}

	public function add_new_kelompok(D_Kelompok_T $kelompok) : bool
	{
		if (!empty($kelompok->id)) return FALSE;
		if (!$kelompok->validate_data(true)) return FALSE;

		$this->db->trans_start();
		$this->db->query(
			"INSERT INTO kelompok_t
            (
             nama_kelompok, 
             id_kegiatan, 
             id_program_kegiatan, 
             mulai_training, 
             selesai_training,
             lokasi_training, 
             min_peserta_training, 
             max_peserta_training
		 	) 
             VALUES 
            (?,?,?,?,?,?,?,?)",
			[
				$kelompok->nama_kelompok,
				$kelompok->id_kegiatan,
				$kelompok->id_program_kegiatan,
				$kelompok->mulai_training->format('Y-m-d H:i:s'),
				$kelompok->selesai_training->format('Y-m-d H:i:s'),
				$kelompok->lokasi_training,
				$kelompok->min_peserta_training,
				$kelompok->max_peserta_training
			]
		);
		$kelompok->id = $this->db->insert_id();
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function update_kelompok(D_Kelompok_T $kelompok) : bool
	{
		if (empty($kelompok->id)) return FALSE;
		if (!$kelompok->validate_data()) return FALSE;

		$this->db->trans_start();
		$this->db->query(
			"UPDATE kelompok_t SET
			nama_kelompok = ?, 
            mulai_training = ?, 
			selesai_training = ?,
			lokasi_training = ?,
		  	id_trainer_sesi1 = ?,
			id_trainer_sesi2 = ?,
		  	id_proctor_training = ?,
			beritaacara_t_sesi1 = ?,
			beritaacara_t_sesi2 = ?,
			min_peserta_training = ?,
			max_peserta_training = ?
			WHERE id = ? ",
			[
				$kelompok->nama_kelompok,
				$kelompok->mulai_training->format('Y-m-d H:i:s'),
				$kelompok->selesai_training->format('Y-m-d H:i:s'),
				$kelompok->lokasi_training,
				$kelompok->id_trainer_sesi1,
				$kelompok->id_trainer_sesi2,
				$kelompok->id_proctor_training,
				$kelompok->beritaacara_t_sesi1,
				$kelompok->beritaacara_t_sesi2,
				$kelompok->min_peserta_training,
				$kelompok->max_peserta_training,
				$kelompok->id
			]
		);
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function delete_kelompok(D_Kelompok_T $kelompok) : bool
	{
		if (empty($kelompok->id)) return FALSE;
		$this->db->trans_start();
		$this->db->query(
			"DELETE FROM kelompok_t WHERE id=?",
			[$kelompok->id]
		);
		$this->db->trans_complete();
		return $this->db->trans_status();
	}


	/**
	 * $id_peserta_hadir :
	 * [[id_peserta_1, TRUE], [id_peserta_2, FALSE], ...]
	 * */
	public function update_absensi_sesi1(array $id_peserta_hadir): bool
	{
		$this->db->trans_start();
		foreach ($id_peserta_hadir as $id)
		{
			$this->db->query(
				"UPDATE pendaftaran SET hadir_training_sesi1 = ? WHERE id = ?",
				[$id[1]? 'y' : 'n', $id[0]]
			);
		}
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	/**
	 * $id_peserta_hadir :
	 * [[id_peserta_1, TRUE], [id_peserta_2, FALSE], ...]
	 * */
	public function update_absensi_sesi2(array $id_peserta_hadir): bool
	{
		$this->db->trans_start();
		foreach ($id_peserta_hadir as $id)
		{
			$this->db->query(
				"UPDATE pendaftaran SET hadir_training_sesi2 = ? WHERE id = ?",
				[$id[1]? 'y' : 'n', $id[0]]
			);
		}
		$this->db->trans_complete();
		return $this->db->trans_status();
	}
}

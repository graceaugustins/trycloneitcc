<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_role extends CI_Model {

	/** @return D_Role[] */
	public function get_all_roles(): array
	{
		$result = [];

		load_data_class('Role');
		$query = $this->db->query(
			"SELECT id, nama_role FROM roles"
		)->result_array();
		foreach ($query as $q) {
			$role = new D_Role();
			$role->surface_fill_from_db($q);
			$result[] = $role;
		}
		return $result;
	}

	public function add_new_role(D_Role $new_role): bool
	{
		if (!empty($new_role->id)) return FALSE;
		if (count($new_role->validate_data(General_Constants::MODE_OPERATION_CREATE)) > 0) return FALSE;
		$this->db->trans_start();
		$this->db->query(
			"INSERT INTO roles (nama_role) VALUES (?)",
			[
				$new_role->nama_role
			]
		);
		$new_role->id = $this->db->insert_id();
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function does_id_already_exists(int $id): bool
	{
		$jumlah = $this->db->query(
			"SELECT COUNT(1) AS jumlah FROM roles WHERE id= ?",
			[$id]
		)->row_array();
		$jumlah = $jumlah['jumlah'];
		return (int)$jumlah > 0;
	}

	public function update_role(D_Role $role): bool
	{
		if (empty($role->id)) return FALSE;
		if (count($role->validate_data(General_Constants::MODE_OPERATION_UPDATE)) > 0) return FALSE;
		$this->db->trans_start();
		$this->db->query(
			"UPDATE roles 
			SET nama_role = ?
			WHERE id = ?",
			[
				$role->nama_role,
				$role->id
			]
		);
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function delete_role(D_Role $role): bool
	{
		if (empty($role->id)) return FALSE;
		if (count($role->validate_data(General_Constants::MODE_OPERATION_DELETE)) > 0) return FALSE;
		$this->db->trans_start();
		$this->db->query(
			"DELETE FROM roles WHERE id = ?",
			[
				(int)$role->id
			]
		);
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	/**
	 * @param $new_id_cap int[]
	 * */
	public function set_new_capability(D_Role $role, array $new_id_cap): bool
	{
		if (empty($role->id)) return FALSE;
		$role->load_capabilities();
		$this->db->trans_start();
		foreach ($role->capabilities as $cap) {
			$exists_in_new = FALSE;
			foreach ($new_id_cap as $id_cap) {
				if ((int)$id_cap === (int)$cap->id && $cap->is_eligible) $exists_in_new = TRUE;
			}
			if ($exists_in_new === FALSE)
				$this->db->query(
					"DELETE FROM hak_akses WHERE id_role=? AND id_capabilities = ?",
					[$role->id, $cap->id]
				);
		}
		foreach ($new_id_cap as $id_cap) {
			$exists_in_old = FALSE;
			foreach ($role->capabilities as $cap) {
				if ((int)$id_cap === (int)$cap->id && $cap->is_eligible) $exists_in_old = TRUE;
			}
			if ($exists_in_old === FALSE)
				$this->db->query(
					"INSERT INTO hak_akses(id_role, id_capabilities) VALUES (?,?)",
					[$role->id, $id_cap]
				);
		}
		$this->db->trans_complete();
		return $this->db->trans_status();
	}
}

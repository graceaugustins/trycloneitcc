<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Trainers_model extends CI_Model{
	// Cek apakah email user yang login
	// adalah trainer atau bukan
	public function is_trainer($email)
	{
		$email = trim(strtolower($email));
		$query = $this->db->query("SELECT COUNT(email) AS jumlah_email
			FROM trainer WHERE email=?",
			[$email]
		)->row_array();

		if((int)$query['jumlah_email']>0)
			return TRUE;
		return FALSE;
	}

    public function get_detail($email)
    {
        $trainer = NULL;
        $trainer = $this->db->query(
            'SELECT id, email, nama_lengkap, no_telepon, file_foto, aktif
            FROM trainer WHERE email=?',
            [(string)$email]
        )->row_array();
        $trainer['aktif'] = ($trainer['aktif'] ==='y');
        return $trainer;
	}
}
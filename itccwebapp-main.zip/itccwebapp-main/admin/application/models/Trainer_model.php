<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Trainer_model extends CI_Model{
    /*
     * List daftar trainer
     * */
    public function get_trainer($id = NULL)
    {
        $trainer = NULL;
        if ($id === NULL)
            $trainer = $this->db->query(
                'SELECT *
                FROM trainer'
            )->result_array();

        elseif(is_numeric($id))
            $trainer = $this->db->query(
                'SELECT *
                FROM trainer WHERE id=?',
                [(int)$id]
            )->result_array();
        elseif(is_array($id))
        {
            $in  = str_repeat('?,', count($id) - 1) . '?';
            $query = "SELECT *
                FROM trainer WHERE id IN ($in)";
            $trainer = $this->db->query(
                $query,
                $id
            )->result_array();
        }
        else return NULL;

        foreach($trainer as $k_t => $t)
        {
            $trainer[$k_t]['aktif'] = ($t['aktif'] ==='y');
        }

        $program = $this->db->query(
            'SELECT program_trainer.id_trainer, program.id, program.nama_program, program.id_sertif, sertifikasi.nama AS nama_sertif
                FROM program_trainer 
                JOIN program ON program.id = program_trainer.id_program
                JOIN sertifikasi ON sertifikasi.id = program.id_sertif'
        )->result_array();

        foreach($trainer as $k_t => $t)
        {
            $trainer[$k_t]['program'] = [];
            foreach($program as $p)
            {
                if ((int)$p['id_trainer'] === (int)$t['id'])
                {
                    $trainer[$k_t]['program'][] = [
                        'id'            => $p['id'],
                        'nama_program'  => $p['nama_program'],
                        'id_sertif'     => $p['id_sertif'],
                        'nama_sertif'   => $p['nama_sertif']
                    ];
                }
            }
        }

        return $trainer;
    }


    /*
     * Get jumlah peserta yang lulus dari trainer ini
     * berdasarkan "sertifikasi", atau "program"
     * return -1 kalau error
     * */
	public function get_jumlah_peserta_lulus($trainer, $c)
	{
		if ($c === 'sertifikasi')
		{
			// grouping sertifikasi trainer
			$id_sertifikasi_trainer = [];
			$sertifikasi_trainer = [];
			foreach($trainer['program'] as $program_trainer)
			{
				$id = (int)$program_trainer['id_sertif'];
				if (!in_array($id, $id_sertifikasi_trainer))
				{
					$id_sertifikasi_trainer[] = $id;
					$sertifikasi_trainer[] = [
						'id' => $id,
						'nama' => $program_trainer['nama_sertif']
					];
				}
			}
			foreach($sertifikasi_trainer as $k_sertifikasi => $sertifikasi)
			{
				$jumlah = $this->db->query(
					"SELECT COUNT(1) AS jumlah_lulus
					FROM pendaftaran
					JOIN kelompok_t ON kelompok_t.id = pendaftaran.id_kelompok_t
					JOIN kelompok_u ON kelompok_u.id = pendaftaran.id_kelompok_u
					JOIN program_kegiatan ON program_kegiatan.id = pendaftaran.id_program_kegiatan
					JOIN program ON program.id = program_kegiatan.id_program
					JOIN kegiatan ON kegiatan.id = kelompok_t.id_kegiatan
					WHERE 
					pendaftaran.skor_ujian >= program.min_skor AND
					(kelompok_t.id_trainer_sesi1 = ? OR kelompok_t.id_trainer_sesi2 = ?) AND 
					kegiatan.id_sertifikasi = ?",
					[(int)$trainer['id'],(int)$trainer['id'], (int)$sertifikasi['id']]
				)->row_array();
				$sertifikasi_trainer[$k_sertifikasi]['jumlah_lulus'] = (int)$jumlah['jumlah_lulus'];
			}
			return $sertifikasi_trainer;
		}
		elseif ($c === 'program')
		{
			// grouping sertifikasi dan program trainer
			$program = [];
			foreach($trainer['program'] as $program_trainer)
			{
				$program[$program_trainer['id_sertif']][] = [
					'id' => $program_trainer['id'],
					'nama' => $program_trainer['nama_program'],
					'nama_sertifikasi' => $program_trainer['nama_sertif']
				];
			}
			foreach($program as $k_pr => $pr)
			{
				foreach($pr as $k_p => $p)
				{
					$jumlah = $this->db->query(
						"SELECT COUNT(1) AS jumlah_lulus
						FROM pendaftaran
						JOIN kelompok_t ON kelompok_t.id = pendaftaran.id_kelompok_t
						JOIN kelompok_u ON kelompok_u.id = pendaftaran.id_kelompok_u
						JOIN program_kegiatan ON program_kegiatan.id = pendaftaran.id_program_kegiatan
						JOIN program ON program.id = program_kegiatan.id_program
						WHERE 
						pendaftaran.skor_ujian >= program.min_skor AND
						(kelompok_t.id_trainer_sesi1 = ? OR kelompok_t.id_trainer_sesi2 = ?) AND 
						program.id = ?",
							[(int)$trainer['id'],(int)$trainer['id'], (int)$p['id']]
						)->row_array();
					$program[$k_pr][$k_p]['jumlah_lulus'] = (int)$jumlah['jumlah_lulus'];
				}

			}
			return $program;
		}
		elseif($c === 'total')
		{
			$jumlah = $this->db->query(
				"SELECT COUNT(1) AS jumlah_lulus
				FROM pendaftaran
				JOIN kelompok_t ON kelompok_t.id = pendaftaran.id_kelompok_t
				JOIN kelompok_u ON kelompok_u.id = pendaftaran.id_kelompok_u
				JOIN program_kegiatan ON program_kegiatan.id = pendaftaran.id_program_kegiatan
				JOIN program ON program.id = program_kegiatan.id_program
				WHERE 
				pendaftaran.skor_ujian >= program.min_skor AND
				(kelompok_t.id_trainer_sesi1 = ? OR kelompok_t.id_trainer_sesi2 = ?)",
				[(int)$trainer['id'],(int)$trainer['id']]
			)->row_array();
			return (int)$jumlah['jumlah_lulus'];
		}
		else
			return [];
    }

	public function get_jumlah_peserta_tidaklulus($trainer, $c)
	{
		if ($c === 'sertifikasi')
		{
			// grouping sertifikasi trainer
			$id_sertifikasi_trainer = [];
			$sertifikasi_trainer = [];
			foreach($trainer['program'] as $program_trainer)
			{
				$id = (int)$program_trainer['id_sertif'];
				if (!in_array($id, $id_sertifikasi_trainer))
				{
					$id_sertifikasi_trainer[] = $id;
					$sertifikasi_trainer[] = [
						'id' => $id,
						'nama' => $program_trainer['nama_sertif']
					];
				}
			}
			foreach($sertifikasi_trainer as $k_sertifikasi => $sertifikasi)
			{
				$jumlah = $this->db->query(
					"SELECT COUNT(1) AS jumlah_tidaklulus
					FROM pendaftaran
					JOIN kelompok_t ON kelompok_t.id = pendaftaran.id_kelompok_t
					JOIN kelompok_u ON kelompok_u.id = pendaftaran.id_kelompok_u
					JOIN program_kegiatan ON program_kegiatan.id = pendaftaran.id_program_kegiatan
					JOIN program ON program.id = program_kegiatan.id_program
					JOIN kegiatan ON kegiatan.id = kelompok_t.id_kegiatan
					WHERE 
					pendaftaran.skor_ujian < program.min_skor AND pendaftaran.skor_ujian <> -1 AND 
					(kelompok_t.id_trainer_sesi1 = ? OR kelompok_t.id_trainer_sesi2 = ?) AND 
					kegiatan.id_sertifikasi = ?",
					[(int)$trainer['id'],(int)$trainer['id'], (int)$sertifikasi['id']]
				)->row_array();
				$sertifikasi_trainer[$k_sertifikasi]['jumlah_tidaklulus'] = (int)$jumlah['jumlah_tidaklulus'];
			}
			return $sertifikasi_trainer;
		}
		elseif ($c === 'program')
		{
			// grouping sertifikasi dan program trainer
			$program = [];
			foreach($trainer['program'] as $program_trainer)
			{
				$program[$program_trainer['id_sertif']][] = [
					'id' => $program_trainer['id'],
					'nama' => $program_trainer['nama_program'],
					'nama_sertifikasi' => $program_trainer['nama_sertif']
				];
			}
			foreach($program as $k_pr => $pr)
			{
				foreach($pr as $k_p => $p)
				{
					$jumlah = $this->db->query(
						"SELECT COUNT(1) AS jumlah_tidaklulus
						FROM pendaftaran
						JOIN kelompok_t ON kelompok_t.id = pendaftaran.id_kelompok_t
						JOIN kelompok_u ON kelompok_u.id = pendaftaran.id_kelompok_u
						JOIN program_kegiatan ON program_kegiatan.id = pendaftaran.id_program_kegiatan
						JOIN program ON program.id = program_kegiatan.id_program
						WHERE 
						pendaftaran.skor_ujian < program.min_skor AND 
						pendaftaran.skor_ujian <> -1 AND
						(kelompok_t.id_trainer_sesi1 = ? OR kelompok_t.id_trainer_sesi2 = ?) AND 
						program.id = ?",
						[(int)$trainer['id'],(int)$trainer['id'], (int)$p['id']]
					)->row_array();
					$program[$k_pr][$k_p]['jumlah_tidaklulus'] = (int)$jumlah['jumlah_tidaklulus'];
				}

			}
			return $program;
		}
		else
			return [];
	}

	public function get_jumlah_peserta_pending($trainer, $c)
	{
		if ($c === 'sertifikasi')
		{
			// grouping sertifikasi trainer
			$id_sertifikasi_trainer = [];
			$sertifikasi_trainer = [];
			foreach($trainer['program'] as $program_trainer)
			{
				$id = (int)$program_trainer['id_sertif'];
				if (!in_array($id, $id_sertifikasi_trainer))
				{
					$id_sertifikasi_trainer[] = $id;
					$sertifikasi_trainer[] = [
						'id' => $id,
						'nama' => $program_trainer['nama_sertif']
					];
				}
			}
			foreach($sertifikasi_trainer as $k_sertifikasi => $sertifikasi)
			{
				$jumlah = $this->db->query(
					"SELECT COUNT(1) AS jumlah_pending
					FROM pendaftaran
					JOIN kelompok_t ON kelompok_t.id = pendaftaran.id_kelompok_t
					JOIN kelompok_u ON kelompok_u.id = pendaftaran.id_kelompok_u
					JOIN kegiatan ON kegiatan.id = kelompok_t.id_kegiatan
					WHERE 
					pendaftaran.skor_ujian = -1 AND
					(kelompok_t.id_trainer_sesi1 = ? OR kelompok_t.id_trainer_sesi2 = ?) AND 
					kegiatan.id_sertifikasi = ?",
					[(int)$trainer['id'],(int)$trainer['id'], (int)$sertifikasi['id']]
				)->row_array();
				$sertifikasi_trainer[$k_sertifikasi]['jumlah_pending'] = (int)$jumlah['jumlah_pending'];
			}
			return $sertifikasi_trainer;
		}
		elseif ($c === 'program')
		{
			// grouping sertifikasi dan program trainer
			$program = [];
			foreach($trainer['program'] as $program_trainer)
			{
				$program[$program_trainer['id_sertif']][] = [
					'id' => $program_trainer['id'],
					'nama' => $program_trainer['nama_program'],
					'nama_sertifikasi' => $program_trainer['nama_sertif']
				];
			}
			foreach($program as $k_pr => $pr)
			{
				foreach($pr as $k_p => $p)
				{
					$jumlah = $this->db->query(
						"SELECT COUNT(1) AS jumlah_pending
						FROM pendaftaran
						JOIN kelompok_t ON kelompok_t.id = pendaftaran.id_kelompok_t
						JOIN kelompok_u ON kelompok_u.id = pendaftaran.id_kelompok_u
						JOIN program_kegiatan ON program_kegiatan.id = pendaftaran.id_program_kegiatan
						JOIN program ON program.id = program_kegiatan.id_program
						WHERE 
						pendaftaran.skor_ujian = -1 AND 
						(kelompok_t.id_trainer_sesi1 = ? OR kelompok_t.id_trainer_sesi2 = ?) AND 
						program.id = ?",
						[(int)$trainer['id'],(int)$trainer['id'], (int)$p['id']]
					)->row_array();
					$program[$k_pr][$k_p]['jumlah_pending'] = (int)$jumlah['jumlah_pending'];
				}

			}
			return $program;
		}
		else
			return [];
	}
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kegiatan_model extends CI_Model {

    private $ci;

    public function __construct()
    {
        parent::__construct();
        $this->ci =& get_instance();
    }

    public function get_kegiatan_nonaktif()
    {
        $sekarang = new DateTime();
        $id = $this->db->query(
            "SELECT id FROM kegiatan 
            WHERE ? > akhir_pelaporan OR batal='y'
			ORDER BY akhir_pelaporan DESC",
            [(string)$sekarang->format('Y-m-d')]
        )->result_array();
        $kegiatan = [];
        foreach($id as $id_kegiatan)
        {
            $kegiatan[] =  $this->get_kegiatan($id_kegiatan['id']);
        }
        return $kegiatan;
    }

    /*
     * Ambil data jumlah peserta registrasi kegiatan
     * */
    public function get_statistik_regis($id, $parameter)
    {
        $result = [];
        foreach($parameter as $param )
        {
            if ($param === 'total')
            {
                $value = $this->db->query(
                    "SELECT COUNT(id) AS jumlah FROM pendaftaran WHERE id_kegiatan=?",
                    [(int)$id]
                )->row_array();
                $value = $value['jumlah'];
                $result['total'] = (int)$value;
            }
            elseif ($param === 'approved')
            {
                $value = $this->db->query(
                    "SELECT COUNT(id) AS jumlah FROM pendaftaran WHERE id_kegiatan=? AND approved='y'",
                    [(int)$id]
                )->row_array();
                $value = $value['jumlah'];
                $result['approved'] = (int)$value;
            }
            elseif ($param === 'sudah_pilih_kelompok_t')
            {
                $value = $this->db->query(
                    "SELECT COUNT(id) AS jumlah FROM pendaftaran WHERE id_kegiatan=? AND approved='y' AND id_kelompok_t IS NOT NULL",
                    [(int)$id]
                )->row_array();
                $value = $value['jumlah'];
                $result['sudah_pilih_kelompok_t'] = (int)$value;
            }
            elseif ($param === 'sudah_pilih_kelompok_u')
            {
                $value = $this->db->query(
                    "SELECT COUNT(id) AS jumlah FROM pendaftaran WHERE id_kegiatan=? AND approved='y' AND id_kelompok_u IS NOT NULL",
                    [(int)$id]
                )->row_array();
                $value = $value['jumlah'];
                $result['sudah_pilih_kelompok_u'] = (int)$value;
            }
        }
        return $result;
    }
}

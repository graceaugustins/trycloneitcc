<?php defined('BASEPATH') OR exit('No direct script access allowed');

class M_history extends CI_Model{

    public function login($email, $role)
    {
        $now = new DateTime();
        $deskripsi = "User $email - $role login ke dalam sistem.";
        $this->db->trans_start();
        $this->db->query(
            "INSERT INTO history (waktu, deskripsi) VALUES (?,?)",
            [$now->format('Y-m-d H:i:s'), $deskripsi]
        );
        $this->db->trans_complete();
	}

    public function logout($email, $role)
    {
        $now = new DateTime();
        $deskripsi = "User $email - $role logout ke dalam sistem.";
        $this->db->trans_start();
        $this->db->query(
            "INSERT INTO history (waktu, deskripsi) VALUES (?,?)",
            [$now->format('Y-m-d H:i:s'), $deskripsi]
        );
        $this->db->trans_complete();
    }

    public function get_history()
    {
        return $this->db->query(
            "SELECT * FROM history ORDER BY waktu DESC LIMIT 500"
        )->result_array();
    }
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sertifikasi_model extends CI_Model{

    /*
     * List daftar sertifikasi beserta programnya
     * */
    public function get_sertifikasi($id = NULL)
    {
        $sertifikasi = NULL;
        if ($id === NULL)
            $sertifikasi = $this->db->query(
                "SELECT * FROM sertifikasi"
            )->result_array();
        elseif(is_numeric($id))
            $sertifikasi = $this->db->query(
                "SELECT * FROM sertifikasi WHERE id=?",
                [(int)$id]
            )->result_array();
        elseif(is_array($id))
        {
            $in  = str_repeat('?,', count($id) - 1) . '?';
            $query = "SELECT * FROM sertifikasi WHERE id IN ($in)";
            $sertifikasi = $this->db->query(
                $query,
                $id
            )->result_array();
        }
        else return NULL;

        $program = $this->db->query(
            "SELECT *
            FROM program ORDER BY nama_program"
        )->result_array();
        foreach($sertifikasi as $k_s => $s)
        {
            $sertifikasi[$k_s]['program'] = [];
            foreach($program as $p)
            {
                if ((int)$p['id_sertif'] === (int)$s['id'])
                {
                    $sertifikasi[$k_s]['program'][] = $p;
                }
            }
        }
        return $sertifikasi;
    }
}

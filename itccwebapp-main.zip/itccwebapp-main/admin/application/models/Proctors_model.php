<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Proctors_model extends CI_Model{
	// Cek apakah email user yang login
	// adalah proctor atau bukan
	public function is_proctor($email)
	{
		$email = trim(strtolower($email));
		$query = $this->db->query("SELECT COUNT(email) AS jumlah_email
			FROM proctor WHERE email=?",
			[$email]
		)->row_array();

		if((int)$query['jumlah_email']>0)
			return TRUE;
		return FALSE;
	}

    public function get_detail($email)
    {
        $proctor = NULL;
        $proctor = $this->db->query(
            'SELECT id, email, nama_lengkap, no_telepon, file_foto, aktif
            FROM proctor WHERE email=?',
            [(string)$email]
        )->row_array();
        $proctor['aktif'] = ($proctor['aktif'] ==='y');
        return $proctor;
	}
}
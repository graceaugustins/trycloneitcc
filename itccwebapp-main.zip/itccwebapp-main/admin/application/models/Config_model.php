<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Config_model extends CI_Model{
    public function get($key)
    {
        $key = (string)$key;
        $result = $this->db->query(
            "SELECT value FROM config WHERE name=?",
            [strtolower(trim($key))]
        )->row_array();
        if (empty($result))
            return NULL;
        return $result['value'];
    }
    public function set($key, $val)
    {
        $this->db->trans_start();
        $result = $this->db->query(
            "SELECT value FROM config WHERE name=?",
            [strtolower(trim($key))]
        )->row_array();
        if (empty($result))
        {
            $this->db->query(
                "INSERT INTO config (name, value) VALUES (?,?)",
                [strtolower(trim($key)), (string)$val]
            );
        }
        else
        {
            $this->db->query(
                "UPDATE config SET value=? WHERE name=?",
                [(string)$val, strtolower(trim($key))]
            );
        }
        $this->db->trans_complete();
    }
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Proctor_model extends CI_Model{
    /*
     * List daftar proctor
     * */
    public function get_proctor($id = NULL)
    {
        $proctor = NULL;
        if ($id === NULL)
            $proctor = $this->db->query(
                'SELECT *
                FROM proctor'
            )->result_array();

        elseif(is_numeric($id))
            $proctor = $this->db->query(
                'SELECT *
                FROM proctor WHERE id=?',
                [(int)$id]
            )->result_array();
        elseif(is_array($id))
        {
            $in  = str_repeat('?,', count($id) - 1) . '?';
            $query = "SELECT *
                FROM proctor WHERE id IN ($in)";
            $proctor = $this->db->query(
                $query,
                $id
            )->result_array();
        }
        else return NULL;

        foreach($proctor as $k_p => $p)
            $proctor[$k_p]['aktif'] = $p['aktif']==='y';

        $sertifikasi = $this->db->query(
            'SELECT sertifikasi_proctor.id_proctor, sertifikasi.id, sertifikasi.nama
                FROM sertifikasi_proctor 
                JOIN sertifikasi ON sertifikasi.id = sertifikasi_proctor.id_sertifikasi'
        )->result_array();

        foreach($proctor as $k_p => $p)
        {
            $proctor[$k_p]['sertifikasi'] = [];
            foreach($sertifikasi as $s)
            {
                if ((int)$s['id_proctor'] === (int)$p['id'])
                {
                    $proctor[$k_p]['sertifikasi'][] = [
                        'id'    => $s['id'],
                        'nama'  => $s['nama']
                    ];
                }
            }
        }

        return $proctor;
    }


    /*
     * Ubah data proctor
     * */
    public function update_proctor($id, $columns)
    {
        $this->db->trans_start();
        if (isset($columns['email']))
            $this->db->query(
                'UPDATE proctor set email=? WHERE id=?',
                [(string)$columns['email'], (int)$id]
            );
        if (isset($columns['nama_lengkap']))
            $this->db->query(
                'UPDATE proctor set nama_lengkap=? WHERE id=?',
                [(string)$columns['nama_lengkap'], (int)$id]
            );
        if (isset($columns['no_telepon']))
            $this->db->query(
                'UPDATE proctor set no_telepon=? WHERE id=?',
                [(string)$columns['no_telepon'], (int)$id]
            );
        if (isset($columns['file_foto']))
            $this->db->query(
                'UPDATE proctor set file_foto=? WHERE id=?',
                [(string)$columns['file_foto'], (int)$id]
            );
        if (isset($columns['aktif']))
        {
            if ($columns['aktif'] === TRUE)
                $this->db->query(
                    "UPDATE proctor set aktif='y' WHERE id=?",
                    [(int)$id]
                );
            elseif($columns['aktif'] === FALSE)
                $this->db->query(
                    "UPDATE proctor set aktif='n' WHERE id=?",
                    [(int)$id]
                );
        }
        if (isset($columns['id_sertifikasi']))
        {
            $old_s_proctor = $this->db->query(
                "SELECT id, id_sertifikasi FROM sertifikasi_proctor WHERE id_proctor=?",
                [(int)$id]
            )->result_array();
            $new_s_proctor = $columns['id_sertifikasi'];
            // delete jika old tidak ada di new
            foreach($old_s_proctor as $old)
            {
                $exists_on_new = FALSE;
                foreach($new_s_proctor as $new)
                {
                    if ((int)$new === (int)$old['id_sertifikasi']) $exists_on_new = TRUE;
                }
                if ($exists_on_new === FALSE)
                {
                    $this->db->query(
                        "DELETE FROM sertifikasi_proctor WHERE id=?",
                        [(int)$old['id']]
                    );
                }
            }
            // insert jika new tidak ada di old
            foreach($new_s_proctor as $new)
            {
                $exists_on_old = FALSE;
                foreach($old_s_proctor as $old)
                {
                    if ((int)$new === (int)$old['id_sertifikasi']) $exists_on_old = TRUE;
                }
                if ($exists_on_old === FALSE)
                {
                    $this->db->query(
                        "INSERT INTO sertifikasi_proctor (id_proctor, id_sertifikasi) VALUES (?,?)",
                        [(int)$id, (int)$new]
                    );
                }
            }
        }
        $this->db->trans_complete();
        return $this->db->trans_status();
    }


	/*
	 * Get jumlah peserta yang lulus dari proctor ini
	 * berdasarkan "sertifikasi", atau "program"
	 * return -1 kalau error
	 * */
	public function get_jumlah_peserta_lulus($proctor, $c)
	{
		if ($c === 'sertifikasi')
		{
			$sertifikasi_proctor = $proctor['sertifikasi'];
			foreach($sertifikasi_proctor as $k_sertifikasi => $sertifikasi)
			{
				$jumlah = $this->db->query(
					"SELECT COUNT(1) AS jumlah_lulus
					FROM pendaftaran
					JOIN kelompok_t ON kelompok_t.id = pendaftaran.id_kelompok_t
					JOIN kelompok_u ON kelompok_u.id = pendaftaran.id_kelompok_u
					JOIN program_kegiatan ON program_kegiatan.id = pendaftaran.id_program_kegiatan
					JOIN program ON program.id = program_kegiatan.id_program
					JOIN kegiatan ON kegiatan.id = pendaftaran.id_kegiatan
					WHERE 
					pendaftaran.skor_ujian >= program.min_skor AND
					(kelompok_t.id_proctor_training = ? OR kelompok_u.id_proctor_ujian = ?) AND 
					kegiatan.id_sertifikasi = ?",
					[(int)$proctor['id'],(int)$proctor['id'], (int)$sertifikasi['id']]
				)->row_array();
				$sertifikasi_proctor[$k_sertifikasi]['jumlah_lulus'] = (int)$jumlah['jumlah_lulus'];
			}
			return $sertifikasi_proctor;
		}
		else
			return [];
	}

	public function get_jumlah_peserta_tidaklulus($proctor, $c)
	{
		if ($c === 'sertifikasi')
		{
			$sertifikasi_proctor = $proctor['sertifikasi'];
			foreach($sertifikasi_proctor as $k_sertifikasi => $sertifikasi)
			{
				$jumlah = $this->db->query(
					"SELECT COUNT(1) AS jumlah_tidaklulus
					FROM pendaftaran
					JOIN kelompok_t ON kelompok_t.id = pendaftaran.id_kelompok_t
					JOIN kelompok_u ON kelompok_u.id = pendaftaran.id_kelompok_u
					JOIN program_kegiatan ON program_kegiatan.id = pendaftaran.id_program_kegiatan
					JOIN program ON program.id = program_kegiatan.id_program
					JOIN kegiatan ON kegiatan.id = pendaftaran.id_kegiatan
					WHERE 
					pendaftaran.skor_ujian >= 0 AND 
					pendaftaran.skor_ujian < program.min_skor AND
					(kelompok_t.id_proctor_training = ? OR kelompok_u.id_proctor_ujian = ?) AND 
					kegiatan.id_sertifikasi = ?",
					[(int)$proctor['id'],(int)$proctor['id'], (int)$sertifikasi['id']]
				)->row_array();
				$sertifikasi_proctor[$k_sertifikasi]['jumlah_tidaklulus'] = (int)$jumlah['jumlah_tidaklulus'];
			}
			return $sertifikasi_proctor;
		}
		else
			return [];
	}

	public function get_jumlah_peserta_pending($proctor, $c)
	{
		if ($c === 'sertifikasi')
		{
			$sertifikasi_proctor = $proctor['sertifikasi'];
			foreach($sertifikasi_proctor as $k_sertifikasi => $sertifikasi)
			{
				$jumlah = $this->db->query(
					"SELECT COUNT(1) AS jumlah_pending
					FROM pendaftaran
					JOIN kelompok_t ON kelompok_t.id = pendaftaran.id_kelompok_t
					JOIN kelompok_u ON kelompok_u.id = pendaftaran.id_kelompok_u
					JOIN program_kegiatan ON program_kegiatan.id = pendaftaran.id_program_kegiatan
					JOIN program ON program.id = program_kegiatan.id_program
					JOIN kegiatan ON kegiatan.id = pendaftaran.id_kegiatan
					WHERE 
					pendaftaran.skor_ujian = -1 AND 
					(kelompok_t.id_proctor_training = ? OR kelompok_u.id_proctor_ujian = ?) AND 
					kegiatan.id_sertifikasi = ?",
					[(int)$proctor['id'],(int)$proctor['id'], (int)$sertifikasi['id']]
				)->row_array();
				$sertifikasi_proctor[$k_sertifikasi]['jumlah_pending'] = (int)$jumlah['jumlah_pending'];
			}
			return $sertifikasi_proctor;
		}
		else
			return [];
	}

	public function get_list_kegiatan_history_proctor($id_proctor)
	{
		$this->load->model('kegiatan_model');
		$list_kegiatan = $this->kegiatan_model->get_kegiatan_nonaktif();
		foreach ($list_kegiatan as $k_list => $keg)
		{
			$total_training = 0;
			$total_ujian = 0;
			$list_kegiatan[$k_list]['sebagai_proctor_training'] = FALSE;
			$list_kegiatan[$k_list]['sebagai_proctor_ujian'] = FALSE;
			foreach($keg['kelompok'] as $kel)
			{
				if ((int)$kel['id_proctor_training'] === (int)$id_proctor)
				{
					$list_kegiatan[$k_list]['sebagai_proctor_training'] = TRUE;
					$total_training += (int)$kel['jumlah_peserta_t'];
				}

				if ((int)$kel['id_proctor_ujian'] === (int)$id_proctor)
				{
					$list_kegiatan[$k_list]['sebagai_proctor_ujian'] = TRUE;
					$total_ujian += (int)$kel['jumlah_peserta_u'];
				}
			}
			$list_kegiatan[$k_list]['jumlah_peserta_proctor_training']  = $total_training;
			$list_kegiatan[$k_list]['jumlah_peserta_proctor_ujian']  = $total_ujian;
		}
		// rapikan list kegiatan, dan filter hanya yang diikuti proctor saja
		$list_kegiatan_ = [];
		foreach ($list_kegiatan as $keg)
		{
			if ($keg['sebagai_proctor_training'] || $keg['sebagai_proctor_ujian'])
				$list_kegiatan_[] = $keg;
		}
		$list_kegiatan = $list_kegiatan_;
		unset($list_kegiatan_);

		foreach ($list_kegiatan as $k_list => $keg)
		{
			$list_kegiatan[$k_list]['statistik'] =
				$this->kegiatan_model->get_statistik_regis($keg['id'], ['approved']);
			$sudah_ujian = [
				'training' => 0,
				'ujian' => 0
			];
			$sebagai_proctor_training = $keg['sebagai_proctor_training'];
			$sebagai_proctor_ujian = $keg['sebagai_proctor_ujian'];
			if ($sebagai_proctor_training)
			{
				$sudah_ujian['training'] = (int)$this->db->query(
					"SELECT COUNT(1) AS jumlah
				FROM pendaftaran
				JOIN kelompok ON kelompok.id = pendaftaran.id_kelompok_t
				WHERE 
				      kelompok.id_proctor_training = ? AND 
				      kelompok.id_kegiatan = ? AND
				      pendaftaran.skor_ujian <> -1",
					[(int)$id_proctor, (int)$keg['id']]
				)->row_array()['jumlah'];
			}
			if ($sebagai_proctor_ujian)
			{
				$sudah_ujian['ujian'] = (int)$this->db->query(
					"SELECT COUNT(1) AS jumlah
				FROM pendaftaran
				JOIN kelompok ON kelompok.id = pendaftaran.id_kelompok_t
				WHERE 
				      kelompok.id_proctor_ujian = ? AND 
				      kelompok.id_kegiatan = ? AND
				      pendaftaran.skor_ujian <> -1",
					[(int)$id_proctor, (int)$keg['id']]
				)->row_array()['jumlah'];
			}
			$list_kegiatan[$k_list]['jumlah_peserta_proctor_sudah_ujian'] = $sudah_ujian;

			$lulus = [
				'training' => 0,
				'ujian' => 0
			];
			if ($sebagai_proctor_training)
			{
				$lulus['training'] = (int)$this->db->query(
					"SELECT COUNT(1) AS jumlah
					FROM pendaftaran
					JOIN kelompok ON kelompok.id = pendaftaran.id_kelompok_t
					JOIN program_kegiatan ON program_kegiatan.id = kelompok.id_program_kegiatan
					JOIN program ON program.id = program_kegiatan.id_program
					WHERE 
				      kelompok.id_proctor_training = ? AND 
					  kelompok.id_kegiatan = ? AND
				      pendaftaran.skor_ujian >= program.min_skor",
					[(int)$id_proctor, (int)$keg['id']]
				)->row_array()['jumlah'];
			}

			if ($sebagai_proctor_ujian)
			{
				$lulus['ujian'] = (int)$this->db->query(
					"SELECT COUNT(1) AS jumlah
					FROM pendaftaran
					JOIN kelompok ON kelompok.id = pendaftaran.id_kelompok_t
					JOIN program_kegiatan ON program_kegiatan.id = kelompok.id_program_kegiatan
					JOIN program ON program.id = program_kegiatan.id_program
					WHERE 
				      kelompok.id_proctor_ujian = ? AND 
					  kelompok.id_kegiatan = ? AND
				      pendaftaran.skor_ujian >= program.min_skor",
					[(int)$id_proctor, (int)$keg['id']]
				)->row_array()['jumlah'];
			}
			$list_kegiatan[$k_list]['jumlah_peserta_proctor_lulus'] = $lulus;

			$tidak_lulus = [
				'training' => 0,
				'ujian' => 0
			];
			if ($sebagai_proctor_training)
			{
				$tidak_lulus['training'] = (int)$this->db->query(
					"SELECT COUNT(1) AS jumlah
				FROM pendaftaran
				JOIN kelompok ON kelompok.id = pendaftaran.id_kelompok_t
				JOIN program_kegiatan ON program_kegiatan.id = kelompok.id_program_kegiatan
				JOIN program ON program.id = program_kegiatan.id_program
				WHERE 
				      kelompok.id_proctor_training = ? AND 
				      kelompok.id_kegiatan = ? AND
				      pendaftaran.skor_ujian <> -1 AND
				      pendaftaran.skor_ujian < program.min_skor",
					[(int)$id_proctor, (int)$keg['id']]
				)->row_array()['jumlah'];
			}

			if ($sebagai_proctor_ujian)
			{
				$tidak_lulus['ujian'] = (int)$this->db->query(
					"SELECT COUNT(1) AS jumlah
				FROM pendaftaran
				JOIN kelompok ON kelompok.id = pendaftaran.id_kelompok_t
				JOIN program_kegiatan ON program_kegiatan.id = kelompok.id_program_kegiatan
				JOIN program ON program.id = program_kegiatan.id_program
				WHERE 
				      kelompok.id_proctor_ujian = ? AND 
				      kelompok.id_kegiatan = ? AND
				      pendaftaran.skor_ujian <> -1 AND
				      pendaftaran.skor_ujian < program.min_skor",
					[(int)$id_proctor, (int)$keg['id']]
				)->row_array()['jumlah'];
			}
			$list_kegiatan[$k_list]['jumlah_peserta_proctor_tidaklulus'] = $tidak_lulus;
		}
		return $list_kegiatan;
	}

}

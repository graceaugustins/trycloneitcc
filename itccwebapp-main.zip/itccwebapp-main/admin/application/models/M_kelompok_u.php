<?php defined('BASEPATH') OR exit('No direct script access allowed');
class M_kelompok_u extends CI_Model{

	public function is_id_exists($id): bool
	{
		$jumlah = $this->db->query(
			"SELECT COUNT(1) AS jumlah FROM kelompok_u WHERE id=?",
			[$id]
		)->row_array();
		$jumlah = $jumlah['jumlah'];
		return (int)$jumlah>0;
	}

	public function add_new_kelompok(D_Kelompok_U $kelompok) : bool
	{
		if (!empty($kelompok->id)) return FALSE;
		if (!$kelompok->validate_data(true)) return FALSE;

		$this->db->trans_start();
		$this->db->query(
			"INSERT INTO kelompok_u
            (
             nama_kelompok, 
             id_kegiatan, 
             id_program_kegiatan, 
             mulai_ujian, 
             selesai_ujian,
             lokasi_ujian, 
             min_peserta_ujian, 
             max_peserta_ujian
		 	) 
             VALUES 
            (?,?,?,?,?,?,?,?)",
			[
				$kelompok->nama_kelompok,
				$kelompok->id_kegiatan,
				$kelompok->id_program_kegiatan,
				$kelompok->mulai_ujian->format('Y-m-d H:i:s'),
				$kelompok->selesai_ujian->format('Y-m-d H:i:s'),
				$kelompok->lokasi_ujian,
				$kelompok->min_peserta_ujian,
				$kelompok->max_peserta_ujian
			]
		);
		$kelompok->id = $this->db->insert_id();
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function update_kelompok(D_Kelompok_U $kelompok) : bool
	{
		if (empty($kelompok->id)) return FALSE;
		if (!$kelompok->validate_data()) return FALSE;

		$this->db->trans_start();
		$this->db->query(
			"UPDATE kelompok_u SET
			nama_kelompok = ?, 
            mulai_ujian = ?, 
			selesai_ujian = ?,
			lokasi_ujian = ?,
		  	id_proctor_ujian = ?,
			beritaacara_ujian = ?,
			min_peserta_ujian = ?,
			max_peserta_ujian = ?
			WHERE id = ? ",
			[
				$kelompok->nama_kelompok,
				$kelompok->mulai_ujian->format('Y-m-d H:i:s'),
				$kelompok->selesai_ujian->format('Y-m-d H:i:s'),
				$kelompok->lokasi_ujian,
				$kelompok->id_proctor_ujian,
				$kelompok->beritaacara_ujian,
				$kelompok->min_peserta_ujian,
				$kelompok->max_peserta_ujian,
				$kelompok->id
			]
		);
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function delete_kelompok(D_Kelompok_U $kelompok) : bool
	{
		if (empty($kelompok->id)) return FALSE;
		$this->db->trans_start();
		$this->db->query(
			"DELETE FROM kelompok_u WHERE id=?",
			[$kelompok->id]
		);
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	/**
	 * $id_peserta_hadir :
	 * [[id_peserta_1, TRUE], [id_peserta_2, FALSE], ...]
	 * */
	public function update_absensi(array $id_peserta_hadir): bool
	{
		$this->db->trans_start();
		foreach ($id_peserta_hadir as $id)
		{
			$this->db->query(
				"UPDATE pendaftaran SET hadir_ujian = ? WHERE id = ?",
				[$id[1]? 'y' : 'n', $id[0]]
			);
		}
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	/**
	 * $id_skor_ujian :
	 * [[id_peserta_1, TRUE], [id_peserta_2, FALSE], ...]
	 * */
	public function update_skor_ujian(D_Kelompok_U $kelompok, array $id_skor_ujian): bool
	{
		$this->db->trans_start();
		foreach ($id_skor_ujian as $id)
		{
			$this->db->query(
				"UPDATE pendaftaran SET skor_ujian = ? WHERE id = ?",
				[$id[1], $id[0]]
			);
		}
		$kelompok->load_list_peserta();
		load_data_class('Program');
		$program = new D_Program($kelompok->id_program);
		foreach($id_skor_ujian as $s)
		{
			$id = (int)$s[0];
			$skor = (int)$s[1];
			foreach($kelompok->list_peserta as $peserta)
			{
				if ($skor === -1 && $skor >= $program->min_skor) continue;
				if ((int)$peserta->id === $id && $skor !== (int)$peserta->skor_ujian)
				{
					$tanggal_terbit = new DateTime();
					// generate kode sertifikat
					do{
						$kode = simple_random_string(5).'-'.simple_random_string(5);
						$kode_exists = $this->db->query(
							"SELECT COUNT(1) AS jumlah FROM sertifikat_keikutsertaan WHERE kode = ?",
							[$kode]
						)->row_array();
						$kode_exists = $kode_exists['jumlah'];
						$exists = (int)$kode_exists >0;
					}
					while ($exists);
					// hapus sertifikat keikutsertaan yang ada
					$this->db->query(
						"DELETE FROM sertifikat_keikutsertaan WHERE id_pendaftaran=?",
						[(int)$id]
					);
					$this->db->query(
						"INSERT INTO sertifikat_keikutsertaan (id_pendaftaran, tanggal_terbit, kode) VALUES (?,?,?)",
						[
							(int)$id,
							$tanggal_terbit->format('Y-m-d H:i:s'),
							$kode
						]
					);
				}
			}
		}
		$this->db->trans_complete();
		return $this->db->trans_status();
	}
}

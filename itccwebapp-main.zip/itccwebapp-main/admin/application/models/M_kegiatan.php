<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_kegiatan extends CI_Model{

	public function is_id_kegiatan_exists($id) : bool
	{
		$query = $this->db->query("SELECT COUNT(1) AS jumlah
			FROM kegiatan WHERE id=?",
			[(int)$id]
		)->row_array();
		return ((int)$query['jumlah']>0);
	}

	/**
	 * Get list kegiatan yang tidak batal
	 * dan belum melewati masa pelaporan
	 * (bisa dibilang belum selesai)
	 * @return D_Kegiatan[]
	 * */
	public function get_kegiatan_active(): array
	{
		$now = new DateTime();
		$list_kegiatan_from_db = $this->db->query(
			"SELECT * FROM kegiatan WHERE batal='n' AND ? <= akhir_pelaporan
			ORDER BY akhir_pelaporan DESC",
			[
				$now->format('Y-m-d')
			]
		)->result_array();
		load_data_class('Kegiatan');
		$list_kegiatan = [];
		foreach ($list_kegiatan_from_db as $result_db)
		{
			$kegiatan = new D_Kegiatan();
			$kegiatan->surface_fill_data_from_db_result($result_db);
			$list_kegiatan[] = $kegiatan;
		}
		return $list_kegiatan;
	}

	/**
	 * Get list kegiatan yang akan masuk masa registrasi
	 * @return D_Kegiatan[]
	 * */
	public function get_kegiatan_before_registrasi(): array
	{
		$now = new DateTime();
		$list_kegiatan_from_db = $this->db->query(
			"SELECT * FROM kegiatan WHERE batal='n' AND ? < awal_registrasi
			ORDER BY awal_registrasi DESC",
			[
				$now->format('Y-m-d H:i:s')
			]
		)->result_array();
		load_data_class('Kegiatan');
		$list_kegiatan = [];
		foreach ($list_kegiatan_from_db as $result_db)
		{
			$kegiatan = new D_Kegiatan();
			$kegiatan->surface_fill_data_from_db_result($result_db);
			$list_kegiatan[] = $kegiatan;
		}
		return $list_kegiatan;
	}

	/**
	 * Get list kegiatan yang sedang dalam masa registrasi
	 * @return D_Kegiatan[]
	 * */
	public function get_kegiatan_in_registrasi(): array
	{
		$now = new DateTime();
		$list_kegiatan_from_db = $this->db->query(
			"SELECT * FROM kegiatan 
			WHERE batal='n' AND 
            awal_registrasi IS NOT NULL AND 
		  	akhir_registrasi IS NOT NULL AND 
		  	? BETWEEN awal_registrasi AND akhir_registrasi
			ORDER BY akhir_registrasi DESC",
			[
				$now->format('Y-m-d H:i:s')
			]
		)->result_array();
		load_data_class('Kegiatan');
		$list_kegiatan = [];
		foreach ($list_kegiatan_from_db as $result_db)
		{
			$kegiatan = new D_Kegiatan();
			$kegiatan->surface_fill_data_from_db_result($result_db);
			$list_kegiatan[] = $kegiatan;
		}
		return $list_kegiatan;
	}

	/**
	 * Get list kegiatan yang akan masuk di pelaksanaan
	 * (training & ujian), terlepas dari periode registrasi
	 * @return D_Kegiatan[]
	 * */
	public function get_kegiatan_before_pelaksanaan(): array
	{
		$now = new DateTime();
		$list_kegiatan_from_db = $this->db->query(
			"SELECT kegiatan.*, MIN(kelompok_t.mulai_training) AS mulai_t
            FROM kegiatan 
            LEFT JOIN kelompok_t ON kelompok_t.id_kegiatan = kegiatan.id
			WHERE kegiatan.batal = 'n' AND ? <= kegiatan.akhir_pelaporan
            GROUP BY kegiatan.id
            HAVING ? < mulai_t OR mulai_t IS NULL
            ORDER BY mulai_t DESC",
			[
				$now->format('Y-m-d H:i:s'),
				$now->format('Y-m-d H:i:s')
			]
		)->result_array();
		load_data_class('Kegiatan');
		$list_kegiatan = [];
		foreach ($list_kegiatan_from_db as $result_db)
		{
			$kegiatan = new D_Kegiatan();
			$kegiatan->surface_fill_data_from_db_result($result_db);
			$list_kegiatan[] = $kegiatan;
		}
		return $list_kegiatan;
	}

	/**
	 * Get list kegiatan yang sedang dalam masa pelaksanaan
	 * (training atau ujian)
	 * @return D_Kegiatan[]
	 * */
	public function get_kegiatan_in_pelaksanaan() : array
	{
		$now = new DateTime();
		$list_kegiatan_from_db = $this->db->query(
			"SELECT kegiatan.*, MIN(kelompok_t.mulai_training) AS mulai_t, MAX(kelompok_u.selesai_ujian) AS selesai_u
            FROM kegiatan 
            LEFT JOIN kelompok_t ON kelompok_t.id_kegiatan = kegiatan.id
			LEFT JOIN kelompok_u ON kelompok_u.id_kegiatan = kegiatan.id
			WHERE kegiatan.batal = 'n'
            GROUP BY kegiatan.id
            HAVING (mulai_t IS NOT NULL AND ? >= mulai_t) AND (selesai_u IS NULL OR ? <= selesai_u)
            ORDER BY selesai_u DESC",
			[
				$now->format('Y-m-d H:i:s'),
				$now->format('Y-m-d H:i:s')
			]
		)->result_array();
		load_data_class('Kegiatan');
		$list_kegiatan = [];
		foreach ($list_kegiatan_from_db as $result_db)
		{
			$kegiatan = new D_Kegiatan();
			$kegiatan->surface_fill_data_from_db_result($result_db);
			$list_kegiatan[] = $kegiatan;
		}
		return $list_kegiatan;
	}

	/**
	 * Get list kegiatan yang masa pelaksanaannya sudah berakhir,
	 * dan belum melewati masa pelaporan
	 * (belum selesai)
	 * @return D_Kegiatan[]
	 * */
	public function get_kegiatan_after_pelaksanaan(): array
	{
		$now = new DateTime();
		$list_kegiatan_from_db = $this->db->query(
			"SELECT kegiatan.*, MIN(kelompok_t.selesai_training) AS selesai_t, MAX(kelompok_u.selesai_ujian) AS selesai_u
            FROM kegiatan 
            LEFT JOIN kelompok_t ON kelompok_t.id_kegiatan = kegiatan.id
			LEFT JOIN kelompok_u ON kelompok_u.id_kegiatan = kegiatan.id
			WHERE kegiatan.batal = 'n' AND ? <= kegiatan.akhir_pelaporan
            GROUP BY kegiatan.id
            HAVING (selesai_t IS NOT NULL AND ? > selesai_t) OR  (selesai_u IS NOT NULL AND ? > selesai_u)
            ORDER BY selesai_u DESC, selesai_t DESC",
			[
				$now->format('Y-m-d H:i:s'),
				$now->format('Y-m-d H:i:s'),
				$now->format('Y-m-d H:i:s')
			]
		)->result_array();
		load_data_class('Kegiatan');
		$list_kegiatan = [];
		foreach ($list_kegiatan_from_db as $result_db)
		{
			$kegiatan = new D_Kegiatan();
			$kegiatan->surface_fill_data_from_db_result($result_db);
			$list_kegiatan[] = $kegiatan;
		}
		return $list_kegiatan;
	}

	/**
	 * Get list kegiatan yang sudah melewati masa pelaporan,
	 * (sudah selesai)
	 * @return D_Kegiatan[]
	 * */
	public function get_kegiatan_inactive(): array
	{
		$now = new DateTime();
		$list_kegiatan_from_db = $this->db->query(
			"SELECT * FROM kegiatan WHERE batal='n' AND ? > akhir_pelaporan
			ORDER BY akhir_pelaporan DESC",
			[
				$now->format('Y-m-d')
			]
		)->result_array();
		load_data_class('Kegiatan');
		$list_kegiatan = [];
		foreach ($list_kegiatan_from_db as $result_db)
		{
			$kegiatan = new D_Kegiatan();
			$kegiatan->surface_fill_data_from_db_result($result_db);
			$list_kegiatan[] = $kegiatan;
		}
		return $list_kegiatan;
	}

	/**
	 * Get list kegiatan yang dibatalkan
	 * @return D_Kegiatan[]
	 * */
	public function get_kegiatan_cancelled(): array
	{
		$list_kegiatan_from_db = $this->db->query(
			"SELECT * FROM kegiatan WHERE batal='y'
			ORDER BY akhir_pelaporan DESC"
		)->result_array();
		load_data_class('Kegiatan');
		$list_kegiatan = [];
		foreach ($list_kegiatan_from_db as $result_db)
		{
			$kegiatan = new D_Kegiatan();
			$kegiatan->surface_fill_data_from_db_result($result_db);
			$list_kegiatan[] = $kegiatan;
		}
		return $list_kegiatan;
	}

	public function add_new_kegiatan(D_Kegiatan $kegiatan): bool
	{
		if (!empty($kegiatan->id)) return FALSE;
		if (!$kegiatan->validate_data(true)) return FALSE;
		$values = str_repeat('?,', 19).'?';
		$this->db->trans_start();
		$this->db->query(
			"INSERT INTO kegiatan 
    		(
    		 nama_kegiatan, 
    		 harga_t_u, 
    		 harga_u, 
    		 registrasi_dibuka, 
             awal_registrasi, 
    		 akhir_registrasi, 
    		 batas_upload_bukti_bayar, 
    		 awal_persiapan, 
    		 akhir_persiapan, 
             awal_pelaporan, 
    		 akhir_pelaporan, 
    		 keterangan_training, 
    		 keterangan_ujian, 
             id_sertifikasi, 
    		 deskripsi, 
    		 dibuka_untuk, 
    		 link_grup, 
    		 kriteria_registrasi, 
             kriteria_peserta_boleh_ujian_saja, 
    		 kriteria_diskon
			) 
            VALUES ($values)",
			[
				$kegiatan->nama_kegiatan,
				$kegiatan->biaya_t_u,
				$kegiatan->biaya_u,
				($kegiatan->registrasi_dibuka) ? 'y' : 'n',
				($kegiatan->dibuka_untuk === General_Constants::ITPLN) ? NULL : $kegiatan->awal_registrasi->format('Y-m-d H:i:s'),
				($kegiatan->dibuka_untuk === General_Constants::ITPLN) ? NULL : $kegiatan->akhir_registrasi->format('Y-m-d H:i:s'),
				empty($kegiatan->batas_upload_bukti_bayar) ? NULL : $kegiatan->batas_upload_bukti_bayar->format('Y-m-d H:i:s'),
				$kegiatan->awal_persiapan->format('Y-m-d'),
				$kegiatan->akhir_persiapan->format('Y-m-d'),
				$kegiatan->awal_pelaporan->format('Y-m-d'),
				$kegiatan->akhir_pelaporan->format('Y-m-d'),
				$kegiatan->keterangan_training,
				$kegiatan->keterangan_ujian,
				$kegiatan->id_sertifikasi,
				$kegiatan->deskripsi,
				$kegiatan->dibuka_untuk,
				$kegiatan->link_grup,
				($kegiatan->dibuka_untuk === General_Constants::ITPLN) ? '[]' : $kegiatan->kriteria_registrasi->json_data,
				($kegiatan->dibuka_untuk === General_Constants::ITPLN) ? '[]' : $kegiatan->kriteria_peserta_boleh_ujian_saja->json_data,
				($kegiatan->dibuka_untuk === General_Constants::ITPLN) ? '[]' : $kegiatan->kriteria_diskon->json_data
			]
		);
		$kegiatan->id = $this->db->insert_id();
		foreach($kegiatan->program_kegiatan as $p)
		{
			$this->db->query(
				"INSERT INTO program_kegiatan (id_kegiatan, id_program) VALUES (?,?)",
				[
					(int)$kegiatan->id,
					(int)$p->id_program
				]
			);
		}
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function update_kegiatan(D_Kegiatan $kegiatan): bool
	{
		if (empty($kegiatan->id)) return FALSE;
		if (!$kegiatan->validate_data()) return FALSE;
		$this->db->trans_start();
		$this->db->query(
			"UPDATE kegiatan SET 
    		nama_kegiatan = ?, 
			harga_t_u = ?, 
			harga_u = ?, 
			registrasi_dibuka = ?, 
			awal_registrasi = ?, 
			akhir_registrasi = ?, 
			batas_upload_bukti_bayar = ?, 
			awal_persiapan = ?, 
			akhir_persiapan = ?, 
			awal_pelaporan = ?, 
			akhir_pelaporan = ?, 
			keterangan_training = ?, 
			keterangan_ujian = ?, 
			deskripsi = ?, 
			link_grup = ?, 
			kriteria_registrasi = ?, 
			kriteria_peserta_boleh_ujian_saja = ?, 
			kriteria_diskon = ?
    		WHERE id = ?",
			[
				$kegiatan->nama_kegiatan,
				$kegiatan->biaya_t_u,
				$kegiatan->biaya_u,
				$kegiatan->registrasi_dibuka ? 'y': 'n',
				($kegiatan->dibuka_untuk === General_Constants::ITPLN) ? NULL : $kegiatan->awal_registrasi->format('Y-m-d H:i:s'),
				($kegiatan->dibuka_untuk === General_Constants::ITPLN) ? NULL : $kegiatan->akhir_registrasi->format('Y-m-d H:i:s'),
				($kegiatan->batas_upload_bukti_bayar === NULL) ? NULL : $kegiatan->batas_upload_bukti_bayar->format('Y-m-d H:i:s'),
				$kegiatan->awal_persiapan->format('Y-m-d'),
				$kegiatan->akhir_persiapan->format('Y-m-d'),
				$kegiatan->awal_pelaporan->format('Y-m-d'),
				$kegiatan->akhir_pelaporan->format('Y-m-d'),
				$kegiatan->keterangan_training,
				$kegiatan->keterangan_ujian,
				$kegiatan->deskripsi,
				$kegiatan->link_grup,
				$kegiatan->kriteria_registrasi->json_data,
				$kegiatan->kriteria_peserta_boleh_ujian_saja->json_data,
				$kegiatan->kriteria_diskon->json_data,
				$kegiatan->id
			]
		);
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function batalkan_kegiatan(D_Kegiatan $kegiatan): bool
	{
		if (empty($kegiatan->id)) return FALSE;
		$this->db->trans_start();
		if ($kegiatan->batal)
		{
			$this->db->query(
				"UPDATE kegiatan SET batal = 'y', keterangan_batal = ?
				WHERE id = ?",
				[
					$kegiatan->keterangan_batal,
					$kegiatan->id
				]
			);
		}
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function add_new_klaim_dana_kegiatan(D_Klaim_Dana_Kegiatan $klaim): bool
	{
		if (!empty($klaim->id)) return FALSE;
		if (!$klaim->validate_data(true)) return FALSE;

		$this->db->trans_start();
		$this->db->query(
			"INSERT INTO klaim_dana_kegiatan 
    		(
    		 id_kegiatan, 
    		 nominal_klaim, 
    		 keterangan, 
    		 file_bukti_klaim
			) 
            VALUES (?, ?, ? , ?)",
			[
				$klaim->id_kegiatan,
				$klaim->nominal_klaim,
				$klaim->keterangan,
				$klaim->file_bukti_klaim
			]
		);
		$klaim->id = $this->db->insert_id();
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function is_id_klaim_exists($id) : bool
	{
		$query = $this->db->query("SELECT COUNT(1) AS jumlah
			FROM klaim_dana_kegiatan WHERE id=?",
			[(int)$id]
		)->row_array();
		return ((int)$query['jumlah']>0);
	}

	public function update_klaim_dana_kegiatan(D_Klaim_Dana_Kegiatan $klaim): bool
	{
		if (empty($klaim->id)) return FALSE;
		if (!$klaim->validate_data()) return FALSE;

		$this->db->trans_start();
		$this->db->query(
			"UPDATE klaim_dana_kegiatan SET 
    		nominal_klaim = ?, 
    		keterangan = ?, 
    		file_bukti_klaim = ?
    		WHERE id = ?",
			[
				$klaim->nominal_klaim,
				$klaim->keterangan,
				$klaim->file_bukti_klaim,
				$klaim->id
			]
		);
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function hapus_klaim_dana_kegiatan(D_Klaim_Dana_Kegiatan $klaim): bool
	{
		if (empty($klaim->id)) return FALSE;

		$this->db->trans_start();
		$this->db->query(
			"DELETE FROM klaim_dana_kegiatan WHERE id = ?",
			[
				$klaim->id
			]
		);
		$this->db->trans_complete();
		$status = $this->db->trans_status();
		if ($status) $klaim->hapus_file_bukti();
		return $status;
	}

	public function is_id_pendaftaran_exists($id) : bool
	{
		$query = $this->db->query("SELECT COUNT(1) AS jumlah
			FROM pendaftaran WHERE id=?",
			[(int)$id]
		)->row_array();
		return ((int)$query['jumlah']>0);
	}

	// untuk update data registrasi (diskon, program yang dipilih, jenis)
	public function update_registrasi(D_Pendaftaran_Kegiatan $pendaftaran, $reset_t_u): bool
	{
		if (empty($pendaftaran->id)) return FALSE;
		if (!$pendaftaran->validate_data_untuk_update_registrasi()) return FALSE;
		$this->db->trans_start();
		$this->db->query(
			"UPDATE pendaftaran SET 
    		diskon = ?, 
    		id_program_kegiatan = ?, 
    		jenis = ?
    		WHERE id = ?",
			[
				$pendaftaran->diskon,
				$pendaftaran->id_program_kegiatan,
				$pendaftaran->jenis,
				$pendaftaran->id,
			]
		);
		if ($reset_t_u)
		{
			$this->db->query(
				"UPDATE pendaftaran SET 
				id_kelompok_t = NULL, 
				id_kelompok_u = NULL, 
				hadir_training_sesi1 = 'n',
				hadir_training_sesi2 = 'n',
			    hadir_ujian = 'n'
				WHERE id = ?",
				[
					$pendaftaran->id
				]
			);
		}
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	// untuk approved, data training & ujian dari pendaftaran
	public function update_pendaftaran(D_Kegiatan_User $pendaftaran): bool
	{
		if (empty($pendaftaran->id)) return FALSE;
		$this->db->trans_start();
		$this->db->query(
			"UPDATE pendaftaran SET 
    		approved = ?, 
    		id_kelompok_t = ?, 
    		id_kelompok_u = ?,
			hadir_training_sesi1 = ?,
			hadir_training_sesi2 = ?,
			hadir_ujian = ?,
			skor_ujian = ?
    		WHERE id = ?",
			[
				$pendaftaran->approved ? 'y' : 'n',
				$pendaftaran->id_kelompok_t,
				$pendaftaran->id_kelompok_u,
				$pendaftaran->hadir_training_sesi1 ? 'y' : 'n',
				$pendaftaran->hadir_training_sesi2 ? 'y' : 'n',
				$pendaftaran->hadir_ujian ? 'y' : 'n',
				$pendaftaran->skor_ujian,
				$pendaftaran->id,
			]
		);
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function hapus_data_registrasi(D_Pendaftaran_Kegiatan $pendaftaran): bool
	{
		if (empty($pendaftaran->id)) return FALSE;
		$this->db->trans_start();
		$this->db->query(
			"DELETE FROM pendaftaran WHERE id = ?",
			[
				$pendaftaran->id
			]
		);
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function registrasi(D_Pendaftaran_Kegiatan $pendaftaran): bool
	{
		if (!empty($pendaftaran->id)) return FALSE;
		if (!$pendaftaran->validate_data_untuk_registrasi()) return FALSE;

		$this->db->trans_start();
		$this->db->query(
			"INSERT INTO pendaftaran (id_user, id_kegiatan, id_program_kegiatan, jenis, diskon) VALUES (?,?,?,?,?)",
			[
				$pendaftaran->id_user,
				$pendaftaran->id_kegiatan,
				$pendaftaran->id_program_kegiatan,
				$pendaftaran->jenis,
				$pendaftaran->diskon
			]
		);
		$pendaftaran->id = $this->db->insert_id();
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function user_sudah_mendaftar_kegiatan(D_User $user, D_Kegiatan $kegiatan): bool
	{
		$query = $this->db->query("SELECT COUNT(1) AS jumlah
			FROM pendaftaran WHERE id_user=? AND id_kegiatan = ?",
			[$user->id, $kegiatan->id]
		)->row_array();
		return ((int)$query['jumlah']>0);
	}

	public function set_approve_bukti_bayar($id, $value): bool
	{
		if (!in_array($value, ['pending','reject', 'accept'])) return FALSE;
		$this->db->trans_start();
		$this->db->query(
			"UPDATE bukti_bayar SET diterima=? WHERE id=?",
			[$value, (int)$id]
		);
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function set_approve_registrasi($id, $value): bool
	{
		$value = ($value) ? 'y' : 'n';
		$this->db->trans_start();
		$this->db->query(
			"UPDATE pendaftaran SET approved=? WHERE id=?",
			[$value, (int)$id]
		);
		// kalau tidak diapprove, maka data kelompok dan kehadiran dihapus
		if ($value === 'n')
		{
			$this->db->query(
				"UPDATE pendaftaran SET 
                       id_kelompok_t=NULL,
                       id_kelompok_u=NULL,
                       hadir_training_sesi1='n',
                       hadir_training_sesi2='n',
                       hadir_ujian='n',
                       skor_ujian=-1
                       WHERE id=?",
				[(int)$id]
			);
		}

		$this->db->trans_complete();
		return $this->db->trans_status();
	}
}

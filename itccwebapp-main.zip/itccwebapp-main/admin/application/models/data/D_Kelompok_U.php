<?php defined('BASEPATH') OR exit('No direct script access allowed');
class D_Kelompok_U {
	var $id = NULL;
	var $id_kegiatan = NULL;

	var $id_program_kegiatan = NULL;
	var $id_program = NULL;
	var $nama_program = "";

	var $nama_kelompok = "";

	var $lokasi_ujian = "";

	/** @var DateTime $mulai_ujian */
	var $mulai_ujian = NULL;

	/** @var DateTime $selesai_ujian */
	var $selesai_ujian = NULL;

	var $id_proctor_ujian = NULL;
	var $proctor_ujian = "";

	var $beritaacara_ujian = "";

	var $min_peserta_ujian = 0;
	var $max_peserta_ujian = 0;

	/** @var D_Peserta[] $list_peserta */
	var $list_peserta = NULL;
	var $jumlah_peserta = 0;

	/** @var D_Kesediaan_Proctor[] $list_kesediaan_proctor_ujian */
	var $list_kesediaan_proctor_ujian = NULL;

	public function __construct($id_kelompok = NULL)
	{
		if ($id_kelompok === NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT kelompok_u.*,
       		program_kegiatan.id_program,
       		program.nama_program,
			proctor_ujian.nama_lengkap AS nama_proctor_ujian,
       		COUNT(pendaftaran.id) AS jumlah_peserta_kelompok
			FROM kelompok_u
			JOIN program_kegiatan ON program_kegiatan.id = kelompok_u.id_program_kegiatan
			JOIN program ON program_kegiatan.id_program = program.id
			LEFT JOIN pendaftaran ON pendaftaran.id_kelompok_u = kelompok_u.id
			LEFT JOIN proctor proctor_ujian ON proctor_ujian.id = kelompok_u.id_proctor_ujian
			WHERE kelompok_u.id = ?
			GROUP BY kelompok_u.id",
			[(int)$id_kelompok]
		)->row_array();
		if (empty($k)) return;
		$this->parse_data_from_db($k);
	}

	public function parse_data_from_db($k)
	{
		$this->id = $k['id'];
		$this->id_kegiatan = $k['id_kegiatan'];
		$this->id_program_kegiatan = $k['id_program_kegiatan'];
		$this->id_program = $k['id_program'];
		$this->nama_program = $k['nama_program'];

		$this->nama_kelompok = $k['nama_kelompok'];

		$this->mulai_ujian = (empty($k['mulai_ujian']) ? NULL : DateTime::createFromFormat('Y-m-d H:i:s', $k['mulai_ujian']));
		$this->selesai_ujian = (empty($k['selesai_ujian']) ? NULL : DateTime::createFromFormat('Y-m-d H:i:s', $k['selesai_ujian']));

		$this->lokasi_ujian = (empty($k['lokasi_ujian']) ? '' : $k['lokasi_ujian']);

		$this->id_proctor_ujian = (empty($k['id_proctor_ujian']) ? NULL : (int)$k['id_proctor_ujian']);
		$this->proctor_ujian = (empty($k['nama_proctor_ujian']) ? "" : $k['nama_proctor_ujian']);

		$this->beritaacara_ujian = (empty($k['beritaacara_ujian']) ? '' : $k['beritaacara_ujian']);

		$this->min_peserta_ujian = (int)$k['min_peserta_ujian'];
		$this->max_peserta_ujian = (int)$k['max_peserta_ujian'];

		$this->jumlah_peserta = (int)$k['jumlah_peserta_kelompok'];
	}

	public function validate_data($create = FALSE): bool
	{
		$errors = [];
		if (!$create && (empty($this->id) ||!is_numeric($this->id)) )
			$errors[] = "ID kelompok tidak boleh kosong.";
		if (!is_string($this->nama_kelompok) || trim($this->nama_kelompok) === '')
			$errors[] = "Nama kelompok tidak boleh kosong.";
		if ($this->id_kegiatan === NULL)
			$errors[] = sprintf(
				"ID kegiatan '%s' tidak boleh kosong.",
				$this->nama_kelompok
			);
		if ($this->id_program_kegiatan === NULL)
			$errors[] = sprintf(
				"ID program '%s' tidak boleh kosong.",
				$this->nama_kelompok
			);
		if (!is_string($this->lokasi_ujian) || trim($this->lokasi_ujian) === '')
			$errors[] = sprintf(
				"Lokasi ujian kelompok '%s' tidak boleh kosong.",
				$this->nama_kelompok
			);
		if(empty($this->mulai_ujian) || empty($this->selesai_ujian))
			$errors[] = sprintf(
				"Tanggal ujian kelompok '%s' tidak valid.",
				$this->nama_kelompok
			);
		if (
			!empty($this->mulai_ujian) && !empty($this->selesai_ujian) &&
			$this->mulai_ujian > $this->selesai_ujian
		)
			$errors[] = sprintf(
				"Range tanggal ujian kelompok '%s' tidak valid.",
				$this->nama_kelompok
			);

		if ((int)$this->min_peserta_ujian > (int)$this->max_peserta_ujian)
			$errors[] = sprintf(
				"Range daya tampung kelompok '%s' tidak valid.",
				$this->nama_kelompok
			);
		foreach($errors as $e)
		{
			set_warning($e);
		}
		$valid = (count($errors) === 0);
		if ($valid)
		{
			$this->nama_kelompok = trim($this->nama_kelompok);
			$this->lokasi_ujian = trim($this->lokasi_ujian);
			$this->min_peserta_ujian = (int)$this->min_peserta_ujian;
			$this->max_peserta_ujian = (int)$this->max_peserta_ujian;
		}
		return $valid;
	}

	public function load_list_peserta()
	{
		if (empty($this->id)) return;
		if ($this->list_peserta !== NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT 
			pendaftaran.*, 
			pendaftaran.id AS id_pendaftaran, 
			users.id AS id_user,
       		users.file_fotoprofil,
       		users.nama_depan,
			users.nama_belakang,
			users.email, 
			users.nim,
			users.angkatan,
			users.jurusan,
			program_kegiatan.id_program,
			program.nama_program,
			program.min_skor,
			program.max_skor,
			kelompok_t.nama_kelompok AS nama_kelompok_t,
			kelompok_u.nama_kelompok AS nama_kelompok_u
			FROM pendaftaran
			JOIN users ON pendaftaran.id_user = users.id
			JOIN program_kegiatan ON program_kegiatan.id = pendaftaran.id_program_kegiatan
			JOIN program ON program.id = program_kegiatan.id_program
			LEFT JOIN kelompok_t ON kelompok_t.id = pendaftaran.id_kelompok_t
			LEFT JOIN kelompok_u ON kelompok_u.id = pendaftaran.id_kelompok_u
			WHERE pendaftaran.approved='y' AND pendaftaran.id_kelompok_u=?
			ORDER BY pendaftaran.id_program_kegiatan",
			[(int)$this->id]
		)->result_array();
		$this->list_peserta = [];
		load_data_class('Peserta');
		foreach($k as $result)
		{
			$peserta = new D_Peserta();
			$peserta->surface_fill_data_from_db_result($result);
			$this->list_peserta[] = $peserta;
		}
	}

	public function load_kesediaan_proctor_ujian()
	{
		if (empty($this->id)) return;
		if ($this->list_kesediaan_proctor_ujian !== NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT 
			kesediaan_proctor_ujian.*,
			proctor.nama_lengkap,
			kelompok_u.nama_kelompok
			FROM kesediaan_proctor_ujian
			JOIN proctor ON proctor.id = kesediaan_proctor_ujian.id_proctor
			JOIN kelompok_u ON kelompok_u.id = kesediaan_proctor_ujian.id_kelompok_u
			WHERE proctor.aktif = 'y' AND kesediaan_proctor_ujian.id_kelompok_u = ?",
			[(int)$this->id]
		)->result_array();
		$this->list_kesediaan_proctor_ujian = [];
		load_data_class('Kesediaan');
		foreach($k as $result)
		{
			$kesediaan = new D_Kesediaan_Proctor();
			$kesediaan->id = $result['id'];
			$kesediaan->nama_kelompok = $result['nama_kelompok'];
			$kesediaan->id_kelompok = $result['id_kelompok_u'];
			$kesediaan->timestamp = $result['waktu'];
			$kesediaan->id_proctor = $result['id_proctor'];
			$kesediaan->nama_proctor = $result['nama_lengkap'];
			$this->list_kesediaan_proctor_ujian[] = $kesediaan;
		}
	}
}

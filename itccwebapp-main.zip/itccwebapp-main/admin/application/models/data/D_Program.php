<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**

 * @var M_Sertifikasi $m_sertifikasi

 **/
class D_Program {
	var $id = NULL;
	var $id_sertif = NULL;
	var $nama_program = "";
	var $link_assesment = "";
	var $file_modul = NULL;
	var $file_logo = "default.jpg";
	var $min_skor = 0;
	var $max_skor = 0;

	public function __construct($id_program = NULL)
	{
		$CI =& get_instance();
		if ($id_program === NULL) return;
		$program = $CI->db->query(
			"SELECT * FROM program WHERE id = ?",
			[(int)$id_program]
		)->row_array();
		if (empty($program)) return;
		$this->id = $program['id'];
		$this->id_sertif = $program['id_sertif'];
		$this->nama_program = $program['nama_program'];
		$this->file_logo = $program['file_logo'];
		$this->file_modul = $program['file_modul'];
		$this->link_assesment = $program['link_assesment'];
		$this->min_skor = (int)$program['min_skor'];
		$this->max_skor = (int)$program['max_skor'];
	}

	public function validate_data($create = FALSE): bool
	{
		$errors = [];
		if (!$create && (empty($this->id) || !is_numeric($this->id)))
			$errors[] = "ID program tidak boleh kosong.";
		if (empty($this->nama_program) || trim($this->nama_program) === '')
			$errors[] = "Nama program tidak boleh kosong.";

		if (empty($this->link_assesment) ||
			filter_var($this->link_assesment, FILTER_VALIDATE_URL) === FALSE ||
			strlen($this->link_assesment) < 10 ||
			!(
				substr($this->link_assesment, 0, 7) === 'http://' ||
				substr($this->link_assesment, 0, 8) === 'https://'
			)
		)
			$errors[] = "Link assesment tidak valid.";

		if (!is_numeric($this->min_skor))
			$errors[] = "Skor minimum tidak valid.";
		if (!is_numeric($this->max_skor))
			$errors[] = "Skor maksimum tidak valid.";
		$this->min_skor = (int)$this->min_skor;
		$this->max_skor = (int)$this->max_skor;
		if ($this->min_skor < 0 || $this->max_skor <= $this->min_skor)
			$errors[] = "Range skor tidak valid.";

		foreach ($errors as $err)
		{
			set_warning($err);
		}
		$valid = (count($errors) === 0);
		if ($valid)
		{
			$this->nama_program = ucwords(trim($this->nama_program));
		}
		return $valid;
	}

	public function hapus_logo()
	{
		if ($this->file_logo === "default.jpg" ) return;
		$path = config_item('UPLOAD_LOGO_PROGRAM')['upload_path'].$this->file_logo;
		if (file_exists($path)) unlink($path);
	}

	public function hapus_modul()
	{
		if (empty($this->file_modul)) return;
		$path = config_item('UPLOAD_MODUL_PROGRAM')['upload_path'].$this->file_modul;
		if (file_exists($path)) unlink($path);
	}

	public function upload_modul($param_name): bool
	{
		$CI =& get_instance();
		$CI->load->library('upload', config_item('UPLOAD_MODUL_PROGRAM'), 'upload_modul');
		if ($CI->upload_modul->do_upload($param_name))
			$this->file_modul = $CI->upload_modul->data('file_name');
		else
			return FALSE;
		return TRUE;
	}

	public function upload_logo($param_name): bool
	{
		$CI =& get_instance();
		$CI->load->library('upload', config_item('UPLOAD_LOGO_PROGRAM'), 'upload_logo');
		if ($CI->upload_logo->do_upload($param_name))
			$this->file_logo = $CI->upload_logo->data('file_name');
		else
			return FALSE;
		return TRUE;
	}

	public function pernah_diadakan_kegiatan(): bool
	{
		$CI =& get_instance();
		$s = $CI->db->query(
			"SELECT COUNT(id) AS jumlah FROM program_kegiatan WHERE id_program=?",
			[$this->id]
		)->row_array();
		$s = $s['jumlah'];
		return ((int)$s >0);
	}

	public function get_link_logo(): string
	{
		return base_url(config_item('UPLOAD_LOGO_PROGRAM')['upload_path'].$this->file_logo);
	}

	public function get_link_modul(): string
	{
		if (empty($this->file_modul)) return "";
		return base_url('storage/?type=upload_modul_program&file_name='.$this->file_modul);
	}
}

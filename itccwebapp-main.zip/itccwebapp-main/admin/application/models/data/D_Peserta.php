<?php defined('BASEPATH') OR exit('No direct script access allowed');
class D_Peserta{
	var $id = NULL;
	var $id_user = NULL;
	var $id_kegiatan = NULL;
	var $id_program = NULL;
	var $id_program_kegiatan = NULL;
	var $jenis = General_Constants::TRAINING_DAN_UJIAN;
	var $id_kelompok_t = NULL;
	var $id_kelompok_u = NULL;
	var $hadir_training_sesi1 = FALSE;
	var $hadir_training_sesi2 = FALSE;
	var $hadir_ujian = FALSE;
	var $skor_ujian = -1;
	var $sertifikat_keikutsertaan = NULL;

	// data non esensial
	var $nama_program = "";
	var $nama_kelompok_t = "";
	var $nama_kelompok_u = "";
	var $nama_depan_user = "";
	var $nama_belakang_user = "";
	var $file_fotoprofil_user = "";
	var $email_user = "";
	var $nim_user = "";
	var $angkatan_user = "";
	var $jurusan_user = "";
	var $program_yang_dipilih = "";
	var $nama_bidang = '';
	var $nama_jabatan = '';

	var $status_kelulusan = General_Constants::STATUS_PENDING;

	public function __construct($id = NULL)
	{
		if ($id === NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT 
			pendaftaran.*, 
			pendaftaran.id AS id_pendaftaran, 
			users.id AS id_user,
       		users.file_fotoprofil,
       		users.nama_depan,
			users.nama_belakang,
			users.email, 
			users.nim,
			users.angkatan,
			users.jurusan,
			program_kegiatan.id_program,
			program.nama_program,
			program.min_skor,
			program.max_skor,
			kelompok_t.nama_kelompok AS nama_kelompok_t,
			kelompok_u.nama_kelompok AS nama_kelompok_u,
       		bidang_itpln.nama_bidang,
       		jabatan_itpln.nama_jabatan
			FROM pendaftaran
			JOIN users ON pendaftaran.id_user = users.id
			JOIN program_kegiatan ON program_kegiatan.id = pendaftaran.id_program_kegiatan
			JOIN program ON program.id = program_kegiatan.id_program
			LEFT JOIN kelompok_t ON kelompok_t.id = pendaftaran.id_kelompok_t
			LEFT JOIN kelompok_u ON kelompok_u.id = pendaftaran.id_kelompok_u
			LEFT JOIN jabatan_itpln ON jabatan_itpln.id = users.id_jabatan
			LEFT JOIN bidang_itpln ON bidang_itpln.id = jabatan_itpln.id_bidang
			WHERE pendaftaran.approved='y' AND pendaftaran.id=?
			ORDER BY pendaftaran.id_program_kegiatan",
			[(int)$id]
		)->row_array();
		$this->surface_fill_data_from_db_result($k);
	}

	public function surface_fill_data_from_db_result($k)
	{
		$this->id = $k['id_pendaftaran'];
		$this->id_user = $k['id_user'];
		$this->id_kegiatan = $k['id_kegiatan'];
		$this->id_program = $k['id_program'];
		$this->id_program_kegiatan = $k['id_program_kegiatan'];
		$this->jenis = $k['jenis'];
		$this->id_kelompok_t = $k['id_kelompok_t'];
		$this->id_kelompok_u = $k['id_kelompok_u'];
		$this->hadir_training_sesi1 = ($k['hadir_training_sesi1'] === 'y');
		$this->hadir_training_sesi2 = ($k['hadir_training_sesi2'] === 'y');
		$this->hadir_ujian = ($k['hadir_ujian'] === 'y');
		$this->skor_ujian = (int)$k['skor_ujian'];

		$this->nama_program = $k['nama_program'];
		$this->nama_kelompok_t = (empty($k['nama_kelompok_t']) ? '' : $k['nama_kelompok_t']);
		$this->nama_kelompok_u = (empty($k['nama_kelompok_u']) ? '' : $k['nama_kelompok_u']);
		$this->file_fotoprofil_user = $k['file_fotoprofil'];
		$this->nama_depan_user = $k['nama_depan'];
		$this->nama_belakang_user = $k['nama_belakang'];
		$this->email_user = $k['email'];
		$this->nim_user = $k['nim'];
		$this->angkatan_user = $k['angkatan'];
		$this->jurusan_user = $k['jurusan'];
		$this->program_yang_dipilih = $k['nama_program'];
		$this->nama_bidang = (empty($k['nama_bidang']) ? '' : $k['nama_bidang']);
		$this->nama_jabatan = (empty($k['nama_jabatan']) ? '' : $k['nama_jabatan']);


		$min_skor = (int)$k['min_skor'];
		$max_skor = (int)$k['max_skor'];
		if ($this->skor_ujian === -1)
			$this->status_kelulusan = General_Constants::STATUS_PENDING;
		elseif($this->skor_ujian < $min_skor)
			$this->status_kelulusan = General_Constants::STATUS_TIDAK_LULUS;
		else $this->status_kelulusan = General_Constants::STATUS_LULUS;
	}

	public function get_link_foto_profil(): string
	{
		if (empty($this->file_fotoprofil_user)) return "";
		return base_url(config_item('UPLOAD_FOTO_PROFIL')['upload_path'].$this->file_fotoprofil_user);
	}
}

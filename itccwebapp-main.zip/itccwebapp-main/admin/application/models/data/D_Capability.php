<?php defined('BASEPATH') OR exit('No direct script access allowed');

class D_Capability {

	var $id = NULL;
	var $nama = "";
    var $deskripsi = "";
    var $is_eligible = FALSE;

    public function surface_fill_from_db($r)
    {
        if (!empty($r['id'])) $this->id = $r['id'];
        if (!empty($r['nama'])) $this->nama = $r['nama'];
        if (!empty($r['deskripsi'])) $this->deskripsi = $r['deskripsi'];

        $this->is_eligible = !empty($r['is_eligible']);
    }
}
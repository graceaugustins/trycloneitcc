<?php defined('BASEPATH') or exit('No direct script access allowed');

class D_Administrator{

	var $id = NULL;
	var $email = '';
	var $nama = '';

	var $id_role = NULL;

	/** @var D_Role $role */
	var $role = NULL;

	/** @var string[] $last_create_validation_errors */
	var $last_create_validation_errors = [];

	/** @var string[] $last_update_validation_errors */
	var $last_update_validation_errors = [];

	/** @var string[] $last_delete_validation_errors */
	var $last_delete_validation_errors = [];

	/**
	 * @param int[] $list_mode
	 * @param string $error_message
	 * */
	private function set_error_validation(array $list_mode, string $error_message)
	{
		if (in_array(General_Constants::MODE_OPERATION_CREATE, $list_mode))
			$this->last_create_validation_errors[] = $error_message;
		if (in_array(General_Constants::MODE_OPERATION_UPDATE, $list_mode))
			$this->last_update_validation_errors[] = $error_message;
		if (in_array(General_Constants::MODE_OPERATION_CREATE, $list_mode))
			$this->last_delete_validation_errors[] = $error_message;
	}

	private function reset_error_validation($mode)
	{
		if ($mode === General_Constants::MODE_OPERATION_CREATE) $this->last_create_validation_errors = [];
		if ($mode === General_Constants::MODE_OPERATION_UPDATE) $this->last_update_validation_errors = [];
		if ($mode === General_Constants::MODE_OPERATION_DELETE) $this->last_delete_validation_errors = [];
	}

	public function __construct($id_administrator = NULL)
	{
		if ($id_administrator === NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT id, email, nama, id_role FROM itcc_internal WHERE id = ?",
			[(int)$id_administrator]
		)->row_array();
		if (empty($k)) return;
		$this->surface_fill_from_db($k);
	}

	public function surface_fill_from_db($r)
	{
		if (!empty($r['id'])) $this->id = $r['id'];
		if (!empty($r['email'])) $this->email = $r['email'];
		if (!empty($r['nama'])) $this->nama = $r['nama'];
		if (!empty($r['id_role'])) $this->id_role = $r['id_role'];
	}

	public function validate_data($mode)
	{
		$this->reset_error_validation($mode);

		$CI =& get_instance();
		if ($mode === General_Constants::MODE_OPERATION_UPDATE || $mode === General_Constants::MODE_OPERATION_DELETE) {
			if (!is_numeric($this->id))
				$this->set_error_validation(
					[General_Constants::MODE_OPERATION_UPDATE, General_Constants::MODE_OPERATION_DELETE],
					'ID tidak valid.'
				);

			$CI->load->model('m_administrator');
			if ($CI->m_administrator->does_id_already_exists($this->id) === FALSE)
				$this->set_error_validation(
					[General_Constants::MODE_OPERATION_UPDATE, General_Constants::MODE_OPERATION_DELETE],
					'ID administrator tidak ditemukan.'
				);
		}

		if ($mode === General_Constants::MODE_OPERATION_CREATE || $mode === General_Constants::MODE_OPERATION_UPDATE) {
			if (!is_string($this->email) || trim($this->email) === '' || filter_var($this->email, FILTER_VALIDATE_EMAIL) === FALSE)
				$this->set_error_validation(
					[General_Constants::MODE_OPERATION_CREATE, General_Constants::MODE_OPERATION_UPDATE],
					'Email tidak valid.'
				);
			else $this->email = strtolower(trim($this->email));

			if (!is_string($this->nama) || trim($this->nama) === '')
				$this->set_error_validation(
					[General_Constants::MODE_OPERATION_CREATE, General_Constants::MODE_OPERATION_UPDATE],
					'Nama administrator tidak boleh kosong.'
				);

			if (empty($this->id_role) || !is_numeric($this->id_role))
				$this->set_error_validation(
					[General_Constants::MODE_OPERATION_CREATE, General_Constants::MODE_OPERATION_UPDATE],
					'ID role tidak valid.'
				);
			else {
				$CI->load->model('m_role');
				if ($CI->m_role->does_id_already_exists($this->id_role) === FALSE)
					$this->set_error_validation(
						[General_Constants::MODE_OPERATION_CREATE, General_Constants::MODE_OPERATION_UPDATE],
						'Role tidak ditemukan.'
					);
			}
		}

		if ($mode === General_Constants::MODE_OPERATION_CREATE) {
			$CI->load->model('m_administrator');
			if ($CI->m_administrator->does_email_already_exists($this->email))
				$this->set_error_validation(
					[General_Constants::MODE_OPERATION_CREATE],
					'E-mail sudah dipakai administrator lain.'
				);
		}

		if ($mode === General_Constants::MODE_OPERATION_UPDATE) {
			$CI->load->model('m_administrator');
			$id_use = $CI->m_administrator->id_use_email($this->email);
			if ($id_use !== NULL && $id_use !== (int)$this->id)
				$this->set_error_validation(
					[General_Constants::MODE_OPERATION_UPDATE],
					'E-mail sudah dipakai administrator lain.'
				);
		}

		if (count($this->last_create_validation_errors) === 0 || count($this->last_update_validation_errors) === 0) {
			$this->email = strtolower(trim($this->email));
			$this->nama = ucwords(trim($this->nama));
		}
	}
}
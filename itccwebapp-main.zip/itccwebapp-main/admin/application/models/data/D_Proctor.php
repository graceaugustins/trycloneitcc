<?php defined('BASEPATH') OR exit('No direct script access allowed');
class D_Proctor {
	var $id = NULL;
	var $email = "";
	var $nama_lengkap = "";
	var $no_telepon = "";
	var $file_foto = "default.jpg";
	var $aktif = TRUE;

	/**
	 * @var D_Sertifikasi[] $list_sertifikasi
	 **/
	var $list_sertifikasi = NULL;

	/** @var string[] $last_create_validation_errors */
	var $last_create_validation_errors = [];

	/** @var string[] $last_update_validation_errors */
	var $last_update_validation_errors = [];

	/** @var string[] $last_delete_validation_errors */
	var $last_delete_validation_errors = [];

	/**
	 * @param int[] $list_mode
	 * @param string $error_message
	 * */
	private function set_error_validation(array $list_mode, string $error_message)
	{
		if (in_array(General_Constants::MODE_OPERATION_CREATE, $list_mode))
			$this->last_create_validation_errors[] = $error_message;
		if (in_array(General_Constants::MODE_OPERATION_UPDATE, $list_mode))
			$this->last_update_validation_errors[] = $error_message;
		if (in_array(General_Constants::MODE_OPERATION_CREATE, $list_mode))
			$this->last_delete_validation_errors[] = $error_message;
	}

	private function reset_error_validation($mode)
	{
		if ($mode === General_Constants::MODE_OPERATION_CREATE) $this->last_create_validation_errors = [];
		if ($mode === General_Constants::MODE_OPERATION_UPDATE) $this->last_update_validation_errors = [];
		if ($mode === General_Constants::MODE_OPERATION_DELETE) $this->last_delete_validation_errors = [];
	}

	public function __construct($id_proctor = NULL)
	{
		if ($id_proctor === NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT * FROM proctor WHERE id = ?",
			[(int)$id_proctor]
		)->row_array();
		if (empty($k)) return;
		$this->surface_fill_from_db($k);
	}

	public function surface_fill_from_db($k)
	{
		if (!empty($k['id'])) $this->id = (int)$k['id'];
		if (!empty($k['email'])) $this->email = $k['email'];
		if (!empty($k['nama_lengkap'])) $this->nama_lengkap = $k['nama_lengkap'];
		if (!empty($k['no_telepon'])) $this->no_telepon = $k['no_telepon'];
		if (!empty($k['file_foto'])) $this->file_foto = $k['file_foto'];
		if (!empty($k['aktif'])) $this->aktif = ($k['aktif'] === 'y');
	}

	public function validate_data($mode)
	{
		$CI =& get_instance();
		$CI->load->model('m_proctor');
		$this->reset_error_validation($mode);
		if ($mode === General_Constants::MODE_OPERATION_UPDATE || $mode === General_Constants::MODE_OPERATION_DELETE)
		{
			if (!is_numeric($this->id))
				$this->set_error_validation(
					[General_Constants::MODE_OPERATION_UPDATE, General_Constants::MODE_OPERATION_DELETE],
					'ID proctor tidak boleh kosong.'
				);
			elseif ($CI->m_proctor->does_id_already_exists($this->id) === FALSE)
				$this->set_error_validation(
					[General_Constants::MODE_OPERATION_UPDATE, General_Constants::MODE_OPERATION_DELETE],
					'Proctor tidak ditemukan.'
				);
		}

		if ($mode === General_Constants::MODE_OPERATION_CREATE || $mode === General_Constants::MODE_OPERATION_UPDATE)
		{
			if (empty($this->nama_lengkap) || trim($this->nama_lengkap) === '')
				$this->set_error_validation(
					[General_Constants::MODE_OPERATION_CREATE, General_Constants::MODE_OPERATION_UPDATE],
					'Nama proctor tidak boleh kosong.'
				);

			if (!is_string($this->no_telepon) || !ctype_digit($this->no_telepon))
				$this->set_error_validation(
					[General_Constants::MODE_OPERATION_CREATE, General_Constants::MODE_OPERATION_UPDATE],
					'Nomor telepon tidak valid.'
				);

			if (!is_string($this->email) || filter_var( $this->email, FILTER_VALIDATE_EMAIL) === FALSE )
				$this->set_error_validation(
					[General_Constants::MODE_OPERATION_CREATE, General_Constants::MODE_OPERATION_UPDATE],
					'Email tidak valid.'
				);
			else $this->email = strtolower(trim($this->email));
		}

		if ($mode === General_Constants::MODE_OPERATION_CREATE)
		{
			if ($CI->m_proctor->does_email_already_exists($this->email))
				$this->set_error_validation(
					[General_Constants::MODE_OPERATION_CREATE],
					'Email proctor sudah terpakai.'
				);
		}
		if ($mode === General_Constants::MODE_OPERATION_UPDATE)
		{
			$id_use_email = $CI->m_proctor->get_id_use_email($this->email);
			if ($id_use_email !== NULL && $id_use_email !== (int)$this->id)
				$this->set_error_validation(
					[General_Constants::MODE_OPERATION_UPDATE],
					'Email proctor sudah terpakai.'
				);
		}
		if ($mode === General_Constants::MODE_OPERATION_DELETE)
		{
			if ($this->pernah_partisipasi())
				$this->set_error_validation(
					[General_Constants::MODE_OPERATION_DELETE],
					'Proctor tidak dapat dihapus karena pernah berpartisipasi di sertifikasi sebelumnya.'
				);
		}

		if (count($this->last_create_validation_errors) === 0 || count($this->last_update_validation_errors) === 0)
		{
			$this->email = strtolower(trim($this->email));
			$this->nama_lengkap = ucwords(trim($this->nama_lengkap));
		}
	}

	public function load_list_sertifikasi()
	{
		if ($this->list_sertifikasi !== NULL) return;
		if ($this->id === NULL) return;
		$CI =& get_instance();
		$list_id_sertif = $CI->db->query(
			"SELECT id_sertifikasi
			FROM sertifikasi_proctor
			WHERE id_proctor=?",
			[$this->id]
		)->result_array();

		load_data_class('Sertifikasi');
		$this->list_sertifikasi = [];
		foreach($list_id_sertif as $id)
		{
			$s = new D_Sertifikasi($id['id_sertifikasi']);
			$this->list_sertifikasi[] = $s;
		}
	}

	public function upload_profil($param_name): bool
	{
		$CI =& get_instance();
		$CI->load->library('upload', config_item('UPLOAD_PROFIL_PROCTOR'), 'upload_profil');
		if ($CI->upload_profil->do_upload($param_name))
			$this->file_foto = $CI->upload_profil->data('file_name');
		else
			return FALSE;
		return TRUE;
	}

	public function hapus_profil()
	{
		if ($this->file_foto === "default.jpg") return;
		$path = config_item('UPLOAD_PROFIL_PROCTOR')['upload_path'].$this->file_foto;
		if (file_exists($path)) unlink($path);
	}

	public function pernah_partisipasi(): bool
	{
		if (empty($this->id)) return FALSE;
		$CI =& get_instance();
		$t = $CI->db->query(
			"SELECT COUNT(1) AS jumlah 
			FROM kelompok_t 
			WHERE id_proctor_training=?",
			[$this->id]
		)->row_array();
		$u = $CI->db->query(
			"SELECT COUNT(1) AS jumlah 
			FROM kelompok_u 
			WHERE id_proctor_ujian=?",
			[$this->id]
		)->row_array();
		$t = $t['jumlah'];
		$u = $u['jumlah'];
		return ((int)$t + (int)$u) > 0;
	}

	public function get_link_profile(): string
	{
		return base_url(config_item('UPLOAD_PROFIL_PROCTOR')['upload_path'].$this->file_foto);
	}
}

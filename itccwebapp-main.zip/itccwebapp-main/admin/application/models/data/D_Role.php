<?php defined('BASEPATH') or exit('No direct script access allowed');

class D_Role{

	var $id = NULL;
	var $nama_role = "";

	/** @var D_Capability[] $capabilities */
	var $capabilities = NULL;

	public function __construct($id_role = NULL)
	{
		if ($id_role === NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT id, nama_role FROM roles WHERE id = ?",
			[(int)$id_role]
		)->row_array();
		if (empty($k)) return;
		$this->surface_fill_from_db($k);
	}

	public function surface_fill_from_db($r)
	{
		if (!empty($r['id'])) $this->id = $r['id'];
		if (!empty($r['nama_role'])) $this->nama_role = $r['nama_role'];
	}

	public function load_capabilities()
	{
		if ($this->capabilities !== NULL) return;
		if ($this->id === NULL) return;

		load_data_class('Capability');
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT capabilities.id, capabilities.nama, capabilities.deskripsi, hak_akses.id_role AS is_eligible
                FROM capabilities
                LEFT JOIN hak_akses 
                ON hak_akses.id_capabilities = capabilities.id AND hak_akses.id_role =? 
                ORDER BY capabilities.nama",
			[$this->id]
		)->result_array();
		$this->capabilities = [];
		foreach ($k as $r) {
			$c = new D_Capability();
			$c->surface_fill_from_db($r);
			$this->capabilities[] = $c;
		}
	}

	/**
	 * @return string[]
	 * */
	public function validate_data(int $mode): array
	{
		$errors = [];
		if ($mode !== General_Constants::MODE_OPERATION_CREATE && !is_numeric($this->id))
			$errors[] = "ID tidak boleh kosong.";
		if (
			$mode !== General_Constants::MODE_OPERATION_DELETE &&
			(!is_string($this->nama_role) || trim($this->nama_role) === '')
		)
			$errors[] = "Nama role tidak boleh kosong.";

		if ($mode === General_Constants::MODE_OPERATION_DELETE && $this->dipakai_administrator())
			$errors[] = "Role tidak dapat dihapus karena sedang dipakai administrator.";

		if (count($errors) === 0) {
			$this->nama_role = ucwords(trim($this->nama_role));
		}
		return $errors;
	}

	public function dipakai_administrator(): bool
	{
		if (empty($this->id)) return FALSE;
		$CI =& get_instance();
		$jumlah = $CI->db->query(
			"SELECT COUNT(1) AS jumlah FROM itcc_internal WHERE id_role =  ?",
			[$this->id]
		)->row_array();
		$jumlah = $jumlah['jumlah'];
		return (int)$jumlah > 0;
	}
}
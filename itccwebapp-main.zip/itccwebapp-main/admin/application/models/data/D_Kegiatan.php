<?php defined('BASEPATH') OR exit('No direct script access allowed');

class D_Kegiatan {
	private $max_length_deskripsi = 300;
	private $max_length_keterangan_training = 250;
	private $max_length_keterangan_ujian = 250;

	var $id = NULL;
	var $nama_kegiatan = "";

	var $dibuka_untuk = General_Constants::UMUM;
	var $deskripsi = "";

	var $batal = FALSE;
	var $keterangan_batal = "";

	var $biaya_t_u = 0;
	var $biaya_u = 0;

	var $registrasi_dibuka = FALSE;

	/** @var DateTime $awal_registrasi */
	var $awal_registrasi = NULL;

	/** @var DateTime $akhir_registrasi */
	var $akhir_registrasi = NULL;

	/** @var DateTime $batas_upload_bukti_bayar */
	var $batas_upload_bukti_bayar = NULL;

	/** @var DateTime $awal_persiapan */
	var $awal_persiapan = NULL;

	/** @var DateTime $akhir_persiapan */
	var $akhir_persiapan = NULL;

	/** @var DateTime $awal_pelaporan */
	var $awal_pelaporan = NULL;

	/** @var DateTime $akhir_pelaporan */
	var $akhir_pelaporan = NULL;

	var $keterangan_training = "";
	var $keterangan_ujian = "";

	var $id_sertifikasi = NULL;
	/** @var D_Sertifikasi $program_kegiatan */
	var $sertifikasi = NULL;

	/** @var D_Program_Kegiatan[] $program_kegiatan */
	var $program_kegiatan = NULL;

	var $link_grup = "";

	/** @var D_Kriteria_Registrasi $kriteria_registrasi */
	var $kriteria_registrasi = NULL;

	/** @var D_Kriteria_Diskon $kriteria_diskon */
	var $kriteria_diskon = NULL;

	/** @var D_Kriteria_Peserta_Ujian_Saja $kriteria_peserta_boleh_ujian_saja */
	var $kriteria_peserta_boleh_ujian_saja = NULL;

	/** @var D_Kelompok_T[] $kelompok_training */
	var $list_kelompok_training = NULL;

	/** @var D_Kelompok_U[] $kelompok_ujian */
	var $list_kelompok_ujian = NULL;

	/** @var D_Klaim_Dana_Kegiatan[] $kelompok_ujian */
	var $list_klaim_dana = NULL;

	/** @var D_Pendaftaran_Kegiatan[] $list_pendaftaran */
	var $list_pendaftaran = NULL;

	/** @var D_Peserta[] $list_peserta */
	var $list_peserta = NULL;

	/** @var D_Pembayaran_Kegiatan[] $list_pembayaran */
	var $list_pembayaran = NULL;

	var $catatan = NULL;

	/** @var D_Peserta_Kegiatan_ITPLN[] $list_peserta_kegiatan_itpln */
	var $list_peserta_kegiatan_itpln = NULL;

	private $total_pendaftar_all = NULL;
	private $total_pendaftar_approved = NULL;
	private $total_sudah_pilih_kelompok_t = NULL;
	private $total_sudah_pilih_kelompok_u = NULL;

	public function __construct($id = NULL)
	{
		if ($id === NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT * FROM kegiatan WHERE id = ?",
			[(int)$id]
		)->row_array();
		$this->surface_fill_data_from_db_result($k);
	}

	public function surface_fill_data_from_db_result($k)
	{
		$this->id = $k['id'];
		$this->id_sertifikasi = $k['id_sertifikasi'];
		$this->nama_kegiatan = $k['nama_kegiatan'];
		$this->dibuka_untuk = $k['dibuka_untuk'];
		$this->deskripsi = $k['deskripsi'];
		$this->batal = ($k['batal'] === 'y');
		$this->keterangan_batal = $k['keterangan_batal'];
		$this->biaya_t_u = (int)$k['harga_t_u'];
		$this->biaya_u = (int)$k['harga_u'];
		$this->registrasi_dibuka = ($k['registrasi_dibuka'] === 'y');

		$this->awal_registrasi = !empty($k['awal_registrasi']) ? DateTime::createFromFormat('Y-m-d H:i:s', $k['awal_registrasi']) : NULL;
		$this->akhir_registrasi = !empty($k['akhir_registrasi']) ? DateTime::createFromFormat('Y-m-d H:i:s', $k['akhir_registrasi']) : NULL;
		$this->batas_upload_bukti_bayar =  empty($k['batas_upload_bukti_bayar']) ? NULL : DateTime::createFromFormat('Y-m-d H:i:s', $k['batas_upload_bukti_bayar']);
		$this->awal_persiapan = DateTime::createFromFormat('Y-m-d', $k['awal_persiapan']);
		$this->akhir_persiapan = DateTime::createFromFormat('Y-m-d', $k['akhir_persiapan']);
		$this->awal_pelaporan = DateTime::createFromFormat('Y-m-d', $k['awal_pelaporan']);
		$this->akhir_pelaporan = DateTime::createFromFormat('Y-m-d', $k['akhir_pelaporan']);

		$this->kriteria_registrasi = new D_Kriteria_Registrasi($k['kriteria_registrasi'], $this->dibuka_untuk);
		$this->kriteria_peserta_boleh_ujian_saja = new D_Kriteria_Peserta_Ujian_Saja($k['kriteria_peserta_boleh_ujian_saja'], $this->dibuka_untuk);
		$this->kriteria_diskon = new D_Kriteria_Diskon($k['kriteria_diskon'], $this->dibuka_untuk);

		$this->keterangan_training = $k['keterangan_training'];
		$this->keterangan_ujian = $k['keterangan_ujian'];
		$this->link_grup = $k['link_grup'];
	}

	public function validate_data($mode_create = FALSE): bool
	{
		$errors = [];
		if (!$mode_create && (empty($this->id) ||!is_numeric($this->id)) )
			$errors[] = "ID kegiatan tidak boleh kosong.";
		if (!is_string($this->nama_kegiatan) || trim($this->nama_kegiatan) === '')
			$errors[] = "Nama kegiatan tidak boleh kosong.";
		if (!is_numeric($this->biaya_t_u))
			$errors[] = "Biaya kegiatan (training & ujian) tidak valid.";
		else
		{
			$this->biaya_t_u = (int)$this->biaya_t_u;
			if ($this->biaya_t_u < 0)
            {
                $this->biaya_t_u = 0;
                $errors[] = "Range biaya kegiatan (training & ujian) tidak valid.";
            }
		}
		if (!is_numeric($this->biaya_u))
			$errors[] = "Biaya kegiatan (ujian saja) tidak valid.";
		else
		{
			$this->biaya_u = (int)$this->biaya_u;
			if ($this->biaya_u < 0){
                $this->biaya_u = 0;
                $errors[] = "Range biaya kegiatan (ujian saja) tidak valid.";
            }
		}

		if ($mode_create)
		{
			if (
			!in_array(
				$this->dibuka_untuk,
				[
					General_Constants::UMUM,
					General_Constants::ITPLN,
					General_Constants::MAHASISWA
				]
			)
			){
                $this->dibuka_untuk = General_Constants::UMUM;
                $errors[] = 'Parameter target kegiatan dibuka tidak valid.';
            }

			$CI =& get_instance();
			$CI->load->model('m_sertifikasi');
			if (
				empty($this->id_sertifikasi) ||
				$CI->m_sertifikasi->is_sertif_exists($this->id_sertifikasi) === FALSE
			)
				$errors[] = 'Sertifikasi yang dipilih tidak valid.';

			if (count($this->program_kegiatan) === 0)
				$errors[] = 'Program sertifikasi minimal 1.';
		}

		if (
			!is_string($this->deskripsi) ||
			trim($this->deskripsi) === '' ||
			strlen(trim($this->deskripsi)) > $this->max_length_deskripsi
		)
			$errors[] = 'Deskripsi kegiatan tidak valid.';

		if (
			!is_string($this->keterangan_training) ||
			trim($this->keterangan_training) === '' ||
			strlen(trim($this->keterangan_training)) > $this->max_length_keterangan_training
		)
			$errors[] = 'Berita acara training tidak valid.';

		if (
			!is_string($this->keterangan_ujian) ||
			trim($this->keterangan_ujian) === '' ||
			strlen(trim($this->keterangan_ujian)) > $this->max_length_keterangan_ujian
		)
			$errors[] = 'Berita acara ujian tidak valid.';

		if (empty($this->awal_persiapan) || empty($this->akhir_persiapan))
			$errors[] = 'Waktu persiapan tidak boleh kosong.';

		if (!empty($this->awal_persiapan) && !empty($this->akhir_persiapan) && $this->akhir_persiapan < $this->awal_persiapan)
			$errors[] = 'Range persiapan tidak valid.';

		if (empty($this->awal_pelaporan) || empty($this->akhir_pelaporan))
			$errors[] = 'Waktu pelaporan tidak boleh kosong.';

		if (!empty($this->awal_pelaporan) && !empty($this->akhir_pelaporan) && $this->akhir_pelaporan < $this->awal_pelaporan)
			$errors[] = 'Range pelaporan tidak valid.';

		if (!empty($this->awal_pelaporan) && !empty($this->akhir_persiapan) && $this->awal_pelaporan < $this->akhir_persiapan)
			$errors[] = 'Periode pelaporan tidak boleh mendahului periode persiapan.';

		if ($this->dibuka_untuk !== General_Constants::ITPLN)
		{
			if (empty($this->awal_registrasi) || empty($this->akhir_registrasi))
				$errors[] = 'Waktu registrasi tidak boleh kosong.';

			if (!empty($this->awal_registrasi) && !empty($this->akhir_registrasi) && $this->akhir_registrasi < $this->awal_registrasi)
				$errors[] = 'Range registrasi tidak valid.';


			if (!($this->biaya_t_u === 0 && $this->biaya_u === 0))
			{
				if (empty($this->batas_upload_bukti_bayar))
					$errors[] = 'Batas upload bukti bayar wajib diberikan jika biaya untuk kedua paket adalah gratis.';
			}

			if (!valid_json_str($this->kriteria_registrasi->json_data))
				$errors[] = 'Kriteria registrasi tidak valid.';
			if (!valid_json_str($this->kriteria_peserta_boleh_ujian_saja->json_data))
				$errors[] = 'Kriteria peserta ujian saja tidak valid.';
			if (!valid_json_str($this->kriteria_diskon->json_data))
				$errors[] = 'Kriteria potongan harga tidak valid.';
		}

		if ( empty($this->link_grup) ||
			filter_var($this->link_grup, FILTER_VALIDATE_URL) === FALSE ||
			strlen($this->link_grup) < 10 ||
			!(
				substr($this->link_grup, 0, 7) === 'http://' ||
				substr($this->link_grup, 0, 8) === 'https://'
			)
		)
			$errors[] = "Link grup tidak valid.";

		foreach ($errors as $err)
		{
			set_warning($err);
		}
		$valid = (count($errors) === 0);
		if ($valid)
		{
			$this->nama_kegiatan = trim($this->nama_kegiatan);
			$this->keterangan_training = trim($this->keterangan_training);
			$this->keterangan_ujian = trim($this->keterangan_ujian);
			$this->deskripsi = trim($this->deskripsi);
			$this->biaya_t_u = (int)$this->biaya_t_u;
			$this->biaya_u = (int)$this->biaya_u;
			if ($this->dibuka_untuk === General_Constants::ITPLN)
				$this->biaya_u = 0;
			if (($this->biaya_t_u === 0 && $this->biaya_u === 0) || $this->dibuka_untuk === General_Constants::ITPLN)
				$this->batas_upload_bukti_bayar = NULL;
		}
		return $valid;
	}

	public function load_list_program()
	{
		if ($this->program_kegiatan !== NULL) return;
		if (empty($this->id)) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT program_kegiatan.*, program.nama_program, program.file_logo
			FROM program_kegiatan
			JOIN program ON program_kegiatan.id_program = program.id
			WHERE program_kegiatan.id_kegiatan = ?",
			[(int)$this->id]
		)->result_array();
		$this->program_kegiatan = [];
		foreach ($k as $result)
		{
			$program_kegiatan = new D_Program_Kegiatan();
			$program_kegiatan->id_program_kegiatan = $result['id'];
			$program_kegiatan->id_program = $result['id_program'];
			$program_kegiatan->nama_program = $result['nama_program'];
			$program_kegiatan->file_logo_program = $result['file_logo'];
			$this->program_kegiatan[] = $program_kegiatan;
		}
	}

	public function load_sertifikasi()
	{
		if (!empty($this->sertifikasi)) return;
		if (empty($this->id_sertifikasi)) return;
		load_data_class('Sertifikasi');
		$this->sertifikasi = new D_Sertifikasi($this->id_sertifikasi);
	}

	public function get_total_pendaftar_all(): int
	{
		if (empty($this->id)) return 0;
		if ($this->total_pendaftar_all !== NULL) return $this->total_pendaftar_all;
		$CI =& get_instance();
		$c = $CI->db->query(
			"SELECT COUNT(1) AS jumlah FROM pendaftaran WHERE id_kegiatan = ?",
			[$this->id]
		)->row_array();
		$c = $c['jumlah'];
		$this->total_pendaftar_all = (int)$c;
		return $this->total_pendaftar_all;
	}

	public function get_total_pendaftar_approved(): int
	{
		if (empty($this->id)) return 0;
		if ($this->total_pendaftar_approved !== NULL) return $this->total_pendaftar_approved;
		$CI =& get_instance();
		$c = $CI->db->query(
			"SELECT COUNT(1) AS jumlah FROM pendaftaran WHERE id_kegiatan = ? AND approved = 'y'",
			[$this->id]
		)->row_array();
		$c = $c['jumlah'];
		$this->total_pendaftar_approved = (int)$c;
		return $this->total_pendaftar_approved;
	}

	public function load_kelompok_training()
	{
		if (empty($this->id)) return;
		if ($this->list_kelompok_training !== NULL) return;
		$CI =& get_instance();
		$c = $CI->db->query(
			"SELECT kelompok_t.*,
       		program_kegiatan.id_program,
       		program.nama_program,
       		trainer_sesi1.nama_lengkap AS nama_trainer_sesi1,
			trainer_sesi2.nama_lengkap AS nama_trainer_sesi2,
			proctor_training.nama_lengkap AS nama_proctor_training,
       		COUNT(pendaftaran.id) AS jumlah_peserta_kelompok
			FROM kelompok_t 
			JOIN program_kegiatan ON program_kegiatan.id = kelompok_t.id_program_kegiatan
			JOIN program ON program_kegiatan.id_program = program.id
			LEFT JOIN pendaftaran ON pendaftaran.id_kelompok_t = kelompok_t.id
			LEFT JOIN trainer trainer_sesi1 ON trainer_sesi1.id = kelompok_t.id_trainer_sesi1
			LEFT JOIN trainer trainer_sesi2 ON trainer_sesi2.id = kelompok_t.id_trainer_sesi2
			LEFT JOIN proctor proctor_training ON proctor_training.id = kelompok_t.id_proctor_training
			WHERE kelompok_t.id_kegiatan = ?
			GROUP BY kelompok_t.id",
			[$this->id]
		)->result_array();
		load_data_class('Kelompok_T');
		$this->list_kelompok_training = [];
		foreach($c as $result_db)
		{
			$kelompok_t = new D_Kelompok_T();
			$kelompok_t->parse_data_from_db($result_db);
			$this->list_kelompok_training[] = $kelompok_t;
		}
	}

	public function load_kelompok_ujian()
	{
		if ($this->list_kelompok_ujian !== NULL) return;
		$CI =& get_instance();
		$c = $CI->db->query(
			"SELECT kelompok_u.*,
       		program_kegiatan.id_program,
       		program.nama_program,
			proctor_ujian.nama_lengkap AS nama_proctor_ujian,
       		COUNT(pendaftaran.id) AS jumlah_peserta_kelompok
			FROM kelompok_u
			JOIN program_kegiatan ON program_kegiatan.id = kelompok_u.id_program_kegiatan
			JOIN program ON program_kegiatan.id_program = program.id
			LEFT JOIN pendaftaran ON pendaftaran.id_kelompok_u = kelompok_u.id
			LEFT JOIN proctor proctor_ujian ON proctor_ujian.id = kelompok_u.id_proctor_ujian
			WHERE kelompok_u.id_kegiatan = ?
			GROUP BY kelompok_u.id",
			[$this->id]
		)->result_array();
		load_data_class('Kelompok_U');
		$this->list_kelompok_ujian = [];
		foreach($c as $result_db)
		{
			$kelompok_u = new D_Kelompok_U();
			$kelompok_u->parse_data_from_db($result_db);
			$this->list_kelompok_ujian[] = $kelompok_u;
		}
	}

	public function get_total_sudah_pilih_kelompok_t(): int
	{
		if (empty($this->id)) return 0;
		if ($this->total_sudah_pilih_kelompok_t !== NULL) return $this->total_sudah_pilih_kelompok_t;
		$CI =& get_instance();
		$c = $CI->db->query(
			"SELECT COUNT(1) AS jumlah FROM pendaftaran WHERE id_kegiatan = ? AND id_kelompok_t IS NOT NULL",
			[$this->id]
		)->row_array();
		$c = $c['jumlah'];
		$this->total_sudah_pilih_kelompok_t = (int)$c;
		return $this->total_sudah_pilih_kelompok_t;
	}

	public function get_total_sudah_pilih_kelompok_u(): int
	{
		if (empty($this->id)) return 0;
		if ($this->total_sudah_pilih_kelompok_u !== NULL) return $this->total_sudah_pilih_kelompok_u;
		$CI =& get_instance();
		$c = $CI->db->query(
			"SELECT COUNT(1) AS jumlah FROM pendaftaran WHERE id_kegiatan = ? AND id_kelompok_u IS NOT NULL",
			[$this->id]
		)->row_array();
		$c = $c['jumlah'];
		$this->total_sudah_pilih_kelompok_u = (int)$c;
		return $this->total_sudah_pilih_kelompok_u;
	}

	public function load_list_pendaftaran()
	{
		if (empty($this->id)) return;
		if ($this->list_pendaftaran !== NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT pendaftaran.*, 
                    CONCAT(users.nama_depan, ' ', users.nama_belakang) AS nama_lengkap,
                    users.email, 
                    users.nim,
                    users.angkatan,
                    users.jurusan,
       				pk.id_program,
                    p.nama_program,
				   	SUM(bukti_bayar.nominal_dibayar) AS nominal_dibayar
			FROM pendaftaran
			JOIN users ON pendaftaran.id_user = users.id
			JOIN program_kegiatan pk on pendaftaran.id_program_kegiatan = pk.id
			JOIN program p on pk.id_program = p.id
			LEFT JOIN bukti_bayar ON bukti_bayar.id_pendaftaran = pendaftaran.id AND bukti_bayar.diterima = 'accept'
			WHERE pendaftaran.id_kegiatan=?
			GROUP BY pendaftaran.id, bukti_bayar.id_pendaftaran",
			[(int)$this->id]
		)->result_array();
		$this->list_pendaftaran = [];
		foreach($k as $result)
		{
			$pendaftaran = new D_Pendaftaran_Kegiatan();
			$pendaftaran->surface_fill_data_from_db_result($result);
			$this->list_pendaftaran[] = $pendaftaran;
		}
	}

	public function load_list_peserta()
	{
		if (empty($this->id)) return;
		if ($this->list_peserta !== NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT 
			pendaftaran.*, 
			pendaftaran.id AS id_pendaftaran, 
			users.id AS id_user,
       		users.file_fotoprofil,
       		users.nama_depan,
			users.nama_belakang,
			users.email, 
			users.nim,
			users.angkatan,
			users.jurusan,
			program_kegiatan.id_program,
			program.nama_program,
			program.min_skor,
			program.max_skor,
			kelompok_t.nama_kelompok AS nama_kelompok_t,
			kelompok_u.nama_kelompok AS nama_kelompok_u,
       		bidang_itpln.nama_bidang,
       		jabatan_itpln.nama_jabatan
			FROM pendaftaran
			JOIN users ON pendaftaran.id_user = users.id
			JOIN program_kegiatan ON program_kegiatan.id = pendaftaran.id_program_kegiatan
			JOIN program ON program.id = program_kegiatan.id_program
			LEFT JOIN kelompok_t ON kelompok_t.id = pendaftaran.id_kelompok_t
			LEFT JOIN kelompok_u ON kelompok_u.id = pendaftaran.id_kelompok_u
			LEFT JOIN jabatan_itpln ON jabatan_itpln.id = users.id_jabatan
			LEFT JOIN bidang_itpln ON bidang_itpln.id = jabatan_itpln.id_bidang
			WHERE pendaftaran.approved='y' AND pendaftaran.id_kegiatan=?
			ORDER BY pendaftaran.id_program_kegiatan",
			[(int)$this->id]
		)->result_array();
		$this->list_peserta = [];
		load_data_class('Peserta');
		foreach($k as $result)
		{
			$peserta = new D_Peserta();
			$peserta->surface_fill_data_from_db_result($result);
			$this->list_peserta[] = $peserta;
		}
	}

	public function load_list_pembayaran()
	{
		if (empty($this->id)) return;
		if ($this->list_pembayaran !== NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT 
			bukti_bayar.*, 
			users.nim, 
			users.nama_depan, 
			users.nama_belakang, 
			users.angkatan, 
			users.email, 
			users.jurusan,
			pendaftaran.id_user
			FROM bukti_bayar 
			JOIN pendaftaran ON bukti_bayar.id_pendaftaran = pendaftaran.id
			JOIN users ON pendaftaran.id_user = users.id
			WHERE pendaftaran.id_kegiatan = ?
			ORDER BY pendaftaran.waktu DESC",
			[(int)$this->id]
		)->result_array();
		$this->list_pembayaran = [];
		foreach($k as $result)
		{
			$pendaftaran = new D_Pembayaran_Kegiatan();
			$pendaftaran->surface_fill_data_from_db_result($result);
			$this->list_pembayaran[] = $pendaftaran;
		}
	}

	public function load_list_klaim_dana()
	{
		if (empty($this->id)) return;
		if ($this->list_klaim_dana !== NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT * FROM klaim_dana_kegiatan WHERE id_kegiatan = ?",
			[(int)$this->id]
		)->result_array();
		$this->list_klaim_dana = [];
		foreach($k as $result)
		{
			$klaim = new D_Klaim_Dana_Kegiatan();
			$klaim->id = $result['id'];
			$klaim->id_kegiatan = $result['id_kegiatan'];
			$klaim->nominal_klaim = $result['nominal_klaim'];
			$klaim->keterangan = $result['keterangan'];
			$klaim->file_bukti_klaim = $result['file_bukti_klaim'];

			$this->list_klaim_dana[] = $klaim;
		}
	}

	/** @param D_Peserta_Kegiatan_ITPLN[] $list */
	public function append_list_peserta_kegiatan_itpln(array $list): bool
	{
		if ($this->id === NULL) return FALSE;
		if ($this->dibuka_untuk !== General_Constants::ITPLN) return FALSE;
		$CI =& get_instance();
		$CI->db->trans_start();
		foreach($list as $p)
		{
			$CI->db->query(
				"INSERT INTO peserta_kegiatan_itpln (id_kegiatan, email, id_program_kegiatan) VALUES (?,?,?)",
				[
					$this->id,
					$p->email,
					$p->id_program_kegiatan
				]
			);
		}
		$CI->db->trans_complete();
		return $CI->db->trans_status();
	}

	public function load_list_peserta_kegiatan_itpln()
	{
		if ($this->id === NULL) return;
		if ($this->dibuka_untuk !== General_Constants::ITPLN) return;
		if ($this->list_peserta_kegiatan_itpln !== NULL) return;
		$CI =& get_instance();
		$list = $CI->db->query(
			"SELECT peserta_kegiatan_itpln.*, program.nama_program
			FROM peserta_kegiatan_itpln 
			JOIN program_kegiatan ON program_kegiatan.id = peserta_kegiatan_itpln.id_program_kegiatan
			JOIN program ON program.id = program_kegiatan.id_program
			WHERE peserta_kegiatan_itpln.id_kegiatan = ?",
			[$this->id]
		)->result_array();
		$this->list_peserta_kegiatan_itpln = [];
		foreach($list as $l)
		{
			$peserta = new D_Peserta_Kegiatan_ITPLN();
			$peserta->id_kegiatan = $l['id_kegiatan'];
			$peserta->email = $l['email'];
			$peserta->id_program_kegiatan = $l['id_program_kegiatan'];
			$peserta->nama_program = $l['nama_program'];
			$this->list_peserta_kegiatan_itpln[] = $peserta;
		}
	}

	public function get_value_diskon(D_User $user, $jenis_pendaftaran) : int
	{
		$kriteria_diskon = json_decode($this->kriteria_diskon->json_data, TRUE);

		$diskon = 0;
		$biaya = ($jenis_pendaftaran === General_Constants::UJIAN_SAJA) ? (int)$this->biaya_u : (int)$this->biaya_t_u;
		foreach($kriteria_diskon as $kriteria)
		{
			if (!isset($kriteria['tipe']) || !isset($kriteria['value'])) continue;
			// persen atau nominal
			$value = (int)$kriteria['value'];
			$jumlah = $value; //nominal
			if ($kriteria['tipe'] === 'persen')
				$jumlah = (int)($value*$biaya/100);

			// cek apakah diskon bisa diterapkan
			$valid = FALSE;

			// berdasarkan jumlah pendaftar saat ini
			$jumlah_pendaftar = $this->get_total_pendaftar_all();
			if (
				isset($kriteria['disc_pendaftar_pertama']) &&
				$jumlah_pendaftar+1 <= (int)$kriteria['disc_pendaftar_pertama']
			)
				$valid = TRUE;

			// berdasarkan waktu daftar
			if (!empty($kriteria['disc_waktu_daftar']['dari']) && !empty($kriteria['disc_waktu_daftar']['sampai']))
			{
				$sekarang = new DateTime();
				$awal = DateTime::createFromFormat('Y-m-d H:i:s', $kriteria['disc_waktu_daftar']['dari']);
				$akhir = DateTime::createFromFormat('Y-m-d H:i:s', $kriteria['disc_waktu_daftar']['sampai']);
				if ($sekarang >= $awal && $sekarang <= $akhir)
					$valid = TRUE;
			}

			// berdasarkan kriteria
			if (isset($kriteria['disc']))
			{
				$k = $kriteria['disc'];
				if ($this->dibuka_untuk === General_Constants::UMUM && $user->tipe_user === General_Constants::UMUM)
				{
					if (is_array($k))
					{
						$user->load_list_instansi();
						foreach($k as $filter)
						{
							if (!isset($filter['tipe']) || !isset($filter['data'])) continue;
							// cek apakah user ini termasuk dalam instansi
							if ($filter['tipe'] === 'instansi')
							{
								$id_instansi = $filter['data'];
								$arr_selected_instansi = array_filter($user->list_instansi, function($val) use ($id_instansi){
									return ((int)$val->id === (int)$id_instansi);
								});
								if (count($arr_selected_instansi) > 0 || $id_instansi === '0')
									$valid = TRUE;
							}
							elseif($filter['tipe'] === 'user' && trim(strtolower($filter['data'])) === trim(strtolower($user->email)))
							{
								$valid = TRUE;
							}
						}
					}
				}
				elseif($this->dibuka_untuk === General_Constants::MAHASISWA && $user->tipe_user === General_Constants::MAHASISWA){
					$nim = $user->nim;
					$angkatan = $user->angkatan;
					$jurusan = $user->jurusan;
					$index = substr($nim, 6, 3);
					if (is_array($k))
					{
						foreach($k as $filter)
						{
							if (!isset($filter['angkatan']) || !isset($filter['jurusan']) || !isset($filter['index']))
								if (
									($filter['angkatan'] === "0" || $filter['angkatan'] === $angkatan) &&
									($filter['jurusan'] === "0" || $filter['jurusan'] === $jurusan) &&
									($filter['index'] === "0" || $filter['index'] === $index)
								)
									$valid = TRUE;
						}
					}

				}
			}
			if ($valid) $diskon += $jumlah;
		}
		return (int)$diskon;
	}
}

class D_Klaim_Dana_Kegiatan{
	private $max_length_keterangan = 500;

	var $id = NULL;
	var $id_kegiatan = NULL;
	var $nominal_klaim = 0;
	var $keterangan = '';
	var $file_bukti_klaim = '';

	public function __construct($id = NULL)
	{
		if ($id === NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT * FROM klaim_dana_kegiatan WHERE id = ?",
			[(int)$id]
		)->row_array();
		if (empty($k)) return;
		$this->id = $k['id'];
		$this->id_kegiatan = $k['id_kegiatan'];
		$this->nominal_klaim = $k['nominal_klaim'];
		$this->keterangan = $k['keterangan'];
		$this->file_bukti_klaim = $k['file_bukti_klaim'];
	}

	public function hapus_file_bukti()
	{
		if (empty($this->file_bukti_klaim)) return;
		$path = config_item('UPLOAD_KLAIM_DANA_KEGIATAN')['upload_path'].$this->file_bukti_klaim;
		if (file_exists($path)) unlink($path);
	}

	public function get_link_bukti_klaim(): string
	{
		if (empty($this->file_bukti_klaim)) return "";
		return base_url('storage/?type=upload_klaim_dana_kegiatan&file_name='.$this->file_bukti_klaim);
	}

	public function upload_bukti($param_name): bool
	{
		$CI =& get_instance();
		$CI->load->library('upload', config_item('UPLOAD_KLAIM_DANA_KEGIATAN'), 'upload_klaim');
		if ($CI->upload_klaim->do_upload($param_name))
			$this->file_bukti_klaim = $CI->upload_klaim->data('file_name');
		else
			return FALSE;
		return TRUE;
	}

	public function validate_data($mode_create = FALSE): bool
	{
		$errors = [];
		if (!$mode_create && (empty($this->id) ||!is_numeric($this->id)) )
			$errors[] = "ID klaim dana kegaitan tidak boleh kosong.";
		if (!is_string($this->keterangan) || trim($this->keterangan) === '')
			$errors[] = "Keterangan klaim tidak boleh kosong.";
		if (is_string($this->keterangan) && strlen($this->keterangan) > $this->max_length_keterangan)
			$errors[] = "Panjang keterangan klaim melebihi batas.";
		if (!is_numeric($this->nominal_klaim))
			$errors[] = "Nominal klaim dana tidak valid.";
		else
		{
			$this->nominal_klaim = (int)$this->nominal_klaim;
			if ($this->nominal_klaim < 0)
				$errors[] = "Range nominal klaim dana tidak valid.";
		}
		if (empty($this->id_kegiatan))
			$errors[] = "Kegiatan yang dipilih tidak valid.";
		if (strlen($this->file_bukti_klaim) === 0)
			$errors[] = "File klaim kegiatan wajib diberikan.";

		foreach ($errors as $err)
		{
			set_warning($err);
		}
		$valid = (count($errors) === 0);
		if ($valid)
		{
			$this->keterangan = ucfirst(trim($this->keterangan));
			$this->nominal_klaim = (int)$this->nominal_klaim;
		}
		return $valid;
	}
}

class D_Kriteria_Registrasi {
	var $json_data = "{}";
	var $dibuka_untuk = General_Constants::UMUM;

	public function __construct($json, $untuk)
	{
		$this->json_data = $json;
		$this->dibuka_untuk = $untuk;
	}
}

class D_Kriteria_Peserta_Ujian_Saja{
	var $json_data = "{}";
	var $dibuka_untuk = General_Constants::UMUM;

	public function __construct($json, $untuk)
	{
		$this->json_data = $json;
		$this->dibuka_untuk = $untuk;
	}
}

class D_Kriteria_Diskon{
	var $json_data = "{}";
	var $dibuka_untuk = General_Constants::UMUM;

	public function __construct($json, $untuk)
	{
		$this->json_data = $json;
		$this->dibuka_untuk = $untuk;
	}
}

class D_Program_Kegiatan{
	var $id_program_kegiatan = NULL;
	var $id_program = NULL;
	var $nama_program = "";
	var $file_logo_program = "";

	public function get_link_logo(): string
	{
		return base_url(config_item('UPLOAD_LOGO_PROGRAM')['upload_path'].$this->file_logo_program);
	}
}

class D_Pendaftaran_Kegiatan{
	var $id = NULL;
	var $waktu = NULL;
	var $id_user = NULL;
	var $id_kegiatan = NULL;
	var $id_program = NULL;
	var $id_program_kegiatan = NULL;
	var $jenis = General_Constants::TRAINING_DAN_UJIAN;
	var $diskon = 0;
	var $approved = FALSE;

	var $terbayar = 0;

	/** @var D_Kegiatan $kegiatan */
	var $kegiatan = NULL;
	/** @var D_User $user */
	var	$user = NULL;

	// data non esensial
	var $nama_lengkap_user = "";
	var $email_user = "";
	var $nim_user = "";
	var $angkatan_user = "";
	var $jurusan_user = "";
	var $program_yang_dipilih = "";

	public function __construct($id = NULL)
	{
		if ($id === NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT pendaftaran.*, 
                    CONCAT(users.nama_depan, ' ', users.nama_belakang) AS nama_lengkap,
                    users.email, 
                    users.nim,
                    users.angkatan,
                    users.jurusan,
       				pk.id_program,
                    p.nama_program,
				   	SUM(bukti_bayar.nominal_dibayar) AS nominal_dibayar
			FROM pendaftaran
			JOIN users ON pendaftaran.id_user = users.id
			JOIN program_kegiatan pk on pendaftaran.id_program_kegiatan = pk.id
			JOIN program p on pk.id_program = p.id
			LEFT JOIN bukti_bayar ON bukti_bayar.id_pendaftaran = pendaftaran.id AND bukti_bayar.diterima = 'accept'
			WHERE pendaftaran.id=? 
			GROUP BY pendaftaran.id, bukti_bayar.id_pendaftaran
			ORDER BY pendaftaran.waktu DESC",
			[(int)$id]
		)->row_array();
		$this->surface_fill_data_from_db_result($k);
	}

	public function pernah_upload_bukti_bayar(): bool
	{
		if ($this->id === NULL) return FALSE;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT COUNT(1) AS jumlah FROM bukti_bayar WHERE id_pendaftaran=?",
			[(int)$this->id]
		)->row_array();
		$k = $k['jumlah'];
		return (int)$k > 0;
	}

	public function ada_sertifikat_keikutsertaan(): bool
	{
		if ($this->id === NULL) return FALSE;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT COUNT(1) AS jumlah FROM sertifikat_keikutsertaan WHERE id_pendaftaran=?",
			[(int)$this->id]
		)->row_array();
		$k = $k['jumlah'];
		return (int)$k > 0;
	}

	public function surface_fill_data_from_db_result($k)
	{
		if(!empty($k['id'])) $this->id = $k['id'];
        if(!empty($k['waktu'])) $this->waktu = $k['waktu'];
        if(!empty($k['id_user'])) $this->id_user = $k['id_user'];
		if(!empty($k['id_kegiatan'])) $this->id_kegiatan = $k['id_kegiatan'];
		if(!empty($k['id_program'])) $this->id_program = $k['id_program'];
		if(!empty($k['id_program_kegiatan'])) $this->id_program_kegiatan = $k['id_program_kegiatan'];
		if(!empty($k['jenis'])) $this->jenis = $k['jenis'];
		if(!empty($k['diskon'])) $this->diskon = (int)$k['diskon'];
		if(!empty($k['nominal_dibayar'])) $this->terbayar = (int)$k['nominal_dibayar'];
		if(!empty($k['approved'])) $this->approved = ($k['approved'] === 'y');
		if(!empty($k['nama_lengkap'])) $this->nama_lengkap_user = $k['nama_lengkap'];
		if(!empty($k['email'])) $this->email_user = $k['email'];
		if(!empty($k['nim'])) $this->nim_user = $k['nim'];
		if(!empty($k['angkatan'])) $this->angkatan_user = $k['angkatan'];
		if(!empty($k['jurusan'])) $this->jurusan_user = $k['jurusan'];
		if(!empty($k['nama_program'])) $this->program_yang_dipilih = $k['nama_program'];
	}

	public function validate_data_untuk_registrasi(): bool
	{
		$errors = [];
		if (!is_numeric($this->id_kegiatan))
			$errors[] = "ID kegiatan tidak boleh kosong.";

		if (!is_numeric($this->id_program_kegiatan))
			$errors[] = "ID program tidak boleh kosong.";

		$jenis_pendaftaran_valid = in_array($this->jenis, [General_Constants::UJIAN_SAJA, General_Constants::TRAINING_DAN_UJIAN]);
		if (!$jenis_pendaftaran_valid)
			$errors[] = "Jenis registrasi tidak valid.";

		$CI =& get_instance();

		$CI->load->model('m_kegiatan');
		$kegiatan_exists = $CI->m_kegiatan->is_id_kegiatan_exists($this->id_kegiatan);
		if (!$kegiatan_exists)
			$errors[] = 'Kegiatan yang dipilih tidak dapat ditemukan.';

		$CI->load->model('m_user');
		$user_exists = $CI->m_user->is_id_user_exists($this->id_user);
		if (!$user_exists)
			$errors[] = 'User tidak dapat ditemukan.';

		if ($user_exists && $kegiatan_exists && is_numeric($this->id_program_kegiatan)) {
			$user = new D_User($this->id_user);
			$kegiatan = new D_Kegiatan($this->id_kegiatan);

			$this->user = $user;
			$this->kegiatan = $kegiatan;

			if ($CI->m_kegiatan->user_sudah_mendaftar_kegiatan($user, $kegiatan))
				$errors[] = 'User sudah terdaftar di kegiatan ini.';

			$tipe_user_sesuai_kegiatan = $user->tipe_user !== $kegiatan->dibuka_untuk;
			if ($tipe_user_sesuai_kegiatan)
				$errors[] = 'Kegiatan yang dipilih tidak sesuai dengan jenis akun user.';

			if ($kegiatan->batal)
				$errors[] = 'Registrasi tidak dapat dilanjutkan karena kegiatan telah dibatalkan.';

			$kegiatan->load_list_program();
			$id_program_kegiatan = (int)$this->id_program_kegiatan;
			$selected_program_kegiatan = array_filter($kegiatan->program_kegiatan, function ($p) use ($id_program_kegiatan) {
				return $id_program_kegiatan === (int)$p->id_program_kegiatan;
			});
			if (count($selected_program_kegiatan) === 0)
				$errors[] = 'Program sertifikasi yang dipilih tidak valid.';
		}

		foreach ($errors as $err)
		{
			set_warning($err);
		}
		$valid = (count($errors) === 0);
		if ($valid)
		{
			$this->diskon = $this->kegiatan->get_value_diskon($this->user, $this->jenis);
		}
		return $valid;
	}

	public function validate_data_untuk_update_registrasi(): bool
	{
		$errors = [];

		if (!is_numeric($this->id_program_kegiatan))
			$errors[] = "ID program tidak boleh kosong.";

		$jenis_pendaftaran_valid = in_array($this->jenis, [General_Constants::UJIAN_SAJA, General_Constants::TRAINING_DAN_UJIAN]);
		if (!$jenis_pendaftaran_valid)
			$errors[] = "Jenis registrasi tidak valid.";

		$CI =& get_instance();
		$CI->load->model('m_kegiatan');
		$kegiatan = new D_Kegiatan($this->id_kegiatan);
		$kegiatan->load_list_program();
		$id_program_kegiatan = (int)$this->id_program_kegiatan;
		$selected_program_kegiatan = array_filter($kegiatan->program_kegiatan, function ($p) use ($id_program_kegiatan) {
			return $id_program_kegiatan === (int)$p->id_program_kegiatan;
		});
		if (count($selected_program_kegiatan) === 0)
			$errors[] = 'Program sertifikasi yang dipilih tidak valid.';

		foreach ($errors as $err)
		{
			set_warning($err);
		}
		return (count($errors) === 0);
	}
}

class D_Pembayaran_Kegiatan{
	var $id = NULL;
	var $id_pendaftaran = NULL;
	var $file_bukti = "";
	var $timestamp = NULL;

	/** @var DateTime $waktu_transfer */
	var $waktu_transfer = NULL;
	var $nominal_dibayar = 0;
	var $nama_pengirim = "";
	var $bank = "";
	var $status = General_Constants::PEMBAYARAN_PENDING;

	// data non esensial
	var $id_user = NULL;
	var $nama_depan = "";
	var $nama_belakang = "";
	var $email_user = "";
	var $nim_user = "";
	var $angkatan_user = "";
	var $jurusan_user = "";

	public function __construct($id = NULL)
	{
		if ($id === NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT 
			bukti_bayar.*, 
			users.nim, 
			users.nama_depan, 
			users.nama_belakang, 
			users.angkatan, 
			users.email, 
			users.jurusan,
			pendaftaran.id_user
			FROM bukti_bayar 
			JOIN pendaftaran ON bukti_bayar.id_pendaftaran = pendaftaran.id
			JOIN users ON pendaftaran.id_user = users.id
			WHERE bukti_bayar.id=?
			ORDER BY pendaftaran.waktu DESC",
			[(int)$id]
		)->row_array();
		$this->surface_fill_data_from_db_result($k);
	}

	public function surface_fill_data_from_db_result($k)
	{
		$this->id = $k['id'];
		$this->id_pendaftaran = $k['id_pendaftaran'];
		$this->file_bukti = $k['file_bukti'];
		$this->timestamp = $k['waktu'];
		$this->waktu_transfer = DateTime::createFromFormat('Y-m-d H:i:s', $k['waktu_transfer']);
		$this->nominal_dibayar = (int)$k['nominal_dibayar'];
		$this->nama_pengirim = $k['nama_pengirim'];
		$this->bank = $k['bank'];
		$this->status = $k['diterima'];

		$this->id_user = $k['id_user'];
		$this->nama_depan = $k['nama_depan'];
		$this->nama_belakang = $k['nama_belakang'];
		$this->email_user = $k['email'];
		$this->nim_user = $k['nim'];
		$this->angkatan_user = $k['angkatan'];
		$this->jurusan_user = $k['jurusan'];
	}

	public function get_link_file_bukti(): string
	{
		return base_url('storage?type=upload_bukti_bayar&file_name='.$this->file_bukti);
	}
}

class D_Peserta_Kegiatan_ITPLN{
	var $id_kegiatan = NULL;
	var $email = '';
	var $nama_program = '';
	var $id_program_kegiatan = NULL;
}

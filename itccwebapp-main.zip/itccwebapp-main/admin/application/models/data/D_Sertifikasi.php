<?php defined('BASEPATH') OR exit('No direct script access allowed');


class D_Sertifikasi {
	var $id = NULL;
	var $nama = "";
	var $deskripsi = "";
	var $file_logo = "default.jpg";
	var $link_template_sertifikat = "";
	/**
	 * @var D_Program[] $list_program
	 */
	var $list_program = NULL;

	public function __construct($id_sertifikasi = NULL)
	{
		if ($id_sertifikasi === NULL) return;
		$CI =& get_instance();
		$s = $CI->db->query(
			"SELECT * FROM sertifikasi WHERE id = ?",
			[(int)$id_sertifikasi]
		)->row_array();
		if (empty($s)) return;
		$this->id = (int)$s['id'];
		$this->nama = $s['nama'];
		$this->deskripsi = $s['deskripsi'];
		$this->file_logo = $s['file_logo'];
		$this->link_template_sertifikat = $s['link_template_sertifikat'];
	}

	public function load_list_program()
	{
		load_data_class('Program');
		$CI =& get_instance();
		$list_id = $CI->db->query(
			"SELECT id FROM program WHERE id_sertif = ?",
			[(int)$this->id]
		)->result_array();

		$this->list_program = [];
		foreach ($list_id as $id)
		{
			$this->list_program[] = new D_Program($id['id']);
		}
	}

	public function validate_data($create = FALSE): bool
	{
		$errors = [];
		if (!$create && !is_numeric($this->id))
			$errors[] = "ID sertifikasi tidak boleh kosong.";
		if (empty($this->nama) || trim($this->nama) === '')
			$errors[] = "Nama sertifikasi tidak boleh kosong.";
		if (empty($this->deskripsi) || trim($this->deskripsi) === '')
			$errors[] = "Deskripsi sertifikasi tidak boleh kosong.";
		if (strlen(trim($this->deskripsi)) > 500)
			$errors[] = "Maks. panjang deskripsi sertifikasi adalah 500 karakter.";
		if ( empty($this->link_template_sertifikat) ||
			filter_var($this->link_template_sertifikat, FILTER_VALIDATE_URL) === FALSE ||
			strlen($this->link_template_sertifikat) < 10 ||
			!(
				substr($this->link_template_sertifikat, 0, 7) === 'http://' ||
				substr($this->link_template_sertifikat, 0, 8) === 'https://'
			)
		)
			$errors[] = "Link template sertifikat keikutsertaan tidak valid.";

		foreach ($errors as $err)
		{
			set_warning($err);
		}
		$valid = (count($errors) === 0);
		if ($valid)
		{
			$this->nama = ucwords(trim($this->nama));
			$this->deskripsi = ucfirst(trim($this->deskripsi));
		}
		return $valid;
	}

	public function upload_logo($param_name): bool
	{
		$CI =& get_instance();
		$CI->load->library('upload', config_item('UPLOAD_LOGO_SERTIFIKASI'), 'upload_logo');
		if ($CI->upload_logo->do_upload($param_name))
			$this->file_logo = $CI->upload_logo->data('file_name');
		else
			return FALSE;
		return TRUE;
	}

	public function hapus_logo()
	{
		if ($this->file_logo === "default.jpg") return;
		$path = config_item('UPLOAD_LOGO_SERTIFIKASI')['upload_path'].$this->file_logo;
		if (file_exists($path)) unlink($path);
	}

	public function pernah_diadakan_kegiatan(): bool
	{
		$CI =& get_instance();
		$s = $CI->db->query(
			"SELECT COUNT(id) AS jumlah FROM kegiatan WHERE id_sertifikasi=?",
			[(int)$this->id]
		)->row_array();
		$s = $s['jumlah'];
		return ((int)$s >0);
	}

	public function get_link_logo(): string
	{
		return base_url(config_item('UPLOAD_LOGO_SERTIFIKASI')['upload_path'].$this->file_logo);
	}
}

<?php defined('BASEPATH') OR exit('No direct script access allowed');
class D_Kelompok_T {
	// dalam jam
	var $jarak_absensi_setelah_training = 1;

	var $id = NULL;
	var $id_kegiatan = NULL;

	var $id_program_kegiatan = NULL;
	var $id_program = NULL;
	var $nama_program = "";

	var $nama_kelompok = "";

	var $lokasi_training = "";

	/** @var DateTime $mulai_training */
	var $mulai_training = NULL;

	/** @var DateTime $selesai_training */
	var $selesai_training = NULL;

	var $id_trainer_sesi1 = NULL;
	var $trainer_sesi1 = "";

	var $id_trainer_sesi2 = NULL;
	var $trainer_sesi2 = "";

	var $id_proctor_training = NULL;
	var $proctor_training = "";

	var $beritaacara_t_sesi1 = "";
	var $beritaacara_t_sesi2 = "";

	var $min_peserta_training = 0;
	var $max_peserta_training = 0;

	/** @var D_Peserta[] $list_peserta */
	var $list_peserta = NULL;

	var $jumlah_peserta = 0;

	/** @var D_Kesediaan_Trainer[] $list_kesediaan_trainer_sesi1 */
	var $list_kesediaan_trainer = NULL;

	/** @var D_Kesediaan_Proctor[] $list_kesediaan_proctor_training */
	var $list_kesediaan_proctor_training = NULL;

	public function __construct($id_kelompok = NULL)
	{
		if ($id_kelompok === NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT kelompok_t.*,
       		program_kegiatan.id_program,
       		program.nama_program,
       		trainer_sesi1.nama_lengkap AS nama_trainer_sesi1,
			trainer_sesi2.nama_lengkap AS nama_trainer_sesi2,
			proctor_training.nama_lengkap AS nama_proctor_training,
       		COUNT(pendaftaran.id) AS jumlah_peserta_kelompok
			FROM kelompok_t 
			JOIN program_kegiatan ON program_kegiatan.id = kelompok_t.id_program_kegiatan
			JOIN program ON program_kegiatan.id_program = program.id
			LEFT JOIN pendaftaran ON pendaftaran.id_kelompok_t = kelompok_t.id
			LEFT JOIN trainer trainer_sesi1 ON trainer_sesi1.id = kelompok_t.id_trainer_sesi1
			LEFT JOIN trainer trainer_sesi2 ON trainer_sesi2.id = kelompok_t.id_trainer_sesi2
			LEFT JOIN proctor proctor_training ON proctor_training.id = kelompok_t.id_proctor_training
			WHERE kelompok_t.id = ?
			GROUP BY kelompok_t.id",
			[(int)$id_kelompok]
		)->row_array();
		if (empty($k)) return;
		$this->parse_data_from_db($k);
	}

	public function parse_data_from_db($k)
	{
		$this->id = $k['id'];
		$this->id_kegiatan = $k['id_kegiatan'];
		$this->id_program_kegiatan = $k['id_program_kegiatan'];
		$this->id_program = $k['id_program'];
		if (is_string($k['nama_program']) && strlen($k['nama_program']) > 0 ) $this->nama_program = $k['nama_program'];

		if (is_string($k['nama_kelompok']) && strlen($k['nama_kelompok']) > 0) $this->nama_kelompok = $k['nama_kelompok'];

		$this->mulai_training = (empty($k['mulai_training']) ? NULL : DateTime::createFromFormat('Y-m-d H:i:s', $k['mulai_training']));
		$this->selesai_training = (empty($k['selesai_training']) ? NULL : DateTime::createFromFormat('Y-m-d H:i:s', $k['selesai_training']));

		$this->lokasi_training = (empty($k['lokasi_training']) ? '' : $k['lokasi_training']);

		$this->id_trainer_sesi1 = (empty($k['id_trainer_sesi1']) ? NULL : (int)$k['id_trainer_sesi1']);
		$this->trainer_sesi1 = (empty($k['nama_trainer_sesi1']) ? "" : $k['nama_trainer_sesi1']);
		$this->id_trainer_sesi2 = (empty($k['id_trainer_sesi2']) ? NULL : (int)$k['id_trainer_sesi2']);
		$this->trainer_sesi2 = (empty($k['nama_trainer_sesi2']) ? "" : $k['nama_trainer_sesi2']);
		$this->id_proctor_training = (empty($k['id_proctor_training']) ? NULL : (int)$k['id_proctor_training']);
		$this->proctor_training = (empty($k['nama_proctor_training']) ? "" : $k['nama_proctor_training']);

		$this->beritaacara_t_sesi1 = (empty($k['beritaacara_t_sesi1']) ? '' : $k['beritaacara_t_sesi1']);
		$this->beritaacara_t_sesi2 = (empty($k['beritaacara_t_sesi2']) ? '' : $k['beritaacara_t_sesi2']);

		$this->min_peserta_training = (int)$k['min_peserta_training'];
		$this->max_peserta_training = (int)$k['max_peserta_training'];

		$this->jumlah_peserta = (int)$k['jumlah_peserta_kelompok'];
	}

	public function validate_data($create = FALSE): bool
	{
		$errors = [];
		if (!$create && (empty($this->id) ||!is_numeric($this->id)) )
			$errors[] = "ID kelompok tidak boleh kosong.";
		if (!is_string($this->nama_kelompok) || trim($this->nama_kelompok) === '')
			$errors[] = "Nama kelompok tidak boleh kosong.";
		if ($this->id_kegiatan === NULL)
			$errors[] = sprintf(
				"ID kegiatan '%s' tidak boleh kosong.",
				$this->nama_kelompok
			);
		if ($this->id_program_kegiatan === NULL)
			$errors[] = sprintf(
				"ID program '%s' tidak boleh kosong.",
				$this->nama_kelompok
			);
		if (!is_string($this->lokasi_training) || trim($this->lokasi_training) === '')
			$errors[] = sprintf(
				"Lokasi training kelompok '%s' tidak boleh kosong.",
				$this->nama_kelompok
			);
		if(empty($this->mulai_training) || empty($this->selesai_training))
			$errors[] = sprintf(
				"Tanggal training kelompok '%s' tidak valid.",
				$this->nama_kelompok
			);
		if (
			!empty($this->mulai_training) && !empty($this->selesai_training) &&
			$this->mulai_training > $this->selesai_training
		)
			$errors[] = sprintf(
				"Range tanggal training kelompok '%s' tidak valid.",
				$this->nama_kelompok
			);

		if ((int)$this->min_peserta_training > (int)$this->max_peserta_training)
			$errors[] = sprintf(
				"Range daya tampung kelompok '%s' tidak valid.",
				$this->nama_kelompok
			);
		foreach($errors as $e)
		{
			set_warning($e);
		}
		$valid = (count($errors) === 0);
		if ($valid)
		{
			$this->nama_kelompok = trim($this->nama_kelompok);
			$this->lokasi_training = trim($this->lokasi_training);
			$this->min_peserta_training = (int)$this->min_peserta_training;
			$this->max_peserta_training = (int)$this->max_peserta_training;
		}
		return $valid;
	}

	public function load_list_peserta()
	{
		if (empty($this->id)) return;
		if ($this->list_peserta !== NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT 
			pendaftaran.*, 
			pendaftaran.id AS id_pendaftaran, 
			users.id AS id_user,
       		users.file_fotoprofil,
       		users.nama_depan,
			users.nama_belakang,
			users.email, 
			users.nim,
			users.angkatan,
			users.jurusan,
			program_kegiatan.id_program,
			program.nama_program,
			program.min_skor,
			program.max_skor,
			kelompok_t.nama_kelompok AS nama_kelompok_t,
			kelompok_u.nama_kelompok AS nama_kelompok_u
			FROM pendaftaran
			JOIN users ON pendaftaran.id_user = users.id
			JOIN program_kegiatan ON program_kegiatan.id = pendaftaran.id_program_kegiatan
			JOIN program ON program.id = program_kegiatan.id_program
			LEFT JOIN kelompok_t ON kelompok_t.id = pendaftaran.id_kelompok_t
			LEFT JOIN kelompok_u ON kelompok_u.id = pendaftaran.id_kelompok_u
			WHERE pendaftaran.approved='y' AND pendaftaran.id_kelompok_t=?
			ORDER BY pendaftaran.id_program_kegiatan",
			[(int)$this->id]
		)->result_array();
		$this->list_peserta = [];
		load_data_class('Peserta');
		foreach($k as $result)
		{
			$peserta = new D_Peserta();
			$peserta->surface_fill_data_from_db_result($result);
			$this->list_peserta[] = $peserta;
		}
	}

	public function load_kesediaan_trainer()
	{
		if (empty($this->id)) return;
		if ($this->list_kesediaan_trainer !== NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT 
			kesediaan_trainer.*,
			trainer.nama_lengkap,
			kelompok_t.nama_kelompok
			FROM kesediaan_trainer
			JOIN trainer ON trainer.id = kesediaan_trainer.id_trainer
			JOIN kelompok_t ON kelompok_t.id = kesediaan_trainer.id_kelompok_t
			WHERE trainer.aktif = 'y' AND kesediaan_trainer.id_kelompok_t = ?",
			[(int)$this->id]
		)->result_array();
		$this->list_kesediaan_trainer = [];
		load_data_class('Kesediaan');
		foreach($k as $result)
		{
			$kesediaan = new D_Kesediaan_Trainer();
			$kesediaan->id = $result['id'];
			$kesediaan->nama_kelompok = $result['nama_kelompok'];
			$kesediaan->id_kelompok_t = $result['id_kelompok_t'];
			$kesediaan->timestamp = $result['waktu'];
			$kesediaan->id_trainer = $result['id_trainer'];
			$kesediaan->nama_trainer = $result['nama_lengkap'];
			$this->list_kesediaan_trainer[] = $kesediaan;
		}
	}

	public function load_kesediaan_proctor_training()
	{
		if (empty($this->id)) return;
		if ($this->list_kesediaan_proctor_training !== NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT 
			kesediaan_proctor_training.*,
			proctor.nama_lengkap,
			kelompok_t.nama_kelompok
			FROM kesediaan_proctor_training
			JOIN proctor ON proctor.id = kesediaan_proctor_training.id_proctor
			JOIN kelompok_t ON kelompok_t.id = kesediaan_proctor_training.id_kelompok_t
			WHERE proctor.aktif = 'y' AND kesediaan_proctor_training.id_kelompok_t = ?",
			[(int)$this->id]
		)->result_array();
		$this->list_kesediaan_proctor_training = [];
		load_data_class('Kesediaan');
		foreach($k as $result)
		{
			$kesediaan = new D_Kesediaan_Proctor();
			$kesediaan->id = $result['id'];
			$kesediaan->nama_kelompok = $result['nama_kelompok'];
			$kesediaan->id_kelompok = $result['id_kelompok_t'];
			$kesediaan->timestamp = $result['waktu'];
			$kesediaan->id_proctor = $result['id_proctor'];
			$kesediaan->nama_proctor = $result['nama_lengkap'];
			$this->list_kesediaan_proctor_training[] = $kesediaan;
		}
	}

	public function masih_bisa_isi_absensi():bool
	{
		$sekarang = new DateTime();
		$terakhir_absensi = clone $this->selesai_training;
		$jarak_absen_setelah_training = new DateInterval('PT'.$this->jarak_absensi_setelah_training.'H');
		$terakhir_absensi->add($jarak_absen_setelah_training);
		return ($sekarang >= $this->mulai_training && $sekarang <= $terakhir_absensi);
	}
}



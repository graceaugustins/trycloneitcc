<?php defined('BASEPATH') OR exit('No direct script access allowed');

class D_Kesediaan_Trainer{
	var $id = NULL;
	var $timestamp = NULL;
	var $id_trainer = NULL;
	var $nama_trainer = "";
	var $id_kelompok_t = NULL;
	var $nama_kelompok = "";
}

class D_Kesediaan_Proctor{
	var $id = NULL;
	var $timestamp = NULL;
	var $id_proctor = NULL;
	var $nama_proctor = "";
	var $id_kelompok = NULL;
	var $nama_kelompok = "";
}

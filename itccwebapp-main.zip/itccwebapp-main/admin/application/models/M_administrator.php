<?php defined('BASEPATH') or exit('No direct script access allowed');

class M_administrator extends CI_Model {

	/**
	 * @return D_Administrator[]
	 * also fill the role data for each administrator
	 */
	public function get_all_administrator(): array
	{
		$db_results = $this->db->query(
			"SELECT ii.id, ii.email, ii.nama, ii.id_role, r.nama_role 
                FROM itcc_internal ii 
                JOIN roles r ON r.id  = ii.id_role "
		)->result_array();
		$result = [];
		load_data_class('Administrator');
		load_data_class('Role');
		foreach ($db_results as $r) {
			$admin = new D_Administrator();
			$admin->surface_fill_from_db($r);

			$fill_role = [
				'id' => $r['id_role'],
				'nama_role' => $r['nama_role']
			];
			$admin->role = new D_Role();
			$admin->role->surface_fill_from_db($fill_role);

			$result[] = $admin;
		}
		return $result;
	}

	public function does_id_already_exists($id): bool
	{
		if (!is_numeric($id)) return FALSE;
		$jumlah = $this->db->query(
			"SELECT COUNT(1) AS jumlah FROM itcc_internal WHERE id = ?",
			[$id]
		)->row_array();
		$jumlah = $jumlah['jumlah'];
		return (int)$jumlah > 0;
	}

	public function id_use_email($email): ?int
	{
		if (!is_string($email)) return NULL;
		$id = $this->db->query(
			"SELECT id FROM itcc_internal WHERE email = ? LIMIT 1",
			[$email]
		)->row_array();
		if ($id === NULL) return NULL;
		$id = $id['id'];
		return (int)$id;
	}

	public function does_email_already_exists($email): bool
	{
		if (!is_string($email)) return FALSE;
		$jumlah = $this->db->query(
			"SELECT COUNT(1) AS jumlah FROM itcc_internal WHERE email = ?",
			[$email]
		)->row_array();
		$jumlah = $jumlah['jumlah'];
		return (int)$jumlah > 0;
	}

	public function add_new_administrator(D_Administrator $admin): bool
	{
		if (count($admin->last_create_validation_errors) > 0) return FALSE;

		$this->db->trans_start();
		$this->db->query(
			"INSERT INTO itcc_internal (email, nama, id_role) VALUES (?,?,?)",
			[
				$admin->email,
				$admin->nama,
				$admin->id_role
			]
		);
		$admin->id = (int)$this->db->insert_id();
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function update_administrator(D_Administrator $admin): bool
	{
		if (count($admin->last_update_validation_errors) > 0) return FALSE;

		$this->db->trans_start();
		$this->db->query(
			"UPDATE itcc_internal 
            SET nama=?, email=?, id_role=?
			WHERE id = ?",
			[
				(string)$admin->nama,
				(string)$admin->email,
				(int)$admin->id_role,
				(int)$admin->id
			]
		);
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function delete_administrator(D_Administrator $admin): bool
	{
		if (count($admin->last_delete_validation_errors) > 0) return FALSE;
		$this->db->trans_start();
		$this->db->query(
			"DELETE FROM itcc_internal WHERE id = ?",
			[
				(int)$admin->id
			]
		);
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function is_superadmin(string $email): bool
	{
		$email = trim(strtolower($email));

		$query = $this->db->query(
			"SELECT value FROM config WHERE name='superadmin_email'",
			[]
		)->row_array();
		if ($query === NULL) return FALSE;
		$superadmin_email = strtolower(trim($query['value']));
		return ($email === $superadmin_email);
	}

	// ambil data admin dan role
	public function get_detail_admin($email): array
	{
		$email = trim(strtolower($email));
		$query = $this->db->query(
			'SELECT itcc_internal.email, 
			itcc_internal.nama, 
			itcc_internal.id_role,
			roles.nama_role
			FROM itcc_internal
			JOIN roles ON roles.id = itcc_internal.id_role
			WHERE itcc_internal.email=?',
			[$email]
		)->row_array();

		// get daftar capabilities
		$capabilities = $this->db->query(
			'SELECT capabilities.nama
			FROM hak_akses
			JOIN capabilities ON hak_akses.id_capabilities = capabilities.id
			WHERE hak_akses.id_role=?',
			[
				(int)$query['id_role']
			]
		)->result_array();
		$c = [];
		foreach ($capabilities as $cap)
		{
			$c[] = $cap['nama'];
		}

		return [
			'email' => $query['email'],
			'nama_lengkap' => $query['nama'],
			'role' => $query['nama_role'],
			'isSuperAdmin' => FALSE,
			'capabilities' => $c
		];

	}
}

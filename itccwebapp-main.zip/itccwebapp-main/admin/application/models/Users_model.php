<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users_model extends CI_Model {
    /*
     * get data user tipe mahasiswa berdasarkan id
     * */
    public function get_user_mhs($first_id, $last_id, $count, $direction, $filter)
    {
        $base_query = "SELECT id, aktif, nama_depan, nama_belakang, 
                        jenis_kelamin, email, nim, alamat, 
                        no_telepon, id_line, file_ktm, file_fotoprofil,
                        username_certiport, password_certiport
                        FROM users WHERE tipe_user='mahasiswa' ";
        $count_query = "SELECT COUNT(id) AS jumlah FROM users WHERE tipe_user='mahasiswa' ";
        $condition = [];
        $param = [];
        $base_param = [];
        if ($direction === 'next')
        {
            $base_query .= ' AND id > ?';
            $base_param[] = (int)$last_id;
        }
        else
        {
            $base_query .= ' AND id < ?';
            $base_param[] = (int)$first_id;
        }

        if (!empty($filter['angkatan']))
        {
            $condition[] = 'angkatan=?';
            $param[] = (string)$filter['angkatan'];
        }
        if (!empty($filter['jurusan']))
        {
            $in = str_repeat('?,', count($filter['jurusan']) - 1) . '?';
			$condition[] = "jurusan IN ($in)";
			foreach ($filter['jurusan'] as $kode_jurusan)
			{
				$param[] = $kode_jurusan;
			}
        }
        if (!empty($filter['nim']))
        {
            $condition[] = "nim LIKE ?";
            $nim = (string)$filter['nim'];
            $param[] = "$nim%";
        }
        if (!empty($filter['email']))
        {
            $condition[] = "email LIKE ?";
            $param[] = ((string)$filter['email'].'%');
        }
        if (!empty($filter['nama_depan']))
        {
            $condition[] = "nama_depan LIKE ?";
            $param[] = ((string)$filter['nama_depan'].'%');
        }
        if (!empty($filter['nama_belakang']))
        {
            $condition[] = "nama_belakang LIKE ?";
            $param[] = ((string)$filter['nama_belakang'].'%');
        }
        if (!empty($filter['aktif']))
        {
            $condition[] = "aktif =?";
            $param[] = (string)$filter['aktif'];
        }

        foreach($condition as $c)
        {
            $base_query .= (' AND '.$c);
            $count_query .= (' AND '.$c);
        }
        $jumlah = $this->db->query($count_query, $param)->row_array();
        $base_query .= (' ORDER BY id LIMIT '.$count);
        foreach($param as $p)
            $base_param[] = $p;
        $result = $this->db->query($base_query, $base_param)->result_array();
        $first_id = 0;
        $last_id = 0;
        foreach($result as $k_r => $r)
        {
            if ($first_id === 0) $first_id = (int)$r['id'];
            $first_id = min($first_id, (int)$r['id']);
            $last_id = max($last_id, (int)$r['id']);
        }

        return [
            'first_id' => $first_id,
            'last_id' => $last_id,
            'total_count' => $jumlah['jumlah'],
            'data' => $result
        ];
    }

    public function get_user_umum($first_id, $last_id, $count, $direction, $filter)
    {
        $base_query = "SELECT id, aktif, nama_depan, nama_belakang, 
                        jenis_kelamin, email, nik, alamat, 
                        no_telepon, file_ktp, file_fotoprofil,
                        username_certiport, password_certiport
                        FROM users WHERE tipe_user='umum' ";
        $count_query = "SELECT COUNT(id) AS jumlah FROM users WHERE tipe_user='umum' ";
        $condition = [];
        $param = [];
        $base_param = [];
        if ($direction === 'next')
        {
            $base_query .= ' AND id > ?';
            $base_param[] = (int)$last_id;
        }
        else
        {
            $base_query .= ' AND id < ?';
            $base_param[] = (int)$first_id;
        }

        if (!empty($filter['email']))
        {
            $condition[] = "email LIKE ?";
            $param[] = ((string)$filter['email'].'%');
        }
        if (!empty($filter['nama_depan']))
        {
            $condition[] = "nama_depan LIKE ?";
            $param[] = ((string)$filter['nama_depan'].'%');
        }
        if (!empty($filter['nama_belakang']))
        {
            $condition[] = "nama_belakang LIKE ?";
            $param[] = ((string)$filter['nama_belakang'].'%');
        }
        if (!empty($filter['aktif']))
        {
            $condition[] = "aktif =?";
            $param[] = (string)$filter['aktif'];
        }

        foreach($condition as $c)
        {
            $base_query .= (' AND '.$c);
            $count_query .= (' AND '.$c);
        }
        $jumlah = $this->db->query($count_query, $param)->row_array();
        $base_query .= (' ORDER BY id LIMIT '.$count);
        foreach($param as $p)
            $base_param[] = $p;
        $result = $this->db->query($base_query, $base_param)->result_array();
        $first_id = 0;
        $last_id = 0;
        foreach($result as $k_r => $r)
        {
            if ($first_id === 0) $first_id = (int)$r['id'];
            $first_id = min($first_id, (int)$r['id']);
            $last_id = max($last_id, (int)$r['id']);
        }

        return [
            'first_id' => $first_id,
            'last_id' => $last_id,
            'total_count' => $jumlah['jumlah'],
            'data' => $result
        ];
    }

	public function get_user_itpln($first_id, $last_id, $count, $direction, $filter)
	{
		$base_query = "SELECT users.*, jabatan_itpln.nama_jabatan, bidang_itpln.nama_bidang
                        FROM users 
						LEFT JOIN jabatan_itpln ON jabatan_itpln.id = users.id_jabatan
						LEFT JOIN bidang_itpln ON bidang_itpln.id = jabatan_itpln.id_bidang
						WHERE users.tipe_user='itpln' ";
		$count_query = "SELECT COUNT(users.id) AS jumlah FROM users 
    					LEFT JOIN jabatan_itpln ON jabatan_itpln.id = users.id_jabatan
						LEFT JOIN bidang_itpln ON bidang_itpln.id = jabatan_itpln.id_bidang
						WHERE users.tipe_user='itpln' ";
		$condition = [];
		$param = [];
		$base_param = [];
		if ($direction === 'next')
		{
			$base_query .= ' AND users.id > ?';
			$base_param[] = (int)$last_id;
		}
		else
		{
			$base_query .= ' AND users.id < ?';
			$base_param[] = (int)$first_id;
		}

		if (!empty($filter['email']))
		{
			$condition[] = "users.email LIKE ?";
			$param[] = ((string)$filter['email'].'%');
		}
		if (!empty($filter['nama_depan']))
		{
			$condition[] = "users.nama_depan LIKE ?";
			$param[] = ((string)$filter['nama_depan'].'%');
		}
		if (!empty($filter['nama_belakang']))
		{
			$condition[] = "users.nama_belakang LIKE ?";
			$param[] = ((string)$filter['nama_belakang'].'%');
		}
		if (!empty($filter['aktif']))
		{
			$condition[] = "users.aktif =?";
			$param[] = (string)$filter['aktif'];
		}

		if (!empty($filter['id_bidang']))
		{
			$condition[] = "bidang_itpln.id = ? ";
			$param[] = ($filter['id_bidang']);
		}

		if (!empty($filter['id_jabatan']))
		{
			$condition[] = "users.id_jabatan = ? ";
			$param[] = ($filter['id_jabatan']);
		}

		if (!empty($filter['nik']))
		{
			$condition[] = "users.nik LIKE ?";
			$param[] = ((string)$filter['nik'].'%');
		}

		foreach($condition as $c)
		{
			$base_query .= (' AND '.$c);
			$count_query .= (' AND '.$c);
		}
		$jumlah = $this->db->query($count_query, $param)->row_array();
		$base_query .= (' ORDER BY users.id LIMIT '.$count);
		foreach($param as $p)
			$base_param[] = $p;
		$result = $this->db->query($base_query, $base_param)->result_array();
		$first_id = 0;
		$last_id = 0;
		foreach($result as $k_r => $r)
		{
			if ($first_id === 0) $first_id = (int)$r['id'];
			$first_id = min($first_id, (int)$r['id']);
			$last_id = max($last_id, (int)$r['id']);
		}

		return [
			'first_id' => $first_id,
			'last_id' => $last_id,
			'total_count' => $jumlah['jumlah'],
			'data' => $result
		];
	}

    public function get_detail($id)
    {
        $result = $this->db->query(
            "SELECT *
            FROM users WHERE id=?",
            [(int)$id]
        )->row_array();
        if (!empty($result))
        {
            $result['aktif'] = ($result['aktif'] === 'y');
            $result['instansi'] = $this->db->query(
                "SELECT instansi.* 
                FROM instansi_user
                JOIN instansi ON instansi_user.id_instansi = instansi.id
                WHERE instansi_user.id_user=?",
                [(int)$id]
            )->result_array();
        }
        return $result;
    }

    public function update($id, $columns)
    {
        $this->db->trans_start();

        if (isset($columns['aktif']))
            $this->db->query(
                "UPDATE users SET aktif=? WHERE id=?",
                [strtoupper($columns['aktif']), (int)$id]
            );
        if (isset($columns['nama_depan']))
            $this->db->query(
                "UPDATE users SET nama_depan=? WHERE id=?",
                [strtoupper($columns['nama_depan']), (int)$id]
            );
        if (isset($columns['nama_belakang']))
            $this->db->query(
                "UPDATE users SET nama_belakang=? WHERE id=?",
                [strtoupper($columns['nama_belakang']), (int)$id]
            );
        if (isset($columns['jenis_kelamin']))
            $this->db->query(
                "UPDATE users SET jenis_kelamin=? WHERE id=?",
                [(string)$columns['jenis_kelamin'], (int)$id]
            );
        if (isset($columns['email']))
            $this->db->query(
                "UPDATE users SET email=? WHERE id=?",
                [(string)$columns['email'], (int)$id]
            );
        if (isset($columns['user_pass']))
            $this->db->query(
                "UPDATE users SET user_pass=? WHERE id=?",
                [password_hash((string)$columns['user_pass'], PASSWORD_DEFAULT), (int)$id]
            );
        if (isset($columns['nim']))
            $this->db->query(
                "UPDATE users SET nim=? WHERE id=?",
                [(string)$columns['nim'], (int)$id]
            );
        if (isset($columns['angkatan']))
            $this->db->query(
                "UPDATE users SET angkatan=? WHERE id=?",
                [(string)$columns['angkatan'], (int)$id]
            );
        if (isset($columns['jurusan']))
            $this->db->query(
                "UPDATE users SET jurusan=? WHERE id=?",
                [(string)$columns['jurusan'], (int)$id]
            );
        if (isset($columns['nik']))
            $this->db->query(
                "UPDATE users SET nik=? WHERE id=?",
                [(string)$columns['nik'], (int)$id]
            );
        if (isset($columns['file_fotoprofil']))
            $this->db->query(
                "UPDATE users SET file_fotoprofil=? WHERE id=?",
                [(string)$columns['file_fotoprofil'], (int)$id]
            );
        if (isset($columns['file_ktm']))
            $this->db->query(
                "UPDATE users SET file_ktm=? WHERE id=?",
                [(string)$columns['file_ktm'], (int)$id]
            );
        if (isset($columns['file_ktp']))
            $this->db->query(
                "UPDATE users SET file_ktp=? WHERE id=?",
                [(string)$columns['file_ktp'], (int)$id]
            );
        if (isset($columns['alamat']))
            $this->db->query(
                "UPDATE users SET alamat=? WHERE id=?",
                [(string)$columns['alamat'], (int)$id]
            );
        if (isset($columns['no_telepon']))
            $this->db->query(
                "UPDATE users SET no_telepon=? WHERE id=?",
                [(string)$columns['no_telepon'], (int)$id]
            );
        if (isset($columns['id_line']))
            $this->db->query(
                "UPDATE users SET id_line=? WHERE id=?",
                [(string)$columns['id_line'], (int)$id]
            );
        if (isset($columns['username_certiport']))
            $this->db->query(
                "UPDATE users SET username_certiport=? WHERE id=?",
                [(string)$columns['username_certiport'], (int)$id]
            );
        if (isset($columns['password_certiport']))
            $this->db->query(
                "UPDATE users SET password_certiport=? WHERE id=?",
                [(string)$columns['password_certiport'], (int)$id]
            );
        $this->db->trans_complete();
        return $this->db->trans_status();
    }

    public function get_bulk_registration()
    {
        return $this->db->query(
            "SELECT nama_belakang, nama_depan, email, id 
            FROM users 
            WHERE (username_certiport IS NULL OR username_certiport='') AND
                  (password_certiport IS NULL OR password_certiport='') ORDER BY id LIMIT 1000"
        )->result_array();
    }

    public function tambah_instansi($nama, $no_telepon, $alamat)
    {
        $id = FALSE;
        $this->db->trans_start();
        $this->db->query(
            'INSERT INTO instansi (nama, no_telepon, alamat) VALUES (?,?,?)',
            [(string)$nama, (string)$no_telepon, (string)$alamat]
        );
        $id = (int)$this->db->insert_id();
        $this->db->trans_complete();
        if ($this->db->trans_status() === TRUE)
            return $id;
        else return FALSE;
    }

    public function get_instansi($id = NULL)
    {
        if (!empty($id))
        {
            $instansi_selected = [];
            $instansi = $this->db->query(
                "SELECT * FROM instansi WHERE id=?",
                [(int)$id]
            )->row_array();
            if (empty($instansi)) return $instansi;
            $instansi_selected['instansi'] = $instansi;
            $instansi_selected['users'] = $this->db->query(
                "SELECT users.*, instansi_user.id AS id_instansi_user
                FROM instansi_user
                JOIN users ON instansi_user.id_user = users.id
                WHERE instansi_user.id_instansi=?",
                [(int)$id]
            )->result_array();
            return $instansi_selected;
        }
        return $this->db->query(
            "SELECT * FROM instansi"
        )->result_array();
    }

    public function update_instansi($id, $columns)
    {
        $this->db->trans_start();
        if (isset($columns['nama']))
            $this->db->query(
                "UPDATE instansi SET nama=? WHERE id=?",
                [$columns['nama'], (int)$id]
            );
        if (isset($columns['alamat']))
            $this->db->query(
                "UPDATE instansi SET alamat=? WHERE id=?",
                [$columns['alamat'], (int)$id]
            );
        if (isset($columns['no_telepon']))
            $this->db->query(
                "UPDATE instansi SET no_telepon=? WHERE id=?",
                [$columns['no_telepon'], (int)$id]
            );
        if (isset($columns['users']))
        {
            $old_id_user = $this->db->query(
                "SELECT id_user FROM instansi_user WHERE id_instansi=?",
                [(int)$id]
            )->result_array();
            $new_id_user = $columns['users'];
            // cek apakah new_id ada di old_id
            foreach($new_id_user as $new_id)
            {
                $exists_in_old = FALSE;
                foreach($old_id_user as $old_id)
                {
                    if ((int)$new_id === (int)$old_id['id_user'])
                        $exists_in_old = TRUE;
                }
                if (!$exists_in_old)
                    $this->db->query(
                        "INSERT INTO instansi_user(id_user, id_instansi) VALUES (?,?)",
                        [(int)$new_id, (int)$id]
                    );
            }
            // cek apakah old_id masih ada di new_id
            foreach($old_id_user as $old_id)
            {
                $exists_in_new = FALSE;
                foreach($new_id_user as $new_id)
                {
                    if ((int)$old_id['id_user'] === (int)$new_id)
                        $exists_in_new = TRUE;
                }
                if (!$exists_in_new)
                    $this->db->query(
                        "DELETE FROM instansi_user WHERE id=?",
                        [(int)$old_id['id']]
                    );
            }
        }
        if (isset($columns['add_user']))
        {
            $id_user = $columns['add_user'];
            $exists = $this->db->query(
                "SELECT COUNT(1) AS jumlah FROM instansi_user WHERE id_user=? AND id_instansi=?",
                [(int)$id_user, (int)$id]
            )->row_array();
            if ((int)$exists['jumlah'] === 0)
            {
                $this->db->query(
                    "INSERT INTO instansi_user (id_user, id_instansi) VALUES (?,?)",
                    [(int)$id_user, (int)$id]
                );
            }
        }
        if (isset($columns['deleted_user']))
            $this->db->query(
                "DELETE FROM instansi_user WHERE id=?",
                [(int)$columns['deleted_user']]
            );
        $this->db->trans_complete();
        return $this->db->trans_status();
    }

	public function hapus_instansi($id)
	{
		$this->db->trans_start();
		$this->db->query(
			"DELETE FROM instansi WHERE id=?",
			[(int)$id]
		);
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function send_info($id_user, $info)
	{
		$this->db->trans_start();
		$this->db->query(
			"INSERT INTO info_user (id_user, info) VALUES (?,?)",
			[(string)$id_user, (string)$info]
		);
		$this->db->trans_complete();
		return $this->db->trans_status();
    }
}

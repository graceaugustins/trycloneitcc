<?php defined('BASEPATH') OR exit('No direct script access allowed');
class M_proctor extends CI_Model{

	/**
	 * @return D_Proctor[]
	 * */
	public function get_list_proctor_aktif(): array
	{
		load_data_class('Proctor');
		$list_data_proctor = $this->db->query(
			"SELECT * FROM proctor WHERE aktif='y'"
		)->result_array();
		$list_proctor = [];
		foreach ($list_data_proctor as $data)
		{
			$t = new D_Proctor();
			$t->id = $data['id'];
			$t->email = $data['email'];
			$t->nama_lengkap = $data['nama_lengkap'];
			$t->no_telepon = $data['no_telepon'];
			$t->file_foto = $data['file_foto'];
			$t->aktif = TRUE;
			$list_proctor[] = $t;
		}
		return $list_proctor;
	}

	/**
	 * @return D_Proctor[]
	 * */
	public function get_list_proctor_nonaktif(): array
	{
		load_data_class('Proctor');
		$list_data_proctor = $this->db->query(
			"SELECT * FROM proctor WHERE aktif='n'"
		)->result_array();
		$list_proctor = [];
		foreach ($list_data_proctor as $data)
		{
			$t = new D_Proctor();
			$t->id = $data['id'];
			$t->email = $data['email'];
			$t->nama_lengkap = $data['nama_lengkap'];
			$t->no_telepon = $data['no_telepon'];
			$t->file_foto = $data['file_foto'];
			$t->aktif = TRUE;
			$list_proctor[] = $t;
		}
		return $list_proctor;
	}

	public function does_email_already_exists($email) : bool
	{
		$jumlah = $this->db->query(
			"SELECT COUNT(1) AS jumlah FROM proctor WHERE email=?",
			[$email]
		)->row_array();
		$jumlah = $jumlah['jumlah'];
		return (int)$jumlah>0;
	}

	public function get_id_use_email($email): ?int
	{
		if (!is_string($email)) return NULL;
		$id = $this->db->query(
			"SELECT id FROM proctor WHERE email = ? LIMIT 1",
			[$email]
		)->row_array();
		if ($id === NULL) return NULL;
		$id = $id['id'];
		return (int)$id;
	}

	public function does_id_already_exists($id): bool
	{
		$jumlah = $this->db->query(
			"SELECT COUNT(1) AS jumlah FROM proctor WHERE id=?",
			[$id]
		)->row_array();
		$jumlah = $jumlah['jumlah'];
		return (int)$jumlah>0;
	}

	public function add_new_proctor(D_Proctor $proctor): bool
	{
		if (count($proctor->last_create_validation_errors) > 0) return FALSE;

		$this->db->trans_start();
		$this->db->query(
			"INSERT INTO proctor (email, nama_lengkap, no_telepon, file_foto, aktif) VALUES (?,?,?,?,?)",
			[
				(string)$proctor->email,
				(string)$proctor->nama_lengkap,
				(string)$proctor->no_telepon,
				(string)$proctor->file_foto,
				($proctor->aktif) ? 'y' : 'n',
			]
		);
		$proctor->id = (int)$this->db->insert_id();
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function update_proctor(D_Proctor $proctor, $id_sertifikasi = [], $update_sertifikasi = TRUE): bool
	{
		if (count($proctor->last_update_validation_errors) > 0) return FALSE;
		$this->db->trans_start();
		$this->db->query(
			"UPDATE proctor 
			SET email = ?, 
			    nama_lengkap = ?, 
			    no_telepon = ?, 
			    file_foto = ?, 
			    aktif = ?
			WHERE id = ?",
			[
				(string)$proctor->email,
				(string)$proctor->nama_lengkap,
				(string)$proctor->no_telepon,
				(string)$proctor->file_foto,
				($proctor->aktif) ? 'y' : 'n',
				$proctor->id
			]
		);
		if ($update_sertifikasi)
		{
			$this->db->query(
				"DELETE FROM sertifikasi_proctor
				WHERE id_proctor = ?",
				[
					$proctor->id
				]
			);
			foreach($id_sertifikasi as $id)
			{
				$this->db->query(
					"INSERT INTO sertifikasi_proctor (id_proctor, id_sertifikasi) VALUES (?,?)",
					[
						$proctor->id,
						$id
					]
				);
			}
		}
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function delete_proctor(D_Proctor $proctor): bool
	{
		if (count($proctor->last_delete_validation_errors) > 0) return FALSE;
		$this->db->trans_start();
		$this->db->query(
			"DELETE FROM proctor WHERE id = ?",
			[
				(int)$proctor->id
			]
		);
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function update_kesediaan_proctor_training(D_Proctor $proctor, array $list_id_kelompok): bool
	{
		if (!is_array($list_id_kelompok)) return FALSE;
		foreach($list_id_kelompok as $k => $v)
			$list_id_kelompok[$k] = (int)$v;

		$this->db->trans_start();
		$old_kesediaan = $this->db->query(
			"SELECT id, id_kelompok_t FROM kesediaan_proctor_training WHERE id_proctor=?",
			[$proctor->id]
		)->result_array();
		$old_id = [];
		foreach($old_kesediaan as $k => $c)
			$old_id[$k] = (int)$c['id_kelompok_t'];
		foreach($old_id as $k => $id)
		{
			// not exists in new
			if (!in_array($id, $list_id_kelompok))
			{
				$this->db->query(
					"DELETE FROM kesediaan_proctor_training WHERE id=?",
					[$old_kesediaan[$k]['id']]
				);
			}
		}
		foreach($list_id_kelompok as $id)
		{
			// not exists in old
			if (!in_array($id, $old_id))
			{
				$this->db->query(
					"INSERT INTO kesediaan_proctor_training (id_proctor, id_kelompok_t) VALUES (?,?)",
					[$proctor->id, (int)$id]
				);
			}
		}
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function update_kesediaan_proctor_ujian(D_Proctor $proctor, array $list_id_kelompok): bool
	{
		if (!is_array($list_id_kelompok)) return FALSE;
		foreach($list_id_kelompok as $k => $v)
			$list_id_kelompok[$k] = (int)$v;

		$this->db->trans_start();
		$old_kesediaan = $this->db->query(
			"SELECT id, id_kelompok_u FROM kesediaan_proctor_ujian WHERE id_proctor=?",
			[$proctor->id]
		)->result_array();
		$old_id = [];
		foreach($old_kesediaan as $k => $c)
			$old_id[$k] = (int)$c['id_kelompok_u'];
		foreach($old_id as $k => $id)
		{
			// not exists in new
			if (!in_array($id, $list_id_kelompok))
			{
				$this->db->query(
					"DELETE FROM kesediaan_proctor_ujian WHERE id=?",
					[$old_kesediaan[$k]['id']]
				);
			}
		}
		foreach($list_id_kelompok as $id)
		{
			// not exists in old
			if (!in_array($id, $old_id))
			{
				$this->db->query(
					"INSERT INTO kesediaan_proctor_ujian (id_proctor, id_kelompok_u) VALUES (?,?)",
					[$proctor->id, (int)$id]
				);
			}
		}
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	/**
	 * @return D_Kegiatan[]
	 * */
	public function get_list_kegiatan_history_proctor(D_Proctor $proctor): array
	{
		$list = $this->db->query(
			"SELECT 
				kegiatan.*, 
				COUNT(kelompok_t.id) AS jumlah_sebagai_proctor_training,
				COUNT(kelompok_u.id) AS jumlah_sebagai_proctor_ujian
			FROM kegiatan
			LEFT JOIN kelompok_t ON kelompok_t.id_kegiatan = kegiatan.id AND kelompok_t.id_proctor_training = ?
			LEFT JOIN kelompok_u ON kelompok_u.id_kegiatan = kegiatan.id AND kelompok_u.id_proctor_ujian = ?
			GROUP BY kegiatan.id, kelompok_t.id_kegiatan, kelompok_u.id_kegiatan, kegiatan.akhir_pelaporan
			HAVING jumlah_sebagai_proctor_training > 0 OR jumlah_sebagai_proctor_ujian > 0
			ORDER BY kegiatan.akhir_pelaporan DESC",
			[$proctor->id, $proctor->id]
		)->result_array();
		$result = [];
		load_data_class('Kegiatan');
		foreach ($list as $k)
		{
			$kegiatan = new D_Kegiatan();
			$kegiatan->surface_fill_data_from_db_result($k);
			$result[] = $kegiatan;
		}
		return $result;
	}

	public function get_jumlah_peserta_proctor_training_kegiatan(D_Kegiatan $keg, D_Proctor $proctor): int
	{
		$list = $this->db->query(
			"SELECT COUNT(1) AS jumlah
			FROM pendaftaran
			JOIN kelompok_t ON pendaftaran.id_kegiatan = ? AND 
			                   pendaftaran.id_kelompok_t = kelompok_t.id AND 
							   kelompok_t.id_proctor_training = ?",
			[$keg->id, $proctor->id]
		)->row_array();
		$list = $list['jumlah'];
		return (int)$list;
	}

	public function get_jumlah_peserta_proctor_training_kegiatan_lulus(D_Kegiatan $keg, D_Proctor $proctor): int
	{
		$list = $this->db->query(
			"SELECT COUNT(1) AS jumlah
			FROM pendaftaran
			JOIN program_kegiatan ON pendaftaran.id_program_kegiatan = program_kegiatan.id
			JOIN program ON program.id = program_kegiatan.id_program
			JOIN kelompok_t ON pendaftaran.id_kegiatan = ? AND 
			                   pendaftaran.id_kelompok_t = kelompok_t.id AND 
							   kelompok_t.id_proctor_training = ? AND 
							   pendaftaran.skor_ujian BETWEEN program.min_skor AND program.max_skor",
			[$keg->id, $proctor->id]
		)->row_array();
		$list = $list['jumlah'];
		return (int)$list;
	}

	public function get_jumlah_peserta_proctor_training_kegiatan_tidak_lulus(D_Kegiatan $keg, D_Proctor $proctor): int
	{
		$list = $this->db->query(
			"SELECT COUNT(1) AS jumlah
			FROM pendaftaran
			JOIN program_kegiatan ON pendaftaran.id_program_kegiatan = program_kegiatan.id
			JOIN program ON program.id = program_kegiatan.id_program
			JOIN kelompok_t ON pendaftaran.id_kegiatan = ? AND 
			                   pendaftaran.id_kelompok_t = kelompok_t.id AND 
							   kelompok_t.id_proctor_training = ? AND 
							   pendaftaran.skor_ujian BETWEEN 0 AND program.min_skor",
			[$keg->id, $proctor->id]
		)->row_array();
		$list = $list['jumlah'];
		return (int)$list;
	}

	public function get_jumlah_peserta_proctor_training_kegiatan_pending(D_Kegiatan $keg, D_Proctor $proctor): int
	{
		$list = $this->db->query(
			"SELECT COUNT(1) AS jumlah
			FROM pendaftaran
			JOIN program_kegiatan ON pendaftaran.id_program_kegiatan = program_kegiatan.id
			JOIN program ON program.id = program_kegiatan.id_program
			JOIN kelompok_t ON pendaftaran.id_kegiatan = ? AND 
			                   pendaftaran.id_kelompok_t = kelompok_t.id AND 
							   kelompok_t.id_proctor_training = ? AND 
							   pendaftaran.skor_ujian = -1",
			[$keg->id, $proctor->id]
		)->row_array();
		$list = $list['jumlah'];
		return (int)$list;
	}

	public function get_jumlah_peserta_proctor_ujian_kegiatan(D_Kegiatan $keg, D_Proctor $proctor): int
	{
		$list = $this->db->query(
			"SELECT COUNT(1) AS jumlah
			FROM pendaftaran
			JOIN kelompok_u ON pendaftaran.id_kegiatan = ? AND 
			                   pendaftaran.id_kelompok_u = kelompok_u.id AND 
							   kelompok_u.id_proctor_ujian = ?",
			[$keg->id, $proctor->id]
		)->row_array();
		$list = $list['jumlah'];
		return (int)$list;
	}

	public function get_jumlah_peserta_proctor_ujian_kegiatan_lulus(D_Kegiatan $keg, D_Proctor $proctor): int
	{
		$list = $this->db->query(
			"SELECT COUNT(1) AS jumlah
			FROM pendaftaran
			JOIN program_kegiatan ON pendaftaran.id_program_kegiatan = program_kegiatan.id
			JOIN program ON program.id = program_kegiatan.id_program
			JOIN kelompok_u ON pendaftaran.id_kegiatan = ? AND 
			                   pendaftaran.id_kelompok_u = kelompok_u.id AND 
							   kelompok_u.id_proctor_ujian = ? AND 
							   pendaftaran.skor_ujian BETWEEN program.min_skor AND program.max_skor",
			[$keg->id, $proctor->id]
		)->row_array();
		$list = $list['jumlah'];
		return (int)$list;
	}

	public function get_jumlah_peserta_proctor_ujian_kegiatan_tidak_lulus(D_Kegiatan $keg, D_Proctor $proctor): int
	{
		$list = $this->db->query(
			"SELECT COUNT(1) AS jumlah
			FROM pendaftaran
			JOIN program_kegiatan ON pendaftaran.id_program_kegiatan = program_kegiatan.id
			JOIN program ON program.id = program_kegiatan.id_program
			JOIN kelompok_u ON pendaftaran.id_kegiatan = ? AND 
			                   pendaftaran.id_kelompok_u = kelompok_u.id AND 
							   kelompok_u.id_proctor_ujian = ? AND 
							   pendaftaran.skor_ujian BETWEEN 0 AND program.min_skor",
			[$keg->id, $proctor->id]
		)->row_array();
		$list = $list['jumlah'];
		return (int)$list;
	}

	public function get_jumlah_peserta_proctor_ujian_kegiatan_pending(D_Kegiatan $keg, D_Proctor $proctor): int
	{
		$list = $this->db->query(
			"SELECT COUNT(1) AS jumlah
			FROM pendaftaran
			JOIN program_kegiatan ON pendaftaran.id_program_kegiatan = program_kegiatan.id
			JOIN program ON program.id = program_kegiatan.id_program
			JOIN kelompok_u ON pendaftaran.id_kegiatan = ? AND 
			                   pendaftaran.id_kelompok_u = kelompok_u.id AND 
							   kelompok_u.id_proctor_ujian = ? AND 
							   pendaftaran.skor_ujian = -1",
			[$keg->id, $proctor->id]
		)->row_array();
		$list = $list['jumlah'];
		return (int)$list;
	}
}

<?php defined('BASEPATH') OR exit('No direct script access allowed');
class M_program extends CI_Model{

	public function is_program_exists($id_program): bool
	{
		$jumlah = $this->db->query(
			"SELECT COUNT(1) AS jumlah FROM program WHERE id=?",
			[$id_program]
		)->row_array();
		$jumlah = $jumlah['jumlah'];
		return (int)$jumlah>0;
	}

	public function add_new_program(D_Program $program): bool
	{
		if (!empty($program->id) || empty($program->id_sertif)) return FALSE;
		if (!$program->validate_data(true)) return FALSE;

		$this->db->trans_start();
		$this->db->query(
			"INSERT INTO program (id_sertif, nama_program, link_assesment, file_modul, min_skor, max_skor, file_logo) VALUES (?,?,?,?,?,?,?)",
			[
				$program->id_sertif,
				$program->nama_program,
				$program->link_assesment,
				$program->file_modul,
				$program->min_skor,
				$program->max_skor,
				$program->file_logo
			]
		);
		$program->id = (int)$this->db->insert_id();
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function update_program(D_Program $program)
	{
		if (empty($program->id) || empty($program->id_sertif)) return FALSE;
		if (!$program->validate_data()) return FALSE;

		$this->db->trans_start();
		$this->db->query(
			"UPDATE program 
			SET id_sertif = ?,
			    nama_program = ?,
			    link_assesment = ?,
			    file_modul = ?, 
			    min_skor = ?, 
			    max_skor = ?, 
			    file_logo = ?
			    WHERE id = ?",
			[
				$program->id_sertif,
				$program->nama_program,
				$program->link_assesment,
				$program->file_modul,
				$program->min_skor,
				$program->max_skor,
				$program->file_logo,
				$program->id
			]
		);
		$program->id = (int)$this->db->insert_id();
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function delete_program(D_Program $program)
	{
		if (empty($program->id)) return FALSE;
		if ($program->pernah_diadakan_kegiatan()) return FALSE;
		$this->db->trans_start();
		$this->db->query(
			"DELETE FROM program WHERE id = ?",
			[
				$program->id
			]
		);
		$this->db->trans_complete();
		return $this->db->trans_status();
	}
}

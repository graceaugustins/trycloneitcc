<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * load class that is used to contain data
 * @param $file string do not use the prefix 'D_'. ex: load D_Kelompok_T = 'Kelompok_T'
 * */
function load_data_class($file)
{
	require_once(APPPATH.'models'.DIRECTORY_SEPARATOR.'data'.DIRECTORY_SEPARATOR.'D_'.$file.'.php');
}

/*
 * warning alert
 * */
function set_warning($warning)
{
    $_SESSION['warning'][] = (string)$warning;
}

function get_warning()
{
    if (!isset($_SESSION['warning'])) $_SESSION['warning'] = [];
    return $_SESSION['warning'];
}

function clear_warning()
{
    $_SESSION['warning'] = [];
}

/**
 * Validasi Date dan DateTime berdasarkan
 * format
 */
function valid_date_time($date, string $format): bool
{
    if (!is_string($date)) return FALSE;
    $d = DateTime::createFromFormat($format, $date);
    return !empty($d);
}

function valid_json_str($json): bool
{
    if (!is_string($json)) return FALSE;
    // decode the JSON data
    $result = json_decode($json);
    if (json_last_error() === JSON_ERROR_NONE)
        return TRUE;
    return FALSE;
}

function tgl_indo(string $tanggal, string $format, $singkat = FALSE): string
{
    $dt = DateTime::createFromFormat($format, $tanggal);
    $new_dt = $dt->format('Y-m-d');
    $bulan = array (
        1 =>   'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember'
    );

    $pecahkan = explode('-', $new_dt);
    // variabel pecahkan 0 = tanggal
    // variabel pecahkan 1 = bulan
    // variabel pecahkan 2 = tahun
    if ($singkat) return $pecahkan[2] . ' ' . substr($bulan[ (int)$pecahkan[1] ], 0,3) . ' ' . $pecahkan[0];
    return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
}

function format_rupiah(string $angka): string
{
    if (!is_numeric($angka)) return "";
    return "Rp " . number_format($angka,2,',','.');
}

function simple_random_string(int $length, $charset = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"): string
{
	$random = "";
	for ($i = 1; $i<=$length;$i++)
	{
		$random .= $charset[mt_rand(0,strlen($charset)-1)];
	}
	return $random;
}

/*
 * Class berisi constants tipe user
 * */
class General_Constants {
	// dibuka untuk
	const MAHASISWA = 'mahasiswa';
	const UMUM = 'umum';
	const ITPLN = 'itpln';

	// jenis kelamin
	const LAKI_LAKI = 'l';
	const PEREMPUAN = 'p';

	// jenis pendaftaran
	const TRAINING_DAN_UJIAN = 't_u';
	const UJIAN_SAJA = 'u';

	// status kelulusan
	const STATUS_PENDING = "pending";
	const STATUS_LULUS = "lulus";
	const STATUS_TIDAK_LULUS = "tidak_lulus";

	// status pembayaran
	const PEMBAYARAN_PENDING = 'pending';
	const PEMBAYARAN_REJECTED = 'reject';
	const PEMBAYARAN_ACCEPTED = 'accept';

    // mode manipulasi data
    const MODE_OPERATION_CREATE = 1;
    const MODE_OPERATION_UPDATE = 2;
    const MODE_OPERATION_DELETE = 3;
}

class Permissions{
	const LIHAT_KEGIATAN_SERTIFIKASI 	= 'lihat_kegiatan_sertifikasi';
	const TAMBAH_KEGIATAN_SERTIFIKASI 	= 'tambah_kegiatan_sertifikasi';
	const EDIT_KEGIATAN_SERTIFIKASI 	= 'edit_kegiatan_sertifikasi';
	const HAPUS_KEGIATAN_SERTIFIKASI 	= 'hapus_kegiatan_sertifikasi';

	const LIHAT_KEUANGAN_KEGIATAN_SERTIFIKASI 	= 'lihat_keuangan_kegiatan_sertifikasi';
	const EDIT_KEUANGAN_KEGIATAN_SERTIFIKASI 	= 'edit_keuangan_kegiatan_sertifikasi';

	const LIHAT_LIST_SERTIFIKASI 	= 'lihat_list_sertifikasi';
	const TAMBAH_LIST_SERTIFIKASI 	= 'tambah_list_sertifikasi';
	const EDIT_LIST_SERTIFIKASI 	= 'edit_list_sertifikasi';
	const HAPUS_LIST_SERTIFIKASI 	= 'hapus_list_sertifikasi';

	const LIHAT_HISTORY_SERTIFIKASI = 'lihat_history_sertifikasi';

	const LIHAT_LIST_TRAINER 	= 'lihat_list_trainer';
	const TAMBAH_LIST_TRAINER 	= 'tambah_list_trainer';
	const EDIT_LIST_TRAINER 	= 'edit_list_trainer';
	const HAPUS_LIST_TRAINER 	= 'hapus_list_trainer';

	const LIHAT_LIST_PROCTOR 	= 'lihat_list_proctor';
	const TAMBAH_LIST_PROCTOR 	= 'tambah_list_proctor';
	const EDIT_LIST_PROCTOR 	= 'edit_list_proctor';
	const HAPUS_LIST_PROCTOR 	= 'hapus_list_proctor';

	const LIHAT_LIST_USER 		= 'lihat_list_user';
	const TAMBAH_LIST_USER 		= 'tambah_list_user';
	const EDIT_LIST_USER 		= 'edit_list_user';
	const HAPUS_LIST_USER 		= 'hapus_list_user';

	const LIHAT_LIST_BIDANG_JABATAN 	= 'lihat_list_bidang_jabatan';
	const TAMBAH_LIST_BIDANG_JABATAN 	= 'tambah_list_bidang_jabatan';
	const EDIT_LIST_BIDANG_JABATAN 		= 'edit_list_bidang_jabatan';
	const HAPUS_LIST_BIDANG_JABATAN 	= 'hapus_list_bidang_jabatan';

	const LIHAT_LIST_INSTANSI 	= 'lihat_list_instansi';
	const TAMBAH_LIST_INSTANSI 	= 'tambah_list_instansi';
	const EDIT_LIST_INSTANSI 	= 'edit_list_instansi';
	const HAPUS_LIST_INSTANSI 	= 'hapus_list_instansi';

	const LIHAT_LIST_ADMINISTRATOR 		= 'lihat_list_administrator';
	const TAMBAH_LIST_ADMINISTRATOR 	= 'tambah_list_administrator';
	const EDIT_LIST_ADMINISTRATOR 		= 'edit_list_administrator';
	const HAPUS_LIST_ADMINISTRATOR 		= 'hapus_list_administrator';

	const LIHAT_LIST_HAK_AKSES 		= 'lihat_list_hak_akses';
	const TAMBAH_LIST_HAK_AKSES 	= 'tambah_list_hak_akses';
	const EDIT_LIST_HAK_AKSES 		= 'edit_list_hak_akses';
	const HAPUS_LIST_HAK_AKSES 		= 'hapus_list_hak_akses';

	const LIHAT_HISTORY_SISTEM 	= 'lihat_history_sistem';
	const EDIT_KONFIGURASI_SISTEM 	= 'edit_konfigurasi_sistem';
}


<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// kumpulan helper khusus admin
// bisa dipakai di semua tempat

// cek apakah admin punya capability yang dimaksud
// return bool TRUE (punya), FALSE (tidak punya)
function admin_capable($capability)
{
	if ($capability === "" || $capability == NULL)
		return FALSE;
	$capability = trim(strtolower($capability));

	// Kalau bukan admin
	if (!isset($_SESSION['admin'])) return FALSE;

	// kalau superadmin pasti TRUE
	if ($_SESSION['admin']['isSuperAdmin']) return TRUE;

	$has = FALSE;
	foreach ($_SESSION['admin']['capabilities'] as $cap)
	{
		if ($capability === trim(strtolower($cap))) $has = TRUE;
	}
	return $has;
}
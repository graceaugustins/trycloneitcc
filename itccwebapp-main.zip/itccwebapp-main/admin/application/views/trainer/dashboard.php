<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> Dashboard Trainer <?php } ?>
<?php function yield_page_header($_this, $data){?>
	<div class="col-md-7 align-self-center">
		<h3 class="page-title text-truncate text-dark font-weight-medium mb-1">Kegiatan sertifikasi yang akan diselenggarakan ITCC</h3>
		<p>*Sesuai program sertifikasi Anda, dan belum masuk periode pelaksanaan</p>
	</div>
	<div class="col-md-5 align-self-center"></div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
<?php
/** @var D_Kegiatan[] $list_kegiatan_akan_dilaksanakan */
$list_kegiatan_akan_dilaksanakan = $data['list_kegiatan_akan_dilaksanakan'];
/** @var D_Kegiatan[] $list_kegiatan_akan_dilaksanakan */
$list_kegiatan_sedang_dilaksanakan = $data['list_kegiatan_sedang_dilaksanakan'];
?>
<div class="col-12">
	<strong>Akan Dilaksanakan</strong>
</div>
<div class="col-12">
	<?php if (count($list_kegiatan_akan_dilaksanakan) === 0) { ?>
		<small class="text-center d-block">- <i>Kosong</i> - </small>
	<?php } else foreach($list_kegiatan_akan_dilaksanakan as $keg) { ?>
		<div class="card">
			<div class="card-body">
				<div class="row g-2 align-items-center">
					<div class="col-md-5">
						<div class="row align-items-center">
							<div class="col-auto">
								<img class="logo" src="<?php echo $keg->sertifikasi->get_link_logo();?>" width="50" alt="logo">
							</div>
							<div class="col">
								<h4 class="card-title m-0 nama-kegiatan">
									<?php echo html_escape($keg->nama_kegiatan); ?>
								</h4>
								<div class="text-muted mt-1 nama-sertifikasi">
									<?php echo html_escape($keg->sertifikasi->nama); ?>
								</div>
								<div class="mt-1">
									<small>
										Jumlah kelompok:
										<strong><?php echo count($keg->list_kelompok_training); ?> (T)</strong>,
										<strong><?php echo count($keg->list_kelompok_ujian); ?> (U)</strong>
									</small>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-5 my-md-0 my-sm-2 my-xs-2">
						<div class="ml-2">
							<span style="width:20px;display: inline-block;" class="font-weight-bolder">R</span>
							<span class="registrasi">
								<?php if (!empty($keg->awal_registrasi) && !empty($keg->akhir_registrasi)) { ?>
									<?php echo tgl_indo($keg->awal_registrasi->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE); ?>
									s/d
									<?php echo tgl_indo($keg->akhir_registrasi->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE); ?>
								<?php } else { ?>
									Tidak ada
								<?php } ?>
							</span>
						</div>
						<div class="ml-2">
							<span style="width:20px;display: inline-block;" class="font-weight-bolder">T</span>
							<span class="training">
								<?php
								$max_date = DateTime::createFromFormat('Y-m-d', '2099-12-31');
								$min_date = DateTime::createFromFormat('Y-m-d', '1980-01-01');
								$awal_training = DateTime::createFromFormat('Y-m-d', '2099-12-31');
								$akhir_training = DateTime::createFromFormat('Y-m-d', '1980-01-01');
								foreach($keg->list_kelompok_training as $kelompok_t)
								{
									if (!empty($kelompok_t->mulai_training))
										$awal_training = min($awal_training, $kelompok_t->mulai_training);
									if (!empty($kelompok_t->selesai_training))
										$akhir_training = max($akhir_training, $kelompok_t->selesai_training);
								}
								if ($awal_training == $max_date || $akhir_training == $min_date)
									echo "- (Belum dapat ditentukan)";
								else
								{
									echo tgl_indo($awal_training->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
									echo " s/d ";
									echo tgl_indo($akhir_training->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
								}
								?>
							</span>
						</div>
						<div class="ml-2">
							<span style="width:20px;display: inline-block;" class="font-weight-bolder">U</span>
							<span class="ujian">
								<?php
								$max_date = DateTime::createFromFormat('Y-m-d', '2099-12-31');
								$min_date = DateTime::createFromFormat('Y-m-d', '1980-01-01');
								$awal_ujian = DateTime::createFromFormat('Y-m-d', '2099-12-31');
								$akhir_ujian = DateTime::createFromFormat('Y-m-d', '1980-01-01');
								foreach($keg->list_kelompok_ujian as $kelompok_u)
								{
									if (!empty($kelompok_u->mulai_ujian))
										$awal_ujian = min($awal_ujian, $kelompok_u->mulai_ujian);
									if (!empty($kelompok_u->selesai_ujian))
										$akhir_ujian = max($akhir_ujian, $kelompok_u->selesai_ujian);
								}
								if ($awal_ujian == $max_date || $akhir_ujian == $min_date)
									echo "- (Belum dapat ditentukan)";
								else
								{
									echo tgl_indo($awal_ujian->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
									echo " s/d ";
									echo tgl_indo($akhir_ujian->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
								}
								?>
							</span>
						</div>
					</div>
					<div class=" col-md-2">
						<span class="d-none programs">
							<?php foreach ($keg->program_kegiatan as $p) { ?>
								<span class="program">
								<span class="id"><?php echo $p->id_program; ?></span>
								<span class="nama-program"><?php echo $p->nama_program; ?></span>
								<span class="file-logo"><?php echo $p->get_link_logo(); ?></span>
							</span>
							<?php } ?>
						</span>
						<a href="#" role="button" class="d-block btn btn-light mb-2" data-toggle="modal" data-target="#info" style="white-space: normal;">
							Info Sertifikasi
						</a>
						<a href="<?php echo base_url('trainer/kesediaan/'.$keg->id); ?>" role="button" class="d-block btn btn-info link-kesediaan" style="white-space: normal;">
							Kesediaan Training
						</a>
					</div>
				</div>
			</div>
		</div>
	<?php } ?>
</div>
<div class="col-12">
	<strong>Sedang Dilaksanakan</strong>
</div>
<div class="col-12">
	<?php if (count($list_kegiatan_sedang_dilaksanakan) === 0) { ?>
		<small class="text-center d-block">- <i>Kosong</i> - </small>
	<?php } else foreach($list_kegiatan_sedang_dilaksanakan as $keg) { ?>
		<div class="card">
			<div class="card-body">
				<div class="row g-2 align-items-center">
					<div class="col-md-5">
						<div class="row align-items-center">
							<div class="col-auto">
								<img class="logo" src="<?php echo $keg->sertifikasi->get_link_logo();?>" width="50" alt="logo">
							</div>
							<div class="col">
								<h4 class="card-title m-0 nama-kegiatan">
									<?php echo html_escape($keg->nama_kegiatan); ?>
								</h4>
								<div class="text-muted mt-1 nama-sertifikasi">
									<?php echo html_escape($keg->sertifikasi->nama); ?>
								</div>
								<div class="mt-1">
									<small>
										Jumlah kelompok:
										<strong><?php echo count($keg->list_kelompok_training); ?> (T)</strong>,
										<strong><?php echo count($keg->list_kelompok_ujian); ?> (U)</strong>
									</small>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-5 my-md-0 my-sm-2 my-xs-2">
						<div class="ml-2">
							<span style="width:20px;display: inline-block;" class="font-weight-bolder">R</span>
							<span class="registrasi">
							<?php if (!empty($keg->awal_registrasi) && !empty($keg->akhir_registrasi)) { ?>
								<?php echo tgl_indo($keg->awal_registrasi->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE); ?>
								s/d
								<?php echo tgl_indo($keg->akhir_registrasi->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE); ?>
							<?php } else { ?>
								Tidak ada
							<?php } ?>
						</span>
						</div>
						<div class="ml-2">
							<span style="width:20px;display: inline-block;" class="font-weight-bolder">T</span>
							<span class="training">
							<?php
							$max_date = DateTime::createFromFormat('Y-m-d', '2099-12-31');
							$min_date = DateTime::createFromFormat('Y-m-d', '1980-01-01');
							$awal_training = DateTime::createFromFormat('Y-m-d', '2099-12-31');
							$akhir_training = DateTime::createFromFormat('Y-m-d', '1980-01-01');
							foreach($keg->list_kelompok_training as $kelompok_t)
							{
								if (!empty($kelompok_t->mulai_training))
									$awal_training = min($awal_training, $kelompok_t->mulai_training);
								if (!empty($kelompok_t->selesai_training))
									$akhir_training = max($akhir_training, $kelompok_t->selesai_training);
							}
							if ($awal_training == $max_date || $akhir_training == $min_date)
								echo "- (Belum dapat ditentukan)";
							else
							{
								echo tgl_indo($awal_training->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
								echo " s/d ";
								echo tgl_indo($akhir_training->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
							}
							?>
						</span>
						</div>
						<div class="ml-2">
							<span style="width:20px;display: inline-block;" class="font-weight-bolder">U</span>
							<span class="ujian">
							<?php
							$max_date = DateTime::createFromFormat('Y-m-d', '2099-12-31');
							$min_date = DateTime::createFromFormat('Y-m-d', '1980-01-01');
							$awal_ujian = DateTime::createFromFormat('Y-m-d', '2099-12-31');
							$akhir_ujian = DateTime::createFromFormat('Y-m-d', '1980-01-01');
							foreach($keg->list_kelompok_ujian as $kelompok_u)
							{
								if (!empty($kelompok_u->mulai_ujian))
									$awal_ujian = min($awal_ujian, $kelompok_u->mulai_ujian);
								if (!empty($kelompok_u->selesai_ujian))
									$akhir_ujian = max($akhir_ujian, $kelompok_u->selesai_ujian);
							}
							if ($awal_ujian == $max_date || $akhir_ujian == $min_date)
								echo "- (Belum dapat ditentukan)";
							else
							{
								echo tgl_indo($awal_ujian->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
								echo " s/d ";
								echo tgl_indo($akhir_ujian->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
							}
							?>
						</span>
						</div>
					</div>
					<div class=" col-md-2">
					<span class="d-none programs">
						<?php foreach ($keg->program_kegiatan as $p) { ?>
							<span class="program">
							<span class="id"><?php echo $p->id_program; ?></span>
							<span class="nama-program"><?php echo $p->nama_program; ?></span>
							<span class="file-logo"><?php echo $p->get_link_logo(); ?></span>
						</span>
						<?php } ?>
					</span>
						<a href="#" role="button" class="d-block btn btn-light mb-2" data-toggle="modal" data-target="#info" style="white-space: normal;">
							Info Sertifikasi
						</a>
						<a href="<?php echo base_url('trainer/kelompok?id_kegiatan='.$keg->id); ?>" role="button" class="d-block btn btn-info link-kesediaan" style="white-space: normal;">
							Data Kelompok
						</a>
					</div>
				</div>
			</div>
		</div>
	<?php } ?>
</div>
<?php } ?>

<?php function yield_bottom_before_script($_this, $data){?>
<!--  Modal info -->
<div class="modal fade" id="info" tabindex="-1" role="dialog" aria-labelledby="infoLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title" id="infoLabel">Detail Kegiatan</h4>
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			</div>
			<div class="modal-body">
				<div class="d-flex">
					<div class="my-auto float-left mr-auto">
						<h3 id="info-title"></h3>
					</div>
					<div class="float-right" style="margin-right: 10px;min-width: 50px;">
						<img id="info-logo" src="" width="50" height="50">
					</div>
				</div>
				<hr>
				<div class="alert alert-info my-3" role="alert">
					Untuk melihat Kelompok Training Anda, silahkan buka menu "Kelompok Saya".
				</div>
				<div class="row mt-2 mb-3">
					<div class="col-md-6">
						<p><b>Sertifikasi</b></p>
						<span class="badge bg-cyan text-white" id="info-nama-sertifikasi"></span>
					</div>
					<div class="col-md-6">
						<p><b>Tanggal Sertifikasi</b></p>
						<ul id="info-tanggal">
							<li>Registrasi : <span></span></li>
							<li>Training : <span></span></li>
							<li>Ujian : <span></span></li>
						</ul>
					</div>

				</div>
				<p class="mt-4 text-center"><b>Program yang dibuka</b></p>
				<div class="row g-2  my-2 text-center justify-content-center" id="info-program" style="line-height: 1.3;font-size: 14px;">
				</div>
			</div>
			<div class="modal-footer">
				<a href="#" class="float-left mr-auto btn btn-link link-secondary" data-dismiss="modal">
					Kembali
				</a>
				<a href="#" class="float-right btn btn-info" id="info-link-kesediaan">
					Isi Kesediaan Training
				</a>
			</div>
		</div>
	</div>
</div>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
<script type="application/javascript">
	$('#info').on('show.bs.modal', function (event) {
		let button = $(event.relatedTarget); // Button that triggered the modal
		var modal = $(this);
		let row = button.parent().parent();
		console.log(row.find('.logo').attr('src'));
		modal.find('.modal-body #info-title').text(row.find('.nama-kegiatan').text());
		modal.find('.modal-body #info-logo').attr('src', row.find('.logo').attr('src'));
		modal.find('.modal-body #info-nama-sertifikasi').text(row.find('.nama-sertifikasi').text());
		modal.find('.modal-body #info-tanggal li:eq(0) span').text(row.find('.registrasi').text());
		modal.find('.modal-body #info-tanggal li:eq(1) span').text(row.find('.training').text());
		modal.find('.modal-body #info-tanggal li:eq(2) span').text(row.find('.ujian').text());
		let pr = modal.find('.modal-body #info-program').html("");
		row.find('.programs .program').each(function(){
			let p = $("<div class='col-md-4 my-2'></div>");
			let img = $("<img class='d-block mx-auto mb-1' height='50'>").attr('src', $(this).find('.file-logo').text());
			p.append(img).append($(this).find('.nama-program').text());
			pr.append(p);
		});
		modal.find('.modal-footer #info-link-kesediaan').attr('href', row.find('.link-kesediaan').attr('href'));
	});
</script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('trainer/components/container_main', [ 'data' => $data]); ?>

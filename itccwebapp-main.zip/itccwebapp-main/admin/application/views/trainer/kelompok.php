<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> Kelompok Training <?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col-7 align-self-center">
        <h3 class="page-title text-dark font-weight-medium mb-1">
            <?php yield_title($_this, $data); ?>
        </h3>
    </div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
<?php
/** @var D_Kegiatan[] $list_kegiatan */
$list_kegiatan = $data['kegiatan'];
/** @var D_Kegiatan $selected_kegiatan */
$selected_kegiatan = $data['selected_kegiatan'];
/** @var D_Trainer $me */
$me = $data['me'];
?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <form action="" method="GET">
                    <div class="form-group my-2 px-3">
                        <label for="kegiatan">Kegiatan yang akan/sedang berjalan : </label>
                        <select class="custom-select form-control text-dark" name="id_kegiatan" onchange="this.form.submit()" style="max-width: 400px;">
                            <option value="">Pilih kegiatan</option>
                            <?php foreach($list_kegiatan as $keg) { ?>
                            <option
                                    value="<?php echo $keg->id; ?>"
                                    <?php if (!empty($selected_kegiatan) && (int)$selected_kegiatan->id === (int)$keg->id)
                                    	echo 'selected'; ?>
                            >
                                <?php echo $keg->nama_kegiatan; ?>
                            </option>
                            <?php } ?>
                        </select>
                    </div>

                </form>
            </div>
        </div>

    </div>

    <?php if (!empty($selected_kegiatan)) {?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h3 class="mb-4 text-center"><?php echo $selected_kegiatan->nama_kegiatan; ?></h3>
                <div class="table-responsive">
                    <table id="kelompok" class="table table-striped table-bordered no-wrap text-center">
                        <thead>
                        <tr>
                            <th>Tgl. Training</th>
                            <th>Jam Training</th>
                            <th>Kelompok</th>
							<th>Sesi</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach($selected_kegiatan->list_kelompok_training as $kelompok) {?>
                        <tr>
                            <?php
                            $sekarang = new DateTime();
                            $jarak_absen_setelah_training = new DateInterval('PT'.config_item('toleransi_absensi_training').'H'); // 1 jam
                            $terakhir_absensi = clone $kelompok->selesai_training;
                            $terakhir_absensi->add($jarak_absen_setelah_training);
                            ?>
                            <td><?php echo tgl_indo($kelompok->mulai_training->format('Y-m-d H:i:s'), 'Y-m-d H:i:s'); ?></td>
                            <td>
                                <?php echo $kelompok->mulai_training->format('H:i'); ?>
                                s/d
                                <?php echo $kelompok->selesai_training->format('H:i'); ?>
                                WIB
                            </td>
                            <td><?php echo $kelompok->nama_kelompok; ?></td>
							<td>
								<?php
								$sesi1 = (int)$kelompok->id_trainer_sesi1 === (int)$me->id;
								$sesi2 = (int)$kelompok->id_trainer_sesi2 === (int)$me->id;
								if (!$sesi1 && !$sesi2) echo '-';
								if ($sesi1) echo '1';
								if ($sesi1 && $sesi2) echo ' & ';
								if ($sesi2) echo '2';
								?>
							</td>

                            <td>
								<?php if (!$sesi1 && !$sesi2) {?>
									<p class="d-block mx-auto alert alert-light border border-dark font-14 px-1 py-1" role="alert"
									   style=" width: 180px; white-space: normal">
										Anda bukan trainer kelompok ini.
									</p>
								<?php } elseif ((int)$kelompok->jumlah_peserta < (int)$kelompok->min_peserta_training) {?>
								<p class="d-block mx-auto alert alert-warning border border-dark font-14 px-1 py-1" role="alert"
								   style=" width: 180px; white-space: normal">
									Training tidak dapat dilaksanakan (belum memenuhi kuota minimum).
								</p>
								<?php } elseif ($sekarang < $kelompok->mulai_training ) {?>
								<p class="d-block mx-auto alert alert-info border border-dark font-14 px-1 py-1" role="alert"
								   style=" width: 180px; white-space: normal">
									Belum bisa absensi training.
								</p>
								<?php } elseif ($sekarang > $terakhir_absensi ) {?>
								<p class="d-block mx-auto alert alert-info border border-dark font-14 px-1 py-1" role="alert"
								   style=" width: 180px; white-space: normal">
									Periode absensi training sudah lewat.
								</p>
								<?php } else { ?>
									<a target="_blank"
									   href="<?php echo base_url('trainer/kelompok/absensi/'.$kelompok->id); ?>"
									   role="button" class="btn btn-rounded btn-info btn-sm">
										Absensi
									</a>
								<?php } ?>
                            </td>
                        </tr>
                        <?php } ?>
                        </tbody>
						<tfoot>
						<tr>
							<th><input style="width:80px" type="text" ></th>
							<th><input style="width:80px" type="text" ></th>
							<th><input style="width:80px" type="text" ></th>
							<th><input style="width:80px" type="text" ></th>
							<th></th>
						</tr>
						</tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php } ?>
<?php } ?>

<?php function yield_bottom_before_script($_this, $data){?>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
	<script>
		var kelompok = setupTable('#kelompok');
	</script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('trainer/components/container_main', [ 'data' => $data]); ?>

<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> History Training <?php } ?>
<?php function yield_page_header($_this, $data){?>
	<div class="col-md-7 align-self-center">
		<h3 class="page-title text-truncate text-dark font-weight-medium mb-1">
			<?php yield_title($_this, $data); ?>
		</h3>
	</div>
	<div class="col-md-5 align-self-center"></div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
	<?php
	/**
	 * @var D_Kegiatan[] $list_kegiatan
	 * @var D_Trainer $me
	 */
	$list_kegiatan = $data['list_kegiatan'];
	$me = $data['me'];
	?>
	<?php if (empty($list_kegiatan)) { ?>
		<div class="col-12">
			<small class="text-center d-block">- <i>Anda belum tergabung di kegiatan sertifikasi apapun</i> - </small>
		</div>
	<?php } else foreach($list_kegiatan as $keg) { ?>
		<div class="col-12">
			<div class="card card-sm">
				<div class="card-body">
					<div class="row g-2 align-items-center">
						<div class="col-md-4 ">
							<div class="row align-items-center">
								<div class="col-auto">
									<img class="logo" src="<?php echo $keg->sertifikasi->get_link_logo(); ?>" width="50" alt="logo">
								</div>
								<div class="col">
									<h4 class="card-title m-0">
										<?php echo $keg->nama_kegiatan; ?>
									</h4>
									<div class="text-muted mt-1">
										<?php echo $keg->sertifikasi->nama; ?>
									</div>
									<div class="mt-1">
										<small>
											Total peserta :
											<strong>
												<?php echo $keg->get_total_pendaftar_approved(); ?>
											</strong>
										</small>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="row">
								<div class="col-12">
									<div class="font-18 text-center">Peserta Anda</div>
								</div>
								<div class="col-md-6">
									<table class="font-weight-lighter font-14">
										<tr>
											<td style="width: 150px;">Total</td>
											<td class="px-2">:</td>
											<td style="width: 45px;" class="text-monospace text-right">
												<?php
												$total_peserta_trainer = 0;
												foreach($keg->list_kelompok_training as $kelompok)
												{
													if ((int)$kelompok->id_trainer_sesi1 === (int)$me->id || (int)$kelompok->id_trainer_sesi2 === (int)$me->id)
														$total_peserta_trainer += (int)$kelompok->jumlah_peserta;
												}
												echo $total_peserta_trainer; ?>
											</td>
										</tr>
										<tr>
											<td style="width: 150px;">Sudah ujian</td>
											<td class="px-2">:</td>
											<td style="width: 45px;" class="text-monospace text-right">
												<?php
												$total_peserta_training_sudah_ujian = 0;
												$total_peserta_trainer_lulus = 0;
												$total_peserta_trainer_tidaklulus = 0;
												foreach($keg->list_kelompok_training as $kelompok)
												{
													if (
														(int)$kelompok->id_trainer_sesi1 === (int)$me->id ||
														(int)$kelompok->id_trainer_sesi2 === (int)$me->id
													)
													{
														$peserta_sudah_ujian = array_filter(
															$kelompok->list_peserta,
															function($peserta){
																return $peserta->status_kelulusan !== General_Constants::STATUS_PENDING;
															}
														);
														$total_peserta_training_sudah_ujian += count($peserta_sudah_ujian);

														$peserta_lulus = array_filter(
															$kelompok->list_peserta,
															function($peserta){
																return $peserta->status_kelulusan === General_Constants::STATUS_LULUS;
															}
														);
														$total_peserta_trainer_lulus += count($peserta_lulus);

														$peserta_tidaklulus = array_filter(
																$kelompok->list_peserta,
																function($peserta){
																	return $peserta->status_kelulusan === General_Constants::STATUS_TIDAK_LULUS;
																}
														);
														$total_peserta_trainer_tidaklulus += count($peserta_tidaklulus);
													}
												}

												echo $total_peserta_training_sudah_ujian; ?>
											</td>
										</tr>

									</table>
								</div>
								<div class="col-md-6">
									<table class="font-weight-lighter font-14">
										<tr>
											<td style="width: 150px;">Lulus</td>
											<td class="px-2">:</td>
											<td style="width: 45px;" class="text-monospace text-right">
												<?php echo $total_peserta_trainer_lulus; ?>
											</td>
										</tr>
										<tr>
											<td style="width: 150px;">Tidak Lulus</td>
											<td class="px-2">:</td>
											<td style="width: 45px;" class="text-monospace text-right">
												<?php echo $total_peserta_trainer_tidaklulus; ?>
											</td>
										</tr>
									</table>
								</div>

							</div>
						</div>

						<div class=" col-md-2">
							<div class="text-center">
								<span class="font-weight-bolder">
									<span class="tingkat-kelulusan">
										<?php
										$jumlah = $total_peserta_trainer_lulus + $total_peserta_trainer_tidaklulus;
										$tingkat_kelulusan = 0;
										if ($jumlah > 0)
											$tingkat_kelulusan = (float)((int)$total_peserta_trainer_lulus/$jumlah);
										$tingkat_kelulusan = $tingkat_kelulusan * 100;
										$tingkat_kelulusan = (int)$tingkat_kelulusan;
										echo $tingkat_kelulusan;
										?>%
									</span>
								</span>
							</div>
							<div class="text-center">
								<div class="stars-outer">
									<div class="text-center stars-inner" data-percentage="<?php echo $tingkat_kelulusan; ?>"></div>
								</div>
							</div>
							<a href="<?php echo base_url('trainer/history/'.$keg->id) ?>" role="button" class="d-block btn btn-light mb-2"  style="white-space: normal;">
								Detail
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php } ?>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('trainer/components/container_main', [ 'data' => $data]); ?>

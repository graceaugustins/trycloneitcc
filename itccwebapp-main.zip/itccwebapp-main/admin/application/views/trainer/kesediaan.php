<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> Kesediaan Training Sertifikasi <?php } ?>
<?php function yield_page_header($_this, $data){?>
	<div class="col-md-9 align-self-center">
		<h3 class="page-title text-truncate text-dark font-weight-medium mb-1">
			<?php yield_title($_this, $data); ?>
		</h3>
	</div>
	<div class="col-md-3 align-self-center">
		<a href="<?php echo base_url('trainer'); ?>" role="button" class="btn btn-light btn-block">Kembali</a>
	</div>
<?php } ?>

<?php function yield_page_content($_this, $data){?>
	<?php
	/**
	 * @var D_Kegiatan $kegiatan
	 * @var DateTime $batas
	 * @var D_Kelompok_T[] $list_kelompok_sesuai
	 * @var D_Trainer $me
	 * */
	$kegiatan = $data['kegiatan'];
	$batas = $data['batas'];
	$list_kelompok_sesuai = $data['list_kelompok_sesuai'];
	$me = $data['me'];
	?>
	<div class="col-12">
		<div class="card">
			<div class="card-body">
				<h3 class="mb-4 text-center"><?php echo $kegiatan->nama_kegiatan; ?></h3>

				<div class="alert alert-light my-3" role="alert">
					Batas Pengisian Kesediaan Training : <strong><?php echo tgl_indo($batas->format('Y-m-d'), 'Y-m-d'); ?> pkl. <?php echo $batas->format('H.i'); ?> WIB</strong>
				</div>

				<form action="<?php echo base_url('trainer/kesediaan/'.$kegiatan->id.'/update'); ?>" method="POST">
					<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
					<input type="hidden" name="bersedia" value="null">
					<div class="table-responsive">
						<table id="kelompok" class="table table-striped nowrap mb-2 text-center" style="white-space: nowrap;">
							<thead>
							<tr>
								<th>Program</th>
								<th>Kelompok</th>
								<th>Tgl. Training</th>
								<th>Jam Training</th>
								<th>Bersedia?</th>
							</tr>
							</thead>
							<tbody>
							<?php foreach($list_kelompok_sesuai as $kel) {?>
								<tr>
									<td><?php echo $kel->nama_program; ?></td>
									<td>
										<span class="nama-kelompok"><?php echo $kel->nama_kelompok; ?></span>
										<span class="d-none id-kelompok"><?php echo $kel->id; ?></span>
									</td>
									<td><?php echo tgl_indo($kel->mulai_training->format('Y-m-d H:i:s'), 'Y-m-d H:i:s'); ?></td>
									<td><?php echo
												$kel->mulai_training->format('H:i')
												.' s/d '.
												$kel->selesai_training->format('H:i')
												.' WIB'; ?></td>
									<td>
										<div class="custom-control custom-checkbox">
											<input type="checkbox"
												   class="custom-control-input"
												   id="check-<?php echo $kel->id; ?>"
												   name="bersedia[]"
												   value="<?php echo $kel->id; ?>"
													<?php
													$id_trainer = (int)$me->id;
													$kelompok_filtered = array_filter(
														$kel->list_kesediaan_trainer,
														function ($kesediaan) use ($id_trainer){
															return (int)$kesediaan->id_trainer === $id_trainer;
														}
													);
													if (!empty($kelompok_filtered)) echo "checked";
													?>
											>
											<label class="custom-control-label" for="check-<?php echo $kel->id; ?>"></label>
										</div>
									</td>
								</tr>
							<?php } ?>

							</tbody>
							<tfoot>
							<tr>
								<th><input style="width:120px" type="text" ></th>
								<th><input style="width:120px" type="text" ></th>
								<th><input style="width:120px" type="text" ></th>
								<th><input style="width:120px" type="text" ></th>
								<th>Bersedia?</th>
							</tr>
							</tfoot>
						</table>
					</div>
					<button type="submit" class="btn btn-success mt-3 float-right">Update Kesediaan</button>
				</form>
			</div>
		</div>
	</div>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
<script type="application/javascript">
	var kelompok = setupTable('#kelompok');
</script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('trainer/components/container_main', ['data' => $data]); ?>

<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> Profil Saya <?php } ?>
<?php function yield_top($_this, $data) {?>
<style type="text/css">
	#profile tr{
		height: 50px;
	}
	#profile td {
		padding-left: 5px;
		padding-right: 5px;
		white-space: nowrap;
	}
</style>
<?php } ?>
<?php function yield_page_header($_this, $data){?>
	<div class="col-7 align-self-center">
		<h3 class="page-title text-dark font-weight-medium mb-1">
			<?php yield_title($_this, $data); ?>
		</h3>
	</div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
	<?php
	/** @var D_Trainer $me */
	$me = $data['me'];
	?>
	<div class="col-md-3">
		<div class="card">
			<div class="card-body">
				<img class="d-block px-2 pt-2 mb-2 w-100" src="<?php echo $me->get_link_profile(); ?>">
				<strong class="d-block text-center"><?php echo $me->nama_lengkap; ?></strong>
			</div>
		</div>
	</div>
	<div class="col-md-9">
		<div class="card">
			<div class="card-body">
				<div class="mb-2">
					<strong class="float-left mr-auto">Data Pribadi</strong>
					<button type="button" class="btn btn-sm btn-link link-secondary float-right" data-toggle="modal" data-target="#ubahNama">ubah</button>
				</div>

				<div class="table-responsive">
					<table class="w-100" id="profile">
						<tr>
							<td width="200">Nama Lengkap</td>
							<td>:</td>
							<td>
								<?php echo $me->nama_lengkap; ?>
							</td>
						</tr>

						<tr>
							<td>Alamat email</td>
							<td>:</td>
							<td><?php echo $me->email; ?></td>
						</tr>

						<tr>
							<td>Nomor Handphone</td>
							<td>:</td>
							<td>+62<?php echo $me->no_telepon; ?></td>
						</tr>
						<tr>
							<td style="vertical-align: top;">Sertifikasi</td>
							<td style="vertical-align: top;">:</td>
							<?php if (count($me->list_sertifikasi) === 0) { ?>
								<td style="vertical-align: top;">Tidak ada</td>
							<?php } else { ?>
								<td>
									<?php foreach($me->list_sertifikasi as $sertif) { ?>

										<div class="mb-2">
											<div class="mb-2">
												<img class="ml-1 mr-2" src="<?php echo $sertif->get_link_logo(); ?>" height="40" alt="logo">
												<i><?php echo $sertif->nama; ?></i>
											</div>

											<div class="text-right">
												<?php foreach($sertif->list_program as $p) { ?>
													<img class="mx-1 mb-3"
														 src="<?php echo $p->get_link_logo(); ?>"
														 height="40"
														 data-toggle="tooltip"
														 data-placement="top"
														 title="<?php echo $p->nama_program; ?>">
												<?php } ?>
											</div>
										</div>
									<?php } ?>
								</td>
							<?php } ?>
						</tr>
						<tr>
							<td colspan="3">
								<p style="white-space: normal;">Anda dapat menambahkan materi tambahan untuk diberikan kepada peserta training (secara default, ITCC sudah menyiapkan materi untuk tiap program).</p>
								<a href="<?php echo base_url('trainer/materi'); ?>" role="button" class="btn btn-info btn-block">Lihat Materi Training Saya</a>
							</td>
						</tr>
					</table>
				</div>

			</div>
		</div>
	</div>
	<div class="col-md-12">
		<div class="card">
			<div class="card-body">
				<div class="card-title">Grafik Kelulusan Peserta</div>

				<strong class="d-block text-center mb-2">SERTIFIKASI</strong>
				<div class="row" id="chart-sertifikasi">

				</div>

				<strong class="d-block text-center mb-2">PROGRAM SERTIFIKASI</strong>
				<div class="row" id="chart-program">

				</div>
			</div>
		</div>
	</div>
<?php } ?>

<?php function yield_bottom_before_script($_this, $data){?>
	<?php
	/** @var D_Trainer $me */
	$me = $data['me'];
	?>
<div class="modal fade" id="ubahNama" tabindex="-1" role="dialog" aria-labelledby="titleUbahNama" aria-hidden="true">
		<div class="modal-dialog ">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title" id="titleUbahNama">Ubah Data</h4>
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				</div>
				<div class="modal-body">
					<form action="" method="POST" enctype="multipart/form-data">
						<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
						<div class="form-group">
							<label for="nama">Nama Lengkap</label>
							<input type="text" class="form-control" name="nama" id="nama" value="<?php echo $me->nama_lengkap; ?>" required="required">
						</div>

						<div class="form-group">
							<label for="nama">Nomor Telepon (disarankan nomor yang aktif WA)</label>
							<div class="row">
								<div class="col-2">
									<input type="text" readonly class="form-control-plaintext text-right" value="+62">
								</div>
								<div class="col-10">
									<input type="number" class="form-control" name="no_telepon" id="notelp" value="<?php echo $me->no_telepon; ?>" required="required">
								</div>
							</div>

						</div>

						<div class="form-group">
							<div class="mb-2">
								Ganti Foto Profil <br>
								<small>(ukuran maks. 500 KB, format file <code>.JPG</code>, <code>.JPEG</code>, atau <code>.PNG</code>)</small>
							</div>
							<div class="custom-file">
								<input type="file" class="custom-file-input" id="inputGroupFile01" name="file_foto">
								<label class="custom-file-label" for="inputGroupFile01">Choose file</label>
							</div>
						</div>
						<button type="submit" class="btn btn-primary">Submit</button>
					</form>
				</div>
			</div>
		</div>
	</div>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
	<script type="text/javascript">
		"use strict";

		// blue, pink, yellow, green, white
		var chartPalletes = ["#26547c", "#ef476f", "#FFD166", "#06D6A0", "#FFFCF9"];

		function randomString(size)
		{
			var chars = "abcdefghijklmnopqrstuvwxyz";
			var output = "";
			for( var i = 0; i <size;i++)
			{
				output += chars[((Math.floor(Math.random()*100))%chars.length)];
			}

			return output;
		}

		function renderChartSertifikasi()
		{
			let param = get_param_ajax();
			$.post(
					BASE_URL+'ajax/trainer/sertifikasi/statistik_lulus_tidaklulus_pending',
					param
			).done(function(data){
				if (data.status !== 'ok')
				{
					alert(`Terjadi kesalahan dalam mengambil data : ${data.message}`);
					return;
				}
				let sertifikasi = [];
				$(data.data).each(function(){
					let title = this.nama;
					let labels = ["Lulus", "Tidak Lulus", "Pending"];
					let data = [
						this.jumlah_lulus,
						this.jumlah_tidaklulus,
						this.jumlah_pending,
					];
					let canvas = $("#chart-sertifikasi");
					canvas.html('');
					let c = $('<canvas></canvas>').attr('id', randomString(10));
					let d = $('<div></div>')
							.addClass('col-md-6')
							.addClass('mb-5')
							.append(c)
							.appendTo(canvas);
					new Chart(c.attr('id'), {
						type: 'pie',
						data: {
							labels: labels,
							datasets: [{
								label: "Jumlah (orang)",
								backgroundColor: chartPalletes.slice(0,labels.length),
								data: data
							}]
						},
						options: {
							title: {
								display: true,
								text: title
							}
						}
					});
				});
			});
		}

		function renderChartProgram()
		{
			let param = get_param_ajax();
			$.post(
					BASE_URL+'ajax/trainer/program/statistik_lulus_tidaklulus_pending',
					param
			).done(function(data){
				if (data.status !== 'ok')
				{
					alert(`Terjadi kesalahan dalam mengambil data : ${data.message}`);
					return;
				}
				$(data.data).each(function () {
					let canvas = $("#chart-program");
					canvas.html('');
					console.log(this);
					let heading = $('<div></div>')
							.addClass('col-12')
							.text(this[0].nama_sertifikasi)
							.appendTo(canvas);
					$(this).each(function(){
						let title = this.nama;
						let labels = ["Lulus", "Tidak Lulus", "Pending"];
						let data = [
							this.jumlah_lulus,
							this.jumlah_tidaklulus,
							this.jumlah_pending,
						];
						let c = $('<canvas></canvas>').attr('id', randomString(10));
						let d = $('<div></div>')
								.addClass('col-md-6')
								.addClass('mb-5')
								.append(c)
								.appendTo(canvas);
						new Chart(c.attr('id'), {
							type: 'pie',
							data: {
								labels: labels,
								datasets: [{
									label: "Jumlah (orang)",
									backgroundColor: chartPalletes.slice(0,labels.length),
									data: data
								}]
							},
							options: {
								title: {
									display: true,
									text: title
								}
							}
						});
					});
				});
			});
		}

		$(document).ready(function () {
			renderChartSertifikasi();
			renderChartProgram();
		});
	</script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('trainer/components/container_main', ['data' => $data]); ?>

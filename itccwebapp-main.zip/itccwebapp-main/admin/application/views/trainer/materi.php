<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> Materi Training Saya <?php } ?>
<?php function yield_page_header($_this, $data){?>
	<div class="col-md-9 align-self-center">
		<h3 class="page-title text-truncate text-dark font-weight-medium mb-1">Materi Training</h3>
	</div>
	<div class="col-md-3 align-self-center">
		<button type="button" class="btn w-100 btn-primary float-right mr-4" data-toggle="modal" data-target="#tambah">Tambah</button>
	</div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
	<?php
	/** @var D_Trainer $me */
	$me = $data['me'];
	?>
	<div class="col-12">
		<div class="card card-sm">
			<div class="card-body">
				<h3 class="card-title">Filter</h3>
				<div class="row g-2">
					<div class="col-md-4">
						<label class="form-label">Sertifikasi</label>
						<select class="custom-select text-dark filter" id="filter-nama-sertifikasi">
							<option value="all">Semua</option>
						</select>
					</div>

					<div class="col-md-4">
						<label class="form-label">Program</label>
						<select class="custom-select text-dark filter" id="filter-nama-program">
							<option value="all">Semua</option>
						</select>
					</div>

				</div>
			</div>
		</div>
	</div>

	<div class="col-12">
		<div class="card">
			<div class="card-body">
				<div class="table-responsive">
					<table class="table ">
						<thead>
						<tr>
							<th scope="col">Sertifikasi</th>
							<th scope="col">Program</th>
							<th scope="col">Deskripsi</th>
							<th scope="col"></th>
						</tr>
						</thead>
						<tbody>
						<?php foreach($me->list_materi as $m) {?>
							<tr class="materi">
								<?php
								$sertif = NULL;
								$program = NULL;
								foreach($me->list_sertifikasi as $s)
								{
									foreach($s->list_program as $p)
									{
										if ((int)$m->id_program === (int)$p->id)
										{
											$sertif = $s;
											$program = $p;
										}
									}
								}
								?>
								<td class="nama-sertifikasi">
									<?php echo $sertif->nama; ?>
								</td>
								<td class="nama-program"><?php echo $program->nama_program; ?></td>
								<td><?php echo $m->deskripsi; ?></td>
								<td>
									<span class="d-none id"><?php echo $m->id; ?></span>
									<span class="dropdown dropleft">
										<button class="btn btn-sm btn-rounded btn-outline-info dropdown-toggle align-text-middle" data-boundary="viewport" data-toggle="dropdown" aria-expanded="false">Action</button>
										<div class="dropdown-menu dropdown-menu-bottom" style="margin: 0px;">
											<a target="_blank" class="dropdown-item" href="<?php echo $m->get_link_materi(); ?>">
												Lihat
											</a>
											<a class="dropdown-item" href="#" data-toggle="modal" data-target="#ubah">
												Ubah
											</a>
											<a class="dropdown-item" href="#" data-toggle="modal" data-target="#hapus">
												Hapus
											</a>
										</div>
									</span>
								</td>
							</tr>
						<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
<?php } ?>

<?php function yield_bottom_before_script($_this, $data){?>
	<?php
	/** @var D_Trainer $me */
	$me = $data['me'];
	?>
	<!--  Modal tambah -->
	<div class="modal fade" id="tambah" tabindex="-1" role="dialog" aria-labelledby="infoLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title" id="infoLabel">Tambah Materi</h4>
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				</div>
				<form action="<?php echo base_url('trainer/materi'); ?>" method="POST" enctype="multipart/form-data">
					<div class="modal-body">
						<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
						<div class="form-group">
							<label for="program">Sertifikasi & Program</label>
							<select class="form-control list-program" name="id_program" required="required" >
								<?php foreach($me->list_sertifikasi as $sertif) {
									foreach($sertif->list_program as $program) {?>
										<option value="<?php echo $program->id; ?>"><?php echo $sertif->nama.' - '.$program->nama_program; ?></option>
									<?php }
								}?>
							</select>
						</div>

						<div class="form-group">
							<label for="deskripsi">Deskripsi Singkat (maks. 250 karakter)</label>
							<input type="text" class="form-control" id="deskripsi" name="deskripsi" placeholder="deskripsi tujuan materi ini" required="required">
						</div>

						<div class="form-group">
							<div class="mb-2">
								Upload File <br>
								<small>(file PDF, ukuran maks. 5 MB)</small>
							</div>
							<div class="custom-file">
								<input type="file" class="custom-file-input" id="inputGroupFile01" name="materi" required>
								<label class="custom-file-label" for="inputGroupFile01">Choose file</label>
							</div>
						</div>

					</div>

					<div class="modal-footer">
						<a href="#" class="float-left mr-auto btn btn-link link-secondary" data-dismiss="modal">
							Kembali
						</a>
						<button type="submit" class="btn btn-primary float-right">Upload</button>
					</div>
				</form>
			</div>
		</div>
	</div>

	<!--  Modal ubah -->
	<div class="modal fade" id="ubah" tabindex="-1" role="dialog" aria-labelledby="lblUbah" aria-hidden="true">
		<div class="modal-dialog ">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title" id="lblUbah">Ubah Materi</h4>
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				</div>
				<form action="<?php echo base_url('trainer/materi/update') ?>" method="POST">
					<div class="modal-body">
						<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
						<input type="hidden" name="id">
						<div class="form-group">
							<label for="deskripsi">Deskripsi Singkat (maks. 250 karakter)</label>
							<input type="text" class="form-control" id="deskripsi" name="deskripsi" placeholder="Deskripsi tujuan materi ini" required="required">
						</div>
					</div>
					<div class="modal-footer">
						<a href="#" class="float-left mr-auto btn btn-link link-secondary" data-dismiss="modal">
							Kembali
						</a>
						<button type="submit" class="btn btn-primary">Submit</button>
					</div>
				</form>
			</div>
		</div>
	</div>

	<!--  Modal hapus -->
	<div class="modal fade" id="hapus" tabindex="-1" role="dialog" aria-labelledby="lblHapus" aria-hidden="true">
		<div class="modal-dialog ">
			<div class="modal-content">
				<div class="modal-header modal-colored-header bg-danger">
					<h4 class="modal-title" id="lblHapus">Hapus Materi?</h4>
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				</div>
				<form action="<?php echo base_url('trainer/materi/delete') ?>" method="POST" >
					<div class="modal-body">
						<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
						<input type="hidden" name="id">
						<div>Deskripsi : </div>
						<div id="hapus-deskripsi"></div>
					</div>
					<div class="modal-footer">
						<a href="#" class="float-left mr-auto btn btn-link link-secondary" data-dismiss="modal">
							Kembali
						</a>
						<button type="submit" class="btn btn-danger">Hapus!</button>
					</div>
				</form>
			</div>
		</div>
	</div>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
	<script type="text/javascript">
		$('#ubah').on('show.bs.modal', function (event) {
			let button = $(event.relatedTarget); // Button that triggered the modal
			var modal = $(this);
			let p = button.parent().parent().parent().parent();
			modal.find('.modal-body input[name=id]').val(p.find('.id').text());
			modal.find('.modal-body input[name=deskripsi]').val(p.find('td:eq(2)').text());
		});
		$('#hapus').on('show.bs.modal', function (event) {
			let button = $(event.relatedTarget); // Button that triggered the modal
			var modal = $(this);
			let p = button.parent().parent().parent().parent();
			modal.find('.modal-body input[name=id]').val(p.find('.id').text());
			modal.find('.modal-body #hapus-deskripsi').text(p.find('td:eq(2)').text());
		});

		// ambil data unik
		var nama_sertifikasi = [];
		$('.nama-sertifikasi').each(function(){
			let nama = $(this).text().trim();
			if (nama_sertifikasi.indexOf(nama) === -1)
				nama_sertifikasi.push(nama);
		});
		nama_sertifikasi.sort();
		var filter_nama_sertifikasi = $('#filter-nama-sertifikasi');
		$(nama_sertifikasi).each(function(){
			let e = $('<option></option>').val(this).text(this);
			filter_nama_sertifikasi.append(e);
		});

		var nama_program = [];
		$('.nama-program').each(function(){
			let nama = $(this).text().trim();
			if (nama_program.indexOf(nama) === -1)
				nama_program.push(nama);
		});
		nama_program.sort();
		var filter_nama_program = $('#filter-nama-program');
		$(nama_program).each(function(){
			let e = $('<option></option>').val(this).text(this);
			filter_nama_program.append(e);
		});

		var contents = $('.materi');
		$('.filter').on('change', function(){
			contents.each(function(){
				let show = false;
				if (
						(filter_nama_sertifikasi.val() === 'all' || $('.nama-sertifikasi', $(this)).text().trim() === filter_nama_sertifikasi.val()) &&
						(filter_nama_program.val() === 'all' || $('.nama-program', $(this)).text().trim() === filter_nama_program.val())
				)
					show = true;
				if (show) $(this).addClass('show').removeClass('d-none');
				else $(this).removeClass('show').addClass('d-none');
			});
		});
	</script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('trainer/components/container_main', [ 'data' => $data]); ?>

<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> Absensi Kelompok Training <?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col-7 align-self-center">
        <h3 class="page-title text-dark font-weight-medium mb-1">
            <?php yield_title($_this, $data); ?>
        </h3>
    </div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
	<?php
	/**
	 * @var D_Trainer $me
	 * @var D_Kegiatan $kegiatan
	 * @var D_Kelompok_T $kelompok
	 * */
	$me = $data['me'];
	$kegiatan = $data['kegiatan'];
	$kelompok = $data['kelompok'];

	$trainer_sesi_1 = (int)$kelompok->id_trainer_sesi1 === (int)$me->id;
	$trainer_sesi_2 = (int)$kelompok->id_trainer_sesi2 === (int)$me->id;
	?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h3 class="text-center">Kelompok <?php echo $kelompok->nama_kelompok; ?></h3>
                <p class="mb-4 text-center"><?php echo $kegiatan->nama_kegiatan; ?></p>
                <div class="mb-2">
                    <span class="text-info">Jumlah Peserta : <?php echo count($kelompok->list_peserta); ?> orang</span>
                    <span class="text-dark float-md-right">Proctor training: <?php if (empty($kelompok->id_proctor_training)) echo 'Belum ada'; else echo $kelompok->proctor_training; ?></span>
					<div class="text-info">Trainer Sesi 1 : <?php echo empty($kelompok->id_trainer_sesi1) ? "-" : $kelompok->trainer_sesi1; ?></div>
					<div class="text-info">Trainer Sesi 2 : <?php echo empty($kelompok->id_trainer_sesi2) ? "-" : $kelompok->trainer_sesi2; ?></div>
				</div>
                <form action="" method="POST">
                    <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                    <div class="table-responsive">
                        <table id="kelompok" class="table table-striped table-bordered text-center" style="white-space: normal;">
                            <thead>
                            <tr>
                                <th width="100" rowspan="2" style="vertical-align: middle;">Foto</th>
                                <th rowspan="2" style="vertical-align: middle;">Nama Depan</th>
                                <th rowspan="2" style="vertical-align: middle;">Nama Belakang</th>
                                <th width="150"
                                    colspan="<?php
                                    $sesi = 0;
                                    if ($trainer_sesi_1 || $trainer_sesi_2) $sesi++;
                                    if ($trainer_sesi_2) $sesi++;
                                    echo $sesi;?>"
                                >
                                    Absensi
                                </th>
                            </tr>
                            <tr>
                                <?php
								if ($trainer_sesi_1 || $trainer_sesi_2) { ?>
                                <th>Sesi 1</th>
                                <?php } ?>
                                <?php if ($trainer_sesi_2) {?>
                                <th>Sesi 2</th>
                                <?php } ?>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach($kelompok->list_peserta as $peserta) { ?>
                            <tr>
                                <td>
                                    <img src="<?php echo $peserta->get_link_foto_profil(); ?>" width="80">
                                </td>
                                <td class="align-middle"><?php echo html_escape($peserta->nama_depan_user); ?></td>
                                <td class="align-middle"><?php echo html_escape($peserta->nama_belakang_user); ?></td>
                                <?php
								if ($trainer_sesi_1 || $trainer_sesi_2) {?>
                                <td class="align-middle">
                                    <input type="checkbox"
                                           name="sesi1[]"
                                           class="sesi-1"
                                           value="<?php echo $peserta->id; ?>"
                                           <?php if ($peserta->hadir_training_sesi1) echo 'checked'; ?>
										   <?php if (!$trainer_sesi_1) echo "disabled";?>
                                    >
                                </td>
                                <?php } ?>
                                <?php if ($trainer_sesi_2) {?>
                                <td class="align-middle">
                                    <input type="checkbox"
                                           name="sesi2[]"
                                           class="sesi-2"
                                           value="<?php echo $peserta->id; ?>"
                                           <?php if ($peserta->hadir_training_sesi2) echo 'checked'; ?>
                                    >
                                </td>
                                <?php } ?>
                            </tr>
                            <?php } ?>

                            </tbody>
                            <tfoot>
                            <tr>
                                <th colspan="3" class="text-right">Jumlah Hadir</th>
                                <?php
								if ($trainer_sesi_1 || $trainer_sesi_2) {?>
                                    <th id="total-sesi-1">0</th>
                                <?php } ?>
                                <?php if ($trainer_sesi_2) {?>
                                    <th id="total-sesi-2">0</th>
                                <?php } ?>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                    <?php if ($trainer_sesi_1 || $trainer_sesi_2) {?>
                    <div class="form-group">
                        <label for="berita1"> Berita Acara Sesi 1<i>(jika ada)</i></label>
                        <textarea
							<?php if (!$trainer_sesi_1) echo "disabled"; ?>
							id="berita1" name="beritaacara_t_sesi1" class="form-control" rows="3" placeholder=""><?php echo html_escape($kelompok->beritaacara_t_sesi1); ?></textarea>
                    </div>
                    <?php }
					if ($trainer_sesi_2) { ?>
                    <div class="form-group">
                        <label for="berita2"> Berita Acara Sesi 2<i>(jika ada)</i></label>
                        <textarea id="berita2" name="beritaacara_t_sesi2" class="form-control" rows="3" placeholder=""><?php echo html_escape($kelompok->beritaacara_t_sesi2); ?></textarea>
                    </div>
                    <?php } ?>
                    <div class="mt-2">
                        <a href="<?php echo base_url('trainer/kelompok?id_kegiatan='.$kegiatan->id); ?>" role="button" class="btn btn-link link-secondary float-left mr-auto">Kembali</a>
                        <button type="submit" class="btn btn-success float-right">Update Absensi</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
<?php } ?>

<?php function yield_bottom_before_script($_this, $data){?>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
    <script type="text/javascript">
        $('.sesi-1').on('change', function(){
            let sum = 0;
            $('.sesi-1').each(function(){
                if (this.checked) sum += 1;
            });
            $('#total-sesi-1').text(sum);
        });
        $('.sesi-2').on('change', function(){
            let sum = 0;
            $('.sesi-2').each(function(){
                if (this.checked) sum += 1;
            });
            $('#total-sesi-2').text(sum);
        });
        $(document).ready(function(){
            let sum = 0;
            $('.sesi-1').each(function(){
                if (this.checked) sum += 1;
            });
            $('#total-sesi-1').text(sum);
            sum = 0;
            $('.sesi-2').each(function(){
                if (this.checked) sum += 1;
            });
            $('#total-sesi-2').text(sum);
        });
    </script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('trainer/components/container_main', [ 'data' => $data]); ?>

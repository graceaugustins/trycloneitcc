<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?>
	<?php
	/**
	 * @var D_Kegiatan $selected_kegiatan
	 * */
	$selected_kegiatan = $data['selected_kegiatan'];
	?>
	Detail History - <?php echo $selected_kegiatan->nama_kegiatan; ?>
<?php } ?>
<?php function yield_page_header($_this, $data){?>
	<div class="col-md-10 align-self-center">
		<h3 class="page-title text-dark font-weight-medium mb-1">
			<?php yield_title($_this, $data); ?>
		</h3>
	</div>
	<div class="col-md-2 align-self-center">
		<a href="<?php echo base_url('trainer/history'); ?>" role="button" class="btn btn-light float-right">Kembali</a>
	</div>
<?php } ?>
<?php function yield_page_content($_this, $data){ ?>
	<?php
	/**
	 * @var D_Kegiatan $selected_kegiatan
	 * @var D_Trainer $me
	 * */
	$selected_kegiatan = $data['selected_kegiatan'];
	$me = $data['me'];
	?>
	<div class="col-12">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col-md-6">
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Kegiatan</div>
							<div class="col-md-7 text-dark"><?php echo $selected_kegiatan->nama_kegiatan; ?></div>
						</div>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Program yang tersedia</div>
							<div class="col-md-7 text-dark">
								<ul class="list-group list-group-flush">
									<?php foreach($selected_kegiatan->program_kegiatan as $program) { ?>
										<li class="list-group-item pl-0 pr-0 pt-0 pb-1"><?php echo $program->nama_program; ?></li>
									<?php } ?>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-md-6"></div>
				</div>
				<hr>
				<div class="row">
					<div class="col-md-6">
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Training</div>
							<div class="col-md-7 text-dark">
								<?php if (count($selected_kegiatan->list_kelompok_training) === 0) echo "- (belum ada kelompok)";
								else {
									$dari = DateTime::createFromFormat('Y-m-d', "2099-12-31");
									foreach($selected_kegiatan->list_kelompok_training as $k){
										$dari = min(
												$dari,
												$k->mulai_training
										);
									}
									echo tgl_indo($dari->format('Y-m-d'), 'Y-m-d', TRUE);
									echo " s/d ";
									$sampai = DateTime::createFromFormat('Y-m-d', "1990-12-31");
									foreach($selected_kegiatan->list_kelompok_training as $k){
										$sampai = max(
												$sampai,
												$k->selesai_training
										);
									}
									echo tgl_indo($sampai->format('Y-m-d'), 'Y-m-d', TRUE);
								} ?>
							</div>
						</div>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Ujian</div>
							<div class="col-md-7 text-dark">
								<?php
								if (count($selected_kegiatan->list_kelompok_ujian) === 0) echo "- (belum ada kelompok)";
								else {
									$dari = DateTime::createFromFormat('Y-m-d', "2099-12-31");
									foreach ($selected_kegiatan->list_kelompok_ujian as $k) {
										$dari = min(
												$dari,
												$k->mulai_ujian
										);
									}

									echo tgl_indo($dari->format('Y-m-d'), 'Y-m-d', TRUE);
									echo " s/d ";
									$sampai = DateTime::createFromFormat('Y-m-d', "1990-12-31");
									foreach ($selected_kegiatan->list_kelompok_ujian as $k) {
										$sampai = max(
												$sampai,
												$k->selesai_ujian
										);
									}
									echo tgl_indo($sampai->format('Y-m-d'), 'Y-m-d', TRUE);
								}
								?>
							</div>
						</div>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Total Peserta</div>
							<div class="col-md-7 text-dark">
								<?php echo $selected_kegiatan->get_total_pendaftar_approved(); ?>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Peserta di kelompok Anda</div>
							<div class="col-md-7 text-dark">
								<?php
								$total_peserta_trainer = 0;
								$total_peserta_training_sudah_ujian = 0;
								$total_peserta_trainer_lulus = 0;
								$total_peserta_trainer_tidaklulus = 0;
								foreach($selected_kegiatan->list_kelompok_training as $kelompok)
								{
									if (
											(int)$kelompok->id_trainer_sesi1 === (int)$me->id ||
											(int)$kelompok->id_trainer_sesi2 === (int)$me->id
									)
									{
										$total_peserta_trainer += (int)$kelompok->jumlah_peserta;
										$peserta_sudah_ujian = array_filter(
												$kelompok->list_peserta,
												function($peserta){
													return $peserta->status_kelulusan !== General_Constants::STATUS_PENDING;
												}
										);
										$total_peserta_training_sudah_ujian += count($peserta_sudah_ujian);

										$peserta_lulus = array_filter(
												$kelompok->list_peserta,
												function($peserta){
													return $peserta->status_kelulusan === General_Constants::STATUS_LULUS;
												}
										);
										$total_peserta_trainer_lulus += count($peserta_lulus);

										$peserta_tidaklulus = array_filter(
												$kelompok->list_peserta,
												function($peserta){
													return $peserta->status_kelulusan === General_Constants::STATUS_TIDAK_LULUS;
												}
										);
										$total_peserta_trainer_tidaklulus += count($peserta_tidaklulus);
									}
								}

								echo $total_peserta_trainer;
								?>
							</div>
						</div>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Yang sudah ujian</div>
							<div class="col-md-7 text-dark"><?php echo $total_peserta_training_sudah_ujian; ?></div>
						</div>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Lulus</div>
							<div class="col-md-7 text-dark"><?php echo $total_peserta_trainer_lulus; ?></div>
						</div>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Tidak Lulus</div>
							<div class="col-md-7 text-dark"><?php echo $total_peserta_trainer_tidaklulus; ?></div>
						</div>
						<hr>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Presentasi Kelulusan</div>
							<div class="col-md-7 text-dark">
								<?php
								$jumlah = (int)$total_peserta_trainer_lulus + (int)$total_peserta_trainer_tidaklulus;
								$tingkat_kelulusan = 0;
								if ($jumlah > 0)
									$tingkat_kelulusan = (float)((int)$total_peserta_trainer_lulus/$jumlah);
								echo $tingkat_kelulusan*100;
								?>%
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>

	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-body">
				<h3 class="mb-4">Data Peserta Anda</h3>
				<div class="table-responsive">
					<table id="ujian" class="table table-striped table-bordered no-wrap text-center">
						<thead>
						<tr>
							<th>No.</th>
							<th>Kelompok Training</th>
							<th>Nama</th>
							<th>Skor Ujian</th>
							<th>Status</th>
						</tr>
						</thead>
						<tbody>
						<?php
						$i = 1;
						foreach ($selected_kegiatan->list_kelompok_training as $kelompok) {
							$t_sesi1 = (int)$me->id === (int)$kelompok->id_trainer_sesi1;
							$t_sesi2 = (int)$me->id === (int)$kelompok->id_trainer_sesi2;
							if (!$t_sesi1 && !$t_sesi2) continue;

							foreach($kelompok->list_peserta as $peserta) {?>
								<tr>
									<td><?php echo $i++; ?></td>
									<td><?php echo $kelompok->nama_kelompok; ?></td>
									<td><?php echo $peserta->nama_depan_user.' '.$peserta->nama_belakang_user; ?></td>
									<td><?php echo $peserta->skor_ujian; ?></td>
									<td>
										<?php if ($peserta->status_kelulusan === General_Constants::STATUS_PENDING) {?>
											<span class="badge badge-info">Pending</span>
										<?php } elseif ($peserta->status_kelulusan === General_Constants::STATUS_TIDAK_LULUS) {?>
											<span class="badge badge-danger">Tidak Lulus</span>
										<?php } elseif ($peserta->status_kelulusan === General_Constants::STATUS_LULUS) { ?>
											<span class="badge badge-success">Lulus</span>
										<?php } ?>
									</td>
								</tr>
							<?php }
						} ?>
						</tbody>
						<tfoot>
						<tr>
							<th></th>
							<th><input style="width:80px" type="text" ></th>
							<th><input style="width:80px" type="text" ></th>
							<th><input style="width:80px" type="text" ></th>
							<th><input style="width:80px" type="text" ></th>
						</tr>
						</tfoot>
					</table>
				</div>
			</div>
		</div>
	</div>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
<script>
	var table_t = setupTable('#ujian');
</script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('trainer/components/container_main', [ 'data' => $data]); ?>

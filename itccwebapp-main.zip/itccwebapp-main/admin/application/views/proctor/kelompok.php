<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> Kelompok Saya <?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col-7 align-self-center">
        <h3 class="page-title text-dark font-weight-medium mb-1">
            <?php yield_title($_this, $data); ?>
        </h3>
    </div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
<?php
 /**
  * @var D_Kegiatan[] $list_kegiatan
  * @var D_Kegiatan $selected_kegiatan
  * @var D_Trainer $me
  * */
$list_kegiatan = $data['list_kegiatan'];
$selected_kegiatan = $data['selected_kegiatan'];
$me = $data['me'];
$sekarang = new DateTime();
?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <form action="" method="GET">
                    <div class="form-group my-2 px-3">
                        <label for="kegiatan">Sertifikasi yang Sedang Berjalan : </label>
                        <select class="custom-select form-control text-dark" name="id_kegiatan" onchange="this.form.submit()" style="max-width: 400px;">
                            <option value="">Pilih kegiatan</option>
                            <?php foreach($list_kegiatan as $keg) { ?>
                            <option
                                    value="<?php echo $keg->id; ?>"
                                    <?php if (!empty($selected_kegiatan && (int)$selected_kegiatan->id === (int)$keg->id)) echo 'selected'; ?>
                            >
                                <?php echo $keg->nama_kegiatan; ?>
                            </option>
                            <?php } ?>
                        </select>
                    </div>

                </form>
            </div>
        </div>

    </div>

    <?php if (!empty($selected_kegiatan)) {?>
	<div class="col-12">
		<div class="card">
			<div class="card-body">
				<h3 class="mb-4 text-center">Kelompok Training</h3>
				<div class="table-responsive">
					<table id="kelompok-t" class="table table-striped table-bordered no-wrap text-center">
						<thead>
						<tr>
							<th>Tgl. Training</th>
							<th>Jam Training</th>
							<th>Kelompok</th>
							<th>Action</th>
						</tr>
						</thead>
						<tbody>
						<?php
						foreach($selected_kegiatan->list_kelompok_training as $kelompok) { ?>
							<tr>
								<td><?php echo tgl_indo($kelompok->mulai_training->format('Y-m-d'), 'Y-m-d'); ?></td>
								<td>
									<?php echo $kelompok->mulai_training->format('H:i'); ?>
									s/d
									<?php echo $kelompok->selesai_training->format('H:i'); ?>
									WIB
								</td>
								<td><?php echo $kelompok->nama_kelompok; ?></td>
								<td>

									<?php if ((int)$kelompok->id_proctor_training !== (int)$me->id) { ?>
										<p class="d-block mx-auto alert alert-light border border-dark font-14 px-1 py-1" role="alert"
										   style=" width: 180px; white-space: normal">
											Anda bukan proctor training kelompok ini.
										</p>
									<?php } elseif ((int)$kelompok->jumlah_peserta < (int)$kelompok->min_peserta_training) { ?>
										<p class="d-block mx-auto alert alert-info border border-dark font-14 px-1 py-1" role="alert"
										   style=" width: 180px; white-space: normal">
											Training tidak dapat dilaksanakan (belum memenuhi kuota minimum).
										</p>
									<?php } elseif ($sekarang < $kelompok->mulai_training ) {?>
										<p class="d-block mx-auto alert alert-info border border-dark font-14 px-1 py-1" role="alert"
										   style=" width: 180px; white-space: normal">
											Belum bisa absensi ujian.
										</p>
									<?php } else { ?>
										<div>
											<a
													target="_blank"
													href="<?php echo base_url('proctor/kelompok_t/absensi/'.$kelompok->id); ?>"
													role="button"
													class="btn btn-rounded btn-info btn-sm">
												Absensi Training
											</a>
										</div>
									<?php } ?>
								</td>
							</tr>
						<?php } ?>
						</tbody>
						<tfoot>
						<tr>
							<th><input style="width:80px" type="text" ></th>
							<th><input style="width:80px" type="text" ></th>
							<th><input style="width:80px" type="text" ></th>
							<th></th>
						</tr>
						</tfoot>
					</table>
				</div>
			</div>
		</div>

	</div>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h3 class="mb-4 text-center">Kelompok Ujian</h3>
                <div class="table-responsive">
                    <table id="kelompok-u" class="table table-striped table-bordered no-wrap text-center">
                        <thead>
                        <tr>
                            <th>Tgl. Ujian</th>
                            <th>Jam Ujian</th>
                            <th>Kelompok</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
						foreach($selected_kegiatan->list_kelompok_ujian as $kelompok) { ?>
                        <tr>
                            <?php
                            $jarak_absen_setelah_ujian = new DateInterval('PT'.config_item('toleransi_absensi_ujian').'H');

                            $terakhir_absensi = clone $kelompok->selesai_ujian;
                            $terakhir_absensi->add($jarak_absen_setelah_ujian);
                            ?>
                            <td><?php echo tgl_indo($kelompok->mulai_ujian->format('Y-m-d'), 'Y-m-d'); ?></td>
                            <td>
                                <?php echo $kelompok->mulai_ujian->format('H:i'); ?>
                                s/d
                                <?php echo $kelompok->selesai_ujian->format('H:i'); ?>
                                WIB
                            </td>
                            <td><?php echo $kelompok->nama_kelompok; ?></td>

                            <td>

								<?php if ((int)$kelompok->id_proctor_ujian !== (int)$me->id) { ?>
									<p class="d-block mx-auto alert alert-light border border-dark font-14 px-1 py-1" role="alert"
									   style=" width: 180px; white-space: normal">
										Anda bukan proctor ujian kelompok ini.
									</p>
								<?php } elseif ((int)$kelompok->jumlah_peserta < (int)$kelompok->min_peserta_ujian) { ?>
									<p class="d-block mx-auto alert alert-info border border-dark font-14 px-1 py-1" role="alert"
									   style=" width: 180px; white-space: normal">
										Ujian tidak dapat dilaksanakan (belum memenuhi kuota minimum).
									</p>
								<?php } elseif ($sekarang < $kelompok->mulai_ujian ) {?>
									<p class="d-block mx-auto alert alert-info border border-dark font-14 px-1 py-1" role="alert"
									   style=" width: 180px; white-space: normal">
										Belum bisa absensi ujian.
									</p>
								<?php } elseif ($sekarang > $terakhir_absensi ) {?>
									<p class="d-block mx-auto alert alert-info border border-dark font-14 px-1 py-1" role="alert"
									   style=" width: 180px; white-space: normal">
										Periode absensi ujian sudah lewat.
									</p>
								<?php } else { ?>
									<div>
										<a
											target="_blank"
											href="<?php echo base_url('proctor/kelompok_u/absensi/'.$kelompok->id); ?>"
											role="button"
											class="btn btn-rounded btn-info btn-sm">
											Absensi Ujian
										</a>
									</div>
								<?php } ?>
                            </td>
                        </tr>
                        <?php } ?>
                        </tbody>
						<tfoot>
						<tr>
							<th><input style="width:80px" type="text" ></th>
							<th><input style="width:80px" type="text" ></th>
							<th><input style="width:80px" type="text" ></th>
							<th></th>
						</tr>
						</tfoot>
                    </table>
                </div>
            </div>
        </div>

    </div>
    <?php } ?>
<?php } ?>

<?php function yield_bottom_before_script($_this, $data){?>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
	<script>
		var kelompok_t = setupTable('#kelompok-t');
		var kelompok_u = setupTable('#kelompok-u');
	</script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('proctor/components/container_main', [ 'data' => $data]); ?>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <?php $this->load->view('admin/components/head'); ?>
    <title>Akun Tidak dapat diakses - ITCC</title>
    <style>
    </style>
</head>

<body>

<div class="preloader">
    <div class="lds-ripple">
        <div class="lds-pos"></div>
        <div class="lds-pos"></div>
    </div>
</div>

<div id="main-wrapper" data-theme="light" data-navbarbg="skin6" data-header-position="fixed" data-boxed-layout="full">
    <header class="topbar" data-navbarbg="skin6">
        <nav class="navbar top-navbar navbar-expand-md">
            <div class="navbar-header" style="box-shadow: none;">
                <!-- This is for the sidebar toggle which is visible on mobile only -->
                <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="#" style="width: 46px;">
                    <i class="d-none ti-menu ti-close"></i>
                </a>
                <div class="navbar-brand">
                    <!-- Logo icon -->
                    <a href="<?php echo base_url("proctor");?>">
                        <b class="logo-icon">
                            <!-- Dark Logo icon -->
                            <img src="<?php echo base_url("assets/images/logo-itcc.png");?>" alt="homepage" height="45" />
                        </b>
                    </a>
                </div>
                <a class=" d-block d-md-none waves-effect waves-light" href="javascript:void(0)" style="color: #7c8798;padding-right:15px;"
                   data-toggle="collapse" data-target="#navbarSupportedContent"
                   aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i class="ti-more"></i>
                </a>
            </div>

            <div class="navbar-collapse collapse border-0" id="navbarSupportedContent">
                <ul class="navbar-nav float-left mr-auto ml-3 pl-1"> </ul>
                <ul class="navbar-nav float-right">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="javascript:void(0)" data-toggle="dropdown"
                           aria-haspopup="true" aria-expanded="false">
                            <img src="<?php echo base_url($this->config->item('UPLOAD_PROFIL_PROCTOR')['upload_path'].$_SESSION['isProctor']['file_foto']); ?>" alt="user" class="rounded-circle" width="40">
                            <span class="ml-2 d-lg-inline-block">
                            <span class="text-dark"><?php echo $_SESSION['isProctor']['nama_lengkap']; ?></span>
                            <i data-feather="chevron-down" class="svg-icon"></i>
                        </span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right user-dd animated flipInY">
                            <a class="dropdown-item" href="<?php echo base_url('proctor/logout'); ?>">
                                <i data-feather="power" class="svg-icon mr-2 ml-1"></i>
                                Keluar
                            </a>
                        </div>
                    </li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="auth-wrapper d-flex no-block justify-content-center position-relative">
        <div class="auth-box row bg-white align-items-center px-4" style="height: 360px;">
            <div class="col-12">
                <i class=" d-block icon-info text-center p-2" style="font-size: 100px;"></i>
                <h2 class="mt-3 text-center">Akun anda tidak dapat diakses</h2>
                <p class="text-center">Akun anda telah dinonaktifkan oleh administrator,
                    dan tidak dapat diakses saat ini.</p>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view("admin/components/bottomscript"); ?>

</body>

</html>

<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> Absensi Kelompok Ujian <?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col-7 align-self-center">
        <h3 class="page-title text-dark font-weight-medium mb-1">
            <?php yield_title($_this, $data); ?>
        </h3>
    </div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
	<?php
	/**
	 * @var D_Proctor $me
	 * @var D_Kegiatan $kegiatan
	 * @var D_Kelompok_U $kelompok
	 * */
	$me = $data['me'];
	$kegiatan = $data['kegiatan'];
	$kelompok = $data['kelompok'];
	?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h3 class="text-center">Kelompok <?php echo $kelompok->nama_kelompok; ?></h3>
                <p class="mb-4 text-center"><?php echo $kegiatan->nama_kegiatan; ?></p>
                <div class="mb-2">
                    <span class="text-info">Jumlah Peserta : <?php echo count($kelompok->list_peserta); ?> orang</span>
                </div>
                <form action="" method="POST">
                    <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                    <div class="table-responsive">
                        <table id="kelompok" class="table table-striped table-bordered text-center" style="white-space: normal;">
                            <thead>
                            <tr>
                                <th width="100" style="vertical-align: middle;">Foto</th>
                                <th style="vertical-align: middle;">Nama Depan</th>
                                <th style="vertical-align: middle;">Nama Belakang</th>
                                <th width="150">Training Sesi 1</th>
                                <th width="150">Training Sesi 2</th>
                                <th width="150">Absensi Ujian</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach($kelompok->list_peserta as $peserta) { ?>
                            <tr>
                                <td>
                                    <img src="<?php echo $peserta->get_link_foto_profil(); ?>" width="80">
                                </td>
                                <td class="align-middle"><?php echo $peserta->nama_depan_user; ?></td>
                                <td class="align-middle"><?php echo $peserta->nama_belakang_user; ?></td>
                                <td class="align-middle hadir-s1"><?php echo ($peserta->hadir_training_sesi1) ? 'Hadir' : 'Tidak Hadir'; ?></td>
                                <td class="align-middle hadir-s2"><?php echo ($peserta->hadir_training_sesi2) ? 'Hadir' : 'Tidak Hadir'; ?></td>
                                <td class="align-middle">
                                    <input type="checkbox" name="ujian[]" class="ujian"
                                           value="<?php echo $peserta->id; ?>"
                                           <?php if ($peserta->hadir_ujian) echo 'checked'; ?>
                                    >
                                </td>
                            </tr>
                            <?php } ?>
                            </tbody>
                            <tfoot>
                            <tr>
                                <th colspan="3" class="text-right">Jumlah Hadir</th>
                                <th id="total-t-s1"></th>
                                <th id="total-t-s2"></th>
                                <th id="total-ujian">0</th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
					<div class="form-group">
						<label for="berita"> Berita Acara Ujian</i></label>
						<textarea class="form-control" rows="3" placeholder="" name="beritaacara_ujian"><?php echo $kelompok->beritaacara_ujian; ?></textarea>
					</div>

                    <div class="mt-2">
                        <a href="<?php echo base_url('proctor/kelompok?id_kegiatan='.$kegiatan->id); ?>" role="button" class="btn btn-link link-secondary float-left mr-auto">Kembali</a>
                        <button type="submit" class="btn btn-success float-right">Update Absensi</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
    <script type="text/javascript">
        $('.ujian').on('change', function(){
            let sum = 0;
            $('.ujian').each(function(){
                if (this.checked) sum += 1;
            });
            $('#total-ujian').text(sum);
        });
        $(document).ready(function(){
            let jumlah_hadir_t_s1 = 0, jumlah_hadir_t_s2 = 0;
            $('.hadir-s1').each(function(){
                if ($(this).text() === 'Hadir') jumlah_hadir_t_s1 +=1;
            });
            $('.hadir-s2').each(function(){
                if ($(this).text() === 'Hadir') jumlah_hadir_t_s2 +=1;
            });
            $('#total-t-s1').text(jumlah_hadir_t_s1);
            $('#total-t-s2').text(jumlah_hadir_t_s2);
            let sum = 0;
            $('.ujian').each(function(){
                if (this.checked) sum += 1;
            });
            $('#total-ujian').text(sum);
        });
    </script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('proctor/components/container_main', [ 'data' => $data]); ?>

<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?>
	<?php
	/**
	 * @var D_Kegiatan $kegiatan
	 * */
	$kegiatan = $data['kegiatan'];
	?>
	Kesediaan Proctor - <?php echo $kegiatan->nama_kegiatan; ?>
<?php } ?>
<?php function yield_page_header($_this, $data){?>
	<div class="col-md-9 align-self-center">
		<h3 class="page-title text-truncate text-dark font-weight-medium mb-1">
			<?php yield_title($_this, $data);?>
		</h3>
	</div>
	<div class="col-md-3 align-self-center">
		<a href="<?php echo base_url('proctor'); ?>" role="button" class="btn btn-light btn-block">Kembali</a>
	</div>
<?php } ?>

<?php function yield_page_content($_this, $data){?>
<?php
/**
 * @var D_Kegiatan $kegiatan
 * @var D_Proctor $me
 * @var DateTime $batas_proctor_training
 * @var DateTime $batas_proctor_ujian
 * @var DateTime $jarak_proctor_training
 * @var DateTime $jarak_proctor_ujian
 * */
$kegiatan = $data['kegiatan'];
$me = $data['me'];
$batas_proctor_training = $data['batas_proctor_training'];
$batas_proctor_ujian = $data['batas_proctor_ujian'];
$sekarang = new DateTime();
?>
	<div class="col-12">
		<div class="card">
			<div class="card-body">
				<h3 class="mb-4 text-center">Kesediaan Proctor Training</h3>

				<div class="alert alert-light my-3" role="alert">
					Batas Pengisian Kesediaan Proctor Training :
					<strong>
						<?php if (count($kegiatan->list_kelompok_training) !== 0) { ?>
							<?php echo tgl_indo($batas_proctor_training->format('Y-m-d'), 'Y-m-d'); ?> pkl. <?php echo $batas_proctor_training->format('H.i'); ?> WIB
						<?php } else { ?>
							- (belum ada kelompok)
						<?php } ?>
					</strong>
				</div>

				<form action="<?php echo base_url('proctor/kesediaan_t/'.$kegiatan->id.'/update'); ?>" method="POST">
					<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
					<input type="hidden" name="bersedia_t" value="null">
					<div class="table-responsive">
						<table id="kelompok-t" class="table table-striped nowrap mb-2 text-center" style="white-space: nowrap;">
							<thead>
							<tr>
								<th>Program</th>
								<th>Kelompok</th>
								<th>Tgl. Training</th>
								<th>Jam Training</th>
								<th>Kesediaan</th>
							</tr>
							</thead>
							<tbody>
							<?php foreach($kegiatan->list_kelompok_training as $kel) {?>
								<tr>
									<td><?php echo $kel->nama_program; ?></td>
									<td>
										<span class="nama-kelompok"><?php echo $kel->nama_kelompok; ?></span>
										<span class="d-none id-kelompok"><?php echo $kel->id; ?></span>
									</td>
									<td><?php echo tgl_indo($kel->mulai_training->format('Y-m-d H:i:s'), 'Y-m-d H:i:s'); ?></td>
									<td><?php echo
											$kel->mulai_training->format('H:i')
											.' s/d '.
											$kel->selesai_training->format('H:i')
											.' WIB'; ?></td>
									<td>
										<div class="custom-control custom-checkbox">
											<input type="checkbox"
												   class="custom-control-input"
												   id="check-t-<?php echo $kel->id; ?>"
												   name="bersedia_t[]"
												   value="<?php echo $kel->id; ?>"
													<?php
													$id_proctor_training = (int)$me->id;
													$kelompok_filtered = array_filter(
														$kel->list_kesediaan_proctor_training,
														function ($kesediaan) use ($id_proctor_training){
															return (int)$kesediaan->id_proctor === $id_proctor_training;
														}
													);
													if (!empty($kelompok_filtered)) echo "checked"; ?>
											>
											<label class="custom-control-label" for="check-t-<?php echo $kel->id; ?>"></label>
										</div>
									</td>

								</tr>
							<?php } ?>

							</tbody>
							<tfoot>
							<tr>
								<th><input style="width:120px" type="text" ></th>
								<th><input style="width:120px" type="text" ></th>
								<th><input style="width:120px" type="text" ></th>
								<th><input style="width:120px" type="text" ></th>
								<th></th>
							</tr>
							</tfoot>
						</table>
					</div>
					<?php if (count($kegiatan->list_kelompok_training) !== 0 && $sekarang < $batas_proctor_training) { ?>
					<button type="submit" class="btn btn-success mt-3 float-right">Update Kesediaan Training</button>
					<?php } ?>
				</form>
			</div>
		</div>
	</div>

	<div class="col-12">
		<div class="card">
			<div class="card-body">
				<h3 class="mb-4 text-center">Kesediaan Proctor Ujian</h3>

				<div class="alert alert-light my-3" role="alert">
					Batas Pengisian Kesediaan Proctor Ujian :
					<strong>
						<?php if (count($kegiatan->list_kelompok_ujian) !== 0) { ?>
							<?php echo tgl_indo($batas_proctor_ujian->format('Y-m-d'), 'Y-m-d'); ?> pkl. <?php echo $batas_proctor_ujian->format('H.i'); ?> WIB
						<?php } else { ?>
							- (belum ada kelompok)
						<?php } ?>
					</strong>
				</div>

				<form action="<?php echo base_url('proctor/kesediaan_u/'.$kegiatan->id.'/update'); ?>" method="POST">
					<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
					<input type="hidden" name="bersedia_u" value="null">
					<div class="table-responsive">
						<table id="kelompok-u" class="table table-striped nowrap mb-2 text-center" style="white-space: nowrap;">
							<thead>
							<tr>
								<th>Program</th>
								<th>Kelompok</th>
								<th>Tgl. Ujian</th>
								<th>Jam Ujian</th>
								<th>Kesediaan</th>
							</tr>
							</thead>
							<tbody>
							<?php foreach($kegiatan->list_kelompok_ujian as $kel) {?>
								<tr>
									<td><?php echo $kel->nama_program; ?></td>
									<td>
										<span class="nama-kelompok"><?php echo $kel->nama_kelompok; ?></span>
										<span class="d-none id-kelompok"><?php echo $kel->id; ?></span>
									</td>
									<td><?php echo tgl_indo($kel->mulai_ujian->format('Y-m-d H:i:s'), 'Y-m-d H:i:s'); ?></td>
									<td><?php echo
												$kel->mulai_ujian->format('H:i')
												.' s/d '.
												$kel->selesai_ujian->format('H:i')
												.' WIB'; ?></td>
									<td>
										<div class="custom-control custom-checkbox">
											<input type="checkbox"
												   class="custom-control-input"
												   id="check-u-<?php echo $kel->id; ?>"
												   name="bersedia_u[]"
												   value="<?php echo $kel->id; ?>"
													<?php
													$id_proctor_ujian = (int)$me->id;
													$kelompok_filtered = array_filter(
															$kel->list_kesediaan_proctor_ujian,
															function ($kesediaan) use ($id_proctor_ujian){
																return (int)$kesediaan->id_proctor === $id_proctor_ujian;
															}
													);
													if (!empty($kelompok_filtered)) echo "checked"; ?>
											>
											<label class="custom-control-label" for="check-u-<?php echo $kel->id; ?>"></label>
										</div>
									</td>

								</tr>
							<?php } ?>

							</tbody>
							<tfoot>
							<tr>
								<th><input style="width:120px" type="text" ></th>
								<th><input style="width:120px" type="text" ></th>
								<th><input style="width:120px" type="text" ></th>
								<th><input style="width:120px" type="text" ></th>
								<th></th>
							</tr>
							</tfoot>
						</table>
					</div>
					<?php if (count($kegiatan->list_kelompok_ujian) !== 0 && $sekarang < $batas_proctor_ujian) { ?>
					<button type="submit" class="btn btn-success mt-3 float-right">Update Kesediaan Ujian</button>
					<?php } ?>
				</form>
			</div>
		</div>
	</div>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
	<script type="application/javascript">
		var kelompok_t = setupTable('#kelompok-t');
		var kelompok_u = setupTable('#kelompok-u');
	</script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('proctor/components/container_main', ['data' => $data]); ?>


<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?>
	<?php
	/**
	 * @var D_Kegiatan $selected_kegiatan
	 * */
	$selected_kegiatan = $data['selected_kegiatan'];
	?>
	Detail History - <?php echo $selected_kegiatan->nama_kegiatan; ?>
<?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col-md-10 align-self-center">
        <h3 class="page-title text-dark font-weight-medium mb-1">
            <?php yield_title($_this, $data); ?>
        </h3>
    </div>
	<div class="col-md-2 align-self-center">
		<a href="<?php echo base_url('proctor/history'); ?>" role="button" class="btn btn-light float-right">Kembali</a>
	</div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
	<?php
	/**
	 * @var D_Kegiatan $selected_kegiatan
	 * @var D_Proctor $me
	 * @var bool $sebagai_proctor_training
	 * @var bool $sebagai_proctor_ujian
	 * @var Proctor $_this
	 * */
	$selected_kegiatan = $data['selected_kegiatan'];
	$keg = $selected_kegiatan;
	$me = $data['me'];
	$sebagai_proctor_training = $data['sebagai_proctor_training'];
	$sebagai_proctor_ujian = $data['sebagai_proctor_ujian'];
	$kelulusan = 0;
	?>
<div class="col-12">
	<div class="card">
		<div class="card-body">
			<div class="row">
				<div class="col-md-6">
					<div class="row mb-2">
						<div class="col-md-5 text-muted">Kegiatan</div>
						<div class="col-md-7 text-dark"><?php echo $selected_kegiatan->nama_kegiatan; ?></div>
					</div>
					<div class="row mb-2">
						<div class="col-md-5 text-muted">Program yang tersedia</div>
						<div class="col-md-7 text-dark">
							<ul class="list-group list-group-flush">
								<?php foreach($selected_kegiatan->program_kegiatan as $program) {?>
								<li class="list-group-item pl-0 pr-0 pt-0 pb-1"><?php echo $program->nama_program; ?></li>
								<?php } ?>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-md-6"></div>
			</div>
			<hr>
			<div class="row">
				<div class="col-md-6">
					<div class="row mb-2">
						<div class="col-md-5 text-muted">Training</div>
						<div class="col-md-7 text-dark">
							<?php if (empty($selected_kegiatan->list_kelompok_training)) echo "- (belum ada kelompok)";
							else {
								$dari = DateTime::createFromFormat('Y-m-d', "2099-12-31");
								foreach($selected_kegiatan->list_kelompok_training as $k){
									$dari = min(
										$dari,
										clone $k->mulai_training
									);
								}
								echo tgl_indo($dari->format('Y-m-d'), 'Y-m-d', TRUE);
								echo " s/d ";
								$sampai = DateTime::createFromFormat('Y-m-d', "1990-12-31");
								foreach($selected_kegiatan->list_kelompok_training as $k){
									$sampai = max(
										$sampai,
										clone $k->selesai_training
									);
								}
								echo tgl_indo($sampai->format('Y-m-d'), 'Y-m-d', TRUE);
							} ?>
						</div>
					</div>
					<div class="row mb-2">
						<div class="col-md-5 text-muted">Ujian</div>
						<div class="col-md-7 text-dark">
							<?php if (empty($selected_kegiatan->list_kelompok_ujian)) echo "- (belum ada kelompok)";
							else {
								$dari = DateTime::createFromFormat('Y-m-d', "2099-12-31");
								foreach($selected_kegiatan->list_kelompok_ujian as $k){
									$dari = min(
										$dari,
										clone $k->mulai_ujian
									);
								}
								echo tgl_indo($dari->format('Y-m-d'), 'Y-m-d', TRUE);
								echo " s/d ";
								$sampai = DateTime::createFromFormat('Y-m-d', "1990-12-31");
								foreach($selected_kegiatan->list_kelompok_ujian as $k){
									$sampai = max(
										$sampai,
										clone $k->selesai_ujian
									);
								}
								echo tgl_indo($sampai->format('Y-m-d'), 'Y-m-d', TRUE);
							} ?>
						</div>
					</div>
					<div class="row mb-2">
						<div class="col-md-5 text-muted">Total Peserta</div>
						<div class="col-md-7 text-dark"><?php echo $selected_kegiatan->get_total_pendaftar_approved(); ?></div>
					</div>
				</div>
				<div class="col-md-6"></div>
				<div class="col-12"><hr></div>
				<?php
				if ($sebagai_proctor_training) {
				$jumlah_peserta_proctor_training = $_this->m_proctor->get_jumlah_peserta_proctor_training_kegiatan($keg, $me);
				$lulus = $_this->m_proctor->get_jumlah_peserta_proctor_training_kegiatan_lulus($keg, $me);
				$tidak_lulus = $_this->m_proctor->get_jumlah_peserta_proctor_training_kegiatan_tidak_lulus($keg, $me);
				$jumlah_peserta_proctor_training_lulus = $lulus;
				$jumlah_peserta_proctor_training_tidak_lulus = $tidak_lulus;
				$jumlah_peserta_proctor_training_sudah_ujian = ($lulus + $tidak_lulus);
				?>
				<div class="col-md-6">
					<h4 class="mb-2 font-weight-bolder">Proctor Training</h4>
					<div class="row mb-2">
						<div class="col-md-5 text-muted">Peserta di kelompok Anda</div>
						<div class="col-md-7 text-dark"><?php echo $jumlah_peserta_proctor_training; ?></div>
					</div>
					<div class="row mb-2">
						<div class="col-md-5 text-muted">Yang sudah ujian</div>
						<div class="col-md-7 text-dark"><?php echo $jumlah_peserta_proctor_training_sudah_ujian; ?></div>
					</div>
					<div class="row mb-2">
						<div class="col-md-5 text-muted">Lulus</div>
						<div class="col-md-7 text-dark"><?php echo $jumlah_peserta_proctor_training_lulus; ?></div>
					</div>
					<div class="row mb-2">
						<div class="col-md-5 text-muted">Tidak Lulus</div>
						<div class="col-md-7 text-dark"><?php echo $jumlah_peserta_proctor_training_tidak_lulus; ?></div>
					</div>
					<div class="row mb-2">
						<div class="col-md-5 text-muted">Presentasi Kelulusan (Kelompok Training)</div>
						<div class="col-md-7 text-dark">
							<?php
							$tingkat_kelulusan = 0;
							if ($jumlah_peserta_proctor_training_sudah_ujian > 0)
								$tingkat_kelulusan = (float)((int)$jumlah_peserta_proctor_training_lulus/$jumlah_peserta_proctor_training_sudah_ujian);
							echo $tingkat_kelulusan*100;
							?>%
						</div>
					</div>
				</div>
				<?php } ?>
				<?php
				if ($sebagai_proctor_ujian) {
				$jumlah_peserta_proctor_ujian = $_this->m_proctor->get_jumlah_peserta_proctor_ujian_kegiatan($keg, $me);
				$lulus = $_this->m_proctor->get_jumlah_peserta_proctor_ujian_kegiatan_lulus($keg, $me);
				$tidak_lulus = $_this->m_proctor->get_jumlah_peserta_proctor_ujian_kegiatan_tidak_lulus($keg, $me);
				$jumlah_peserta_proctor_ujian_lulus = $lulus;
				$jumlah_peserta_proctor_ujian_tidak_lulus = $tidak_lulus;
				$jumlah_peserta_proctor_ujian_sudah_ujian = ($lulus + $tidak_lulus);
				?>
				<div class="col-md-6">
						<h4 class="mb-2 font-weight-bolder">Proctor Ujian</h4>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Peserta di kelompok Anda</div>
							<div class="col-md-7 text-dark"><?php echo $jumlah_peserta_proctor_ujian; ?></div>
						</div>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Yang sudah ujian</div>
							<div class="col-md-7 text-dark"><?php echo $jumlah_peserta_proctor_ujian_sudah_ujian; ?></div>
						</div>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Lulus</div>
							<div class="col-md-7 text-dark"><?php echo $jumlah_peserta_proctor_ujian_lulus; ?></div>
						</div>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Tidak Lulus</div>
							<div class="col-md-7 text-dark"><?php echo $jumlah_peserta_proctor_ujian_tidak_lulus; ?></div>
						</div>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Presentasi Kelulusan (Kelompok Ujian)</div>
							<div class="col-md-7 text-dark">
								<?php
								$tingkat_kelulusan = 0;
								if ($jumlah_peserta_proctor_ujian_sudah_ujian > 0)
									$tingkat_kelulusan = (float)((int)$jumlah_peserta_proctor_ujian_lulus/$jumlah_peserta_proctor_ujian_sudah_ujian);
								echo $tingkat_kelulusan*100;
								$kelulusan = $tingkat_kelulusan*100;
								?>%
							</div>
						</div>

				</div>
				<?php } ?>
				<div class="col-12">
					<hr>
					Tingkat kelulusan :
					<span class="font-weight-bolder">
						<?php echo $kelulusan; ?>%
					</span>
				</div>
			</div>

		</div>
	</div>

</div>
<?php if ($sebagai_proctor_training) {?>
<div class="col-12">
	<div class="card">
		<div class="card-body">
			<h3 class="mb-4">Data Peserta Anda (Sebagai Proctor Training)</h3>
			<div class="table-responsive">
				<table id="training" class="table table-striped table-bordered no-wrap text-center">
					<thead>
					<tr>
						<th>No.</th>
						<th>Kelompok</th>
						<th>Nama</th>
						<th>Skor Ujian</th>
						<th>Status</th>
					</tr>
					</thead>
					<tbody>
					<?php
					$i = 1;
					foreach ($selected_kegiatan->list_kelompok_training as $kelompok) {
						if ((int)$kelompok->id_proctor_training !== (int)$me->id)  continue;
						foreach($kelompok->list_peserta as $peserta) { ?>
						<tr>
							<td><?php echo $i++; ?></td>
							<td><?php echo $kelompok->nama_kelompok; ?></td>
							<td><?php echo $peserta->nama_depan_user.' '.$peserta->nama_belakang_user; ?></td>
							<td><?php echo $peserta->skor_ujian; ?></td>
							<td>
								<?php
								if ($peserta->status_kelulusan === General_Constants::STATUS_PENDING) {?>
									<span class="badge badge-info">Pending</span>
								<?php } elseif ($peserta->status_kelulusan === General_Constants::STATUS_TIDAK_LULUS) {?>
									<span class="badge badge-danger">Tidak Lulus</span>
								<?php } elseif ($peserta->status_kelulusan === General_Constants::STATUS_LULUS) { ?>
									<span class="badge badge-success">Lulus</span>
								<?php } ?>
							</td>
						</tr>
					<?php }
					} ?>
					</tbody>
					<tfoot>
					<tr>
						<th></th>
						<th><input style="width:80px" type="text" ></th>
						<th><input style="width:80px" type="text" ></th>
						<th><input style="width:80px" type="text" ></th>
						<th><input style="width:80px" type="text" ></th>
					</tr>
					</tfoot>
				</table>
			</div>
		</div>
	</div>
</div>
<?php } ?>

<?php if ($sebagai_proctor_ujian) {?>
	<div class="col-12">
		<div class="card">
			<div class="card-body">
				<h3 class="mb-4">Data Peserta Anda (Sebagai Proctor Ujian)</h3>
				<div class="table-responsive">
					<table id="ujian" class="table table-striped table-bordered no-wrap text-center">
						<thead>
						<tr>
							<th>No.</th>
							<th>Kelompok</th>
							<th>Nama</th>
							<th>Skor Ujian</th>
							<th>Status</th>
						</tr>
						</thead>
						<tbody>
						<?php
						$i = 1;
						foreach ($selected_kegiatan->list_kelompok_ujian as $kelompok) {
							if ((int)$kelompok->id_proctor_ujian !== (int)$me->id)  continue;
							foreach($kelompok->list_peserta as $peserta) { ?>
								<tr>
									<td><?php echo $i++; ?></td>
									<td><?php echo $kelompok->nama_kelompok; ?></td>
									<td><?php echo $peserta->nama_depan_user.' '.$peserta->nama_belakang_user; ?></td>
									<td><?php echo $peserta->skor_ujian; ?></td>
									<td>
										<?php
										if ($peserta->status_kelulusan === General_Constants::STATUS_PENDING) {?>
											<span class="badge badge-info">Pending</span>
										<?php } elseif ($peserta->status_kelulusan === General_Constants::STATUS_TIDAK_LULUS) {?>
											<span class="badge badge-danger">Tidak Lulus</span>
										<?php } elseif ($peserta->status_kelulusan === General_Constants::STATUS_LULUS) { ?>
											<span class="badge badge-success">Lulus</span>
										<?php } ?>
									</td>
								</tr>
							<?php }
						} ?>
						</tbody>
						<tfoot>
						<tr>
							<th><input style="width:80px" type="text" ></th>
							<th><input style="width:80px" type="text" ></th>
							<th><input style="width:80px" type="text" ></th>
							<th><input style="width:80px" type="text" ></th>
							<th><input style="width:80px" type="text" ></th>
						</tr>
						</tfoot>
					</table>
				</div>
			</div>
		</div>
	</div>
<?php } ?>

<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
<script>
    var table_t = setupTable('#training');
	var table_u = setupTable('#ujian');
</script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('proctor/components/container_main', [ 'data' => $data]); ?>

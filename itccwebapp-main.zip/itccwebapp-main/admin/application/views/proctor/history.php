<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> History Proctor <?php } ?>
<?php function yield_page_header($_this, $data){?>
	<div class="col-md-7 align-self-center">
		<h3 class="page-title text-truncate text-dark font-weight-medium mb-1">
			<?php yield_title($_this, $data); ?>
		</h3>
	</div>
	<div class="col-md-5 align-self-center"></div>
<?php } ?>

<?php function yield_page_content($_this, $data){?>
	<?php
	/**
	 * @var D_Kegiatan[] $list_kegiatan
	 * @var D_Proctor $me
	 * @var Proctor $_this
	 */
	$list_kegiatan = $data['list_kegiatan'];
	$me = $data['me'];
	?>
	<?php if (empty($list_kegiatan)) { ?>
		<div class="col-12">
			<small class="text-center d-block">- <i>Anda belum tergabung di kegiatan sertifikasi apapun</i> - </small>
		</div>
	<?php } else foreach($list_kegiatan as $keg) { ?>
		<?php
		$id_proctor = (int)$me->id;
		$kelompok_proctor_training = array_filter($keg->list_kelompok_training, function ($kel) use	($id_proctor){
			return (int)$kel->id_proctor_training === $id_proctor;
		});
		$kelompok_proctor_ujian = array_filter($keg->list_kelompok_ujian, function ($kel) use	($id_proctor){
			return (int)$kel->id_proctor_ujian === $id_proctor;
		});
		$sebagai_proctor_training = count($kelompok_proctor_training) > 0;
		$sebagai_proctor_ujian = count($kelompok_proctor_ujian) > 0;
		$kelulusan = 0;
		?>
		<div class="col-12">
			<div class="card card-sm">
				<div class="card-body">
					<div class="row g-2 align-items-center">
						<div class="col-md-4">
							<div class="row align-items-center">
								<div class="col-auto">
									<img class="logo" src="<?php echo $keg->sertifikasi->get_link_logo(); ?>" width="50">
								</div>
								<div class="col">
									<h4 class="card-title m-0">
										<?php echo $keg->nama_kegiatan; ?>
									</h4>
									<div class="text-muted mt-1">
										<?php echo $keg->sertifikasi->nama; ?>
									</div>
									<div class="mt-1">
										<small>
											Total peserta :
											<strong>
												<?php echo $keg->get_total_pendaftar_approved(); ?>
											</strong>
										</small>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="row">
								<div class="col-md-4">
									<?php if ($sebagai_proctor_training) {?>
									<div class="font-18 text-center">Proctor Training</div>
									<table class="font-weight-lighter font-14 w-100">
										<tr>
											<td style="width: 150px;">Total</td>
											<td class="px-2">:</td>
											<td style="width: 45px;" class="text-monospace text-right">
												<?php
												$jumlah_peserta_proctor_training = $_this->m_proctor->get_jumlah_peserta_proctor_training_kegiatan($keg, $me);
												$lulus = $_this->m_proctor->get_jumlah_peserta_proctor_training_kegiatan_lulus($keg, $me);
												$tidak_lulus = $_this->m_proctor->get_jumlah_peserta_proctor_training_kegiatan_tidak_lulus($keg, $me);
												$jumlah_peserta_proctor_training_lulus = $lulus;
												$jumlah_peserta_proctor_training_tidak_lulus = $tidak_lulus;
												$jumlah_peserta_proctor_training_sudah_ujian = ($lulus + $tidak_lulus);
												echo $jumlah_peserta_proctor_training;
												?>
											</td>
										</tr>
										<tr>
											<td style="width: 150px;">Sudah ujian</td>
											<td class="px-2">:</td>
											<td style="width: 45px;" class="text-monospace text-right">
												<?php echo $jumlah_peserta_proctor_training_sudah_ujian; ?>
											</td>
										</tr>
										<tr>
											<td style="width: 150px;">Lulus</td>
											<td class="px-2">:</td>
											<td style="width: 45px;" class="text-monospace text-right">
												<?php echo $jumlah_peserta_proctor_training_lulus; ?>
											</td>
										</tr>
										<tr>
											<td style="width: 150px;">Tidak Lulus</td>
											<td class="px-2">:</td>
											<td style="width: 45px;" class="text-monospace text-right">
												<?php echo $jumlah_peserta_proctor_training_tidak_lulus; ?>
											</td>
										</tr>
									</table>
									<?php } ?>
								</div>
								<div class="col-md-4">
									<?php if ($sebagai_proctor_ujian) {?>
										<div class="font-18 text-center">Proctor Ujian</div>
										<table class="font-weight-lighter font-14 w-100">
											<tr>
												<td style="width: 150px;">Total</td>
												<td class="px-2">:</td>
												<td style="width: 45px;" class="text-monospace text-right">
													<?php
													$jumlah_peserta_proctor_ujian = $_this->m_proctor->get_jumlah_peserta_proctor_ujian_kegiatan($keg, $me);
													$lulus = $_this->m_proctor->get_jumlah_peserta_proctor_ujian_kegiatan_lulus($keg, $me);
													$tidak_lulus = $_this->m_proctor->get_jumlah_peserta_proctor_ujian_kegiatan_tidak_lulus($keg, $me);
													$jumlah_peserta_proctor_ujian_lulus = $lulus;
													$jumlah_peserta_proctor_ujian_tidak_lulus = $tidak_lulus;
													$jumlah_peserta_proctor_ujian_sudah_ujian = ($lulus + $tidak_lulus);

													echo $jumlah_peserta_proctor_ujian;
													?>
												</td>
											</tr>
											<tr>
												<td style="width: 150px;">Sudah ujian</td>
												<td class="px-2">:</td>
												<td style="width: 45px;" class="text-monospace text-right">
													<?php echo $jumlah_peserta_proctor_ujian_sudah_ujian; ?>
												</td>
											</tr>
											<tr>
												<td style="width: 150px;">Lulus</td>
												<td class="px-2">:</td>
												<td style="width: 45px;" class="text-monospace text-right">
													<?php echo $jumlah_peserta_proctor_ujian_lulus; ?>
												</td>
											</tr>
											<tr>
												<td style="width: 150px;">Tidak Lulus</td>
												<td class="px-2">:</td>
												<td style="width: 45px;" class="text-monospace text-right">
													<?php echo $jumlah_peserta_proctor_ujian_tidak_lulus; ?>
												</td>
											</tr>
										</table>
										<?php
										if ($jumlah_peserta_proctor_ujian_sudah_ujian > 0)
										{
											$kelulusan = (float)($jumlah_peserta_proctor_ujian_lulus/$jumlah_peserta_proctor_ujian_sudah_ujian);
											$kelulusan = (int)($kelulusan*100);
										}
										?>
									<?php } ?>
								</div>
							</div>
						</div>
						<div class="col-md-2">
							<div class="text-center">
								<span class="font-weight-bolder">
									<span class="tingkat-kelulusan">
										<?php echo $kelulusan; ?>
									</span>%
								</span>
							</div>
							<div class="text-center">
								<div class="stars-outer">
									<div class="text-center stars-inner" data-percentage="<?php echo $kelulusan; ?>"></div>
								</div>
							</div>
							<a href="<?php echo base_url('proctor/history/'.$keg->id) ?>"
							   role="button"
							   class="d-block btn btn-light mb-2"
							   style="white-space: normal;">
								Detail
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php } ?>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('proctor/components/container_main', [ 'data' => $data]); ?>

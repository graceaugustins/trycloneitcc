<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
    <?php $this->load->view('admin/components/head'); ?>
    <title><?php if (function_exists('yield_title')) yield_title($this, $data); ?> - ITCC</title>
    <?php if (function_exists('yield_top')) yield_top($this, $data); ?>
</head>
<body>
<div class="preloader">
    <div class="lds-ripple">
        <div class="lds-pos"></div>
        <div class="lds-pos"></div>
    </div>
</div>
<div id="main-wrapper" data-theme="light" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
     data-sidebar-position="fixed" data-header-position="fixed" data-boxed-layout="full">

    <?php $this->load->view("proctor/components/navbar"); ?>
    <?php $this->load->view("proctor/components/sidebar"); ?>

    <div class="page-wrapper">
        <div class="page-breadcrumb">
            <div class="row">
                <?php if (function_exists('yield_page_header')) yield_page_header($this, $data); ?>
            </div>
        </div>

        <div class="container-fluid">
            <div class="row">
                <div class="col-12 mb-2">
                    <?php foreach(get_warning() as $n) {?>
                        <div class="alert alert-warning alert-dismissable fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                            <strong><?php echo $n; ?></strong>
                        </div>
                    <?php } clear_warning(); ?>
                </div>
                <?php if (function_exists('yield_page_content')) yield_page_content($this, $data); ?>
            </div>
        </div>
        <?php $this->load->view('admin/components/footer'); ?>
    </div>
</div>
<?php if (function_exists('yield_bottom_before_script')) yield_bottom_before_script($this, $data); ?>
<?php $this->load->view('admin/components/bottomscript'); ?>
<?php if (function_exists('yield_bottom_after_script')) yield_bottom_after_script($this, $data); ?>
</body>

</html>
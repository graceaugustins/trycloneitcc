<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><header class="topbar" data-navbarbg="skin6">
    <nav class="navbar top-navbar navbar-expand-md">
        <div class="navbar-header" data-logobg="skin6">
            <!-- This is for the sidebar toggle which is visible on mobile only -->
            <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)"><i
                    class="ti-menu ti-close"></i></a>
            <div class="navbar-brand">
                <!-- Logo icon -->
                <a href="<?php echo base_url("proctor");?>">
                    <b class="logo-icon">
                        <!-- Dark Logo icon -->
                        <img src="https://itcc.itpln.ac.id/home/wp-content/uploads/2021/12/Logo-ITCC-BARU-01.png" alt="homepage" height="45" />
                    </b>
                </a>
            </div>

            <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)"
               data-toggle="collapse" data-target="#navbarSupportedContent"
               aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i class="ti-more"></i>
            </a>
        </div>

        <div class="navbar-collapse collapse" id="navbarSupportedContent">
            <ul class="navbar-nav float-left mr-auto ml-3 pl-1"> </ul>
            <ul class="navbar-nav float-right">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="javascript:void(0)" data-toggle="dropdown"
                       aria-haspopup="true" aria-expanded="false">
                        <img src="<?php echo base_url($this->config->item('UPLOAD_PROFIL_PROCTOR')['upload_path'].$_SESSION['isProctor']['file_foto']); ?>" alt="user" class="rounded-circle" height="40">
                        <span class="ml-2 d-lg-inline-block">
                            <span class="text-dark"><?php echo $_SESSION['isProctor']['nama_lengkap']; ?></span>
                            <i data-feather="chevron-down" class="svg-icon"></i>
                        </span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right user-dd animated flipInY">
                        <a class="dropdown-item" href="<?php echo base_url('proctor/profile'); ?>">
                            <i data-feather="user" class="svg-icon mr-2 ml-1"></i>
                            Profil Saya
                        </a>

                        <a class="dropdown-item" href="<?php echo base_url('proctor/logout'); ?>">
                            <i data-feather="power" class="svg-icon mr-2 ml-1"></i>
                            Keluar
                        </a>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
</header>

<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> Absensi Training <?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col-7 align-self-center">
        <h3 class="page-title text-dark font-weight-medium mb-1">
            <?php yield_title($_this, $data); ?>
        </h3>
    </div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
<?php
/**
 * @var D_Proctor $me
 * @var D_Kegiatan $kegiatan
 * @var D_Kelompok_T $kelompok
 * */
$me = $data['me'];
$kegiatan = $data['kegiatan'];
$kelompok = $data['kelompok'];
?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h3 class="text-center">Kelompok <?php echo $kelompok->nama_kelompok; ?></h3>
                <p class="mb-4 text-center"><?php echo $kegiatan->nama_kegiatan; ?></p>
                <div class="mb-2">
                    <span class="text-info">Jumlah Peserta : <?php echo count($kelompok->list_peserta); ?> orang</span>
                    <span class="text-dark float-md-right text-right">
						Trainer (Sesi 1/ Sesi 2) : <br>
						<?php
                        if ($kelompok->id_trainer_sesi1 === $kelompok->id_trainer_sesi2)
                        {
                            if (empty($kelompok->id_trainer_sesi1)) echo 'Belum ada';
                            else echo $kelompok->trainer_sesi1;
                        }
                        else
                        {
                            if (!empty($kelompok->id_trainer_sesi1)) echo $kelompok->trainer_sesi1;
                            else {?>
								<code>Belum ada</code>
							<?php }
							echo '/';
                            if (!empty($kelompok->id_trainer_sesi2)) echo $kelompok->trainer_sesi2;
							else { ?>
								<code>Belum ada</code>
							<?php }
                        }  ?>
                    </span>
                </div>
                <form action="" method="POST">
                    <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                    <div class="table-responsive">
                        <table id="kelompok" class="table table-striped table-bordered text-center" style="white-space: normal;">
                            <thead>
                            <tr>
                                <th width="100" style="vertical-align: middle;">Foto</th>
                                <th style="vertical-align: middle;">Nama Depan</th>
                                <th style="vertical-align: middle;">Nama Belakang</th>
                                <th width="150">Training Sesi 1</th>
                                <th width="150">Training Sesi 2</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach($kelompok->list_peserta as $peserta) { ?>
                            <tr>
                                <td>
                                    <img src="<?php echo $peserta->get_link_foto_profil(); ?>" width="80">
                                </td>
                                <td class="align-middle"><?php echo $peserta->nama_depan_user; ?></td>
                                <td class="align-middle"><?php echo $peserta->nama_belakang_user; ?></td>
                                <td class="align-middle hadir-s1"><?php echo ($peserta->hadir_training_sesi1) ? 'Hadir' : 'Tidak Hadir'; ?></td>
                                <td class="align-middle hadir-s2"><?php echo ($peserta->hadir_training_sesi2) ? 'Hadir' : 'Tidak Hadir'; ?></td>
                            </tr>
                            <?php } ?>
                            </tbody>
                            <tfoot>
                            <tr>
                                <th colspan="3" class="text-right">Jumlah Hadir</th>
                                <th id="total-t-s1"></th>
                                <th id="total-t-s2"></th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div class="form-group">
                        <label for="berita"> Berita Acara Sesi 1<i>(jika ada)</i></label>
                        <textarea id="berita" name="beritaacara_t_sesi1" class="form-control" rows="3" placeholder=""><?php echo $kelompok->beritaacara_t_sesi1; ?></textarea>
                    </div>
					<div class="form-group">
						<label for="berita"> Berita Acara Sesi 2<i>(jika ada)</i></label>
						<textarea id="berita" name="beritaacara_t_sesi2" class="form-control" rows="3" placeholder=""><?php echo $kelompok->beritaacara_t_sesi2; ?></textarea>
					</div>

                    <div class="mt-2">
                        <a href="<?php echo base_url('proctor/kelompok?id_kegiatan='.$kegiatan->id); ?>" role="button" class="btn btn-link link-secondary float-left mr-auto">Kembali</a>
                        <button type="submit" class="btn btn-success float-right">Update Data</button>
                    </div>

                </form>


            </div>
        </div>

    </div>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
    <script type="text/javascript">
        $(document).ready(function(){
            let jumlah_hadir_t_s1 = 0, jumlah_hadir_t_s2 = 0;
            $('.hadir-s1').each(function(){
                if ($(this).text() === 'Hadir') jumlah_hadir_t_s1 +=1;
            });
            $('.hadir-s2').each(function(){
                if ($(this).text() === 'Hadir') jumlah_hadir_t_s2 +=1;
            });
            $('#total-t-s1').text(jumlah_hadir_t_s1);
            $('#total-t-s2').text(jumlah_hadir_t_s2);
        });
    </script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('proctor/components/container_main', [ 'data' => $data]); ?>

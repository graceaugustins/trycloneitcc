<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> User (Mahasiswa) <?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col-md-9 align-self-center">
        <h3 class="page-title text-dark font-weight-medium mb-1">
            <?php yield_title($_this, $data); ?>
        </h3>
    </div>
	<?php if(admin_capable(Permissions::TAMBAH_LIST_USER)) {?>
	<div class="col-md-3 align-self-center">
		<button class="btn btn-block btn-info" data-toggle="modal" data-target="#tambah-user">Tambah user mahasiswa</button>
	</div>
	<?php } ?>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
	<?php
	$json_data_fakultas_jurusan = $_this->config->item('FAKULTAS');
	$list_kode_jurusan = array_keys($_this->config->item('JURUSAN'));
	foreach($json_data_fakultas_jurusan as $fakultas => $list_jurusan){
		$pair_kode_jurusan_and_nama_jurusan = [];
		foreach($list_jurusan as $kode_jurusan){
			if (in_array($kode_jurusan, $list_kode_jurusan))
			{
				$pair_kode_jurusan_and_nama_jurusan[$kode_jurusan] = $_this->config->item('JURUSAN')[$kode_jurusan];
			}
			else $pair_kode_jurusan_and_nama_jurusan[$kode_jurusan] = '-';
		}
		$json_data_fakultas_jurusan[$fakultas] = $pair_kode_jurusan_and_nama_jurusan;
	}
	?>
<div class="col-12">
    <div class="card card-sm">
        <div class="card-body">
            <h3 class="card-title">Filter</h3>
            <div class="row g-2 mb-3" id="filter-data">
                <div class="col-md-2 mb-2">
                    <label class="form-label">Angkatan</label>
                    <input type="number" min="0" value="0" class="form-control filter" name="angkatan">
                </div>
				<script id="list-fakultas-jurusan" type="application/json"><?php echo json_encode($json_data_fakultas_jurusan); ?></script>
				<script id="list-jurusan-json" type="application/json"><?php echo json_encode($_this->config->item('JURUSAN')); ?></script>
				<div class="col-md-2 mb-2">
					<label class="form-label">Fakultas</label>
					<select class="custom-select text-dark filter" name="fakultas" id="list-fakultas">
						<option value="all">Semua</option>
					</select>
				</div>
				<div class="col-md-2 mb-2">
                    <label class="form-label">Program Studi</label>
                    <select class="custom-select text-dark filter" name="jurusan" id="list-jurusan">
                        <option value="all">Semua</option>
                        <?php foreach($_this->config->item('JURUSAN') as $kode => $nama) {?>
                            <option value="<?php echo $kode ?>"><?php echo $nama; ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="col-md-2 mb-2">
                    <label class="form-label">NIM</label>
                    <input type="text" class="form-control filter" name="nim">
                </div>
                <div class="col-md-2 mb-2">
                    <label class="form-label">Email</label>
                    <input type="text" class="form-control filter" name="email">
                </div>
                <div class="col-md-2 mb-2">
                    <label class="form-label">Nama Depan</label>
                    <input type="text" class="form-control filter" name="nama_depan">
                </div>
                <div class="col-md-2 mb-2">
                    <label class="form-label">Nama Belakang</label>
                    <input type="text" class="form-control filter" name="nama_belakang">
                </div>
                <div class="col-md-2 mb-2">
                    <label class="form-label">Aktif?</label>
                    <select class="custom-select text-dark filter" name="aktif">
                        <option value="all">Semua</option>
                        <option value="true">Aktif</option>
                        <option value="false">Tidak Aktif</option>
                    </select>
                </div>
                <input type="hidden" class="filter" name="first_id" value="0">
                <input type="hidden" class="filter" name="last_id" value="0">
            </div>
            <button type="button" class="btn btn-primary" id="btn-filter">Filter</button>
        </div>
    </div>
</div>
<div class="col-12">
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <select class="custom-select text-dark" id="table-count" style="width: 150px;">
                    <option value="10">10 Baris</option>
                    <option value="25">25 Baris</option>
                    <option value="50">50 Baris</option>
                    <option value="100">100 Baris</option>
                </select>
                <div class="float-right mr-2">Jumlah data : <span id="total-count" class="text-dark">0</span></div>
                <table id="user-mhs" class="mb-2 compact" style="white-space: nowrap;">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Aktif?</th>
                        <th>Email</th>
                        <th>Nama Depan</th>
                        <th>Nama Belakang</th>
                        <th>Jenis Kelamin</th>
                        <th>NIM</th>
                        <th>No. Telepon</th>
                        <th>Profil</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>Act</th>
                    </tr>
                    </thead>
                    <tbody>
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>ID</th>
                        <th>Aktif?</th>
                        <th>Email</th>
                        <th>Nama Depan</th>
                        <th>Nama Belakang</th>
                        <th>Jenis Kelamin</th>
                        <th>NIM</th>
                        <th>No. Telepon</th>
                        <th>Profil</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>Act</th>
                    </tr>
                    </tfoot>
                </table>
                <div class="float-right">
                    <button type="button" id="user-mhs_previous" class="btn btn-primary">Previous</button>
                    <button type="button" id="user-mhs_next" class="btn btn-primary">Next</button>
                </div>

            </div>
        </div>
    </div>
</div>
<?php } ?>

<?php function yield_bottom_before_script($_this, $data){?>
	<!-- Modal tambah user -->
	<?php if(admin_capable(Permissions::TAMBAH_LIST_USER)) {?>
		<div id="tambah-user" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-tambah-user" style="display: none;" aria-hidden="true">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="label-tambah-user">Tambah User Baru</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					</div>

					<form method="POST" action="<?php echo base_url('admin/user/mahasiswa/add'); ?>" enctype='multipart/form-data' >
						<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
						<div class="modal-body">
							<div class="row">
								<!-- Email -->
								<div class="col-md-6">
									<label for="add-user-email">
										Alamat email
										<small>(akun Microsoft, huruf kecil, tanpa spasi)</small>
									</label>
									<input class="form-control mb-2" id="add-user-email" type="email" name="email" required="required" placeholder="johndoe@itpln.ac.id">
								</div>
								<!-- No telepon -->
								<div class="col-md-6">
									<label for="add-user-telepon">Nomor telepon</label>
									<div class="row mb-2">
										<div class="col-2">
											<input type="text" readonly class="form-control-plaintext text-right" value="+62">
										</div>
										<div class="col-10">
											<input class="form-control mb-2" id="add-user-telepon" type="text" pattern="[0-9]+" name="no_telepon" required="required" placeholder="81234567890">
										</div>
									</div>
								</div>
								<!-- Nama Depan -->
								<div class="col-md-6">
									<label for="add-user-nama-depan">Nama depan</label>
									<input class="form-control mb-2" id="add-user-nama-depan" type="text" name="nama_depan" required="required" placeholder="John">
								</div>
								<!-- Nama Belakang -->
								<div class="col-md-6">
									<label for="add-user-nama-belakang">Nama belakang</label>
									<input class="form-control mb-2" id="add-user-nama-belakang" type="text" name="nama_belakang" required="required" placeholder="Doe">
								</div>
								<!-- Jenis Kelamin -->
								<div class="col-md-6">
									<label for="add-user-jenis-kelamin">Jenis Kelamin</label>
									<div class="form-group">
										<div class="form-check form-check-inline">
											<div class="custom-control custom-radio">
												<input type="radio" class="custom-control-input" id="r-add-user-l" name="jenis_kelamin" value="l" checked>
												<label class="custom-control-label" for="r-add-user-l">Laki-laki</label>
											</div>
										</div>
										<div class="form-check form-check-inline">
											<div class="custom-control custom-radio">
												<input type="radio" class="custom-control-input" id="r-add-user-p" name="jenis_kelamin" value="p">
												<label class="custom-control-label" for="r-add-user-p">Perempuan</label>
											</div>
										</div>
									</div>
								</div>
								<!-- NIM -->
								<div class="col-md-6">
									<label for="add-user-nim">NIM</label>
									<input class="form-control mb-2" id="add-user-nim" type="text" name="nim" required="required" placeholder="Hanya angka saja">
								</div>
								<!-- Alamat -->
								<div class="col-md-6">
									<label for="add-user-alamat">Alamat</label>
									<textarea id="add-user-alamat" required name="alamat" class="form-control" rows="3"
											  placeholder="Maksimal 200 karakter"></textarea>
								</div>
								<!-- Pas Foto -->
								<div class="col-md-6">
									<label for="add-user-foto">Upload Pas Foto 3x4</label>
									<div class="custom-file">
										<input required type="file" class="custom-file-input" id="add-user-foto" name="file_fotoprofil">
										<label class="custom-file-label" for="add-user-foto">File .jpg atau .png max 500KB</label>
									</div>
								</div>
								<!-- KTM -->
								<div class="col-md-6">
									<label for="add-user-ktm">Upload KTM</label>
									<div class="custom-file">
										<input required type="file" class="custom-file-input" id="add-user-ktm" name="file_ktm">
										<label class="custom-file-label" for="add-user-ktm">File .jpg atau .png max 500KB</label>
									</div>
								</div>
								<!-- LINE -->
								<div class="col-md-6">
									<label for="add-user-id-line">ID Line (Jika ada)</label>
									<input class="form-control mb-2" id="add-user-id-line" type="text" name="id_line" placeholder="john123_">
								</div>
								<!-- Telegram -->
								<div class="col-md-6">
									<label for="add-user-id-telegram">ID Telegram (Jika ada)</label>
									<input class="form-control mb-2" id="add-user-id-telegram" type="text" name="id_telegram" placeholder="john123_">
								</div>

								<!-- Username Certiport -->
								<div class="col-md-6">
									<label for="add-user-username-certiport">Username Certiport (Jika ada)</label>
									<input class="form-control mb-2" id="add-user-username-certiport" type="text" name="username_certiport">
								</div>
								<!-- Password Certiport -->
								<div class="col-md-6">
									<label for="add-user-password-certiport">Password Certiport (Jika ada)</label>
									<input class="form-control mb-2" id="add-user-password-certiport" type="text" name="password_certiport">
								</div>
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-success">Tambah</button>
						</div>
					</form>
				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div>
	<?php } ?>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
<script>
	let json_fakultas_jurusan = JSON.parse(document.getElementById('list-fakultas-jurusan').textContent);
	let list_fakultas = $('#list-fakultas');
	list_fakultas.html('');
	$('<option></option>').val('all').text('Semua').appendTo(list_fakultas);
	for (let fakultas in json_fakultas_jurusan)
	{
		if (json_fakultas_jurusan.hasOwnProperty(fakultas))
			$('<option></option>').val(fakultas).text(fakultas).appendTo(list_fakultas);
	}
	function refresh_fakultas_jurusan(){
		let list_fakultas = $('#list-fakultas');
		let value_fakultas = list_fakultas.val();
		let list_jurusan = $('#list-jurusan');
		let value_jurusan = list_jurusan.val();
		let json_fakultas_jurusan = JSON.parse(document.getElementById('list-fakultas-jurusan').textContent);
		let json_jurusan = JSON.parse(document.getElementById('list-jurusan-json').textContent);
		if (value_fakultas === 'all')
		{
			list_jurusan.html('');
			$('<option></option>').val('all').text('Semua').appendTo(list_jurusan);
			for (let k in json_jurusan)
			{
				if (json_jurusan.hasOwnProperty(k))
					$('<option></option>').val(k).text(json_jurusan[k]).appendTo(list_jurusan);
			}
		}
		else
		{
			list_jurusan.html('');
			$('<option></option>').val('all').text('Semua').appendTo(list_jurusan);
			if (json_fakultas_jurusan.hasOwnProperty(value_fakultas)){
				let current_fakultas = json_fakultas_jurusan[value_fakultas];
				for (let kode_jurusan in current_fakultas)
				{
					if (current_fakultas.hasOwnProperty(kode_jurusan))
					{
						$('<option></option>').val(kode_jurusan).text(current_fakultas[kode_jurusan]).appendTo(list_jurusan);
					}
				}
			}
		}
	}
	refresh_fakultas_jurusan();
	list_fakultas.on('change', function(){
		refresh_fakultas_jurusan();
	});

    var dt_config_user = dt_config;
    dt_config_user['pageLength'] = 50;
    dt_config_user['paging'] = false;
    var table = $('#user-mhs').DataTable(dt_config_user);
    var btn_next = $('#user-mhs_next');
    var btn_previous = $('#user-mhs_previous');
    function get_data(direction = 'next', reset = false){
        // ambil data filter
        let param = {};
        param['<?php echo $_this->security->get_csrf_token_name(); ?>'] = '<?php echo $_this->security->get_csrf_hash(); ?>';
        param['count'] = $('#table-count').val();
        param['direction'] = direction;
        $('#filter-data .filter').each(function(){
            param[$(this).attr('name')] = $(this).val();
        });
        if (reset)
        {
            param['first_id'] = 0;
            param['last_id'] = 0;
        }
        $.post(
            BASE_URL+'ajax/user_mhs/get',
            param
        ).done(function(resp){
			table.clear();
            if (resp.status === 'ok')
            {
                $('#filter-data .filter[name=first_id]').val(resp.data.first_id);
                $('#filter-data .filter[name=last_id]').val(resp.data.last_id);
                $('#total-count').text(resp.data.total_count);
                $(resp.data.data).each(function(){
                    let row = [];
                    row.push(this.id);
                    let val = 'YA';
                    if (this.aktif === 'n')
                        val = 'TIDAK';
                    row.push(val);
                    row.push(this.email);
                    row.push(this.nama_depan);
                    row.push(this.nama_belakang);
                    val = 'Laki-laki';
                    if (this.jenis_kelamin === 'p')
                        val = 'Perempuan';
                    row.push(val);
                    row.push(this.nim);
                    row.push('+62'+this.no_telepon);
                    row.push(`<a href="${this.file_fotoprofil}" target="_blank">Lihat</a>`);
                    val = (this.username_certiport === null) ? '-' : this.username_certiport;
                    row.push(val);
                    val = (this.password_certiport === null) ? '-' : this.password_certiport;
                    row.push(val);
                    // tombol act
                    let button = $('<div class="dropdown sub-dropdown"></div>')
                    .append('<button class="btn btn-link text-muted dropdown-toggle" type="button"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg> </button>');
                    let dropdown_menu = $('<div class="dropdown-menu dropdown-menu-right" x-placement="top-end" style="position: absolute; will-change: transform; top: 0; left: 0; transform: translate3d(-110px, -152px, 0px);"> </div>')
                    .append(`<a role="button" href="${BASE_URL+'admin/user/'+this.id}" class="dropdown-item">Detail User</a>`);
                    button.append(dropdown_menu);
                    row.push(button.html());
                    table.row.add(row);
                });
                table.draw();
            }
        });
    }
    $('#btn-filter').on('click', function(){
        get_data('next', true);
    });
    btn_next.on('click', function(){
        get_data('next');
    });
    btn_previous.on('click', function(){
        get_data('previous');
    });
</script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('admin/components/container_main', [ 'data' => $data]); ?>

<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> Update Akun Certiport <?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col-7 align-self-center">
        <h3 class="page-title text-dark font-weight-medium mb-1">
            <?php yield_title($_this, $data); ?>
        </h3>
    </div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
<div class="col-12">
    <div class="card card-sm">
        <div class="card-body">
            <h4 class="card-title">Cara menambahkan data akun login Certiport user</h4>
            <ol>
                <li class="mb-3">
                    <p>
                        Download data user yang belum memiliki akun di bawah
                        <br>(file download dalam format <code>TXT</code> tab delimited (dengan nama kolom di baris 1), terdiri 4 kolom, yaitu <code>nama_belakang</code>, <code>nama_depan</code>, <code>email</code>, dan <code>id</code>).
                    </p>
                    <div>
                        <a href="<?php echo base_url('admin/user/certiport/bulk-registration-data'); ?>" target="_blank" role="button" class="btn btn-primary">
                            Download data akun yang belum punya username & password
                        </a>
                    </div>
                </li>
                <li class="mb-3">
                    Sesuaikan data user yang baru saja di-download untuk diupload ke Certiport.
                </li>
                <li class="mb-3">
                    <p>
                        Setelah anda berhasil melakukan "<b>Bulk Registration</b>" untuk seluruh data tadi,
                        ubah file bulk registration tadi dengan ketentuan sbb :
                    </p>
                    <ul>
                        <li>Format file harus <code>CSV</code> (comma delimited).</li>
                        <li>Baris pertama memuat nama kolom (tidak langsung username dan password).</li>
                        <li>
                            Terdiri dari 4 kolom, yaitu
                            <code>id</code>, <code>email</code>, <code>username</code>, dan <code>password</code>
                            (tidak boleh typo).
                        </li>
                        <li>Format file untuk upload dapat di-download di bawah.</li>
                    </ul>
                    <div>
                        <a href="<?php echo base_url('admin/user/certiport/upload-template'); ?>" target="_blank" role="button" class="btn btn-primary">
                            Download format data akun Certiport untuk diupload ke dalam sistem ITCC
                        </a>
                    </div>

                </li>
                <li>
                    <p>
                        Upload data akun Certiport.
                        Sistem akan otomatis mengupdate username dan password sesuai email di tiap baris.
                    </p>
                    <div style="max-width : 500px;">
                        <form action="<?php echo base_url('admin/user/certiport/bulk-registration-data'); ?>" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="file_akun" name="file_akun">
                                <label class="custom-file-label" for="file_akun">File <code>.csv</code> max 2 MB</label>
                            </div>
                            <button type="submit" class="btn btn-success btn-block my-2">Upload</button>
                        </form>
                    </div>
                </li>
                <li>Jika file yang diupload terdapat email yang sudah memiliki akun sebelumnya, maka akun sebelumnya akan digantikan dengan yang baru.</li>
                <li>Perhatikan baik-baik posisi nama depan dan nama belakang dalam melakukan bulk registration.</li>
            </ol>
        </div>
    </div>
</div>
<?php } ?>

<?php function yield_bottom_before_script($_this, $data){?>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('admin/components/container_main', [ 'data' => $data]); ?>

<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> Bidang & Jabatan <?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col-7 align-self-center">
        <h3 class="page-title text-dark font-weight-medium mb-1">
            <?php yield_title($_this, $data); ?>
        </h3>
    </div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
    <?php
	/**
	 * @var D_Bidang_User_ITPLN[] $list_bidang
	 * @var D_Bidang_User_ITPLN $selected_bidang
	 * */
	$list_bidang = $data['list_bidang'];
	$selected_bidang = NULL;
	if (!empty($data['selected_bidang'])) $selected_bidang = $data['selected_bidang'];
	?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <!-- Tabs -->
                <ul class="nav nav-tabs nav-bordered mb-3">
                    <li class="nav-item">
                        <a href="#list-bidang" data-toggle="tab" class="nav-link <?php if (empty($selected_bidang)) echo "active"; ?>">
                            Bidang
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#list-jabatan" data-toggle="tab" class="nav-link <?php if (!empty($selected_bidang)) echo "active"; ?>">
                            Jabatan
                        </a>
                    </li>
                </ul>

                <div class="tab-content">
                    <div class="tab-pane <?php if (empty($selected_bidang)) echo "show active"; ?>" id="list-bidang">
                        <div class="my-2">
                            <?php if(admin_capable(Permissions::TAMBAH_LIST_BIDANG_JABATAN)) {?>
								<form method="POST" action="<?php echo base_url('admin/user/bidang_jabatan/add_bidang'); ?>" class="form-inline">
									<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
									<label for="tambah-bidang-nama" class="mr-2 mb-2">Tambah Bidang</label>
									<input class="form-control mr-2 mb-2" id="tambah-bidang-nama" type="text" name="nama_bidang" required="required">
									<button type="submit" class="btn btn-success mb-2">Tambah</button>
								</form>
                            <?php } ?>
                        </div>

                        <div class="table-responsive">
                            <table id="t-list-bidang" class="mb-2 compact">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Nama Bidang</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $i=1;
                                foreach($list_bidang as $bidang) { ?>
									<tr>
										<td>
											<?php echo $i++; ?>
											<span class="d-none id-bidang"><?php echo $bidang->id; ?></span>
										</td>
										<td><?php echo $bidang->nama_bidang; ?></td>
										<td>
											<?php if (admin_capable(Permissions::EDIT_LIST_BIDANG_JABATAN)) {?>
												<button class="btn btn-sm m-1 btn-info" data-toggle="modal" data-target="#ubah-bidang">Ubah</button>
											<?php } ?>
											<?php if (admin_capable(Permissions::HAPUS_LIST_BIDANG_JABATAN)) {?>
												<button class="btn btn-sm m-1 btn-danger" data-toggle="modal" data-target="#hapus-bidang">Hapus</button>
											<?php } ?>
										</td>
									</tr>
								<?php } ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <th>#</th>
                                    <th><input style="width:80px" type="text" ></th>
                                    <th>Action</th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>

					<div class="tab-pane <?php if (!empty($selected_bidang)) echo "show active"; ?>" id="list-jabatan">
						<div class="row">
							<div class="col-md-4">
								<form action="" method="GET">
									<select onchange="this.form.submit();" class="custom-select text-dark" required="required" name="id_bidang">
										<option value="">Pilih Bidang</option>
										<?php foreach($list_bidang as $b) { ?>
											<option value="<?php echo $b->id; ?>"
											<?php if (!empty($selected_bidang) && (int)$selected_bidang->id === (int)$b->id) echo "selected"; ?>
											>
												<?php echo html_escape($b->nama_bidang); ?>
											</option>
										<?php } ?>
									</select>
								</form>
							</div>
						</div>
						<?php if (!empty($selected_bidang)) { ?>
						<div class="my-2">
							<?php if(admin_capable(Permissions::TAMBAH_LIST_BIDANG_JABATAN)) {?>
								<form method="POST" action="<?php echo base_url('admin/user/bidang_jabatan/add_jabatan'); ?>" class="form-inline">
									<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
									<input type="hidden" name="id_bidang" value="<?php echo $selected_bidang->id; ?>">
									<label for="tambah-jabatan-nama" class="mr-2 mb-2">Tambah Jabatan</label>
									<input class="form-control mr-2 mb-2" id="tambah-jabatan-nama" type="text" name="nama_jabatan" required="required">
									<button type="submit" class="btn btn-success mb-2">Tambah</button>
								</form>
							<?php } ?>
						</div>

						<div class="table-responsive">
							<table id="t-list-jabatan" class="mb-2 compact">
								<thead>
								<tr>
									<th>#</th>
									<th>Nama Jabatan</th>
									<th>Action</th>
								</tr>
								</thead>
								<tbody>
								<?php $i=1;
								foreach($selected_bidang->list_jabatan as $jabatan) { ?>
									<tr>
										<td>
											<?php echo $i++; ?>
											<span class="d-none id-jabatan"><?php echo $jabatan->id; ?></span>
										</td>
										<td><?php echo $jabatan->nama_jabatan; ?></td>
										<td>
											<?php if (admin_capable(Permissions::EDIT_LIST_BIDANG_JABATAN)) {?>
												<button class="btn btn-sm m-1 btn-info" data-toggle="modal" data-target="#ubah-jabatan">Ubah</button>
											<?php } ?>
											<?php if (admin_capable(Permissions::HAPUS_LIST_BIDANG_JABATAN)) {?>
												<button class="btn btn-sm m-1 btn-danger" data-toggle="modal" data-target="#hapus-jabatan">Hapus</button>
											<?php } ?>
										</td>
									</tr>
								<?php } ?>
								</tbody>
								<tfoot>
								<tr>
									<th>#</th>
									<th><input style="width:80px" type="text" ></th>
									<th>Action</th>
								</tr>
								</tfoot>
							</table>
						</div>
						<?php } ?>
					</div>
                </div>
            </div>
        </div>
    </div>
<?php } ?>

<?php function yield_bottom_before_script($_this, $data) { ?>

    <!-- Modal edit data bidang -->
    <?php if(admin_capable(Permissions::EDIT_LIST_BIDANG_JABATAN)) {?>
        <div id="ubah-bidang" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-edit-bidang" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-edit-bidang">Ubah Data Bidang</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/user/bidang_jabatan/update_bidang'); ?>">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <input type="hidden" name="id">

                            <label for="ubah-bidang-nama">Nama bidang</label>
                            <input class="form-control mb-2" id="ubah-bidang-nama" type="text" name="nama_bidang" required="required">

                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Ubah</button>
                        </div>
                    </form>

                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>

    <!-- Modal hapus data bidang -->
    <?php if(admin_capable(Permissions::HAPUS_LIST_BIDANG_JABATAN)) {?>
        <div id="hapus-bidang" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-hapus-bidang" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-hapus-bidang">Anda yakin ingin menghapus bidang ini?</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/user/bidang_jabatan/delete_bidang'); ?>">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <input type="hidden" name="id">
                            <div class="mb-2">
                                Nama : <strong class="m-hapus-bidang-nama"></strong>
                            </div>
                            <div class="alert alert-warning fade show" role="alert">
                                <strong class="d-block">Bidang tidak akan dihapus jika sudah dipakai user.</strong>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-danger float-right">Hapus</button>
                        </div>
                    </form>

                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>

	<!-- Modal edit data jabatan -->
	<?php if(admin_capable(Permissions::EDIT_LIST_BIDANG_JABATAN)) {?>
		<div id="ubah-jabatan" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-edit-jabatan" style="display: none;" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="label-edit-jabatan">Ubah Data Jabatan</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					</div>

					<form method="POST" action="<?php echo base_url('admin/user/bidang_jabatan/update_jabatan'); ?>">
						<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
						<div class="modal-body">
							<input type="hidden" name="id">

							<label for="ubah-jabatan-nama">Nama jabatan</label>
							<input class="form-control mb-2" id="ubah-jabatan-nama" type="text" name="nama_jabatan" required="required">

						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-success">Ubah</button>
						</div>
					</form>

				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div>
	<?php } ?>

	<!-- Modal hapus data jabatan -->
	<?php if(admin_capable(Permissions::HAPUS_LIST_BIDANG_JABATAN)) {?>
		<div id="hapus-jabatan" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-hapus-jabatan" style="display: none;" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="label-hapus-jabatan">Anda yakin ingin menghapus jabatan ini?</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					</div>

					<form method="POST" action="<?php echo base_url('admin/user/bidang_jabatan/delete_jabatan'); ?>">
						<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
						<div class="modal-body">
							<input type="hidden" name="id">
							<div class="mb-2">
								Nama : <strong class="m-hapus-jabatan-nama"></strong>
							</div>
							<div class="alert alert-warning fade show" role="alert">
								<strong class="d-block">Jabatan tidak akan dihapus jika sudah dipakai user.</strong>
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-danger float-right">Hapus</button>
						</div>
					</form>

				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div>
	<?php } ?>

<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
    <script type="text/javascript">
        let t_list_bidang = setupTable('#t-list-bidang');
        let t_list_jabatan = setupTable('#t-list-jabatan');

        $('#ubah-bidang').on('show.bs.modal', function (event) {
            let button = $(event.relatedTarget); // Button that triggered the modal
            var modal = $(this);
            let p = button.parent().parent();
            modal.find('.modal-body input[name=id]').val(p.find('td:eq(0) .id-bidang').text());
            modal.find('.modal-body input[name=nama_bidang]').val(p.children('td:eq(1)').text());
        });

        $('#hapus-bidang').on('show.bs.modal', function (event) {
            let button = $(event.relatedTarget); // Button that triggered the modal
            var modal = $(this);
            let p = button.parent().parent();
			modal.find('.modal-body input[name=id]').val(p.find('td:eq(0) .id-bidang').text());
            modal.find('.modal-body .m-hapus-bidang-nama').text(p.children('td:eq(1)').text());
        });

		$('#ubah-jabatan').on('show.bs.modal', function (event) {
			let button = $(event.relatedTarget); // Button that triggered the modal
			var modal = $(this);
			let p = button.parent().parent();
			modal.find('.modal-body input[name=id]').val(p.find('td:eq(0) .id-jabatan').text());
			modal.find('.modal-body input[name=nama_jabatan]').val(p.children('td:eq(1)').text());
		});

		$('#hapus-jabatan').on('show.bs.modal', function (event) {
			let button = $(event.relatedTarget); // Button that triggered the modal
			var modal = $(this);
			let p = button.parent().parent();
			modal.find('.modal-body input[name=id]').val(p.find('td:eq(0) .id-jabatan').text());
			modal.find('.modal-body .m-hapus-jabatan-nama').text(p.children('td:eq(1)').text());
		});

    </script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('admin/components/container_main', [ 'data' => $data]); ?>

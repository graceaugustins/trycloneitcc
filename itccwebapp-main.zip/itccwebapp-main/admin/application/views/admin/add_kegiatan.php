<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php function yield_title($_this, $data){?> Adakan Kegiatan Baru <?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col-md-8 align-self-center">
        <h3 class="page-title text-dark font-weight-medium mb-1">
            <?php yield_title($_this, $data); ?>
        </h3>
    </div>
    <div class="col-md-4 align-self-center">
        <a role="button" href="<?php echo base_url('admin/sertifikasi/kegiatan'); ?>" class="btn btn-light float-right mr-md-4">
            Batal
        </a>
    </div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
	<?php
	/** @var D_Sertifikasi[] $list_sertifikasi */
	$list_sertifikasi = $data['list_sertifikasi'];
	?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo base_url('admin/sertifikasi/kegiatan/add_kegiatan'); ?>" method="POST" id="form-tambah-kegiatan" enctype='multipart/form-data'>
                    <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                    <input type="hidden" name="kriteria_peserta">
                    <input type="hidden" name="kriteria_diskon">
                    <input type="hidden" name="kriteria_peserta_boleh_ujian_saja">
                    <div class="row g-2">
                        <!-- Deskripsi Kegiatan -->
                        <div class="col-md-6">
                            <p class="font-weight-bolder">Deskripsi Kegiatan</p>
                            <!-- Nama Kegiatan -->
                            <div class="form-group row ">
                                <label class="col-sm-4 col-form-label">
                                    Nama Kegiatan <span class="text-danger">*</span>
                                </label>
                                <input required name="nama_kegiatan" type="text" class="col-sm-8 form-control" placeholder="maks. 100 karakter, cth: MOS Angkatan 2019 Gel. 1"
                                        value="">
                            </div>
                            <!-- Biaya T & U -->
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">
                                    Biaya Pendaftaran <span class="text-danger">*</span>
                                    <br><small>(training & ujian)</small>
                                </label>
                                <input required name="biaya_t_u" type="number" class="col-sm-8 form-control" min="0"
                                       value="0">
                            </div>
                            <!-- Biaya U -->
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">
                                    Biaya Pendaftaran <span class="text-danger">*</span>
                                    <br><small>(ujian saja)</small>
                                </label>
                                <input required name="biaya_u" type="number" class="col-sm-8 form-control" min="0"
                                       value="0">
                            </div>
                            <!-- Deskripsi Kegiatan -->
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">
                                    Deskripsi Singkat Kegiatan <span class="text-danger">*</span>
                                </label>
                                <textarea required name="deskripsi" class="col-sm-8 form-control" rows="3"
                                          placeholder="Maksimal 300 karakter"></textarea>
                            </div>
                            <!-- Sertifikasi -->
							<script id="list-sertifikasi-program" type="application/json"><?php echo json_encode($list_sertifikasi); ?></script>
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">Sertifikasi<span class="text-danger">*</span></label>
                                <select name="id_sertifikasi" class="col-sm-8 custom-select text-body" id="dropdown-sertifikasi" required
                                        data-id-sertifikasi="">
                                    <option value="">Pilih</option>
                                </select>
                            </div>
                            <!-- Program Sertifikasi -->
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">
                                    Program Sertifikasi<span class="text-danger">*</span>
                                    <br><small>(minimal 1)</small>
                                </label>
                                <div class="col-sm-8">
                                    <div class="row" id="checkbox-program"></div>
                                </div>
                            </div>
                            <!-- Berita Acara Training -->
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">Berita Acara Training<span class="text-danger">*</span></label>
                                <textarea name="keterangan_training" required class="col-sm-8 form-control" rows="3"
                                          placeholder="Maksimal 250 karakter"></textarea>
                            </div>
                            <!-- Berita Acara Ujian -->
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">Berita Acara Ujian<span class="text-danger">*</span></label>
                                <textarea name="keterangan_ujian" required class="col-sm-8 form-control" rows="3"
                                          placeholder="Maksimal 250 karakter"></textarea>
                            </div>
                            <!-- Link Grup -->
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">
                                    Link Grup<span class="text-danger">*</span>
                                    <br><small>(wajib ada <code>http://</code> atau <code>https://</code>)</small>
                                </label>
                                <input required name="link_grup" type="text" class="col-sm-8 form-control" placeholder="Link untuk peserta join"
                                       value="">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <!-- Periode Registrasi -->
                            <div class="mb-2" id="panel-periode-registrasi">
                                <p class="font-weight-bolder">Periode Registrasi</p>
                                <!-- Pendaftaran dibuka -->
                                <label class="d-block">
                                    <input type="checkbox" name="pendaftaran_dibuka">
                                    Pendaftaran dibuka
                                </label>
                                <!-- Awal registrasi -->
                                <label>Dari</label>
                                <div class="row">
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <input name="awal_regis_date" type="date" class="form-control"
                                                   value="">
                                        </div>
                                    </div>
                                    <div class="col-md-7 row">
                                        <div class="col-9">
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <input name="awal_regis_time" type="text" class="form-control bootstrap-timepicker"
                                                           value="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-3 form-group align-self-center">
                                            WIB
                                        </div>
                                    </div>
                                </div>
                                <!-- Akhir Registrasi -->
                                <label>Sampai</label>
                                <div class="row">
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <input name="selesai_regis_date" type="date" class="form-control"
                                                   value="">
                                        </div>
                                    </div>
                                    <div class="col-md-7 row">
                                        <div class="col-9">
                                            <div class="form-group">
                                                <input name="selesai_regis_time" type="text" class="form-control bootstrap-timepicker"
                                                       value="">
                                            </div>
                                        </div>
                                        <div class="col-3 form-group align-self-center">
                                            WIB
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Batas Upload Bukti Bayar -->
                            <div class="mb-2" id="section-batas-upload-bukti-bayar">
                                <p class="font-weight-medium">Batas Upload Bukti Bayar<span class="text-danger">*</span></p>
                                <div class="row">
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <input required name="batas_upload_bukti_bayar_date" type="date" class="form-control"
                                                   value="">
                                        </div>
                                    </div>
                                    <div class="col-md-7 row">
                                        <div class="col-9">
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <input required name="batas_upload_bukti_bayar_time" type="text" class="form-control bootstrap-timepicker"
                                                           value="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-3 form-group align-self-center">
                                            WIB
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Periode Persiapan -->
                            <div class="mb-2">
                                <p class="font-weight-bolder">Periode Persiapan </p>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Dari <span class="text-danger">*</span></label>
                                            <input required name="awal_persiapan" type="date" class="form-control"
                                                   value="">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Sampai <span class="text-danger">*</span></label>
                                            <input required name="selesai_persiapan" type="date" class="form-control"
                                                   value="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Periode Pelaporan -->
                            <div class="mb-2">
                                <p class="font-weight-bolder">Periode Pelaporan </p>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Dari <span class="text-danger">*</span></label>
                                            <input required name="awal_pelaporan" type="date" class="form-control"
                                                   value="">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Sampai <span class="text-danger">*</span></label>
                                            <input required name="selesai_pelaporan" type="date" class="form-control"
                                                   value="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12"><hr></div>

                        <!-- Peserta sertifikasi-->
                        <div class="col-12 my-4">
                            <p class="font-weight-bolder">Peserta Sertifikasi</p>
                            <div class="row">
                                <label class="col-md-2 ">Dibuka untuk <span class="text-danger">*</span></label>
                                <div class="col-md-10 form-group pl-md-0">
                                    <div class="form-check form-check-inline">
                                        <div class="custom-control custom-radio">
                                            <input type="radio" class="custom-control-input" id="radio-dibukauntuk-mahasiswa" name="dibuka_untuk" value="<?php echo General_Constants::MAHASISWA; ?>" checked>
                                            <label class="custom-control-label" for="radio-dibukauntuk-mahasiswa">Mahasiswa IT-PLN</label>
                                        </div>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <div class="custom-control custom-radio">
                                            <input type="radio" class="custom-control-input" id="radio-dibukauntuk-umum" name="dibuka_untuk" value="<?php echo General_Constants::UMUM; ?>">
                                            <label class="custom-control-label" for="radio-dibukauntuk-umum">Umum</label>
                                        </div>
                                    </div>
									<div class="form-check form-check-inline">
										<div class="custom-control custom-radio">
											<input type="radio" class="custom-control-input" id="radio-dibukauntuk-itpln" name="dibuka_untuk" value="<?php echo General_Constants::ITPLN; ?>">
											<label class="custom-control-label" for="radio-dibukauntuk-itpln">IT-PLN</label>
										</div>
									</div>
                                </div>
                            </div>
                            <div id="kriteria-peserta-mhs">
                                <div class="alert alert-light" role="alert">
                                    <ol>
                                        <li>
                                            Contoh kriteria : <code>2020|Semua| 0</code>
                                            <br>
                                            Artinya kegiatan dibuka untuk angkatan 2020 semua jurusan
                                        </li>
                                        <li>
                                            Contoh kriteria : <code>0|Semua| 0</code>
                                            <br>
                                            Artinya kegiatan dibuka untuk semua angkatan & semua jurusan
                                        </li>
                                        <li>
                                            Contoh kriteria : <code>2016|S1 T. Informatika| 1 </code>
                                            <br>
                                            Artinya kegiatan dibuka untuk mahasiswa angkatan 2016 S1 Informatika index 001 <br>
                                            (NIM 201631001)
                                        </li>
                                        <li>Jika kriteria tidak diberikan, maka kegiatan dibuka untuk semua jurusan, semua angkatan, semua index</li>
                                        <li>
                                            Jika peserta adalah mahasiswa dan tidak termasuk kriteria, kegiatan ini tidak akan
                                            muncul di dashboardnya.
                                        </li>
                                    </ol>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <button type="button" class="btn btn-primary btn-sm m-2" id="btn-tambah-kriteria-regis-mhs">Tambah Kriteria Peserta</button>
                                    </div>
                                    <div class="col-12">
                                        <div class="table-responsive">
                                            <table class=" table table-sm table-striped" id="tbl-tambah-kriteria-regis-mhs" style="max-width: 700px;">
                                                <thead>
                                                <tr>
                                                    <th>Angkatan</th>
                                                    <th>Jurusan</th>
                                                    <th>Index</th>
                                                    <th>Action</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>

                            <div id="kriteria-peserta-umum">
                                <div class="alert alert-light" role="alert">
                                    <ol>
                                        <li>
                                            Contoh kriteria : <code>Instansi | Semua</code>
                                            <br>
                                            Artinya kegiatan dibuka untuk semua instansi
                                            <br>
                                            (user yang tidak terhubung ke instansi manapun tidak bisa mendaftar)
                                        </li>
                                        <li>
                                            Contoh kriteria : <code>Instansi | Instansi A</code>
                                            <br>
                                            Artinya kegiatan dibuka untuk semua user yang terhubung ke <code>Instansi A</code>
                                            <br>
                                            (user yang tidak terhubung ke <code>Instansi A</code> tidak bisa mendaftar)
                                        </li>
                                        <li>
                                            Contoh kriteria : <code>User | Semua</code>
                                            <br>
                                            Artinya kegiatan dibuka untuk semua user umum
                                        </li>
                                        <li>
                                            Contoh kriteria : <code>User | john.doe@gmail.com</code>
                                            <br>
                                            Artinya kegiatan dibuka untuk user dengan email <code>john.doe@gmail.com</code>
                                        </li>
                                        <li>Jika kriteria tidak diberikan, maka kegiatan dibuka untuk semua user umum.</li>
                                        <li>
                                            Jika user tidak termasuk kriteria ini, maka kegiatan ini tidak akan
                                            muncul di dashboardnya.
                                        </li>
                                    </ol>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <button type="button" class="btn btn-primary btn-sm m-2" id="btn-tambah-kriteria-regis-umum">Tambah Kriteria Peserta</button>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="table-responsive">
                                            <table class=" table table-sm table-striped" id="tbl-tambah-kriteria-regis-umum" style="max-width: 700px;">
                                                <thead>
                                                <tr>
                                                    <th>Tipe</th>
                                                    <th>Data</th>
                                                    <th class="text-center">Semua</th>
                                                    <th class="text-center">Action</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>

							<div id="kriteria-peserta-itpln">
								<div class="alert alert-light" role="alert">
									Upload data peserta kegiatan dapat dilakukan setelah kegiatan berhasil dibuat.
								</div>
							</div>
                        </div>
                        <div class="col-12"><hr></div>

                        <!-- Peserta yang boleh ujian saja-->
                        <div class="col-12 my-4" id="panel-kriteria-peserta-ujian-saja">
                            <p class="font-weight-bolder">Kriteria Peserta yang Boleh memilih Ujian Saja</p>
                            <div class="alert alert-light" role="alert">
                                <ol>
                                    <li>
                                        Data yang diinput adalah email calon peserta yang diperbolehkan untuk mengikuti ujian saja
                                        <br>
                                        (tidak perlu mengikuti training)
                                    </li>
                                    <li>
                                        Jika User memenuhi kriteria peserta, dan juga memenuhi kriteria boleh memilih
                                        ujian saja, maka akan muncul 2 pilihan ketika registrasi, yaitu <code>Training & Ujian</code>
                                        dan <code>Ujian Saja</code>.
                                    </li>
                                    <li>
                                        <b>Ini tidak sama dengan kriteria peserta</b>. Jika seorang user ada dalam list ini, namun dia
                                        tidak memenuhi kriteria peserta, maka dia tetap tidak bisa mendaftar.
                                    </li>
                                </ol>
                            </div>
                            <div class="row">
                                <div class="col-12 mb-2">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <input class="form-control search-user" type="text" id="search-user-nama-depan" placeholder="Nama Depan">
                                                </div>
                                                <div class="col-md-4">
                                                    <input class="form-control search-user" type="text" id="search-user-nama-belakang" placeholder="Nama Belakang">
                                                </div>
                                                <div class="col-md-4">
                                                    <input class="form-control search-user" type="text" id="search-user-email" placeholder="Email">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div style="height: 250px;overflow-y: scroll;">
                                        <div class="table-responsive w-100">
                                            <table class="w-100 table table-sm table-bordered" id="search-user-boleh-ujian-result">
                                                <thead>
                                                <tr>
                                                    <th>Nama Depan</th>
                                                    <th>Nama Belakang</th>
                                                    <th>Email</th>
                                                    <th></th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="table-responsive w-100" style="height: 250px;overflow-y: scroll;">
                                        <table class="w-100 table table-sm table-bordered" id="search-user-boleh-ujian-selected">
                                            <thead>
                                            <tr>
                                                <th>Nama Depan</th>
                                                <th>Nama Belakang</th>
                                                <th>Email</th>
                                                <th></th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="col-12"><hr></div>

                        <!-- Potongan Harga-->
                        <div class="col-12 my-4" id="panel-kriteria-diskon">
                            <p class="font-weight-bolder">Potongan Harga</p>

                            <div class="alert alert-light" role="alert">
                                <ol>
                                    <li>
                                        Jika sertifikasi diadakan untuk umum, maka tidak perlu menambahkan diskon mahasiswa
                                    </li>
                                    <li>
                                        Value adalah nilai diskon. <br>
                                        Cth : Jenis potongan adalah 'Nominal' dan value adalah 10000, maka potongannya adalah Rp 10.000,00 <br>
                                        Cth : Jenis potongan adalah 'Persen' dan value adalah 10, maka potongannya adalah 10%
                                    </li>
                                </ol>
                            </div>

                            <div class="row">
                                <div class="col-12">
                                    <button type="button" class="btn btn-primary btn-sm m-2 float-right" id="btn-tambah-diskon">Tambah Potongan Harga</button>
                                </div>
                                <div class="col-12" id="list-potongan-harga">
                                </div>
                            </div>

                        </div>
                        <div class="col-12"><hr></div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-block btn-success">Tambah Kegiatan Sertifikasi</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
<?php $_this->load->view("admin/components/kriteria_registrasi_diskon_ujiansaja"); ?>
<script type="text/javascript">
	const list_sertifikasi_program = JSON.parse(document.getElementById('list-sertifikasi-program').textContent);
    var daftar_instansi = null;
    var dropdown_list_sertif = $('#dropdown-sertifikasi');
    var checkbox_program = $('#checkbox-program');
    var table_tambah_kriteria_regis_mhs = $('#tbl-tambah-kriteria-regis-mhs');
    var table_tambah_kriteria_regis_umum = $('#tbl-tambah-kriteria-regis-umum');
    var list_potongan_harga = $('#list-potongan-harga');
    var form_tambah_kegiatan = $('#form-tambah-kegiatan');

    var table_search_user_boleh_ujian_saja = $('#search-user-boleh-ujian-result');
    var table_selected_user_boleh_ujian_saja = $('#search-user-boleh-ujian-selected');

    $(document).ready(function(){
        checkbox_program.html('');

		$(list_sertifikasi_program).each(function(){
			$('<option></option>').val(this.id).text(this.nama).appendTo(dropdown_list_sertif);
		});
		let id_sertifikasi = dropdown_list_sertif.data('id-sertifikasi');
		dropdown_list_sertif.val(id_sertifikasi);
		refresh_program_sertifikasi(id_sertifikasi);

        // ambil daftar instansi
        let param_ajax_instansi = get_param_ajax();
        $.post(
            BASE_URL+'ajax/instansi/get_all',
            param_ajax_instansi
        ).done(function(data){
            if (data.status !== 'ok')
            {
                alert(`Terjadi kesalahan dalam mengambil data instansi : ${data.message}`);
                return;
            }
            daftar_instansi = data.data;
        });
    });

	function refresh_program_sertifikasi(val)
	{
		checkbox_program.html('');
		$(list_sertifikasi_program).each(function(){
			// cari value di object
			// yang sesuai dengan value dropdown
			if (parseInt(this.id) === parseInt(val))
			{
				$(this.list_program).each(function(){
					let container = $('<div class="col-md-6 form-check mb-1"></div>');
					let label = $('<label class="form-check-label"></label>');
					label.append(`<input class="form-check-input" type="checkbox" name="id_program[]" value="${this.id}">`).append(`<span class="ml-1">${this.nama_program}</span>`);
					container.append(label);
					checkbox_program.append(container);
				});
			}
		});
	}

	// ubah daftar program ketika dropdown
	// sertifikasi diganti
	dropdown_list_sertif.on('change', function(){
		let val = $(this).val();
		refresh_program_sertifikasi(val);
	});

    function disable_upload_bukti_bayar()
	{
		let value = $('input[name=dibuka_untuk]:checked').val();
		if (value === 'itpln') return;
		let biaya_u = $("form input[name=biaya_u]");
		let biaya_t_u = $("form input[name=biaya_t_u]");
		if (parseInt(biaya_u.val()) === 0 && parseInt(biaya_t_u.val()) === 0)
		{
			$("#section-batas-upload-bukti-bayar").addClass("d-none");
			$("form input[name=batas_upload_bukti_bayar_date], form input[name=batas_upload_bukti_bayar_time]")
					.prop("required", false)
					.val("");
		}
		else
		{
			$("#section-batas-upload-bukti-bayar").removeClass("d-none");
			$("form input[name=batas_upload_bukti_bayar_date], form input[name=batas_upload_bukti_bayar_time]")
					.prop("required", true);
		}
	}
	disable_upload_bukti_bayar();
    $("form input[name=biaya_u], form input[name=biaya_t_u]").on("change", function(){
		disable_upload_bukti_bayar();
	});

    // kalau user klik tombol tambah kriteria peserta untuk mahasiswa
    $('#btn-tambah-kriteria-regis-mhs').on('click', function(){
        tambah_row_kriteria_regis_mhs(this, table_tambah_kriteria_regis_mhs);
    });

    // kalau user klik tombol tambah kriteria peserta untuk umum
    $('#btn-tambah-kriteria-regis-umum').on('click', function () {
        tambah_row_kriteria_regis_umum(this, table_tambah_kriteria_regis_umum);
    });

    // Klik tombol tambah diskon
    $('#btn-tambah-diskon').on('click', function(){
        tambah_diskon(this, list_potongan_harga, $('input[name=dibuka_untuk]:checked').val());
    });

    // update form tergantung radio button
    // apakah sertifikasi untuk umum atau mhs
    function refresh_dibuka_untuk(){
    	let value = $('input[name=dibuka_untuk]:checked').val();
        if ( value === 'mahasiswa')
        {
            $('.disc-mahasiswa').each(function(){
                $(this).removeClass('d-none');
            });
            $('.disc-umum').each(function(){
                $(this).addClass('d-none');
            });
            $('#kriteria-peserta-mhs').removeClass('d-none');
            $('#kriteria-peserta-umum').addClass('d-none');
			$('#kriteria-peserta-itpln').addClass('d-none');
			$('.search-user').trigger('keyup');
			$('#panel-kriteria-peserta-ujian-saja').removeClass('d-none');
			$('#panel-kriteria-diskon').removeClass('d-none');
			$('#panel-periode-registrasi')
					.removeClass('d-none')
					.find('input[name=awal_regis_date], input[name=awal_regis_time], input[name=selesai_regis_date], input[name=selesai_regis_time]')
					.prop('required', true);
			$("#section-batas-upload-bukti-bayar").removeClass("d-none");
			$("form input[name=batas_upload_bukti_bayar_date], form input[name=batas_upload_bukti_bayar_time]")
					.prop("required", true);
        }
        else if (value === 'umum')
        {
            $('.disc-mahasiswa').each(function(){
                $(this).addClass('d-none');
            });
            $('.disc-umum').each(function(){
                $(this).removeClass('d-none');
            });
            $('#kriteria-peserta-mhs').addClass('d-none');
            $('#kriteria-peserta-umum').removeClass('d-none');
			$('#kriteria-peserta-itpln').addClass('d-none');
			$('.search-user').trigger('keyup');
			$('#panel-kriteria-peserta-ujian-saja').removeClass('d-none');
			$('#panel-kriteria-diskon').removeClass('d-none');
			$('#panel-periode-registrasi')
					.removeClass('d-none')
					.find('input[name=awal_regis_date], input[name=awal_regis_time], input[name=selesai_regis_date], input[name=selesai_regis_time]')
					.prop('required', true);
			$("#section-batas-upload-bukti-bayar").removeClass("d-none");
			$("form input[name=batas_upload_bukti_bayar_date], form input[name=batas_upload_bukti_bayar_time]")
					.prop("required", true);
        }
        else if (value === 'itpln')
		{
			$('.disc-mahasiswa').each(function(){
				$(this).addClass('d-none');
			});
			$('.disc-umum').each(function(){
				$(this).addClass('d-none');
			});
			$('#kriteria-peserta-mhs').addClass('d-none');
			$('#kriteria-peserta-umum').addClass('d-none');
			$('#kriteria-peserta-itpln').removeClass('d-none');
			$('#panel-kriteria-peserta-ujian-saja').addClass('d-none');
			$('#panel-kriteria-diskon').addClass('d-none');
			$('#panel-periode-registrasi')
					.addClass('d-none')
					.find('input[name=awal_regis_date], input[name=awal_regis_time], input[name=selesai_regis_date], input[name=selesai_regis_time]')
					.prop('required', false);
			$("#section-batas-upload-bukti-bayar").addClass("d-none");
			$("form input[name=batas_upload_bukti_bayar_date], form input[name=batas_upload_bukti_bayar_time]")
					.prop("required", false)
					.val("");
		}
    }
    refresh_dibuka_untuk();
    $('input[name=dibuka_untuk]').on('click', refresh_dibuka_untuk);

    // user ketik nama di kriteria peserta yang boleh
    // ikut ujian saja
    $('.search-user').on('keyup', function(){
        let nama_depan = $('#search-user-nama-depan').val();
        let nama_belakang = $('#search-user-nama-belakang').val();
        let email = $('#search-user-email').val();
        fill_search_user(
        		this,
				table_search_user_boleh_ujian_saja,
				table_selected_user_boleh_ujian_saja,
				$('input[name=dibuka_untuk]:checked').val(),
				nama_depan,
				nama_belakang,
				email
		);
    });

    // proses submit form tambah kegiatan
    form_tambah_kegiatan.on('submit', function(event){
        event.preventDefault();

        let dibuka_untuk = $('input[name=dibuka_untuk]:checked').val();
        let kriteria_peserta = parse_kriteria_peserta(this, dibuka_untuk, table_tambah_kriteria_regis_mhs, table_tambah_kriteria_regis_umum);
        let kriteria_peserta_boleh_ujian_saja = parse_kriteria_ujian_saja(this, table_selected_user_boleh_ujian_saja);
        let kriteria_diskon = parse_kriteria_diskon(this, list_potongan_harga, dibuka_untuk);

        if (kriteria_diskon !== null)
        {
            $('input[name=kriteria_peserta]', this).val(JSON.stringify(kriteria_peserta));
            $('input[name=kriteria_peserta_boleh_ujian_saja]', this).val(JSON.stringify(kriteria_peserta_boleh_ujian_saja));
            $('input[name=kriteria_diskon]', this).val(JSON.stringify(kriteria_diskon));
            this.submit();
        }
    });
</script>
<?php unset($_SESSION['show_program_immediately']); ?>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('admin/components/container_main', [ 'data' => $data]); ?>

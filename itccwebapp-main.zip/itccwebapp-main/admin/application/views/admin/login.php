<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon icon -->
	<link rel="icon" href="https://itcc.itpln.ac.id/home/wp-content/uploads/2021/12/200pxl-01.png" sizes="32x32" />
    <title>Login Administrator - ITCC</title>
    <!-- Custom CSS -->
    <link href="<?php echo base_url("assets/dist/css/style.min.css");?>" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>
    <div class="main-wrapper">
        
        <div class="preloader">
            <div class="lds-ripple">
                <div class="lds-pos"></div>
                <div class="lds-pos"></div>
            </div>
        </div>
        
        <div class="auth-wrapper d-flex no-block justify-content-center align-items-center position-relative"
            style="background:url(<?php echo base_url("assets/images/big/auth-bg3.jpg"); ?>) no-repeat center center;background-size: cover;">
            <div class="auth-box row" style="min-width: 60%;box-shadow: 0 3px 9px 0 rgba(162,176,190, 0.60)">
                <div class="col-md-6 modal-bg-img" style="background-image: url(<?php echo base_url("assets/images/big/4.jpg");?>);">
                </div>
                <div class="col-md-6 bg-white py-3">
                    <div class="p-3">
                        <div class="text-center">
                            <img style="width: auto;height: auto;max-width: 100%;" src="https://itcc.itpln.ac.id/home/wp-content/uploads/2022/01/Logo-ITCC-.png" alt="wrapkit">
                        </div>
                        <h2 class="mt-3 text-center text-dark">Masuk Sebagai Admin ITCC</h2>
                        <button class="btn btn-block btn-light mt-4" onclick="window.location.href='<?php echo base_url('msauth/signin?login_type=admin&next='.$next); ?>'">
                            <img src="<?php echo base_url("assets/images/login-microsoft.png");?>" width="180px;" style="display:block;margin:10px auto;max-width: 100%;">
                            Masuk Menggunakan Akun Microsoft
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
    </div>

    <script src="<?php echo base_url("assets/libs/jquery/dist/jquery.min.js");?>"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?php echo base_url("assets/libs/popper.js/dist/umd/popper.min.js");?>"></script>
    <script src="<?php echo base_url("assets/libs/bootstrap/dist/js/bootstrap.min.js");?>"></script>
    <script>
        $(".preloader ").fadeOut();
    </script>
</body>

</html>

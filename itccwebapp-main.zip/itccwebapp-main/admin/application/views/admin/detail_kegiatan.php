<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php function yield_title($_this, $data){?>
	<?php
	/** @var D_Kegiatan $kegiatan */
	$kegiatan = $data['kegiatan'];
	?>
    Detail Kegiatan - <?php echo html_escape($kegiatan->nama_kegiatan); ?>
<?php } ?>
<?php function yield_page_header($_this, $data){?>
	<?php
	/** @var D_Kegiatan $kegiatan */
	$kegiatan = $data['kegiatan'];
	/** @var bool $is_history */
	$is_history = $data['history'];
	?>
    <div class="col-md-9 align-self-center">
        <div class="row">
            <div class="col-auto pr-0 ">
                <img src="<?php echo $kegiatan->sertifikasi->get_link_logo(); ?>" width="50" alt="logo">
            </div>
            <div class="col">
                <h3 class="page-title text-dark font-weight-medium mb-1"><?php echo html_escape($kegiatan->nama_kegiatan); ?></h3>
                <p class="text-muted"><?php echo html_escape($kegiatan->sertifikasi->nama); ?></p>
            </div>
        </div>
    </div>
	<?php if (!$is_history){ ?>
    <div class="col-md-3 align-self-center">
        <a role="button" href="<?php echo base_url("admin/sertifikasi/kegiatan/".$kegiatan->id."/ubah"); ?>" class="btn btn-light btn-block">Ubah</a>
    </div>
	<?php } ?>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
	<?php
	/** @var D_Kegiatan $kegiatan */
	$kegiatan = $data['kegiatan'];
	/** @var bool $is_history */
	$is_history = $data['history'];
	$kegiatan_dibuka_untuk_itpln = $kegiatan->dibuka_untuk === General_Constants::ITPLN;
	$kegiatan_dibuka_untuk_mahasiswa = $kegiatan->dibuka_untuk === General_Constants::MAHASISWA;
	?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <span class="d-none">
                    <span id="id-kegiatan"><?php echo $kegiatan->id; ?></span>
                    <span id="dibuka-untuk"><?php echo $kegiatan->dibuka_untuk; ?></span>
                </span>
                <!-- Summary -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-12"><h4 class="card-title mb-3">Tanggal</h4></div>
                        </div>
						<div class="row mb-2">
							<div class="col-md-4 text-muted">
								Registrasi
							</div>
							<div class="col-md-8 text-dark">
								<?php if (!empty($kegiatan->awal_registrasi) && !empty($kegiatan->akhir_registrasi)) { ?>
									<?php echo tgl_indo($kegiatan->awal_registrasi->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE); ?>
									s/d
									<?php echo tgl_indo($kegiatan->akhir_registrasi->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE); ?>
								<?php } else { ?>
									-
								<?php } ?>
							</div>
						</div>
                        <div class="row mb-2">
                            <div class="col-md-4 text-muted">
                                Persiapan
                            </div>
                            <div class="col-md-8 text-dark">
                                <?php echo tgl_indo($kegiatan->awal_persiapan->format('Y-m-d'), 'Y-m-d', TRUE); ?>
                                s/d
                                <?php echo tgl_indo($kegiatan->akhir_persiapan->format('Y-m-d'), 'Y-m-d', TRUE); ?>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-md-4 text-muted">
                                Training
                            </div>
                            <div class="col-md-8 text-dark">
								<?php
								$max_date = DateTime::createFromFormat('Y-m-d', '2099-12-31');
								$min_date = DateTime::createFromFormat('Y-m-d', '1980-01-01');
								$awal_training = DateTime::createFromFormat('Y-m-d', '2099-12-31');
								$akhir_training = DateTime::createFromFormat('Y-m-d', '1980-01-01');
								foreach($kegiatan->list_kelompok_training as $kelompok_t)
								{
									if (!empty($kelompok_t->mulai_training))
										$awal_training = min($awal_training, $kelompok_t->mulai_training);
									if (!empty($kelompok_t->selesai_training))
										$akhir_training = max($akhir_training, $kelompok_t->selesai_training);
								}
								if ($awal_training == $max_date || $akhir_training == $min_date)
									echo "- (Belum dapat ditentukan)";
								else
								{
									echo tgl_indo($awal_training->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
									echo " s/d ";
									echo tgl_indo($akhir_training->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
								}
								?>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-md-4 text-muted">
                                Ujian
                            </div>
                            <div class="col-md-8 text-dark">
								<?php
								$max_date = DateTime::createFromFormat('Y-m-d', '2099-12-31');
								$min_date = DateTime::createFromFormat('Y-m-d', '1980-01-01');
								$awal_ujian = DateTime::createFromFormat('Y-m-d', '2099-12-31');
								$akhir_ujian = DateTime::createFromFormat('Y-m-d', '1980-01-01');
								foreach($kegiatan->list_kelompok_ujian as $kelompok_u)
								{
									if (!empty($kelompok_u->mulai_ujian))
										$awal_ujian = min($awal_ujian, $kelompok_u->mulai_ujian);
									if (!empty($kelompok_u->selesai_ujian))
										$akhir_ujian = max($akhir_ujian, $kelompok_u->selesai_ujian);
								}
								if ($awal_ujian == $max_date || $akhir_ujian == $min_date)
									echo "- (Belum dapat ditentukan)";
								else
								{
									echo tgl_indo($awal_ujian->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
									echo " s/d ";
									echo tgl_indo($akhir_ujian->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
								}
								?>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-md-4 text-muted">
                                Pelaporan
                            </div>
                            <div class="col-md-8 text-dark">
                                <?php echo tgl_indo($kegiatan->awal_pelaporan->format('Y-m-d'), 'Y-m-d', TRUE); ?>
                                s/d
                                <?php echo tgl_indo($kegiatan->akhir_pelaporan->format('Y-m-d'), 'Y-m-d', TRUE); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-12">
                                <h4 class="card-title mb-3">Ringkasan</h4>
                            </div>
                        </div>
						<?php if (!$kegiatan_dibuka_untuk_itpln) { ?>
                        <div class="row mb-2">
                            <div class="col-md-4 text-muted">
                                Total Registrasi
                            </div>
                            <div class="col-md-8 text-dark">
                                <?php echo $kegiatan->get_total_pendaftar_all(); ?>
                            </div>
                        </div>
						<?php } ?>
                        <div class="row mb-2">
                            <div class="col-md-4 text-muted">
                                Total Peserta
                            </div>
                            <div class="col-md-8 text-dark">
                                <?php echo $kegiatan->get_total_pendaftar_approved(); ?>
                                <br>
                                <?php echo $kegiatan->get_total_sudah_pilih_kelompok_t(); ?> sudah memilih kelompok training
								<br>
                                <?php echo $kegiatan->get_total_sudah_pilih_kelompok_u(); ?> sudah memilih kelompok ujian
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-md-4 text-muted">
                                Jumlah Kelompok
                            </div>
                            <div class="col-md-8 text-dark">
                                <?php echo count($kegiatan->list_kelompok_training); ?> (T),
								<?php echo count($kegiatan->list_kelompok_ujian); ?> (U)
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-md-4 text-muted">
                                Biaya (T + U)
                            </div>
                            <div class="col-md-8 text-dark">
                                <?php echo format_rupiah($kegiatan->biaya_t_u); ?>
                            </div>
                        </div>
						<?php if (!$kegiatan_dibuka_untuk_itpln) { ?>
                        <div class="row mb-2">
                            <div class="col-md-4 text-muted">
                                Biaya (U)
                            </div>
                            <div class="col-md-8 text-dark">
                                <?php echo format_rupiah($kegiatan->biaya_u); ?>
                            </div>
                        </div>
						<?php } ?>
                    </div>
                </div>

                <!-- Tabs -->
                <ul class="nav nav-tabs nav-bordered mb-3">
                    <li class="nav-item">
                        <a href="#about" data-toggle="tab" class="nav-link <?php if (empty($_this->input->get('tab')) || $_this->input->get('tab') === 'about') echo 'active'; ?>">
                            Tentang
                        </a>
                    </li>
					<?php if (!$kegiatan_dibuka_untuk_itpln) { ?>
                    <li class="nav-item">
                        <a href="#registrasi" data-toggle="tab" class="nav-link <?php if ($_this->input->get('tab') === 'registrasi') echo 'active'; ?>">
                            Registrasi
                        </a>
                    </li>
					<?php if (admin_capable(Permissions::LIHAT_KEUANGAN_KEGIATAN_SERTIFIKASI)) {?>
                    <li class="nav-item">
                        <a href="#pembayaran" data-toggle="tab" class="nav-link <?php if ($_this->input->get('tab') === 'pembayaran') echo 'active'; ?>">
                            Bukti Bayar
                        </a>
                    </li>
					<?php } ?>
					<?php } ?>
                    <li class="nav-item">
                        <a href="#kelompok-t" data-toggle="tab" class="nav-link <?php if ($_this->input->get('tab') === 'kelompok-t') echo 'active'; ?>">
                            Kelompok (T)
                        </a>
                    </li>

					<li class="nav-item">
						<a href="#kelompok-u" data-toggle="tab" class="nav-link <?php if ($_this->input->get('tab') === 'kelompok-u') echo 'active'; ?>">
							Kelompok (U)
						</a>
					</li>

                    <li class="nav-item">
                        <a href="#peserta" data-toggle="tab" class="nav-link <?php if ($_this->input->get('tab') === 'peserta') echo 'active'; ?>">
                            Peserta
                        </a>
                    </li>

					<?php if (admin_capable(Permissions::LIHAT_KEUANGAN_KEGIATAN_SERTIFIKASI)) {?>
						<li class="nav-item">
							<a href="#klaim-dana" data-toggle="tab" class="nav-link <?php if ($_this->input->get('tab') === 'klaim-dana') echo 'active'; ?>">
								Klaim Dana
							</a>
						</li>
					<?php } ?>
                </ul>

                <!-- Content Tab -->
                <div class="tab-content">
                    <!-- Detail About -->
                    <div class="tab-pane <?php if (empty($_this->input->get('tab')) || $_this->input->get('tab') === 'about') echo 'show active'; ?>" id="about">
                        <!-- Dibuka Untuk -->
                        <div class="row mb-2">
                            <div class="col-md-3 text-muted">
                                Dibuka untuk
                            </div>
                            <div class="col-md-9 text-dark">
                                <?php echo strtoupper($kegiatan->dibuka_untuk); ?>
                            </div>
                        </div>
                        <!-- Nama Sertifikasi -->
                        <div class="row mb-2">
                            <div class="col-md-3 text-muted">
                                Sertifikasi
                            </div>
                            <div class="col-md-9 text-dark">
                                <a target="_blank" href="<?php echo base_url('admin/sertifikasi/program'); ?>">
                                    <?php echo html_escape($kegiatan->sertifikasi->nama); ?>
                                </a>
                            </div>
                        </div>
                        <!-- List Program -->
                        <div class="row mb-2">
                            <div class="col-md-3 text-muted">
                                Program
                            </div>
                            <div class="col-md-9 text-dark">
                                <?php foreach($kegiatan->program_kegiatan as $program_kegiatan) { ?>
                                    <div><?php echo $program_kegiatan->nama_program; ?></div>
                                <?php } ?>
                            </div>
                        </div>
                        <!-- Link Grup -->
                        <div class="row mb-2">
                            <div class="col-md-3 text-muted">
                                Link Grup
                            </div>
                            <div class="col-md-9 text-dark">
                                <a href="<?php echo $kegiatan->link_grup; ?>" target="_blank">
                                    <?php echo $kegiatan->link_grup; ?>
                                </a>
                            </div>
                        </div>
						<!-- Link CSV daftar Program -->
						<div class="row mb-2">
							<div class="col-md-3 text-muted">
								Link CSV daftar program
							</div>
							<div class="col-md-9 text-dark">
								<a href="<?php echo base_url('admin/sertifikasi/kegiatan/'.$kegiatan->id.'/download_csv_program'); ?>" target="_blank">
									Download
								</a>
							</div>
						</div>
                        <div class="row mb-4">
                            <div class="col-md-3 text-muted">
                                Kriteria Registrasi Peserta
                            </div>
                            <div class="col-md-9 text-dark" id="kriteria-registrasi">
                                <pre class="d-none" id="json-kriteria-regis"><?php echo $kegiatan->kriteria_registrasi->json_data; ?></pre>
                                <?php if ($kegiatan->dibuka_untuk === General_Constants::MAHASISWA) {?>
                                    <table class=" table table-sm table-striped table-bordered text-dark" id="t-kriteria-regis" style="max-width: 500px;">
                                        <thead>
                                        <tr>
                                            <th>Angkatan</th>
                                            <th>Jurusan</th>
                                            <th>Index</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                <?php } else if ($kegiatan->dibuka_untuk === General_Constants::UMUM){?>
                                    <table class=" table table-sm table-striped table-bordered text-dark" id="t-kriteria-regis" style="max-width: 500px;">
                                        <thead>
                                        <tr>
                                            <th>Tipe</th>
                                            <th>Kriteria</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                <?php } else echo '-'; ?>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-md-3 text-muted">
                                Peserta yang boleh ujian saja
                            </div>
                            <div class="col-md-9 text-dark" id="kriteria-peserta-ujian-saja">
                                <pre class="d-none" id="json-kriteria-peserta-ujian-saja"><?php echo $kegiatan->kriteria_peserta_boleh_ujian_saja->json_data; ?></pre>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-md-3 text-muted">
                                Kriteria Potongan Harga
                            </div>
                            <div class="col-md-9 text-dark" id="kriteria-diskon">
                                <pre class="d-none" id="json-kriteria-diskon"><?php echo $kegiatan->kriteria_diskon->json_data; ?></pre>
                            </div>
                        </div>
                    </div>

					<?php if (!$kegiatan_dibuka_untuk_itpln) { ?>
					<!-- Detail tabel registrasi -->
                    <div class="tab-pane <?php if ($_this->input->get('tab') === 'registrasi') echo 'show active'; ?>" id="registrasi">
						<a target="_blank"
						   role="button"
						   href="<?php echo base_url('admin/sertifikasi/kegiatan/'.$kegiatan->id.'/download-data-registrasi') ?>"
						   class="mb-3 btn btn-success float-right">
							Download Data Registrasi
						</a>
						<div class="table-responsive">
                            <table id="t-registrasi" class="mb-2 compact" style="white-space: nowrap;">
                                <thead>
                                <tr>
                                    <th>Timestamp</th>
                                    <?php if ($kegiatan->dibuka_untuk === General_Constants::MAHASISWA) {?>
                                        <th>Angkatan</th>
                                        <th>Jurusan</th>
                                        <th>NIM</th>
                                    <?php } ?>
                                    <th>E-mail</th>
                                    <th>Nama</th>
                                    <th>Program</th>
                                    <th>Jenis</th>
                                    <th>Nominal</th>
                                    <th>Terbayar</th>
                                    <th>Approve?</th>
                                    <th>Act</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($kegiatan->list_pendaftaran as $pendaftaran) { ?>
                                    <tr>
                                        <td>
											<?php echo $pendaftaran->waktu; ?>
											<span class="d-none id-program-kegiatan"><?php echo $pendaftaran->id_program_kegiatan; ?></span>
											<span class="d-none jenis"><?php echo $pendaftaran->jenis; ?></span>
											<span class="d-none diskon"><?php echo $pendaftaran->diskon; ?></span>
											<span class="d-none id-pendaftaran"><?php echo $pendaftaran->id; ?></span>
										</td>
                                        <?php if ($kegiatan->dibuka_untuk === General_Constants::MAHASISWA) {?>
                                            <td><?php echo $pendaftaran->angkatan_user; ?></td>
                                            <td><?php
												if (in_array($pendaftaran->jurusan_user, array_keys(config_item("JURUSAN"))))
													echo config_item("JURUSAN")[$pendaftaran->jurusan_user];
												else echo $pendaftaran->jurusan_user;
												?></td>
                                            <td><?php echo $pendaftaran->nim_user; ?></td>
                                        <?php } ?>
                                        <td class="r-email"><?php echo $pendaftaran->email_user; ?></td>
                                        <td class="r-nama"><?php echo html_escape($pendaftaran->nama_lengkap_user); ?></td>
                                        <td><?php echo $pendaftaran->program_yang_dipilih; ?></td>
                                        <td><?php
											switch ($pendaftaran->jenis)
											{
												case General_Constants::TRAINING_DAN_UJIAN:
													echo "Training & Ujian";
													break;
												case General_Constants::UJIAN_SAJA:
													echo "Ujian saja";
													break;
												default:
													echo "-";
													break;
											}
                                            ?></td>
                                        <td><?php
											$harga_awal = 0;
											switch ($pendaftaran->jenis)
											{
												case General_Constants::TRAINING_DAN_UJIAN:
													$harga_awal = $kegiatan->biaya_t_u;
													break;
												case General_Constants::UJIAN_SAJA:
													$harga_awal = $kegiatan->biaya_u;
													break;
											}
											$total = $harga_awal - $pendaftaran->diskon;
											if ($total < 0) $total = 0;
											echo format_rupiah($total); ?>
                                        </td>
                                        <td><?php echo format_rupiah($pendaftaran->terbayar); ?></td>
                                        <td>
											<?php if (!$is_history) { ?>
                                            <select class="approve-registrasi" data-id="<?php echo $pendaftaran->id; ?>" style="width: 100px;">
                                                <option value="true" <?php if ($pendaftaran->approved) echo "selected"; ?>>Ya</option>
                                                <option value="false" <?php if (!$pendaftaran->approved) echo "selected"; ?>>Tidak</option>
                                            </select>
											<?php } else {
												if ($pendaftaran->approved) echo "Ya"; else echo "Tidak";
											}
											?>
                                        </td>
                                        <td>
                                            <div class="dropdown sub-dropdown">
                                                <button class="btn btn-link text-muted dropdown-toggle" type="button"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
                                                </button>
                                                <div class="dropdown-menu dropdown-menu-right" x-placement="top-end" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-110px, -152px, 0px);">
													<?php if (!$is_history) { ?>
														<button type="button" class="dropdown-item" data-toggle="modal" data-target="#ubah-data-registrasi">Ubah</button>
														<button type="button" class="dropdown-item" data-toggle="modal" data-target="#hapus-data-registrasi">Hapus</button>
													<?php } ?>
													<a class="dropdown-item" target="_blank" href="<?php echo base_url('admin/user/'.$pendaftaran->id_user); ?>">
														Lihat user
													</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php } ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <?php if ($kegiatan->dibuka_untuk === General_Constants::MAHASISWA) {?>
                                        <th><input type="text" style="width: 80px;"></th>
                                        <th><input type="text" style="width: 80px;"></th>
                                        <th><input type="text" style="width: 80px;"></th>
                                    <?php } ?>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th></th>
                                    <th></th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>

					<?php if (admin_capable(Permissions::LIHAT_KEUANGAN_KEGIATAN_SERTIFIKASI)) { ?>
					<!-- Tabel bukti pembayaran -->
                    <div class="tab-pane <?php if ($_this->input->get('tab') === 'pembayaran') echo 'show active'; ?>" id="pembayaran">
						<div>
							Total yang diterima:
							<?php
							$total = 0;
							foreach ($kegiatan->list_pembayaran as $pembayaran)
							{
								if ($pembayaran->status === General_Constants::PEMBAYARAN_ACCEPTED)
									$total += $pembayaran->nominal_dibayar;
							}
							echo format_rupiah($total);
							?>
						</div>
						<a target="_blank"
						   role="button"
						   href="<?php echo base_url('admin/sertifikasi/kegiatan/'.$kegiatan->id.'/download-data-bukti-bayar') ?>"
						   class="mb-3 btn btn-success float-right">
							Download Data Bukti Bayar
						</a>
						<div class="table-responsive">
                            <table id="t-pembayaran" class="mb-2 compact" style="white-space: nowrap;">
                                <thead>
                                <tr>
                                    <th>Timestamp</th>
                                    <th>Waktu Trf</th>
                                    <th>Nama Pengirim</th>
                                    <th>Bank</th>
                                    <th>Nominal</th>
                                    <th>Peserta</th>
                                    <th>Bukti</th>
                                    <th>Valid?</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($kegiatan->list_pembayaran as $pembayaran) {?>
                                    <tr>
                                        <td><?php echo $pembayaran->timestamp; ?></td>
                                        <td><?php echo
												tgl_indo($pembayaran->waktu_transfer->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE)
                                                .' '
												. $pembayaran->waktu_transfer->format('H:i:s')
                                                .' WIB';?></td>
                                        <td><?php echo html_escape($pembayaran->nama_pengirim); ?></td>
                                        <td>
											<?php
											if (in_array($pembayaran->bank, config_item("LIST_BANK")))
												echo config_item("LIST_BANK")[$pembayaran->bank];
											else echo strtoupper(html_escape($pembayaran->bank));
											?>
										</td>
                                        <td><?php echo format_rupiah($pembayaran->nominal_dibayar); ?></td>
                                        <td><?php echo html_escape($pembayaran->nama_depan.' '.$pembayaran->nama_belakang); ?></td>
                                        <td>
                                            <a target="_blank" href="<?php echo $pembayaran->get_link_file_bukti(); ?>">
                                                Lihat
                                            </a>
                                        </td>
                                        <td>
											<?php if (!$is_history) { ?>
                                            <select class="update-pembayaran" data-id="<?php echo $pembayaran->id; ?>" style="width: 100px;">
                                                <option value="pending" <?php if ($pembayaran->status === General_Constants::PEMBAYARAN_PENDING) echo "selected"; ?>>Pending</option>
                                                <option value="reject" <?php if ($pembayaran->status === General_Constants::PEMBAYARAN_REJECTED) echo "selected"; ?>>Ditolak</option>
                                                <option value="accept" <?php if ($pembayaran->status === General_Constants::PEMBAYARAN_ACCEPTED) echo "selected"; ?>>Diterima</option>
                                            </select>
											<?php
											} else {
												if ($pembayaran->status === General_Constants::PEMBAYARAN_PENDING) echo "Pending";
												elseif ($pembayaran->status === General_Constants::PEMBAYARAN_REJECTED) echo "Ditolak";
												elseif ($pembayaran->status === General_Constants::PEMBAYARAN_ACCEPTED) echo "Diterima";
											}
											?>
                                        </td>
                                    </tr>
                                <?php } ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <th></th>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th></th>
                                    <th></th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                    <?php } ?>
					<?php } ?>
					<!-- Tabel daftar kelompok training -->
                    <div class="tab-pane <?php if ($_this->input->get('tab') === 'kelompok-t') echo 'show active'; ?>" id="kelompok-t">
						<?php if (!$is_history) { ?>
                        <button class="d-block btn btn-primary btn-sm mb-4 float-right k-btn-tambah-kelompok">Tambah Kelompok</button>
                        <div class="table-responsive mb-4 d-none panel-tambah-kelompok">
                            <table class="template-row d-none">
                                <tbody>
                                <tr>
                                    <td><input required name="nama[]" type="text" class="form-control p-0" style="width: 150px;"></td>
                                    <td>
                                        <select required name="id_program_kegiatan[]" id="asd" class="custom-select text-body" style="width: 160px;">
                                            <?php foreach($kegiatan->program_kegiatan as $p) { ?>
                                                <option value="<?php echo $p->id_program_kegiatan ?>"><?php echo $p->nama_program ?></option>
                                            <?php } ?>
                                        </select>
                                    </td>
                                    <td><input required name="tanggal_training[]" type="date" class="form-control" style="width: 160px;"></td>
                                    <td>
                                        <input required name="waktu_mulai_training[]"
                                               type="text" class="form-control bootstrap-timepicker d-inline-block" style="width: 100px;">
                                        s/d
                                        <input required name="waktu_selesai_training[]"
                                               type="text" class="form-control bootstrap-timepicker d-inline-block" style="width: 100px;">
                                    </td>
                                    <td><input required name="lokasi_training[]" type="text" class="form-control p-0" style="width: 180px;"></td>
                                    <td>
                                        <input required name="daya_tampung_min_training[]"
                                               type="number" class="form-control d-inline-block" min="0" value="0" style="width: 80px;">
                                        s/d
                                        <input required name="daya_tampung_max_training[]"
                                               type="number" class="form-control d-inline-block" min="0" value="0" style="width: 80px;">
                                    </td>
                                    <td><button type="button" class="btn btn-sm btn-danger k-hapus-row-tambah-kelompok">Hapus</button></td>
                                </tr>
                                </tbody>
                            </table>
                            <button type="button" class="d-block btn btn-light btn-sm mb-2 k-btn-tambah-baris-kelompok" >Tambah Baris</button>
                            <form action="<?php echo base_url('admin/sertifikasi/kegiatan/'.$kegiatan->id.'/add_kelompok_t'); ?>" method="POST" class="table-responsive nowrap">
                                <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                                <table class="mb-3 table-bordered k-table-list-kelompok-baru">
                                    <thead style="text-align: center">
                                    <tr>
                                        <th rowspan="2" style="width: 150px;">Nama</th>
                                        <th rowspan="2" style="width: 160px;">Program</th>
                                        <th colspan="3" style="width: 700px;">Training</th>
                                        <th rowspan="2" style="width: 150px;">Daya tampung</th>
                                        <th rowspan="2" style="width: 100px;"></th>
                                    </tr>
                                    <tr>
                                        <th style="width: 160px;">Tanggal</th>
                                        <th style="width: 180px;">Waktu (WIB)</th>
                                        <th style="width: 180px;">Lokasi</th>
                                    </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                                <button class="btn btn-success btn-sm" type="submit">Submit Data Kelompok</button>
                            </form>
                            <hr>
                        </div>
						<?php } ?>
                        <div class="table-responsive k-list-existing-kelompok" >
                            <table id="t-kelompok-t" class="mb-2 compact" style="white-space: nowrap;">
                                <thead>
                                <tr>
                                    <th style="min-width: 140px;">Kelompok</th>
                                    <th style="min-width: 160px;">Program</th>
                                    <th style="min-width: 140px;">Tgl Training</th>
                                    <th style="min-width: 180px;">Jam Training (WIB)</th>
                                    <th style="min-width: 160px;">Lokasi Training</th>
                                    <th style="min-width: 200px;">Trainer Sesi 1</th>
									<th style="min-width: 200px;">Trainer Sesi 2</th>
									<th style="min-width: 200px;">Proctor Training</th>
                                    <th style="min-width: 150px;">Terisi</th>
                                    <th style="min-width: 50px;">Action</th>
                                </tr>
                                </thead>
                                <tbody>
								<?php foreach($kegiatan->list_kelompok_training as $kelompok) { ?>
								<tr>
									<td>
										<span class="nama"><?php echo html_escape($kelompok->nama_kelompok); ?></span>
										<span class="d-none id-kelompok"><?php echo html_escape($kelompok->id); ?></span>
									</td>
									<td><?php echo $kelompok->nama_program; ?></td>
									<td><?php echo tgl_indo($kelompok->mulai_training->format('Y-m-d'), 'Y-m-d'); ?></td>
									<td>
										<?php echo $kelompok->mulai_training->format('H:i:s'); ?>
										s/d
										<?php echo $kelompok->selesai_training->format('H:i:s'); ?>
									</td>
									<td><?php echo html_escape($kelompok->lokasi_training); ?></td>
									<td><?php echo (!empty($kelompok->trainer_sesi1)) ? $kelompok->trainer_sesi1 : 'Belum ada'; ?></td>
									<td><?php echo (!empty($kelompok->trainer_sesi2)) ? $kelompok->trainer_sesi2 : 'Belum ada'; ?></td>
									<td><?php echo (!empty($kelompok->proctor_training)) ? $kelompok->proctor_training : 'Belum ada'; ?></td>
									<td>
										<span class="daya-tampung"><?php echo $kelompok->min_peserta_training; ?></span>
										/
										<span class="daya-tampung"><?php echo $kelompok->max_peserta_training; ?></span>
										/
										<span class="terisi"><?php echo $kelompok->jumlah_peserta; ?></span>
									</td>
									<td>
										<div class="dropdown sub-dropdown">
											<button class="btn btn-link text-muted dropdown-toggle" type="button"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
												<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
											</button>
											<div class="dropdown-menu dropdown-menu-right" x-placement="top-end" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-110px, -152px, 0px);">
												<a target="_blank" role="button" class="dropdown-item"
												   href="<?php echo $is_history ? base_url('admin/sertifikasi/history/kelompok_t/'.$kelompok->id) : base_url('admin/sertifikasi/kegiatan/kelompok_t/detail/'.$kelompok->id); ?>"
												>
													Detail Kelompok
												</a>
												<?php if (!$is_history) { ?>
												<button type="button" class="dropdown-item" data-toggle="modal" data-target="#hapus-kelompok-t">Hapus(!)</button>
												<?php } ?>
											</div>
										</div>
									</td>
								</tr>
								<?php } ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th><input type="text" style="width: 80px;"></th>
									<th><input type="text" style="width: 80px;"></th>
									<th><input type="text" style="width: 80px;"></th>
                                    <th></th>
                                    <th>Action</th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>

					<!-- Tabel daftar kelompok ujian -->
					<div class="tab-pane <?php if ($_this->input->get('tab') === 'kelompok-u') echo 'show active'; ?>" id="kelompok-u">
						<?php if (!$is_history) { ?>
						<button class="d-block btn btn-primary btn-sm mb-4 float-right k-btn-tambah-kelompok">Tambah Kelompok</button>
						<div class="table-responsive mb-4 d-none panel-tambah-kelompok">
							<table class="template-row d-none">
								<tbody>
								<tr>
									<td><input required name="nama[]" type="text" class="form-control p-0" style="width: 150px;"></td>
									<td>
										<select required name="id_program_kegiatan[]" id="asd" class="custom-select text-body" style="width: 160px;">
											<?php foreach($kegiatan->program_kegiatan as $p) { ?>
												<option value="<?php echo $p->id_program_kegiatan ?>"><?php echo $p->nama_program ?></option>
											<?php } ?>
										</select>
									</td>
									<td><input required name="tanggal_ujian[]" type="date" class="form-control" style="width: 160px;"></td>
									<td>
										<input required name="waktu_mulai_ujian[]"
											   type="text" class="form-control bootstrap-timepicker d-inline-block" style="width: 100px;">
										s/d
										<input required name="waktu_selesai_ujian[]"
											   type="text" class="form-control bootstrap-timepicker d-inline-block" style="width: 100px;">
									</td>
									<td><input required name="lokasi_ujian[]" type="text" class="form-control p-0" style="width: 180px;"></td>
									<td>
										<input required name="daya_tampung_min_ujian[]"
											   type="number" class="form-control d-inline-block" min="0" value="0" style="width: 80px;">
										s/d
										<input required name="daya_tampung_max_ujian[]"
											   type="number" class="form-control d-inline-block" min="0" value="0" style="width: 80px;">
									</td>
									<td><button type="button" class="btn btn-sm btn-danger k-hapus-row-tambah-kelompok">Hapus</button></td>
								</tr>
								</tbody>
							</table>
							<button type="button" class="d-block btn btn-light btn-sm mb-2 k-btn-tambah-baris-kelompok" >Tambah Baris</button>
							<form action="<?php echo base_url('admin/sertifikasi/kegiatan/'.$kegiatan->id.'/add_kelompok_u'); ?>" method="POST" class="table-responsive nowrap">
								<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
								<table class="mb-3 table-bordered k-table-list-kelompok-baru">
									<thead style="text-align: center">
									<tr>
										<th rowspan="2" style="width: 150px;">Nama</th>
										<th rowspan="2" style="width: 160px;">Program</th>
										<th colspan="3" style="width: 700px;">Ujian</th>
										<th rowspan="2" style="width: 150px;">Daya tampung</th>
										<th rowspan="2" style="width: 100px;"></th>
									</tr>
									<tr>
										<th style="width: 160px;">Tanggal</th>
										<th style="width: 180px;">Waktu (WIB)</th>
										<th style="width: 180px;">Lokasi</th>
									</tr>
									</thead>
									<tbody></tbody>
								</table>
								<button class="btn btn-success btn-sm" type="submit">Submit Data Kelompok</button>
							</form>
							<hr>
						</div>
						<?php } ?>
						<div class="table-responsive k-list-existing-kelompok" >
							<table id="t-kelompok-u" class="mb-2 compact" style="white-space: nowrap;">
								<thead>
								<tr>
									<th style="min-width: 140px;">Kelompok</th>
									<th style="min-width: 160px;">Program</th>
									<th style="min-width: 140px;">Tgl Ujian</th>
									<th style="min-width: 180px;">Jam Ujian (WIB)</th>
									<th style="min-width: 160px;">Lokasi Ujian</th>
									<th style="min-width: 200px;">Proctor Ujian</th>
									<th style="min-width: 150px;">Terisi</th>
									<th style="min-width: 50px;">Action</th>
								</tr>
								</thead>
								<tbody>
								<?php foreach($kegiatan->list_kelompok_ujian as $kelompok) { ?>
									<tr>
										<td>
											<span class="nama"><?php echo html_escape($kelompok->nama_kelompok); ?></span>
											<span class="d-none id-kelompok"><?php echo html_escape($kelompok->id); ?></span>
										</td>
										<td><?php echo $kelompok->nama_program; ?></td>
										<td><?php echo tgl_indo($kelompok->mulai_ujian->format('Y-m-d'), 'Y-m-d'); ?></td>
										<td>
											<?php echo $kelompok->mulai_ujian->format('H:i:s'); ?>
											s/d
											<?php echo $kelompok->selesai_ujian->format('H:i:s'); ?>
										</td>
										<td><?php echo html_escape($kelompok->lokasi_ujian); ?></td>
										<td><?php echo (!empty($kelompok->proctor_ujian)) ? $kelompok->proctor_ujian : 'Belum ada'; ?></td>
										<td>
											<span class="daya-tampung"><?php echo $kelompok->min_peserta_ujian; ?></span>
											/
											<span class="daya-tampung"><?php echo $kelompok->max_peserta_ujian; ?></span>
											/
											<span class="terisi"><?php echo $kelompok->jumlah_peserta; ?></span>
										</td>
										<td>
											<div class="dropdown sub-dropdown">
												<button class="btn btn-link text-muted dropdown-toggle" type="button"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
													<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
												</button>
												<div class="dropdown-menu dropdown-menu-right" x-placement="top-end" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-110px, -152px, 0px);">
													<a target="_blank" role="button" class="dropdown-item"
													   href="<?php echo $is_history ? base_url('admin/sertifikasi/history/kelompok_u/'.$kelompok->id) :  base_url('admin/sertifikasi/kegiatan/kelompok_u/detail/'.$kelompok->id); ?>">
														Detail Kelompok
													</a>
													<?php if (!$is_history) { ?>
													<button type="button" class="dropdown-item" data-toggle="modal" data-target="#hapus-kelompok-u">Hapus(!)</button>
													<?php } ?>
												</div>
											</div>
										</td>
									</tr>
								<?php } ?>
								</tbody>
								<tfoot>
								<tr>
									<th><input type="text" style="width: 80px;"></th>
									<th><input type="text" style="width: 80px;"></th>
									<th><input type="text" style="width: 80px;"></th>
									<th><input type="text" style="width: 80px;"></th>
									<th><input type="text" style="width: 80px;"></th>
									<th><input type="text" style="width: 80px;"></th>
									<th></th>
									<th>Action</th>
								</tr>
								</tfoot>
							</table>
						</div>
					</div>

                    <!-- Tabel daftar peserta -->
                    <div class="tab-pane <?php if ($_this->input->get('tab') === 'peserta') echo 'show active'; ?>" id="peserta">
						<?php if (!$is_history) { ?>
						<button class="btn btn-light mb-3 float-right"
								type="button"
								data-toggle='modal'
								data-target='#tambah-peserta'>
							Tambah Peserta
						</button>
						<?php } ?>
						<a target="_blank"
						   role="button"
						   href="<?php echo base_url('admin/sertifikasi/kegiatan/'.$kegiatan->id.'/download-data-peserta') ?>"
						   class="mb-3 btn btn-success">
							Download Data
						</a>

                        <div class="table-responsive" id="p-peserta">
                            <table id="t-peserta" class="mb-2 compact" style="white-space: nowrap;">
                                <thead>
                                <tr>
                                    <th>Email</th>
                                    <?php if ($kegiatan_dibuka_untuk_mahasiswa) {?>
                                        <th>Angkatan</th>
                                        <th>Jurusan</th>
                                        <th>NIM</th>
                                    <?php } ?>
                                    <th>Nama Lengkap</th>
                                    <th>Kelompok (T)</th>
                                    <th>Absensi Training 1</th>
                                    <th>Absensi Training 2</th>
									<th>Kelompok (U)</th>
                                    <th>Absensi Ujian</th>
                                    <th>Skor Ujian</th>
                                    <th>Status</th>
                                    <th>Act</th>
                                </tr>
                                </thead>
                                <tbody>
								<?php
								if ($kegiatan_dibuka_untuk_itpln) {
									foreach($kegiatan->list_peserta_kegiatan_itpln as $peserta_belum_daftar) {
										$sudah_mendaftar = FALSE;
										foreach ($kegiatan->list_peserta as $p)
										{
											if (trim(strtolower($p->email_user)) === trim(strtolower($peserta_belum_daftar->email)))
												$sudah_mendaftar = TRUE;
										}
										if ($sudah_mendaftar) continue;
								?>
										<tr>
											<td><?php echo $peserta_belum_daftar->email;?></td>
											<td><code>Belum daftar</code></td>
											<td><code>Belum daftar</code></td>
											<td><code>Belum daftar</code></td>
											<td><code>Belum daftar</code></td>
											<td><code>Belum daftar</code></td>
											<td><code>Belum daftar</code></td>
											<td><code>Belum daftar</code></td>
											<td><code>Belum daftar</code></td>
											<td></td>
										</tr>
									<?php }
								} ?>
                                <?php foreach($kegiatan->list_peserta as $peserta) {?>
									<tr>
										<td><?php echo $peserta->email_user;?></td>
										<?php if ($kegiatan_dibuka_untuk_mahasiswa) {?>
											<td><?php echo $peserta->angkatan_user; ?></td>
											<td><?php echo config_item('JURUSAN')[$peserta->jurusan_user]; ?></td>
											<td><?php echo $peserta->nim_user; ?></td>
										<?php } ?>

										<td><?php echo html_escape($peserta->nama_depan_user); ?> <?php echo html_escape($peserta->nama_belakang_user); ?></td>
										<td>
											<?php if ($peserta->jenis === General_Constants::UJIAN_SAJA) { ?>
												Ujian Saja
											<?php } else { ?>
												<?php
												$id_program_kegiatan = (int)$peserta->id_program_kegiatan;
												$kelompok_sesuai_program = array_filter(
													$kegiatan->list_kelompok_training,
													function($kelompok) use ($id_program_kegiatan){
													return ((int)$kelompok->id_program_kegiatan === $id_program_kegiatan);
												}); ?>
												<?php if (!$is_history) { ?>
												<select class="peserta-kelompok-t" data-id="<?php echo $peserta->id; ?>">
													<option value="null">Belum pilih</option>
													<?php foreach($kelompok_sesuai_program as $k) { ?>
														<option value="<?php echo $k->id; ?>"
																<?php if (!empty($peserta->id_kelompok_t) && (int)$k->id === (int)$peserta->id_kelompok_t)
																	echo 'selected'; ?>
														>
															<?php echo $k->nama_kelompok; ?>
														</option>
													<?php } ?>
												</select>
												<?php } else {
													if (!empty($peserta->id_kelompok_t)) echo $peserta->nama_kelompok_t;
													else echo '-';
												}
												?>
											<?php } ?>
										</td>
										<td><?php if ($peserta->hadir_training_sesi1) echo 'Hadir'; else echo 'Tidak Hadir'; ?></td>
										<td><?php if ($peserta->hadir_training_sesi2) echo 'Hadir'; else echo 'Tidak Hadir'; ?></td>
										<td>
											<?php
											$id_program_kegiatan = (int)$peserta->id_program_kegiatan;
											$kelompok_sesuai_program = array_filter(
													$kegiatan->list_kelompok_ujian,
													function($kelompok) use ($id_program_kegiatan){
														return ((int)$kelompok->id_program_kegiatan === $id_program_kegiatan);
													}); ?>
											<?php if (!$is_history) { ?>
											<select class="peserta-kelompok-u" data-id="<?php echo $peserta->id; ?>">
												<option value="null">Belum pilih</option>
												<?php foreach($kelompok_sesuai_program as $k) { ?>
													<option value="<?php echo $k->id; ?>"
															<?php if (!empty($peserta->id_kelompok_u) && (int)$k->id === (int)$peserta->id_kelompok_u)
																echo 'selected'; ?>
													>
														<?php echo $k->nama_kelompok; ?>
													</option>
												<?php } ?>
											</select>
											<?php } else {
												if (!empty($peserta->id_kelompok_u)) echo $peserta->nama_kelompok_u;
												else echo '-';
											} ?>
										</td>
										<td><?php if ($peserta->hadir_ujian) echo 'Hadir'; else echo 'Tidak Hadir'; ?></td>
										<td><?php
											if ($peserta->status_kelulusan === General_Constants::STATUS_PENDING) echo 'Pending';
											else echo $peserta->skor_ujian; ?></td>
										<td>
											<?php if ($peserta->status_kelulusan === General_Constants::STATUS_PENDING) {?>
												<span class="badge badge-info">Pending</span>
											<?php } elseif ($peserta->status_kelulusan === General_Constants::STATUS_TIDAK_LULUS) {?>
												<span class="badge badge-danger">Tidak Lulus</span>
											<?php } else { ?>
												<span class="badge badge-success">Lulus</span>
											<?php } ?>
										</td>
										<td>
											<div class="dropdown sub-dropdown">
												<button class="btn btn-link text-muted dropdown-toggle" type="button"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
													<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
												</button>
												<div class="dropdown-menu dropdown-menu-right" x-placement="top-end" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-110px, -152px, 0px);">
													<?php if (!empty($peserta->id_kelompok_t)) {?>
													<a target="_blank" role="button" class="dropdown-item"
													   href="<?php echo $is_history ? base_url('admin/sertifikasi/history/kelompok_t/'.$peserta->id_kelompok_t) :  base_url('admin/sertifikasi/kegiatan/kelompok_t/detail/'.$peserta->id_kelompok_t); ?>">
														Detail Kelompok Training
													</a>
													<?php } ?>
													<?php if (!empty($peserta->id_kelompok_u)) {?>
													<a target="_blank" role="button" class="dropdown-item"
													   href="<?php echo $is_history ? base_url('admin/sertifikasi/history/kelompok_u/'.$peserta->id_kelompok_u) :  base_url('admin/sertifikasi/kegiatan/kelompok_u/detail/'.$peserta->id_kelompok_u); ?>">
														Detail Kelompok ujian
													</a>
													<?php } ?>
													<a target="_blank" role="button" class="dropdown-item" href="<?php echo base_url('admin/user/'.$peserta->id_user); ?>">Lihat User</a>
												</div>
											</div>
										</td>
									</tr>
                                <?php } ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <?php if ($kegiatan_dibuka_untuk_mahasiswa) {?>
                                        <th><input type="text" style="width: 80px;"></th>
                                        <th><input type="text" style="width: 80px;"></th>
                                        <th><input type="text" style="width: 80px;"></th>
                                    <?php } ?>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th><input type="text" style="width: 80px;"></th>
									<th><input type="text" style="width: 80px;"></th>
									<th><input type="text" style="width: 80px;"></th>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th></th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>

					<?php if (admin_capable(Permissions::LIHAT_KEUANGAN_KEGIATAN_SERTIFIKASI)) { ?>
					<!-- Tabel daftar klaim dana kegiatan -->
					<div class="tab-pane <?php if ($_this->input->get('tab') === 'klaim') echo 'show active'; ?>" id="klaim-dana">
						<div class="row">
							<div class="col-md-6">
								<?php
								$total_klaim = 0;
								foreach($kegiatan->list_klaim_dana as $klaim) {
									$total_klaim += (int)$klaim->nominal_klaim;
								}
								?>
								<p>Total klaim dana : <?php echo format_rupiah($total_klaim); ?></p>
							</div>
							<?php if (!$is_history) { ?>
							<div class="col-md-6">
								<button class="btn btn-light mb-3 float-right" type="button" data-toggle='modal' data-target='#tambah-klaim'>
									Tambah Data Klaim
								</button>
							</div>
							<?php } ?>
						</div>

						<div class="table-responsive">
							<table id="t-klaim-dana" class="mb-2 compact" style="white-space: nowrap;">
							<thead>
							<tr>
								<th>Nominal Klaim</th>
								<th>Keterangan</th>
								<th>File</th>
								<th>Action</th>
							</tr>
							</thead>
							<tbody>
							<?php foreach($kegiatan->list_klaim_dana as $klaim) { ?>
								<tr>
									<td>
										<span class="d-none"><?php echo $klaim->id; ?></span>
										<span class="d-none"><?php echo $klaim->nominal_klaim; ?></span>
										<span><?php echo format_rupiah($klaim->nominal_klaim); ?></span>
									</td>
									<td><?php echo html_escape($klaim->keterangan); ?></td>
									<td>
										<a target="_blank" href="<?php echo $klaim->get_link_bukti_klaim(); ?>">Lihat</a>
									</td>
									<td>
										<?php if (!$is_history) { ?>
										<div class="dropdown sub-dropdown">
											<button class="btn btn-link text-muted dropdown-toggle" type="button"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
												<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
											</button>
											<div class="dropdown-menu dropdown-menu-right" x-placement="top-end" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-110px, -152px, 0px);">
												<button type="button" class="dropdown-item" data-toggle="modal" data-target="#ubah-klaim">Ubah Data</button>
												<button type="button" class="dropdown-item" data-toggle="modal" data-target="#hapus-klaim">Hapus(!)</button>
											</div>
										</div>
										<?php } ?>
									</td>
								</tr>
							<?php } ?>
							</tbody>
							<tfoot>
							<tr>
								<th><input type="text" style="width: 80px;"></th>
								<th><input type="text" style="width: 80px;"></th>
								<th></th>
								<th></th>
							</tr>
							</tfoot>
						</table>
						</div>
					</div>
					<?php } ?>

                </div>
            </div>
        </div>
    </div>
<?php } ?>

<?php function yield_bottom_before_script($_this, $data){?>
	<?php
	/** @var D_Kegiatan $kegiatan */
	$kegiatan = $data['kegiatan'];
	/** @var bool $is_history */
	$is_history = $data['history'];
	if ($is_history) return;
	$kegiatan_dibuka_untuk_itpln = $kegiatan->dibuka_untuk === General_Constants::ITPLN;
	$kegiatan_dibuka_untuk_mahasiswa = $kegiatan->dibuka_untuk === General_Constants::MAHASISWA;
	$kegiatan_dibuka_untuk_umum = $kegiatan->dibuka_untuk === General_Constants::UMUM;
	?>
	<!-- Modal tambah data peserta -->
	<?php if(admin_capable(Permissions::EDIT_KEGIATAN_SERTIFIKASI)) {?>
		<?php if ($kegiatan_dibuka_untuk_itpln) { ?>
			<div id="tambah-peserta" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-tambah-peserta" style="display: none;" aria-hidden="true">
				<div class="modal-dialog modal-lg">
					<div class="modal-content">
						<div class="modal-header">
							<h4 class="modal-title" id="label-tambah-peserta">Tambah Peserta ITPLN</h4>
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
						</div>

						<form method="POST" action="<?php echo base_url('admin/sertifikasi/kegiatan/'.$kegiatan->id.'/tambah_peserta'); ?>" enctype='multipart/form-data' >
							<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
							<div class="modal-body">
								<div class="alert alert-light" role="alert">
									Upload data peserta kegiatan di sini (anda bisa mengubahnya nanti).
									<ol>
										<li>File dalam format <code>CSV</code> (comma delimited).</li>
										<li>Di dalam file hanya ada satu sheet, dan terdiri dari dua kolom.</li>
										<li>Kolom pertama berisi email.</li>
										<li>
											Kolom kedua berisi nama program. Daftar nama program dapat didownload
											<a target="_blank" href="<?php echo base_url('admin/sertifikasi/kegiatan/'.$kegiatan->id.'/download_csv_program') ?>">di sini</a>
										</li>
										<li>Tidak perlu ada header (judul) kolom.</li>
										<li>Data peserta yang diupload akan ditambahkan (append) ke data peserta yang sudah ada, tidak ditimpa. </li>
										<li>Jika anda tidak mengupload file daftar peserta, maka diasumsikan tidak ada kriteria peserta untuk saat ini.</li>
									</ol>
								</div>
								<div class="custom-file">
									<input required type="file" class="custom-file-input" id="tambah-peserta-file" name="file_list_peserta">
									<label class="custom-file-label" for="tambah-peserta-file">File .csv</label>
								</div>
							</div>
							<div class="modal-footer">
								<button type="submit" class="btn btn-success">Tambah</button>
							</div>
						</form>


					</div><!-- /.modal-content -->
				</div><!-- /.modal-dialog -->
			</div>
		<?php } elseif ($kegiatan_dibuka_untuk_mahasiswa) { ?>
			<div id="tambah-peserta" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-tambah-peserta" style="display: none;" aria-hidden="true">
				<div class="modal-dialog modal-lg">
					<div class="modal-content">
						<div class="modal-header">
							<h4 class="modal-title" id="label-tambah-peserta">Tambah Peserta</h4>
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
						</div>
						<form method="POST" id="form-tambah-peserta-mhs" action="<?php echo base_url('admin/sertifikasi/kegiatan/'.$kegiatan->id.'/tambah_peserta'); ?>">
							<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
							<div class="modal-body">
								<div class="row">
									<div class="col-12">Cari</div>
									<div class="col-12 mb-2">
										<div class="row">
											<div class="col-md-4">
												<input class="form-control search-user" type="text" id="search-user-nama-depan" placeholder="Nama Depan">
											</div>
											<div class="col-md-4">
												<input class="form-control search-user" type="text" id="search-user-nama-belakang" placeholder="Nama Belakang">
											</div>
											<div class="col-md-4">
												<input class="form-control search-user" type="text" id="search-user-email" placeholder="Email">
											</div>
										</div>
									</div>
									<div class="col-12">
										<div style="height: 250px;overflow-y: scroll;">
											<div class="table-responsive w-100">
												<table class="w-100 table table-sm table-bordered" id="tambah-peserta-search-result-user-mhs">
													<thead>
													<tr>
														<th>Nama Depan</th>
														<th>Nama Belakang</th>
														<th>Email</th>
														<th></th>
													</tr>
													</thead>
													<tbody>
													</tbody>
												</table>
											</div>
										</div>
									</div>
									<div class="col-12">List Peserta</div>
									<div class="col-12">
										<div class="table-responsive w-100" style="height: 250px;overflow-y: scroll;">
											<table class="w-100 table table-sm table-bordered" id="tambah-peserta-list-user-mhs">
												<thead>
												<tr>
													<th>Nama Depan</th>
													<th>Nama Belakang</th>
													<th>Email</th>
													<th>Jenis</th>
													<th>Program</th>
													<th></th>
												</tr>
												</thead>
												<tbody>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
							<div class="modal-footer">
								<button type="submit" class="btn btn-success">Tambah</button>
							</div>
						</form>

					</div><!-- /.modal-content -->
				</div><!-- /.modal-dialog -->
			</div>
		<?php } elseif ($kegiatan_dibuka_untuk_umum) { ?>
			<div id="tambah-peserta" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-tambah-peserta" style="display: none;" aria-hidden="true">
				<div class="modal-dialog modal-xl">
					<div class="modal-content">
						<div class="modal-header">
							<h4 class="modal-title" id="label-tambah-peserta">Tambah Peserta</h4>
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
						</div>

						<form method="POST" id="form-tambah-peserta-umum" action="<?php echo base_url('admin/sertifikasi/kegiatan/'.$kegiatan->id.'/tambah_peserta'); ?>">
							<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
							<div class="modal-body">
								<div class="row">
									<div class="col-12">Cari</div>
									<div class="col-12 mb-2">
										<div class="row">
											<div class="col-md-4">
												<input class="form-control search-user" type="text" id="search-user-nama-depan" placeholder="Nama Depan">
											</div>
											<div class="col-md-4">
												<input class="form-control search-user" type="text" id="search-user-nama-belakang" placeholder="Nama Belakang">
											</div>
											<div class="col-md-4">
												<input class="form-control search-user" type="text" id="search-user-email" placeholder="Email">
											</div>
										</div>
									</div>
									<div class="col-12">
										<div style="height: 250px;overflow-y: scroll;">
											<div class="table-responsive w-100">
												<table class="w-100 table table-sm table-bordered" id="tambah-peserta-search-result-user-umum">
													<thead>
													<tr>
														<th>Nama Depan</th>
														<th>Nama Belakang</th>
														<th>Email</th>
														<th></th>
													</tr>
													</thead>
													<tbody>
													</tbody>
												</table>
											</div>
										</div>
									</div>
									<div class="col-12">List Peserta</div>
									<div class="col-12">
										<div class="table-responsive w-100" style="height: 250px;overflow-y: scroll;">
											<table class="w-100 table table-sm table-bordered" id="tambah-peserta-list-user-umum">
												<thead>
												<tr>
													<th>Nama Depan</th>
													<th>Nama Belakang</th>
													<th>Email</th>
													<th>Jenis</th>
													<th>Program</th>
													<th></th>
												</tr>
												</thead>
												<tbody>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
							<div class="modal-footer">
								<button type="submit" class="btn btn-success">Tambah</button>
							</div>
						</form>
					</div><!-- /.modal-content -->
				</div><!-- /.modal-dialog -->
			</div>
		<?php } ?>
	<?php } ?>
    <!-- Modal hapus kelompok (training & ujian) -->
    <?php if(admin_capable(Permissions::HAPUS_KEGIATAN_SERTIFIKASI)) { ?>
        <div id="hapus-kelompok-t" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-hapus-kelompok" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-hapus-kelompok">Anda yakin ingin menghapus kelompok training ini?</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/sertifikasi/kegiatan/kelompok_t/delete'); ?>">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <input type="hidden" name="id">
                            <div class="mb-2">
                                Kelompok : <strong id="m-hapus-klp-nama"></strong>
                            </div>
                            <div class="alert alert-warning fade show" role="alert">
                                <strong class="d-block mb-2">
									Peserta harus memilih kelompok training yang lain,
									dan semua kesediaan trainer dan proctor training akan terhapus.
								</strong>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-danger float-right">Hapus (!)</button>
                        </div>
                    </form>

                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>

		<div id="hapus-kelompok-u" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-hapus-kelompok" style="display: none;" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="label-hapus-kelompok">Anda yakin ingin menghapus kelompok ujian ini?</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					</div>

					<form method="POST" action="<?php echo base_url('admin/sertifikasi/kegiatan/kelompok_u/delete'); ?>">
						<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
						<div class="modal-body">
							<input type="hidden" name="id">
							<div class="mb-2">
								Kelompok : <strong id="m-hapus-klp-nama"></strong>
							</div>
							<div class="alert alert-warning fade show" role="alert">
								<strong class="d-block mb-2">
									Peserta harus memilih kelompok ujian yang lain,
									dan semua kesediaan proctor ujian akan terhapus.
								</strong>
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-danger float-right">Hapus (!)</button>
						</div>
					</form>

				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div>
    <?php } ?>

	<?php if (admin_capable(Permissions::EDIT_KEUANGAN_KEGIATAN_SERTIFIKASI)) { ?>
		<div id="tambah-klaim" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-tambah-klaim" style="display: none;" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="label-tambah-klaim">Tambah Data Klaim</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					</div>

					<form method="POST" action="<?php echo base_url('admin/sertifikasi/kegiatan/'.$kegiatan->id.'/add_klaim'); ?>" enctype='multipart/form-data' >
						<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
						<div class="modal-body">
							<label for="tambah-klaim-keterangan">Keterangan Klaim</label>
							<textarea required name="keterangan" class="form-control mb-2" rows="3" id="tambah-klaim-keterangan"
									  placeholder="Maksimal 500 karakter"></textarea>

							<label for="tambah-klaim-nominal">Nominal</label>
							<input required name="nominal" type="number" class="form-control mb-2" min="0" value="0" id="tambah-klaim-nominal">

							<label for="tambah-klaim-file">Upload file bukti klaim</label>
							<div class="custom-file">
								<input type="file" class="custom-file-input" id="tambah-klaim-file" name="bukti" required>
								<label class="custom-file-label" for="tambah-trainer-foto">File .jpg atau .png max 2 MB</label>
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-success">Tambah</button>
						</div>
					</form>


				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div>

		<div id="ubah-klaim" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-ubah-klaim" style="display: none;" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="label-ubah-klaim">Ubah Data Klaim</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					</div>

					<form method="POST" action="<?php echo base_url('admin/sertifikasi/kegiatan/klaim/ubah'); ?>" enctype='multipart/form-data' >
						<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
						<div class="modal-body">
							<input type="hidden" name="id" required>
							<label for="tambah-klaim-keterangan">Keterangan Klaim</label>
							<textarea required name="keterangan" class="form-control mb-2" rows="3" id="ubah-klaim-keterangan"
									  placeholder="Maksimal 500 karakter"></textarea>

							<label for="tambah-klaim-nominal">Nominal</label>
							<input required name="nominal" type="number" class="form-control mb-2" min="0" value="0" id="ubah-klaim-nominal">

							<div class="custom-control custom-checkbox my-2">
								<input id="cbx-ubah-klaim-file" class="custom-control-input" type="checkbox" name="ganti_file">
								<label for="cbx-ubah-klaim-file" class="custom-control-label">Ganti file klaim?</label>
							</div>

							<label for="ubah-klaim-file">Upload file bukti klaim</label>
							<div class="custom-file">
								<input type="file" class="custom-file-input" id="ubah-klaim-file" name="bukti">
								<label class="custom-file-label" for="tambah-trainer-foto">File .jpg atau .png max 2 MB</label>
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-success">Tambah</button>
						</div>
					</form>


				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div>

		<div id="hapus-klaim" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-hapus-klaim" style="display: none;" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="label-hapus-klaim">Anda yakin ingin menghapus data klaim ini?</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					</div>

					<form method="POST" action="<?php echo base_url('admin/sertifikasi/kegiatan/klaim/hapus'); ?>">
						<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
						<div class="modal-body">
							<input type="hidden" name="id">
							<div class="mb-2">
								Keterangan : <strong id="m-hapus-klaim-keterangan"></strong>
							</div>
							<div class="alert alert-warning fade show" role="alert">
								<strong class="d-block mb-2">
									Data klaim yang sudah dihapus tidak dapat dikembalikan lagi.
								</strong>
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-danger float-right">Hapus (!)</button>
						</div>
					</form>

				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div>
	<?php } ?>

	<!-- Modal ubah data & hapus registrasi -->
	<?php if(admin_capable(Permissions::EDIT_KEGIATAN_SERTIFIKASI) && !$kegiatan_dibuka_untuk_itpln) {?>
		<div id="ubah-data-registrasi" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-ubah-registrasi" style="display: none;" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="label-ubah-registrasi">Ubah data registrasi</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					</div>

					<form method="POST" action="<?php echo base_url('admin/sertifikasi/kegiatan/'.$kegiatan->id.'/ubah_data_registrasi'); ?>">
						<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
						<div class="modal-body">
							<input type="hidden" name="id">
							<div class="form-group row">
								<label class="col-sm-4 col-form-label">
									Email
								</label>
								<input type="text" class="col-sm-8 form-control-plaintext mb-2" value="" id="ubah-registrasi-email">
							</div>
							<div class="form-group row">
								<label class="col-sm-4 col-form-label">
									Nama
								</label>
								<input type="text" class="col-sm-8 form-control-plaintext mb-2" value="" id="ubah-registrasi-nama">
							</div>

							<div class="form-group row">
								<label class="col-sm-4 col-form-label">
									Program
								</label>
								<select required name="id_program_kegiatan" class="col-sm-8 custom-select text-body">
									<?php foreach($kegiatan->program_kegiatan as $program_kegiatan) { ?>
										<option value="<?php echo $program_kegiatan->id_program_kegiatan; ?>"><?php echo $program_kegiatan->nama_program; ?></option>
									<?php } ?>
								</select>
							</div>

							<div class="form-group row">
								<label class="col-sm-4 col-form-label">
									Jenis
								</label>
								<select required name="jenis" class="col-sm-8 custom-select text-body">
									<option value="t_u">Training & Ujian</option>
									<option value="u">Ujian Saja</option>
								</select>
							</div>

							<div class="form-group row">
								<label class="col-sm-4 col-form-label">
									Potongan Harga
								</label>
								<input type="number" name="diskon" class="col-sm-8 form-control mb-2" value="0" min="0">
							</div>

						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-success">Ubah</button>
						</div>
					</form>


				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div>

		<div id="hapus-data-registrasi" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-hapus-registrasi" style="display: none;" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="label-hapus-registrasi">Anda yakin ingin menghapus data registrasi ini ini?</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					</div>

					<form method="POST" action="<?php echo base_url('admin/sertifikasi/kegiatan/'.$kegiatan->id.'/hapus_data_registrasi'); ?>">
						<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
						<div class="modal-body">
							<input type="hidden" name="id">
							<div class="mb-2">
								User : <strong id="m-hapus-registrasi-user"></strong>
							</div>
							<div class="alert alert-warning fade show" role="alert">
								<strong class="d-block mb-2">
									Data registrasi dapat dihapus jika status user adalah not approved.
								</strong>
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-danger float-right">Hapus (!)</button>
						</div>
					</form>

				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div>
	<?php } ?>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
	<?php $_this->load->view("admin/components/kriteria_registrasi_diskon_ujiansaja"); ?>
	<?php
	/** @var D_Kegiatan $kegiatan */
	$kegiatan = $data['kegiatan'];
	$kegiatan_dibuka_untuk_mahasiswa = $kegiatan->dibuka_untuk === General_Constants::MAHASISWA;
	$kegiatan_dibuka_untuk_umum = $kegiatan->dibuka_untuk === General_Constants::UMUM;
	?>
    <script type="text/javascript">
        // Approve registrasi
        $('.approve-registrasi').on('change', function(){
            let param = get_param_ajax();
            param['id'] = $(this).data('id');
            param['value'] = $(this).val();
            $.post(
                BASE_URL+'ajax/kegiatan/approve_registrasi',
                param
            ).done(function(data){
                if (data.status === 'ok')
                    toastr.info('Update registrasi berhasil');
				else if (data.status === 'fail')
					toastr.warning('Gagal update registrasi: ' + data.message);
            });
        });

        // update status bukti bayar
        $('.update-pembayaran').on('change', function(){
            let param = get_param_ajax();
            param['id'] = $(this).data('id');
            param['value'] = $(this).val();
            $.post(
                BASE_URL+'ajax/kegiatan/set_bukti_bayar',
                param
            ).done(function(data){
                if (data.status === 'ok')
                    toastr.info('Update bukti bayar berhasil');
				else if (data.status === 'fail')
					toastr.warning('Gagal update pembayaran: ' + data.message);
            });

        });

        // Peserta pilih kelompok (training)
        $('.peserta-kelompok-t').on('change', function(){
            let param = get_param_ajax();
            param['id'] = $(this).data('id');
            param['id_kelompok'] = $(this).val();
            $.post(
                BASE_URL+'ajax/kegiatan/ubah_kelompok_peserta/t',
                param
            ).done(function(data){
                if (data.status === 'ok')
                    toastr.info('Update kelompok training berhasil');
				else if (data.status === 'fail')
					toastr.warning('Gagal update kelompok training: ' + data.message);
            });
        });

		// Peserta pilih kelompok (ujian)
		$('.peserta-kelompok-u').on('change', function(){
			let param = get_param_ajax();
			param['id'] = $(this).data('id');
			param['id_kelompok'] = $(this).val();
			$.post(
					BASE_URL+'ajax/kegiatan/ubah_kelompok_peserta/u',
					param
			).done(function(data){
				if (data.status === 'ok')
					toastr.info('Update kelompok ujian berhasil');
				else if (data.status === 'fail')
					toastr.warning('Gagal update kelompok ujian: ' + data.message);
			});
		});

        var t_registrasi = setupTable('#t-registrasi');
        var t_pembayaran = setupTable('#t-pembayaran');
        var id_kegiatan = $('#id-kegiatan').text();
        var t_kelompok_t = setupTable("#t-kelompok-t");
		var t_kelompok_u = setupTable("#t-kelompok-u");
        var t_peserta = setupTable('#t-peserta');
		var t_klaim_dana = setupTable('#t-klaim-dana');

        var kriteria_registrasi = JSON.parse($("#json-kriteria-regis").text());
        var kriteria_diskon = JSON.parse($("#json-kriteria-diskon").text());
        var kriteria_peserta_ujian_saja = JSON.parse($("#json-kriteria-peserta-ujian-saja").text());

        var t_kriteria_registrasi = $("#t-kriteria-regis");
        var dibuka_untuk = $("#dibuka-untuk").text();
        $(document).ready(function(){
            // render kriteria regis
            $('tbody', t_kriteria_registrasi).html("");
            if (dibuka_untuk === 'mahasiswa')
            {
            	if (kriteria_registrasi.length === 0)
				{
					let row = $("<tr></tr>");
					$("<td>Semua</td>").appendTo(row);
					$("<td>Semua</td>").appendTo(row);
					$("<td>Semua</td>").appendTo(row);
					$('tbody', t_kriteria_registrasi).append(row);
				}
            	else
				{
					$(kriteria_registrasi).each(function(){
						let row = $("<tr></tr>");
						$("<td></td>").append((this.angkatan === "0")? "Semua" : this.angkatan).appendTo(row);
						let dropdown = "Error";
						if (this.jurusan === "0") dropdown = "Semua";
						else
						{
							let that = this;
							jurusan.forEach(function(value){
								if (value.kode === that.jurusan)
									dropdown = value.nama;
							});
						}
						$("<td></td>").append(dropdown).appendTo(row);
						$("<td></td>").append((this.index === "0")? "Semua" : this.index).appendTo(row);
						$('tbody', t_kriteria_registrasi).append(row);
					});
				}
            }
            else
            {
				// ambil daftar instansi
				let param_ajax_instansi = get_param_ajax();
				$.post(
						BASE_URL+'ajax/instansi/get_all',
						param_ajax_instansi
				).done(function(data){
					if (data.status !== 'ok')
					{
						alert(`Terjadi kesalahan dalam mengambil data instansi : ${data.message}`);
						return;
					}
					let list_instansi = data.data;
					if (kriteria_registrasi.length === 0)
					{
						let row = $("<tr></tr>");
						$("<td>Semua</td>").appendTo(row);
						$("<td>Semua</td>").appendTo(row);
						$('tbody', t_kriteria_registrasi).append(row);
					}
					else
					{
						$(kriteria_registrasi).each(function(){
							let row = $("<tr></tr>");
							$("<td></td>").append(this.tipe).appendTo(row);
							let data_ = $("<td></td>");
							if (this.data === '0')
							{
								data_.append('Semua');
							}
							else if (this.tipe === 'instansi')
							{
								let id = this.data;
								$(list_instansi).each(function(){
									if (this.id === id)
										data_.append(this.nama);
								});

							}
							else if (this.tipe === 'user')
							{
								data_.append(this.data);
							}
							row.append(data_);
							$('tbody', t_kriteria_registrasi).append(row);
						});
					}
				});
            }

            // render kriteria potongan harga
			if (kriteria_diskon.length === 0)
			{
				$("<div class='potongan-harga p-2 mb-2 border border-primary'>-</div>").appendTo($('#kriteria-diskon'));
			}
            $(kriteria_diskon).each(function(){
                let container = $("<div class='potongan-harga p-2 mb-2 border border-primary'></div>");
                let nilai = "";
                if (this.tipe === "nominal")
                    nilai = format_rupiah(parseInt(this.value));
                else
                    nilai = this.value + "%";
                let jenis = $("<div class='mb-2'></div>").append("Jumlah potongan sebesar ").append(nilai);
                let disc_pendaftar_pertama = "";
                if (parseInt(this.disc_pendaftar_pertama) > 0)
                    disc_pendaftar_pertama = $("<div></div>").append("Untuk " + this.disc_pendaftar_pertama + " user pertama yang registrasi");
                let disc_waktu_daftar = "";
                if (this.disc_waktu_daftar.dari !== null && this.disc_waktu_daftar.sampai !== null)
                    disc_waktu_daftar = $("<div></div>").append("Untuk user yang mendaftar dari " + dayjs(this.disc_waktu_daftar.dari).format('D MMMM YYYY HH:mm:ss') + " WIB s/d " + dayjs(this.disc_waktu_daftar.sampai).format('D MMMM YYYY HH:mm:ss') + " WIB");
				let d_ = $("<div></div>");
                if (dibuka_untuk === 'mahasiswa')
				{
					$(this.disc).each(function(){
						let d = $("<div></div>");
						if (parseInt(this.angkatan) === 0)
							d.append("Berlaku untuk mahasiswa seluruh angkatan, ");
						else d.append("Berlaku untuk mahasiswa angkatan " + this.angkatan + ", ");
						if (parseInt(this.jurusan) === 0)
							d.append("seluruh jurusan");
						else
						{
							let that = this;
							$(jurusan).each(function(){
								if (this.kode === that.jurusan)
									d.append("jurusan " + this.nama);
							});
						}
						if (parseInt(this.index) !== 0)
							d.append(", index " + this.index);
						d_.append(d);
					});
				}
                else if (dibuka_untuk === 'umum')
				{
					let kriteria_disc = this.disc;
					console.log(kriteria_disc);
					// ambil daftar instansi
					let param_ajax_instansi = get_param_ajax();
					$.post(
							BASE_URL+'ajax/instansi/get_all',
							param_ajax_instansi
					).done(function(data){
						if (data.status !== 'ok')
						{
							alert(`Terjadi kesalahan dalam mengambil data instansi : ${data.message}`);
							return;
						}
						daftar_instansi = data.data;
						$(kriteria_disc).each(function(){
							let d = $("<div></div>");
							if (this.tipe === 'instansi')
							{
								if (parseInt(this.data) === 0)
								{
									d.append("Berlaku untuk seluruh instansi");
								}
								else {
									let id_instansi = this.data;
									$(daftar_instansi).each(function(){
										if (parseInt(this.id) === id_instansi)
										{
											d.append("Berlaku untuk instansi" + this.nama);
										}
									});
								}
							}
							else if (this.tipe === 'user')
							{
								if (this.data === '0')
								{
									d.append("Berlaku untuk seluruh user");
								}
								else
								{
									d.append("Berlaku untuk user " + this.data);
								}
							}
							d_.append(d);
						});
					});
				}
                container.append(jenis).append(disc_pendaftar_pertama)
                    .append(disc_waktu_daftar)
                    .append(d_);
                $('#kriteria-diskon').append(container);
            });

            // render kriteria user boleh ujian saja
            let container = $("<div class='p-2 mb-2 border border-secondary'></div>");
            $(kriteria_peserta_ujian_saja).each(function(){
                container.append(this.email);
            });
            if (kriteria_peserta_ujian_saja.length === 0)
				container.append('-');
            $('#kriteria-peserta-ujian-saja').append(container);
        });

        // klik tombol tambah kelompok di tab kelompok
        $(".k-btn-tambah-kelompok").on('click', function(){
        	console.log('ASD');
        	let panel_new = $(this).parent().find('.panel-tambah-kelompok');
        	let panel_existing = $(this).parent().find('.k-list-existing-kelompok');
            if (panel_new.hasClass('d-none'))
            {
                $(this).text('Batal Tambah');
				panel_new.removeClass('d-none');
				panel_existing.addClass('d-none');
            }
            else
            {
                $(this).text('Tambah Kelompok');
				panel_new.addClass('d-none');
				panel_existing.removeClass('d-none');
            }
        });

        $(".k-btn-tambah-baris-kelompok").on('click', function(){
            let template = $(".template-row tbody tr:eq(0)", $(this).parent()).clone();
            let table = $(".k-table-list-kelompok-baru tbody").append(template);
            $('.bootstrap-timepicker', table).timepicker(timepicker_config);
        });

        $('.k-table-list-kelompok-baru').on('click', '.k-hapus-row-tambah-kelompok', function(){
            $(this).parent().parent().remove();
        });

        $('#hapus-kelompok-t').on('show.bs.modal', function (event) {
            let button = $(event.relatedTarget); // Button that triggered the modal
            var modal = $(this);
            let row = button.parent().parent().parent().parent();
            modal.find('.modal-body input[name=id]').val(row.find('td:eq(0) .id-kelompok').text());
            modal.find('.modal-body #m-hapus-klp-nama').text(row.find('td:eq(0) .nama').text());
        });

		$('#hapus-kelompok-u').on('show.bs.modal', function (event) {
			let button = $(event.relatedTarget); // Button that triggered the modal
			var modal = $(this);
			let row = button.parent().parent().parent().parent();
			modal.find('.modal-body input[name=id]').val(row.find('td:eq(0) .id-kelompok').text());
			modal.find('.modal-body #m-hapus-klp-nama').text(row.find('td:eq(0) .nama').text());
		});

		$('#ubah-klaim').on('show.bs.modal', function (event) {
			let button = $(event.relatedTarget); // Button that triggered the modal
			var modal = $(this);
			let row = button.parent().parent().parent().parent();
			modal.find('.modal-body input[name=id]').val(row.find('td:eq(0) span:eq(0)').text());
			modal.find('.modal-body input[name=nominal]').val(parseInt(row.find('td:eq(0) span:eq(1)').text()));
			modal.find('.modal-body textarea[name=keterangan]').val(row.find('td:eq(1)').text());
		});

		$('#hapus-klaim').on('show.bs.modal', function (event) {
			let button = $(event.relatedTarget); // Button that triggered the modal
			var modal = $(this);
			let row = button.parent().parent().parent().parent();
			modal.find('.modal-body input[name=id]').val(row.find('td:eq(0) span:eq(0)').text());
			modal.find('.modal-body #m-hapus-klaim-keterangan').text(row.find('td:eq(1)').text());
		});

		$('#ubah-data-registrasi').on('show.bs.modal', function (event) {
			let button = $(event.relatedTarget); // Button that triggered the modal
			var modal = $(this);
			let row = button.parent().parent().parent().parent();
			modal.find('.modal-body #ubah-registrasi-email').val(row.find('.r-email').text());
			modal.find('.modal-body #ubah-registrasi-nama').val(row.find('.r-nama').text());
			modal.find('.modal-body select[name=id_program_kegiatan]').val(row.find('.id-program-kegiatan').text());
			modal.find('.modal-body select[name=jenis]').val(row.find('.jenis').text());
			modal.find('.modal-body input[name=diskon]').val(parseInt(row.find('.diskon').text().trim()));
			modal.find('.modal-body input[name=id]').val(parseInt(row.find('.id-pendaftaran').text().trim()));
		});

		$('#hapus-data-registrasi').on('show.bs.modal', function (event) {
			let button = $(event.relatedTarget); // Button that triggered the modal
			var modal = $(this);
			let row = button.parent().parent().parent().parent();
			modal.find('.modal-body input[name=id]').val(parseInt(row.find('.id-pendaftaran').text().trim()));
			modal.find('.modal-body #m-hapus-registrasi-user').text(row.find('td:eq(2)').text());
		});

    </script>
	<?php if ($kegiatan_dibuka_untuk_umum) {?>
		<script id="list-program-kegiatan" type="application/json"><?php echo json_encode($kegiatan->program_kegiatan); ?></script>
		<script>
			const list_program_kegiatan = JSON.parse(document.getElementById('list-program-kegiatan').textContent);
			const table_search_user_umum = $('#tambah-peserta-search-result-user-umum');
			const table_result_user_umum = $('#tambah-peserta-list-user-umum');
			$('.search-user').on('keyup', function(){
				let nama_depan = $('#search-user-nama-depan').val();
				let nama_belakang = $('#search-user-nama-belakang').val();
				let email = $('#search-user-email').val();
				fill_search_user(
					this, table_search_user_umum, table_result_user_umum, 'umum',  nama_depan, nama_belakang, email,
					function(){
						$('tbody tr', table_result_user_umum).each(function(){
							let row = this;
							let col_3_jenis = $('td:eq(3)', row);
							let button_hapus_col_3 = $('button', col_3_jenis).clone().addClass('delete-row-add-peserta-umum');
							let is_button_hapus_exists_col_3 = button_hapus_col_3.length > 0;
							if (is_button_hapus_exists_col_3)
							{
								// col 4
								$('<td></td>').appendTo(row);
								// col 5
								$('<td></td>').appendTo(row);

								$('td:eq(5)', row).append(button_hapus_col_3);

								col_3_jenis.empty();
								let dropdown_jenis = $('<select></select>').addClass('custom-select bg-white text-body').attr('name', 'jenis[]');
								$('<option></option>').val('t_u').text('Training & Ujian').appendTo(dropdown_jenis);
								$('<option></option>').val('u').text('Ujian Saja').appendTo(dropdown_jenis);
								dropdown_jenis.appendTo(col_3_jenis);

								let col_4_program = $('td:eq(4)', row);
								let dropdown_program = $('<select></select>').addClass('custom-select bg-white text-body').attr('name', 'id_program_kegiatan[]');
								$(list_program_kegiatan).each(function(){
									$('<option></option>').val(this.id_program_kegiatan).text(this.nama_program).appendTo(dropdown_program);
								});
								dropdown_program.appendTo(col_4_program);
							}
						});
					}
				);
			});
			$(table_result_user_umum).on('click', '.delete-row-add-peserta-umum', function(){
				$(this).parent().parent().remove();
				let email = $('td:eq(2)', $(this).parent().parent()).text().trim();
				$('tbody tr', table_search_user_umum).each(function () {
					if ($('td:eq(2)', this).text().trim().toLowerCase() === email.trim().toLowerCase())
						$('td:eq(3) button', this).removeClass('d-none');
				});
			});
			const form = $('#form-tambah-peserta-umum');
			form.on('submit', function(event){
				event.preventDefault();
				$('tbody tr', table_result_user_umum).each(function(){
					let td_2 = $('td:eq(2)', this);
					let email = td_2.text();
					td_2.html('');
					$('<input></input>').attr('type', 'text').attr('name', 'email[]').addClass('form-control-plaintext').val(email).appendTo(td_2);
				});
				this.submit();
			});
		</script>
	<?php } ?>
	<?php if ($kegiatan_dibuka_untuk_mahasiswa) {?>
		<script id="list-program-kegiatan" type="application/json"><?php echo json_encode($kegiatan->program_kegiatan); ?></script>
		<script>
			const list_program_kegiatan = JSON.parse(document.getElementById('list-program-kegiatan').textContent);
			const table_search_user_mhs = $('#tambah-peserta-search-result-user-mhs');
			const table_result_user_mhs = $('#tambah-peserta-list-user-mhs');
			$('.search-user').on('keyup', function(){
				let nama_depan = $('#search-user-nama-depan').val();
				let nama_belakang = $('#search-user-nama-belakang').val();
				let email = $('#search-user-email').val();
				fill_search_user(
					this, table_search_user_mhs, table_result_user_mhs, 'mahasiswa',  nama_depan, nama_belakang, email,
					function(){
						$('tbody tr', table_result_user_mhs).each(function(){
							let row = this;
							let col_3_jenis = $('td:eq(3)', row);
							let button_hapus_col_3 = $('button', col_3_jenis).clone().addClass('delete-row-add-peserta-umum');
							let is_button_hapus_exists_col_3 = button_hapus_col_3.length > 0;
							if (is_button_hapus_exists_col_3)
							{
								// col 4
								$('<td></td>').appendTo(row);
								// col 5
								$('<td></td>').appendTo(row);

								$('td:eq(5)', row).append(button_hapus_col_3);

								col_3_jenis.empty();
								let dropdown_jenis = $('<select></select>').addClass('custom-select bg-white text-body').attr('name', 'jenis[]');
								$('<option></option>').val('t_u').text('Training & Ujian').appendTo(dropdown_jenis);
								$('<option></option>').val('u').text('Ujian Saja').appendTo(dropdown_jenis);
								dropdown_jenis.appendTo(col_3_jenis);

								let col_4_program = $('td:eq(4)', row);
								let dropdown_program = $('<select></select>').addClass('custom-select bg-white text-body').attr('name', 'id_program_kegiatan[]');
								$(list_program_kegiatan).each(function(){
									$('<option></option>').val(this.id_program_kegiatan).text(this.nama_program).appendTo(dropdown_program);
								});
								dropdown_program.appendTo(col_4_program);
							}
						});
					}
				);
			});
			$(table_result_user_mhs).on('click', '.delete-row-add-peserta-umum', function(){
				$(this).parent().parent().remove();
				let email = $('td:eq(2)', $(this).parent().parent()).text().trim();
				$('tbody tr', table_search_user_mhs).each(function () {
					if ($('td:eq(2)', this).text().trim().toLowerCase() === email.trim().toLowerCase())
						$('td:eq(3) button', this).removeClass('d-none');
				});
			});
			const form = $('#form-tambah-peserta-mhs');
			form.on('submit', function(event){
				event.preventDefault();
				$('tbody tr', table_result_user_mhs).each(function(){
					let td_2 = $('td:eq(2)', this);
					let email = td_2.text();
					td_2.html('');
					$('<input></input>').attr('type', 'text').attr('name', 'email[]').addClass('form-control-plaintext').val(email).appendTo(td_2);
				});
				this.submit();
			});
		</script>
	<?php } ?>
<?php } ?>
<?php
$data = isset($data) ? $data : [];
$this->load->view('admin/components/container_main', ['data' => $data]); ?>

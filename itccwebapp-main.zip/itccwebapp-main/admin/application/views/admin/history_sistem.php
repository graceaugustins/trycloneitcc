<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> Detail History Sistem <?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col-7 align-self-center">
        <h3 class="page-title text-dark font-weight-medium mb-1">
            <?php yield_title($_this, $data); ?>
        </h3>
    </div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
<div class="col-12">
    <div class="card card-sm">
        <div class="card-body">
            <h3 class="card-title mb-4">History Sistem</h3>
            <div class="table-responsive">
                <table id="table-history" class="mb-2 compact" style="white-space: nowrap;">
                    <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>Deskripsi</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($data['history'] as $history) {?>
                        <tr>
                            <td>
                                <?php echo tgl_indo($history['waktu'], 'Y-m-d H:i:s', TRUE)
                                            .' '
                                            .DateTime::createFromFormat('Y-m-d H:i:s', $history['waktu'])->format('H:i:s')
                                            .' WIB'; ?>
                            </td>
                            <td>
                                <?php echo $history['deskripsi']; ?>
                            </td>
                        </tr>
                    <?php } ?>
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>Timestamp</th>
                        <th>Deskripsi</th>
                    </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
<script>
    var table = setupTable('#table-history');
</script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('admin/components/container_main', [ 'data' => $data]); ?>
<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> Detail kelompok <?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col-7 align-self-center">
        <h3 class="page-title text-dark font-weight-medium mb-1">
            <?php yield_title($_this, $data); ?>
        </h3>
    </div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
<?php
/** @var D_Kelompok_U $kelompok */
$kelompok = $data['kelompok'];
/** @var D_Kegiatan $kegiatan */
$kegiatan = $data['kegiatan'];
/** @var bool $is_history */
$is_history = empty($data['history']) ? FALSE : $data['history'];
?>
<div class="col-12">
    <div class="card card-sm">
        <div class="card-body">
			<div class="row">
				<div class="col-md-9 mb-2">
					<h3 class="card-title mb-4">Summary kelompok "<?php echo html_escape($kelompok->nama_kelompok); ?>"</h3>
				</div>
				<?php if (!$is_history) { ?>
				<div class="col-md-3 mb-2">
					<a role="button"
					   href="<?php echo base_url("admin/sertifikasi/kegiatan/kelompok_u/".$kelompok->id."/update"); ?>"
					   class="btn btn-sm btn-light float-right">
						Ubah
					</a>
				</div>
				<?php } ?>
			</div>

            <div class="row mb-4">
				<div class="col-md-6">
					<div class="row mb-2">
						<div class="col-md-5 text-muted">Kegiatan</div>
						<div class="col-md-7 text-dark"><?php echo html_escape($kegiatan->nama_kegiatan); ?></div>
					</div>
					<div class="row mb-2">
						<div class="col-md-5 text-muted">Program</div>
						<div class="col-md-7 text-dark"><?php echo $kelompok->nama_program; ?></div>
					</div>
				</div>
				<div class="col-md-6">
				</div>
				<div class="col-12">
					<hr>
				</div>
                <div class="col-md-6">
                    <div class="row mb-2">
                        <div class="col-md-5 text-muted">Tanggal Ujian</div>
                        <div class="col-md-7 text-dark"><?php echo tgl_indo($kelompok->mulai_ujian->format('Y-m-d H:i:s'), 'Y-m-d H:i:s'); ?></div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-md-5 text-muted">Waktu Ujian</div>
                        <div class="col-md-7 text-dark">
                            <?php echo $kelompok->mulai_ujian->format('H:i:s')
									.' s/d '
									.$kelompok->selesai_ujian->format('H:i:s')
									.' WIB';
                            ?>
                        </div>
                    </div>
					<div class="row mb-2">
						<div class="col-md-5 text-muted">Lokasi Ujian</div>
						<div class="col-md-7 text-dark">
							<?php echo $kelompok->lokasi_ujian; ?>
						</div>
					</div>
					<div class="row mb-2">
						<div class="col-md-5 text-muted">Jumlah terisi</div>
						<div class="col-md-7 text-dark">
							<?php echo count($kelompok->list_peserta); ?>
							dari
							<?php echo $kelompok->max_peserta_ujian; ?>
							(min. <?php echo $kelompok->min_peserta_ujian; ?>)
						</div>
					</div>
                </div>
				<div class="col-md-6">
					<div class="row mb-2">
						<div class="col-md-5 text-muted">Proctor Ujian</div>
						<div class="col-md-7 text-dark">
							<?php if (empty($kelompok->id_proctor_ujian)) {?>
								<code>Belum ada</code>
							<?php } else echo $kelompok->proctor_ujian; ?>
						</div>
					</div>
				</div>
            </div>
        </div>
    </div>
</div>
<div class="col-12">
    <div class="card">
        <div class="card-body">
            <form action="" method="POST">
                <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                <h3 class="card-title mb-4">Ujian</h3>
                <div class="table-responsive mb-4">
                    <table id="absensi-ujian" class="mb-2 compact" style="white-space: nowrap;">
                        <thead>
                        <tr>
                            <th>Foto</th>
                            <?php if ($kegiatan->dibuka_untuk === General_Constants::MAHASISWA) {?>
                            <th>Angkatan</th>
                            <th>Jurusan</th>
                            <th>NIM</th>
                            <?php } ?>
                            <th>Nama</th>
                            <th>Hadir Ujian</th>
                            <th>Skor</th>
							<th>Status</th>
                            <th>Act</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach($kelompok->list_peserta as $peserta) {?>
                            <tr>
                                <td>
                                    <img src="<?php echo $peserta->get_link_foto_profil(); ?>" height="70" alt="logo">
                                </td>
                                <?php if ($kegiatan->dibuka_untuk === General_Constants::MAHASISWA) {?>
                                <td><?php echo $peserta->angkatan_user; ?></td>
                                <td><?php echo config_item('JURUSAN')[$peserta->jurusan_user]; ?></td>
                                <td><?php echo $peserta->nim_user; ?></td>
                                <?php } ?>
                                <td>
                                    <?php echo $peserta->nama_depan_user; ?>
                                    <?php echo $peserta->nama_belakang_user; ?>
                                </td>
                                <td>
									<?php if (!$is_history) { ?>
                                    <select name="hadir_ujian[<?php echo $peserta->id; ?>]">
                                        <option value="y" <?php if ($peserta->hadir_ujian) echo 'selected'; ?>>Hadir</option>
                                        <option value="n" <?php if (!$peserta->hadir_ujian) echo 'selected'; ?>>Tidak Hadir</option>
                                    </select>
									<?php } else {
										if ($peserta->hadir_ujian) echo 'Hadir'; else echo 'Tidak Hadir';
									} ?>
                                </td>
								<td>
									<?php if (!$is_history) { ?>
										<?php if ($peserta->hadir_ujian) { ?>
										<input name="skor_ujian[<?php echo $peserta->id; ?>]" type="text" style="width: 80px;" value="<?php echo $peserta->skor_ujian; ?>">
										<?php } else echo $peserta->skor_ujian; ?></td>
									<?php } else {
										echo $peserta->skor_ujian;
									} ?>
                                <td>
                                    <?php if ($peserta->status_kelulusan === General_Constants::STATUS_LULUS) { ?>
										<span class="badge badge-success">Lulus</span>
									<?php } elseif ($peserta->status_kelulusan === General_Constants::STATUS_TIDAK_LULUS) { ?>
										<span class="badge badge-danger">Tidak Lulus</span>
									<?php } elseif ($peserta->status_kelulusan === General_Constants::STATUS_PENDING) { ?>
										<span class="badge badge-secondary">Pending</span>
									<?php } ?>
                                </td>
                                <td>
                                    <div class="dropdown sub-dropdown">
                                        <button class="btn btn-link text-muted dropdown-toggle" type="button"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
                                        </button>
                                        <div class="dropdown-menu dropdown-menu-right" x-placement="top-end" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-110px, -152px, 0px);">
                                            <a target="_blank" role="button" class="dropdown-item" href="<?php echo base_url('admin/user/'.$peserta->id_user); ?>">Lihat user</a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>
                        </tbody>
                        <tfoot>
                        <tr>
                            <th></th>
                            <?php if ($kegiatan->dibuka_untuk === General_Constants::MAHASISWA) {?>
                            <th><input type="text" style="width: 80px;"></th>
                            <th><input type="text" style="width: 80px;"></th>
                            <th><input type="text" style="width: 80px;"></th>
                            <?php } ?>
                            <th><input type="text" style="width: 80px;"></th>
                            <th><input type="text" style="width: 80px;"></th>
                            <th><input type="text" style="width: 80px;"></th>
							<th><input type="text" style="width: 80px;"></th>
                            <th></th>
                        </tr>
                        </tfoot>
                    </table>
                </div>
                <div class="row mb-4">
                    <div class="col-md-6 mb-2">
                        <label> Berita Acara Ujian</label>
                        <textarea
							<?php if ($is_history) echo "disabled"; ?>
							name="beritaacara_ujian" class="form-control" rows="3" placeholder=""><?php echo $kelompok->beritaacara_ujian; ?></textarea>
                    </div>
                </div>
                <button type="submit" disabled style="display: none" aria-hidden="true"></button>
				<?php if (!$is_history) { ?>
                <button type="submit" class="btn btn-success btn-block">Update Data Ujian</button>
				<?php } ?>
            </form>
        </div>
    </div>
</div>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
<script>
    var table_u = setupTable('#absensi-ujian');
</script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('admin/components/container_main', [ 'data' => $data]); ?>


<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> Dashboard Administrator <?php } ?>
<?php function yield_page_header($_this, $data){?>
	<div class="col-7 align-self-center">
		<h3 class="page-title text-dark font-weight-medium mb-1">
			Dashboard
		</h3>
	</div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
	<?php
	/**
	 * @var D_Kegiatan[] $list_kegiatan_in_registrasi
	 * @var D_Kegiatan[] $list_kegiatan_before_pelaksanaan
	 * @var D_Kegiatan[] $list_kegiatan_in_pelaksanaan
	 */
	$list_kegiatan_in_registrasi = $data['list_kegiatan_in_registrasi'];
	$list_kegiatan_before_pelaksanaan = $data['list_kegiatan_before_pelaksanaan'];
	$list_kegiatan_in_pelaksanaan = $data['list_kegiatan_in_pelaksanaan'];
	?>
	<div class="col-12">
		<strong>Dalam Masa Registrasi</strong>
	</div>
	<div class="col-12">
		<?php if (count($list_kegiatan_in_registrasi) === 0) { ?>
			<small class="text-center d-block">- <i>Kosong</i> - </small>
		<?php } else foreach($list_kegiatan_in_registrasi as $keg) { ?>
			<div class="card">
				<div class="card-body">
					<div class="row g-2 align-items-center">
						<div class=" col-md-5">
							<div class="row align-items-center">
								<div class="col-auto">
									<img src="<?php echo $keg->sertifikasi->get_link_logo();?>" width="50" alt="logo">
								</div>
								<div class="col">
									<h4 class="card-title m-0">
										<?php echo html_escape($keg->nama_kegiatan); ?>
									</h4>
									<div class="text-muted mt-1">
										<?php echo html_escape($keg->sertifikasi->nama); ?>
									</div>
									<div class="mt-1">
										<small>Jumlah pendaftar: <strong><?php echo $keg->get_total_pendaftar_all(); ?></strong></small>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-5 my-md-0 my-sm-2 my-xs-2">
							<div class="ml-2">
								<span style="width:20px;display: inline-block;" class="font-weight-bolder">R</span>
								<?php echo tgl_indo($keg->awal_registrasi->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE); ?>
								s/d
								<?php echo tgl_indo($keg->akhir_registrasi->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE); ?>
							</div>
							<div class="ml-2">
								<span style="width:20px;display: inline-block;" class="font-weight-bolder">T</span>
								<?php
								$max_date = DateTime::createFromFormat('Y-m-d', '2099-12-31');
								$min_date = DateTime::createFromFormat('Y-m-d', '1980-01-01');
								$awal_training = DateTime::createFromFormat('Y-m-d', '2099-12-31');
								$akhir_training = DateTime::createFromFormat('Y-m-d', '1980-01-01');
								foreach($keg->list_kelompok_training as $kelompok_t)
								{
									if (!empty($kelompok_t->mulai_training))
										$awal_training = min($awal_training, $kelompok_t->mulai_training);
									if (!empty($kelompok_t->selesai_training))
										$akhir_training = max($akhir_training, $kelompok_t->selesai_training);
								}
								if ($awal_training == $max_date || $akhir_training == $min_date)
									echo "- (Belum dapat ditentukan)";
								else
								{
									echo tgl_indo($awal_training->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
									echo " s/d ";
									echo tgl_indo($akhir_training->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
								}
								?>
							</div>
							<div class="ml-2">
								<span style="width:20px;display: inline-block;" class="font-weight-bolder">U</span>
								<?php
								$max_date = DateTime::createFromFormat('Y-m-d', '2099-12-31');
								$min_date = DateTime::createFromFormat('Y-m-d', '1980-01-01');
								$awal_ujian = DateTime::createFromFormat('Y-m-d', '2099-12-31');
								$akhir_ujian = DateTime::createFromFormat('Y-m-d', '1980-01-01');
								foreach($keg->list_kelompok_ujian as $kelompok_u)
								{
									if (!empty($kelompok_u->mulai_ujian))
										$awal_ujian = min($awal_ujian, $kelompok_u->mulai_ujian);
									if (!empty($kelompok_u->selesai_ujian))
										$akhir_ujian = max($akhir_ujian, $kelompok_u->selesai_ujian);
								}
								if ($awal_ujian == $max_date || $akhir_ujian == $min_date)
									echo "- (Belum dapat ditentukan)";
								else
								{
									echo tgl_indo($awal_ujian->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
									echo " s/d ";
									echo tgl_indo($akhir_ujian->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
								}
								?>
							</div>
						</div>
						<div class=" col-md-2">
							<a href="<?php echo base_url("admin/sertifikasi/kegiatan/".$keg->id."/detail"); ?>" role="button" class="d-block btn btn-light mb-2"  style="white-space: normal;">
								Detail
							</a>
						</div>
					</div>
				</div>
			</div>
		<?php } ?>
	</div>

	<div class="col-12">
		<strong>Akan Dilaksanakan</strong>
	</div>
	<div class="col-12">
		<?php if (count($list_kegiatan_before_pelaksanaan) === 0) { ?>
			<small class="text-center d-block">- <i>Kosong</i> - </small>
		<?php } else foreach($list_kegiatan_before_pelaksanaan as $keg) { ?>
			<div class="card">
				<div class="card-body">
					<div class="row g-2 align-items-center">
						<div class="col-md-5">
							<div class="row align-items-center">
								<div class="col-auto">
									<img src="<?php echo $keg->sertifikasi->get_link_logo();?>" width="50" alt="logo">
								</div>
								<div class="col">
									<h4 class="card-title m-0">
										<?php echo html_escape($keg->nama_kegiatan); ?>
									</h4>
									<div class="text-muted mt-1">
										<?php echo html_escape($keg->sertifikasi->nama); ?>
									</div>
									<div class="mt-1">
										<small>
											Jumlah kelompok:
											<strong><?php echo count($keg->list_kelompok_training); ?> (T)</strong>,
											<strong><?php echo count($keg->list_kelompok_ujian); ?> (U)</strong>
										</small>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-5 my-md-0 my-sm-2 my-xs-2">
							<div class="ml-2">
								<span style="width:20px;display: inline-block;" class="font-weight-bolder">R</span>
								<?php if (!empty($keg->awal_registrasi) && !empty($keg->akhir_registrasi)) { ?>
									<?php echo tgl_indo($keg->awal_registrasi->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE); ?>
									s/d
									<?php echo tgl_indo($keg->akhir_registrasi->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE); ?>
								<?php } else { ?>
									-
								<?php } ?>
							</div>
							<div class="ml-2">
								<span style="width:20px;display: inline-block;" class="font-weight-bolder">T</span>
								<?php
								$max_date = DateTime::createFromFormat('Y-m-d', '2099-12-31');
								$min_date = DateTime::createFromFormat('Y-m-d', '1980-01-01');
								$awal_training = DateTime::createFromFormat('Y-m-d', '2099-12-31');
								$akhir_training = DateTime::createFromFormat('Y-m-d', '1980-01-01');
								foreach($keg->list_kelompok_training as $kelompok_t)
								{
									if (!empty($kelompok_t->mulai_training))
										$awal_training = min($awal_training, $kelompok_t->mulai_training);
									if (!empty($kelompok_t->selesai_training))
										$akhir_training = max($akhir_training, $kelompok_t->selesai_training);
								}
								if ($awal_training == $max_date || $akhir_training == $min_date)
									echo "- (Belum dapat ditentukan)";
								else
								{
									echo tgl_indo($awal_training->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
									echo " s/d ";
									echo tgl_indo($akhir_training->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
								}
								?>
							</div>
							<div class="ml-2">
								<span style="width:20px;display: inline-block;" class="font-weight-bolder">U</span>
								<?php
								$max_date = DateTime::createFromFormat('Y-m-d', '2099-12-31');
								$min_date = DateTime::createFromFormat('Y-m-d', '1980-01-01');
								$awal_ujian = DateTime::createFromFormat('Y-m-d', '2099-12-31');
								$akhir_ujian = DateTime::createFromFormat('Y-m-d', '1980-01-01');
								foreach($keg->list_kelompok_ujian as $kelompok_u)
								{
									if (!empty($kelompok_u->mulai_ujian))
										$awal_ujian = min($awal_ujian, $kelompok_u->mulai_ujian);
									if (!empty($kelompok_u->selesai_ujian))
										$akhir_ujian = max($akhir_ujian, $kelompok_u->selesai_ujian);
								}
								if ($awal_ujian == $max_date || $akhir_ujian == $min_date)
									echo "- (Belum dapat ditentukan)";
								else
								{
									echo tgl_indo($awal_ujian->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
									echo " s/d ";
									echo tgl_indo($akhir_ujian->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
								}
								?>
							</div>
						</div>
						<div class=" col-md-2">
							<a href="<?php echo base_url("admin/sertifikasi/kegiatan/".$keg->id."/detail"); ?>" role="button" class="d-block btn btn-light mb-2"  style="white-space: normal;">
								Detail
							</a>
						</div>
					</div>
				</div>
			</div>
		<?php } ?>
	</div>

	<div class="col-12">
		<strong>Sedang Dilaksanakan</strong>
	</div>
	<div class="col-12">
		<?php if (count($list_kegiatan_in_pelaksanaan) === 0) { ?>
			<small class="text-center d-block">- <i>Kosong</i> - </small>
		<?php } else foreach($list_kegiatan_in_pelaksanaan as $keg) { ?>
			<div class="card">
				<div class="card-body">
					<div class="row g-2 align-items-center">
						<div class="col-md-5">
							<div class="row align-items-center">
								<div class="col-auto">
									<img src="<?php echo $keg->sertifikasi->get_link_logo();?>" width="50" alt="logo">
								</div>
								<div class="col">
									<h4 class="card-title m-0">
										<?php echo html_escape($keg->nama_kegiatan); ?>
									</h4>

									<div class="text-muted mt-1">
										<?php echo html_escape($keg->sertifikasi->nama); ?>
									</div>
									<div class="mt-1">
										<small>Jumlah kelompok: <strong><?php echo count($keg->list_kelompok_training); ?></strong></small>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-5 my-md-0 my-sm-2 my-xs-2">
							<div class="ml-2">
								<span style="width:20px;display: inline-block;" class="font-weight-bolder">R</span>
								<?php if (!empty($keg->awal_registrasi) && !empty($keg->akhir_registrasi)) { ?>
									<?php echo tgl_indo($keg->awal_registrasi->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE); ?>
									s/d
									<?php echo tgl_indo($keg->akhir_registrasi->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE); ?>
								<?php } else { ?>
									-
								<?php } ?>
							</div>
							<div class="ml-2">
								<span style="width:20px;display: inline-block;" class="font-weight-bolder">T</span>
								<?php
								$max_date = DateTime::createFromFormat('Y-m-d', '2099-12-31');
								$min_date = DateTime::createFromFormat('Y-m-d', '1980-01-01');
								$awal_training = DateTime::createFromFormat('Y-m-d', '2099-12-31');
								$akhir_training = DateTime::createFromFormat('Y-m-d', '1980-01-01');
								foreach($keg->list_kelompok_training as $kelompok_t)
								{
									if (!empty($kelompok_t->mulai_training))
										$awal_training = min($awal_training, $kelompok_t->mulai_training);
									if (!empty($kelompok_t->selesai_training))
										$akhir_training = max($akhir_training, $kelompok_t->selesai_training);
								}
								if ($awal_training == $max_date || $akhir_training == $min_date)
									echo "- (Belum dapat ditentukan)";
								else
								{
									echo tgl_indo($awal_training->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
									echo " s/d ";
									echo tgl_indo($akhir_training->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
								}
								?>
							</div>
							<div class="ml-2">
								<span style="width:20px;display: inline-block;" class="font-weight-bolder">U</span>
								<?php
								$max_date = DateTime::createFromFormat('Y-m-d', '2099-12-31');
								$min_date = DateTime::createFromFormat('Y-m-d', '1980-01-01');
								$awal_ujian = DateTime::createFromFormat('Y-m-d', '2099-12-31');
								$akhir_ujian = DateTime::createFromFormat('Y-m-d', '1980-01-01');
								foreach($keg->list_kelompok_ujian as $kelompok_u)
								{
									if (!empty($kelompok_u->mulai_ujian))
										$awal_ujian = min($awal_ujian, $kelompok_u->mulai_ujian);
									if (!empty($kelompok_u->selesai_ujian))
										$akhir_ujian = max($akhir_ujian, $kelompok_u->selesai_ujian);
								}
								if ($awal_ujian == $max_date || $akhir_ujian == $min_date)
									echo "- (Belum dapat ditentukan)";
								else
								{
									echo tgl_indo($awal_ujian->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
									echo " s/d ";
									echo tgl_indo($akhir_ujian->format('Y-m-d H:i:s'), 'Y-m-d H:i:s', TRUE);
								}
								?>
							</div>
						</div>
						<div class="col-md-2">
							<a href="<?php echo base_url("admin/sertifikasi/kegiatan/".$keg->id."/detail"); ?>" role="button" class="d-block btn btn-light mb-2"  style="white-space: normal;">
								Detail
							</a>
						</div>
					</div>
				</div>
			</div>
		<?php } ?>
	</div>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('admin/components/container_main', [ 'data' => $data]); ?>

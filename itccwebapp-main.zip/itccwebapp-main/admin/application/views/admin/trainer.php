<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> Trainer <?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col-7 align-self-center">
        <h3 class="page-title text-dark font-weight-medium mb-1">
            <?php yield_title($_this, $data); ?>
        </h3>
    </div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
    <?php
	/**
	 * @var D_Trainer[] $trainer_aktif
	 * @var D_Trainer[] $trainer_nonaktif
	 * @var D_Sertifikasi[] $list_sertifikasi
	 * */
	$trainer_aktif = $data['trainer_aktif'];
	$trainer_nonaktif = $data['trainer_nonaktif'];
	$list_sertifikasi = $data['sertifikasi'];?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <!-- Tabs -->
                <ul class="nav nav-tabs nav-bordered mb-3">
                    <li class="nav-item">
                        <a href="#profil-trainer-aktif" data-toggle="tab" class="nav-link active">
                            Profil Trainer
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#profil-trainer-nonaktif" data-toggle="tab" class="nav-link">
                            Trainer nonaktif
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#performance" data-toggle="tab" class="nav-link">
                            Performa
                        </a>
                    </li>
                </ul>

                <div class="tab-content">
                    <div class="tab-pane show active" id="profil-trainer-aktif">
                        <div class="my-2">
                            <?php if(admin_capable('tambah_list_trainer')) {?>
                            <button class="btn btn-light mb-3 float-right" type="button" data-toggle='modal' data-target='#tambah-trainer'>Tambah Trainer Baru</button>
                            <?php } ?>
                        </div>

                        <div class="table-responsive">
                            <table id="t-profil-trainer" class="mb-2 compact">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Foto</th>
                                    <th>Email</th>
                                    <th>Nama</th>
                                    <th>No. Telepon</th>
                                    <th>Program</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $i=1;
                                foreach($trainer_aktif as $t) { ?>
									<tr>
										<td><?php echo $i++; ?></td>
										<td>
											<span class="d-none id-trainer"><?php echo $t->id; ?></span>
											<?php if (!empty($t->list_sertifikasi))
												foreach($t->list_sertifikasi as $s){
													foreach ($s->list_program as $p) {?>
														<span class="d-none id-program"><?php echo $p->id; ?></span>
												<?php }
												} ?>
											<img height="70"
												 src="<?php echo $t->get_link_profile(); ?>" alt="logo">
										</td>
										<td><?php echo html_escape($t->email); ?></td>
										<td><?php echo html_escape($t->nama_lengkap); ?></td>
										<td><?php echo html_escape($t->no_telepon); ?></td>
										<td style="width:28%;">
											<?php if (empty($t->list_sertifikasi)) echo '-';
											else foreach($t->list_sertifikasi as $s){
												foreach($s->list_program as $p) { ?>
												<?php echo html_escape($s->nama.'-'.$p->nama_program); ?><br>
											<?php }
											} ?>
										</td>
										<td>
											<?php if (admin_capable('edit_list_trainer')) {?>
												<button class="btn btn-sm m-1 btn-info" data-toggle="modal" data-target="#ubah-trainer">Ubah</button>
											<?php } ?>
											<?php if (admin_capable('hapus_list_trainer')) {?>
												<button class="btn btn-sm m-1 btn-danger" data-toggle="modal" data-target="#hapus-trainer">Hapus/Nonaktif</button>
											<?php } ?>
										</td>
									</tr>
								<?php } ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <th>#</th>
                                    <th>Foto</th>
                                    <th><input style="width:80px" type="text" ></th>
                                    <th><input style="width:80px" type="text" ></th>
                                    <th><input style="width:80px" type="text" ></th>
                                    <th><input style="width:120px" type="text" ></th>
                                    <th>Action</th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>

                    <div class="tab-pane" id="profil-trainer-nonaktif">
                        <div class="table-responsive">
                            <table id="t-profil-trainer-nonaktif" class="mb-2 compact">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Foto</th>
                                    <th>Email</th>
                                    <th>Nama</th>
                                    <th>No. Telepon</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $i=1;
                                foreach($trainer_nonaktif as $t) { ?>
									<tr>
										<td><?php echo $i++; ?></td>
										<td><img height="70"
												 src="<?php echo $t->get_link_profile(); ?>"></td>
										<td><?php echo html_escape($t->email); ?></td>
										<td><?php echo html_escape($t->nama_lengkap); ?></td>
										<td><?php echo html_escape($t->no_telepon); ?></td>
										<td>
											<?php if (admin_capable('edit_list_trainer')) {?>
												<button class="btn btn-sm btn-success" data-id="<?php echo $t->id; ?>" data-toggle="modal" data-target="#aktifkan-trainer">Set Aktif</button>
											<?php } ?>
										</td>
									</tr>
								<?php } ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <th>#</th>
                                    <th>Foto</th>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th><input type="text" style="width: 80px;"></th>
                                    <th>Action</th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>

					<div class="tab-pane" id="performance">
						<div class="row mb-2">
							<div class="col-md-4">
								<form action="" method="GET">
									<select onchange="this.form.submit();" class="custom-select text-dark" required="required" name="view_sertif_performance">
										<option value="all">Semua Sertifikasi</option>
										<?php foreach($list_sertifikasi as $s) { ?>
											<option value="<?php echo $s->id; ?>"
											<?php if ($data['view_sertif_performance'] === (string)$s->id) echo "selected"; ?>
											>
												<?php echo html_escape($s->nama); ?>
											</option>
										<?php } ?>
									</select>
								</form>
							</div>
						</div>

						<div class="table-responsive">
							<table id="t-performa-trainer" class="mb-2 nowrap w-100">
								<thead>
								<tr>
									<th rowspan="2">Nama</th>
									<?php if ($data['view_sertif_performance'] === "all"){
										foreach($list_sertifikasi as $sertif) {?>
											<th colspan="2" class="text-center"><?php echo html_escape($sertif->nama); ?></th>
										<?php }
									} else {
										$id_sertif = (int)$data['view_sertif_performance'];
										$selected_sertifikasi = array_filter($list_sertifikasi, function($s) use ($id_sertif){
											return (int)$s->id === $id_sertif;
										});

										/**
										 * @var D_Sertifikasi $selected_sertifikasi
										 * */
										$selected_sertifikasi = reset($selected_sertifikasi);
										foreach($selected_sertifikasi->list_program as $program){ ?>
											<th colspan="2" class="text-center"><?php echo html_escape($program->nama_program); ?></th>
									<?php }
									} ?>
									<th colspan="2" class="text-center">Total</th>
									<th rowspan="2" class="text-center" style="width: 200px;">Rating</th>
								</tr>
								<tr>
									<?php if ($data['view_sertif_performance'] === "all"){
										foreach($list_sertifikasi as $s) {?>
											<th class="text-center">Lulus</th>
											<th class="text-center">Gagal</th>
										<?php }
									} else {
										$id_sertif = (int)$data['view_sertif_performance'];
										$selected_sertifikasi = array_filter($list_sertifikasi, function($s) use ($id_sertif){
											return (int)$s->id === $id_sertif;
										});

										/**
										 * @var D_Sertifikasi $selected_sertifikasi
										 * */
										$selected_sertifikasi = reset($selected_sertifikasi);
										foreach($selected_sertifikasi->list_program as $program){ ?>
											<th class="text-center">Lulus</th>
											<th class="text-center">Gagal</th>
										<?php }
									} ?>
									<th class="text-center">Lulus</th>
									<th class="text-center">Gagal</th>
								</tr>
								</thead>
								<tbody>
								<?php
								$list_trainer = [];
								foreach($trainer_aktif as $t) {
									$list_trainer[] = $t;
								}
								foreach($trainer_nonaktif as $t) {
									$list_trainer[] = $t;
								}
								foreach($list_trainer as $t) {
									if ($data['view_sertif_performance'] !== "all")
									{
										$id_sertif = (int)$data['view_sertif_performance'];
										$sertif_trainer = array_filter($t->list_sertifikasi, function($s) use($id_sertif){
											return $id_sertif === (int)$s->id;
										});
										if (count($sertif_trainer) === 0) continue;
									}
								?>
								<tr>
									<td><?php echo html_escape($t->nama_lengkap); ?></td>
									<?php
									$total_lulus = 0;
									$total_tidak_lulus = 0;
									if ($data['view_sertif_performance'] === "all")
									{
										foreach($list_sertifikasi as $s){
											$id = (int)$s->id;
											$selected_performa = array_filter($t->performance, function($stat) use ($id){
												return $id === (int)$stat->id_sertifikasi;
											});
											$jumlah_lulus = 0;
											$jumlah_tidaklulus = 0;
											if (!empty($selected_performa))
											{
												/**
												 * @var D_Performa_Trainer $selected_performa
												 * */
												$selected_performa = reset($selected_performa);
												foreach($selected_performa->list_program as $program)
												{
													$total_lulus += (int)$program->total_lulus;
													$total_tidak_lulus += (int)$program->total_tidak_lulus;
													$jumlah_lulus += (int)$program->total_lulus;
													$jumlah_tidaklulus += (int)$program->total_tidak_lulus;
												}
											}
											?>
											<td class="text-center"><?php echo (empty($selected_performa))?'-':$jumlah_lulus; ?></td>
											<td class="text-center"><?php echo (empty($selected_performa))?'-':$jumlah_tidaklulus; ?></td>
										<?php }
									} else {
										$id_sertif = (int)$data['view_sertif_performance'];
										$selected_sertifikasi = array_filter($list_sertifikasi, function($s) use ($id_sertif){
											return (int)$s->id === $id_sertif;
										});

										/**
										 * @var D_Sertifikasi $selected_sertifikasi
										 * */
										$selected_sertifikasi = reset($selected_sertifikasi);
										$selected_performa_sertifikasi = array_filter($t->performance, function($performance) use ($id_sertif){
											return $id_sertif === (int)$performance->id_sertifikasi;
										});
										/**
										 * @var D_Performa_Trainer $selected_performa_sertifikasi
										 * */
										$selected_performa_sertifikasi = reset($selected_performa_sertifikasi);
										foreach($selected_sertifikasi->list_program as $program){ ?>

											<?php
											$id_program = (int)$program->id;
											$selected_performa_program = array_filter($selected_performa_sertifikasi->list_program, function ($p) use ($id_program){
												return (int)$p->id_program === $id_program;
											});
											/**
											 * @var D_Program_Performa_Trainer $selected_performa_program
											 * */
											$selected_performa_program = reset($selected_performa_program);
											$jumlah_lulus = '-';
											$jumlah_tidaklulus = '-';
											if (!empty($selected_performa_program))
											{
												$jumlah_lulus = $selected_performa_program->total_lulus;
												$jumlah_tidaklulus = $selected_performa_program->total_tidak_lulus;
												$total_lulus += (int)$selected_performa_program->total_lulus;
												$total_tidak_lulus += (int)$selected_performa_program->total_tidak_lulus;
											}
											?>
											<td class="text-center"><?php echo $jumlah_lulus; ?></td>
											<td class="text-center"><?php echo $jumlah_tidaklulus; ?></td>

										<?php }
									} ?>
									<td class="text-center"><?php echo $total_lulus; ?></td>
									<td class="text-center"><?php echo $total_tidak_lulus; ?></td>
									<td>
										<?php
										$rating = 0;
										$all = $total_lulus + $total_tidak_lulus;
										if ($all >0)
										{
											$rating = (int)($total_lulus*100/$all);
										}
										?>
										<div class="text-center">
											<div class="stars-outer font-20">
												<div class="text-center stars-inner" data-percentage="<?php echo $rating; ?>"></div>
											</div>
										</div>
									</td>
								</tr>
								<?php } ?>
								</tbody>
								<tfoot>
								<tr>
									<th><input style="width:80px" type="text" ></th>
									<?php if ($data['view_sertif_performance'] === "all"){
										foreach($list_sertifikasi as $sertif) {?>
											<th></th>
											<th></th>
										<?php }
									} else {
										$id_sertif = (int)$data['view_sertif_performance'];
										$selected_sertifikasi = array_filter($list_sertifikasi, function($s) use ($id_sertif){
											return (int)$s->id === $id_sertif;
										});
										/**
										 * @var D_Sertifikasi $selected_sertifikasi
										 * */
										$selected_sertifikasi = reset($selected_sertifikasi);
										foreach($selected_sertifikasi->list_program as $program){ ?>
											<th></th>
											<th></th>
										<?php }
									} ?>

									<th></th>
									<th></th>
									<th></th>
								</tr>
								</tfoot>
							</table>
						</div>
					</div>
                </div>

            </div>
        </div>
    </div>
<?php } ?>

<?php function yield_bottom_before_script($_this, $data) { ?>
    <?php
	/**
	 * @var D_Sertifikasi[] $list_sertifikasi
	 * */
	$list_sertifikasi = $data['sertifikasi'];
	?>
    <!-- Modal tambah trainer -->
    <?php if(admin_capable('tambah_list_trainer')) {?>
        <div id="tambah-trainer" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-tambah-trainer" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-tambah-trainer">Tambah Trainer Baru</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/trainer/add_new'); ?>" enctype='multipart/form-data' >
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <label for="tambah-trainer-email">Alamat email (akun Microsoft, huruf kecil, tanpa spasi)</label>
                            <input class="form-control mb-2" id="tambah-trainer-email" type="email" name="email" required="required">

                            <label for="tambah-trainer-nama">Nama lengkap trainer</label>
                            <input class="form-control mb-2" id="tambah-trainer-nama" type="text" name="nama_lengkap" required="required">

                            <label for="tambah-trainer-telepon">Nomor telepon</label>
                            <div class="row mb-2">
                                <div class="col-2">
                                    <input type="text" readonly class="form-control-plaintext text-right" value="+62">
                                </div>
                                <div class="col-10">
                                    <input class="form-control mb-2" id="tambah-trainer-telepon" type="text" pattern="[0-9]+" name="nomor_telepon" required="required">
                                </div>
                            </div>

                            <label for="tambah-trainer-foto">Upload foto trainer <br><small>(jika tidak diberikan, maka akan memakai foto default)</small></label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="tambah-trainer-foto" name="foto">
                                <label class="custom-file-label" for="tambah-trainer-foto">File .jpg atau .png max 500KB</label>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Tambah</button>
                        </div>
                    </form>


                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>

    <!-- Modal edit trainer -->
    <?php if(admin_capable('edit_list_trainer')) {?>
        <div id="ubah-trainer" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-edit-trainer" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-edit-trainer">Ubah Data Trainer</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/trainer/update'); ?>" enctype="multipart/form-data">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <input type="hidden" name="id">
                            <label for="ubah-trainer-email">Alamat email (akun Microsoft, huruf kecil, tanpa spasi)</label>
                            <input class="form-control mb-2" id="ubah-trainer-email" type="email" name="email" required="required">

                            <label for="ubah-trainer-nama">Nama lengkap trainer</label>
                            <input class="form-control mb-2" id="ubah-trainer-nama" type="text" name="nama_lengkap" required="required">

                            <label for="ubah-trainer-telepon">Nomor telepon</label>
                            <div class="row mb-2">
                                <div class="col-2">
                                    <input type="text" readonly class="form-control-plaintext text-right" value="+62">
                                </div>
                                <div class="col-10">
                                    <input class="form-control mb-2" id="ubah-trainer-telepon" type="text" pattern="[0-9]+" name="nomor_telepon" required="required">
                                </div>
                            </div>

                            <div class="custom-control custom-checkbox my-2">
                                <input id="ubah-trainer-ganti-foto" class="custom-control-input" type="checkbox" name="ganti_profil">
                                <label for="ubah-trainer-ganti-foto" class="custom-control-label">Ganti foto trainer?</label>
                            </div>
                            <div>
                                <label for="ubah-trainer-foto">Upload foto trainer <br><small>(jika tidak diberikan, maka akan memakai foto default)</small></label>
                                <div class="custom-file mb-3">
                                    <input type="file" class="custom-file-input" id="ubah-trainer-foto" name="foto">
                                    <label class="custom-file-label" for="ubah-trainer-foto">File .jpg atau .png max 500KB</label>
                                </div>
                            </div>

                            <div class="mb-2">Sertifikasi Trainer</div>
                            <div class="accordion" id="accordion-ubah-trainer" >
                                <?php foreach($list_sertifikasi as $s) {?>
                                    <div class="card">
                                        <div class="card-header border" id="h-accord-<?php echo $s->id; ?>" style="padding:5px;">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse-accord-<?php echo $s->id; ?>" aria-expanded="false" aria-controls="collapse-accord-<?php echo $s->id; ?>">
                                                    <?php echo html_escape($s->nama); ?>
                                                </button>
                                            </h2>
                                        </div>

                                        <div id="collapse-accord-<?php echo $s->id; ?>" class="collapse" aria-labelledby="h-accord-<?php echo $s->id; ?>" data-parent="#accordion-ubah-trainer">
                                            <div class="card-body border" style="padding:5px 0 0 13px;">
                                                <?php foreach($s->list_program as $p) { ?>
                                                    <div class="custom-control custom-checkbox my-2">
                                                        <input id="program-accord-<?php echo $p->id; ?>" class="custom-control-input"
                                                               type="checkbox" name="id_program[]" value="<?php echo $p->id; ?>"
                                                        >
                                                        <label for="program-accord-<?php echo $p->id; ?>" class="custom-control-label"><?php echo html_escape($p->nama_program); ?></label>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Ubah</button>
                        </div>
                    </form>

                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>

    <!-- Modal hapus trainer -->
    <?php if(admin_capable('hapus_list_trainer')) {?>
        <div id="hapus-trainer" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-hapus-trainer" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-hapus-trainer">Anda yakin ingin menghapus trainer ini?</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/trainer/delete'); ?>">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <input type="hidden" name="id">
                            <div class="mb-2">
                                Trainer : <strong class="m-hapus-trainer-nama"></strong>
                            </div>
                            <div class="alert alert-warning fade show" role="alert">
                                <strong class="d-block mb-2">Jika trainer ini baru saja ditambahkan, atau belum pernah mengikuti sertifikasi apapun,
                                    maka akan dihapus dari database.</strong>
                                <strong class="d-block">Jika trainer ini sudah pernah mengikuti sertifikasi, akan di nonaktifkan (tidak dihapus).</strong>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-danger float-right">Hapus/Nonaktif</button>
                        </div>
                    </form>

                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>

    <!-- Modal aktifkan trainer -->
    <?php if(admin_capable('edit_list_trainer')) {?>
        <div id="aktifkan-trainer" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-aktifkan-trainer" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-aktifkan-trainer">Konfirmasi</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/trainer/set_aktif'); ?>">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <input type="hidden" name="id">
                            <div class="mb-2">
                                Trainer : <strong class="m-aktifkan-trainer-nama"></strong>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success float-right">Set Aktif</button>
                        </div>
                    </form>

                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
    <script type="text/javascript">
        let t_trainer_aktif = setupTable('#t-profil-trainer');
        let t_trainer_nonaktif = setupTable('#t-profil-trainer-nonaktif');
        let t_performa_trainer = setupTable('#t-performa-trainer');

        const checkbox_ubah_trainer_foto = $('#ubah-trainer-ganti-foto');
        const form_ubah_trainer_foto = $('#ubah-trainer-foto');

        function switch_ubah_trainer_foto(){
            if (checkbox_ubah_trainer_foto.is(':checked')) form_ubah_trainer_foto.parent().parent().removeClass('d-none');
            else form_ubah_trainer_foto.val('').parent().parent().addClass('d-none');
        }

        switch_ubah_trainer_foto();
        checkbox_ubah_trainer_foto.on('change', function(){
            switch_ubah_trainer_foto();
        });

        $('#ubah-trainer').on('show.bs.modal', function (event) {
            let button = $(event.relatedTarget); // Button that triggered the modal
            var modal = $(this);
            let p = button.parent().parent();
            modal.find('.modal-body input[name=id]').val(p.children('td:eq(1)').children('.id-trainer').text());
            modal.find('.modal-body input[name=email]').val(p.children('td:eq(2)').text());
            modal.find('.modal-body input[name=nama_lengkap]').val(p.children('td:eq(3)').text());
            modal.find('.modal-body input[name=nomor_telepon]').val(p.children('td:eq(4)').text());
            let id_program = p.children('td:eq(1)').children('.id-program');
            // centang sertifikasi di modal
            modal.find('.modal-body .accordion .card-body .custom-checkbox input[type=checkbox]').each(function(){
                let that = $(this);
                id_program.each(function(){
                    if (that.val() === $(this).text())
                        that.attr('checked', true);
                });
            });
        });

        $('#hapus-trainer').on('show.bs.modal', function (event) {
            let button = $(event.relatedTarget); // Button that triggered the modal
            var modal = $(this);
            let p = button.parent().parent();
            modal.find('.modal-body input[name=id]').val(p.children('td:eq(1)').children('.id-trainer').text());
            modal.find('.modal-body .m-hapus-trainer-nama').text(p.children('td:eq(3)').text());
        });

        $('#aktifkan-trainer').on('show.bs.modal', function (event) {
            let button = $(event.relatedTarget); // Button that triggered the modal
            var modal = $(this);
            modal.find('.modal-body input[name=id]').val(button.data('id'));
            modal.find('.modal-body .m-aktifkan-trainer-nama').text(button.parent().parent().children('td:eq(3)').text());
        });
    </script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('admin/components/container_main', [ 'data' => $data]); ?>

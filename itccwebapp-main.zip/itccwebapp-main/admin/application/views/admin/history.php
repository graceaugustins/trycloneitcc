<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> History Kegiatan Sertifikasi <?php } ?>
<?php function yield_page_header($_this, $data){?>
	<div class="col-7 align-self-center">
		<h3 class="page-title text-dark font-weight-medium mb-1">
			<?php yield_title($_this, $data); ?>
		</h3>
	</div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
	<?php
	/** @var D_Kegiatan[] $list_kegiatan_inactive */
	$list_kegiatan_inactive = $data['list_kegiatan_inactive'];
	/** @var D_Kegiatan[] $list_kegiatan_cancelled */
	$list_kegiatan_cancelled = $data['list_kegiatan_cancelled'];
	?>
	<div class="col-12">
		<strong>Kegiatan yang Sudah Selesai</strong>
	</div>
	<div class="col-12">
		<?php if (empty($list_kegiatan_inactive)) {?>
			<small class="text-center d-block">- <i>Kosong</i> - </small>
		<?php } else foreach ($list_kegiatan_inactive as $keg) {?>
			<div class="card">
		<div class="card-body">
			<div class="row g-2 align-items-center">
				<div class=" col-md-9">
					<div class="row align-items-center">
						<div class="col-auto">
							<img src="<?php echo $keg->sertifikasi->get_link_logo();?>" width="50">
						</div>
						<div class="col">
							<h4 class="card-title m-0">
								<?php echo $keg->nama_kegiatan; ?>
							</h4>

							<div class="text-muted mt-1">
								<?php echo $keg->sertifikasi->nama; ?>
							</div>
							<div class="mt-1">
								<small>Total Pendaftar: <strong><?php echo $keg->get_total_pendaftar_all(); ?></strong></small>
							</div>
						</div>
					</div>
				</div>
				<div class=" col-md-3">
					<a href="<?php echo base_url('admin/sertifikasi/history/'.$keg->id); ?>" role="button" class="d-block btn btn-light mb-2"  style="white-space: normal;">
						Detail
					</a>
				</div>
			</div>
		</div>
	</div>
		<?php } ?>
	</div>
	<div class="col-12">
		<strong>Kegiatan yang Dibatalkan</strong>
	</div>
	<div class="col-12">
		<?php if (empty($list_kegiatan_cancelled)) {?>
			<small class="text-center d-block">- <i>Kosong</i> - </small>
		<?php } else foreach ($list_kegiatan_cancelled as $keg) {?>
			<div class="card">
				<div class="card-body">
					<div class="row g-2 align-items-center">
						<div class=" col-md-9">
							<div class="row align-items-center">
								<div class="col-auto">
									<img src="<?php echo $keg->sertifikasi->get_link_logo();?>" width="50">
								</div>
								<div class="col">
									<h4 class="card-title m-0">
										<?php echo $keg->nama_kegiatan; ?>
									</h4>

									<div class="text-muted mt-1">
										<?php echo $keg->sertifikasi->nama; ?>
									</div>
									<div class="mt-1">
										<small>Total Pendaftar: <strong><?php echo $keg->get_total_pendaftar_all(); ?></strong></small>
									</div>
								</div>
							</div>
						</div>
						<div class=" col-md-3">
							<a href="<?php echo base_url('admin/sertifikasi/history/'.$keg->id); ?>" role="button" class="d-block btn btn-light mb-2"  style="white-space: normal;">
								Detail
							</a>
						</div>
					</div>
				</div>
			</div>
		<?php } ?>
	</div>

<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('admin/components/container_main', [ 'data' => $data]); ?>

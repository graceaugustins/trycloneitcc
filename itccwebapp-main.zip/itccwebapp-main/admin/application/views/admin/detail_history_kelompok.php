<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> History kelompok <?php } ?>
<?php function yield_page_header($_this, $data){?>
	<div class="col-7 align-self-center">
		<h3 class="page-title text-dark font-weight-medium mb-1">
			<?php yield_title($_this, $data); ?>
		</h3>
	</div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
	<div class="col-12">
		<div class="card card-sm">
			<div class="card-body">
				<div class="row">
					<div class="col-md-9 mb-2">
						<h3 class="card-title mb-4">Summary kelompok "<?php echo $data['kelompok']['nama_kelompok']; ?>"</h3>
					</div>
					<div class="col-md-3 mb-2">
					</div>
				</div>

				<div class="row mb-4">
					<div class="col-md-6">
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Kegiatan</div>
							<div class="col-md-7 text-dark"><?php echo $data['kegiatan']['nama_kegiatan']; ?></div>
						</div>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Program</div>
							<div class="col-md-7 text-dark"><?php echo $data['kelompok']['nama_program']; ?></div>
						</div>
					</div>
					<div class="col-md-6">
					</div>
					<div class="col-12">
						<hr>
					</div>
					<div class="col-md-6">
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Tanggal Training</div>
							<div class="col-md-7 text-dark"><?php echo tgl_indo($data['kelompok']['mulai_training'], 'Y-m-d H:i:s'); ?></div>
						</div>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Waktu Training</div>
							<div class="col-md-7 text-dark">
								<?php echo DateTime::createFromFormat('Y-m-d H:i:s', $data['kelompok']['mulai_training'])->format('H:i')
										.' s/d '
										.DateTime::createFromFormat('Y-m-d H:i:s', $data['kelompok']['selesai_training'])->format('H:i')
										.' WIB';
								?>
							</div>
						</div>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Lokasi Training</div>
							<div class="col-md-7 text-dark">
								<?php echo $data['kelompok']['lokasi_training']; ?>
							</div>
						</div>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Trainer (Sesi 1) </div>
							<div class="col-md-7 text-dark">
								<?php if (empty($data['kelompok']['trainer_sesi1'])) {?>
									<code>Belum ada</code>
								<?php } else echo $data['kelompok']['trainer_sesi1']; ?>
							</div>
						</div>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Trainer (Sesi 2) </div>
							<div class="col-md-7 text-dark">
								<?php if (empty($data['kelompok']['trainer_sesi2'])) {?>
									<code>Belum ada</code>
								<?php } else echo $data['kelompok']['trainer_sesi2']; ?>
							</div>
						</div>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Proctor Training</div>
							<div class="col-md-7 text-dark">
								<?php if (empty($data['kelompok']['proctor_training'])) {?>
									<code>Belum ada</code>
								<?php } else echo $data['kelompok']['proctor_training']; ?>
							</div>
						</div>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Jumlah terisi (training)</div>
							<div class="col-md-7 text-dark">
								<?php echo $data['kelompok']['jumlah_peserta_t']; ?>
								dari
								<?php echo $data['kelompok']['max_peserta_training']; ?>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Tanggal Ujian</div>
							<div class="col-md-7 text-dark"><?php echo tgl_indo($data['kelompok']['mulai_ujian'], 'Y-m-d H:i:s'); ?></div>
						</div>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Waktu Ujian</div>
							<div class="col-md-7 text-dark">
								<?php echo DateTime::createFromFormat('Y-m-d H:i:s', $data['kelompok']['mulai_ujian'])->format('H:i')
										.' s/d '
										.DateTime::createFromFormat('Y-m-d H:i:s', $data['kelompok']['selesai_ujian'])->format('H:i')
										.' WIB';
								?>
							</div>
						</div>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Lokasi Ujian</div>
							<div class="col-md-7 text-dark">
								<?php echo $data['kelompok']['lokasi_ujian']; ?>
							</div>
						</div>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Proctor Ujian</div>
							<div class="col-md-7 text-dark">
								<?php if (empty($data['kelompok']['proctor_ujian'])) {?>
									<code>Belum ada</code>
								<?php } else echo $data['kelompok']['proctor_ujian']; ?>
							</div>
						</div>
						<div class="row mb-2">
							<div class="col-md-5 text-muted">Jumlah terisi (ujian)</div>
							<div class="col-md-7 text-dark">
								<?php echo $data['kelompok']['jumlah_peserta_u']; ?>
								dari
								<?php echo $data['kelompok']['max_peserta_ujian']; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-body">
				<h3 class="card-title mb-4">Training</h3>
				<div class="table-responsive mb-4">
					<table id="absensi-training" class="mb-2 compact" style="white-space: nowrap;">
						<thead>
						<tr>
							<th>Foto</th>
							<?php if ($data['kegiatan']['dibuka_untuk'] === 'mahasiswa') {?>
								<th>Angkatan</th>
								<th>Jurusan</th>
								<th>NIM</th>
							<?php } ?>
							<th>Nama</th>
							<th>Training Sesi 1</th>
							<th>Training Sesi 2</th>
							<th>Act</th>
						</tr>
						</thead>
						<tbody>
						<?php foreach($data['peserta_t'] as $peserta) {?>
							<tr>
								<td>
									<img src="<?php echo base_url(config_item('UPLOAD_FOTO_PROFIL')['upload_path'].$peserta['file_fotoprofil']); ?>" height="70">
								</td>
								<?php if ($data['kegiatan']['dibuka_untuk'] === 'mahasiswa') {?>
									<td><?php echo $peserta['angkatan']; ?></td>
									<td><?php echo config_item('JURUSAN')[$peserta['jurusan']]; ?></td>
									<td><?php echo $peserta['nim']; ?></td>
								<?php } ?>
								<td>
									<?php echo $peserta['nama_depan']; ?>
									<?php echo $peserta['nama_belakang']; ?>
								</td>
								<td>
									<?php if ($peserta['hadir_training_sesi1']) { ?>
										<span>Hadir</span>
									<?php } else { ?>
										<span>Tidak Hadir</span>
									<?php } ?>
								</td>
								<td>
									<?php if ($peserta['hadir_training_sesi2']) { ?>
										<span>Hadir</span>
									<?php } else { ?>
										<span>Tidak Hadir</span>
									<?php } ?>
								</td>
								<td>
									<div class="dropdown sub-dropdown">
										<button class="btn btn-link text-muted dropdown-toggle" type="button"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
										</button>
										<div class="dropdown-menu dropdown-menu-right" x-placement="top-end" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-110px, -152px, 0px);">
											<a target="_blank" role="button" class="dropdown-item" href="<?php echo base_url('admin/user/'.$peserta['id_user']); ?>">Lihat user</a>
										</div>
									</div>
								</td>
							</tr>
						<?php } ?>
						</tbody>
						<tfoot>
						<tr>
							<th>Foto</th>
							<?php if ($data['kegiatan']['dibuka_untuk'] === 'mahasiswa') {?>
								<th><input type="text" style="width: 80px;"></th>
								<th><input type="text" style="width: 80px;"></th>
								<th><input type="text" style="width: 80px;"></th>
							<?php } ?>
							<th><input type="text" style="width: 80px;"></th>
							<th><input type="text" style="width: 80px;"></th>
							<th><input type="text" style="width: 80px;"></th>
							<th>Act</th>
						</tr>
						</tfoot>
					</table>
				</div>
				<div class="row mb-4">
					<div class="col-md-6 mb-2">
						<label> Berita Acara Training Sesi 1</label>
						<textarea readonly class="form-control" rows="3" placeholder=""><?php echo $data['kelompok']['beritaacara_t_sesi1']; ?></textarea>
					</div>
					<div class="col-md-6 mb-2">
						<label> Berita Acara Training Sesi 2</label>
						<textarea readonly class="form-control" rows="3" placeholder=""><?php echo $data['kelompok']['beritaacara_t_sesi2']; ?></textarea>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-12">
		<div class="card">
			<div class="card-body">
				<h3 class="card-title mb-4">Ujian</h3>
				<div class="table-responsive mb-4">
					<table id="absensi-ujian" class="mb-2 compact" style="white-space: nowrap;">
						<thead>
						<tr>
							<th>Foto</th>
							<?php if ($data['kegiatan']['dibuka_untuk'] === 'mahasiswa') {?>
								<th>Angkatan</th>
								<th>Jurusan</th>
								<th>NIM</th>
							<?php } ?>
							<th>Nama</th>
							<th>Ujian</th>
							<th>Skor <code>(-1 = pending)</code></th>
							<th>Act</th>
						</tr>
						</thead>
						<tbody>
						<?php foreach($data['peserta_u'] as $peserta) {?>
							<tr>
								<td>
									<img src="<?php echo base_url(config_item('UPLOAD_FOTO_PROFIL')['upload_path'].$peserta['file_fotoprofil']); ?>" height="70">
								</td>
								<?php if ($data['kegiatan']['dibuka_untuk'] === 'mahasiswa') {?>
									<td><?php echo $peserta['angkatan']; ?></td>
									<td><?php echo config_item('JURUSAN')[$peserta['jurusan']]; ?></td>
									<td><?php echo $peserta['nim']; ?></td>
								<?php } ?>
								<td>
									<?php echo $peserta['nama_depan']; ?>
									<?php echo $peserta['nama_belakang']; ?>
								</td>
								<td>
									<?php if ($peserta['hadir_ujian']) { ?>
										<span>Hadir</span>
									<?php } else { ?>
										<span>Tidak Hadir</span>
									<?php } ?>
								</td>
								<td>
									<?php echo $peserta['skor_ujian']; ?>
								</td>

								<td>
									<div class="dropdown sub-dropdown">
										<button class="btn btn-link text-muted dropdown-toggle" type="button"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
										</button>
										<div class="dropdown-menu dropdown-menu-right" x-placement="top-end" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-110px, -152px, 0px);">
											<a target="_blank" role="button" class="dropdown-item" href="<?php echo base_url('admin/user/'.$peserta['id_user']); ?>">Lihat user</a>
										</div>
									</div>
								</td>
							</tr>
						<?php } ?>
						</tbody>
						<tfoot>
						<tr>
							<th>Foto</th>
							<?php if ($data['kegiatan']['dibuka_untuk'] === 'mahasiswa') {?>
								<th><input type="text" style="width: 80px;"></th>
								<th><input type="text" style="width: 80px;"></th>
								<th><input type="text" style="width: 80px;"></th>
							<?php } ?>
							<th><input type="text" style="width: 80px;"></th>
							<th><input type="text" style="width: 80px;"></th>
							<th><input type="text" style="width: 80px;"></th>
							<th>Act</th>
						</tr>
						</tfoot>
					</table>

				</div>
				<div class="row mb-4">
					<div class="col-md-6 mb-2">
						<label> Berita Acara Ujian</label>
						<textarea readonly class="form-control" rows="3" placeholder=""><?php echo $data['kelompok']['beritaacara_ujian']; ?></textarea>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php } ?>

<?php function yield_bottom_before_script($_this, $data){?>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
	<script>
		var table_t = setupTable('#absensi-training');
		var table_u = setupTable('#absensi-ujian');
	</script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('admin/components/container_main', [ 'data' => $data]); ?>

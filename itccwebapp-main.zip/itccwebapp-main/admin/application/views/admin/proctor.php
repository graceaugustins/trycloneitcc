<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php function yield_title($_this, $data){?> Proctor <?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col-7 align-self-center">
        <h3 class="page-title text-dark font-weight-medium mb-1">
            <?php yield_title($_this, $data); ?>
        </h3>
    </div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
    <?php
	/**
	 * @var D_Proctor[] $list_proctor_aktif
	 * @var D_Proctor[] $list_proctor_nonaktif
	 * */
	$list_proctor_aktif = $data['proctor_aktif'];
	$list_proctor_nonaktif = $data['proctor_nonaktif'];
	?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <!-- Tabs -->
                <ul class="nav nav-tabs nav-bordered mb-3">
                    <li class="nav-item">
                        <a href="#profil-proctor-aktif" data-toggle="tab" class="nav-link active">
                            Profil Proctor
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#profil-proctor-nonaktif" data-toggle="tab" class="nav-link">
                            Proctor nonaktif
                        </a>
                    </li>
                </ul>

                <div class="tab-content">
                    <div class="tab-pane show active" id="profil-proctor-aktif">
                        <div class="my-2">
                            <?php if(admin_capable(Permissions::TAMBAH_LIST_PROCTOR)) {?>
                                <button class="btn btn-light mb-3 float-right" type="button" data-toggle='modal' data-target='#tambah-proctor'>Tambah Proctor Baru</button>
                            <?php } ?>
                        </div>

                        <div class="table-responsive">
                            <table id="t-profil-proctor-aktif" class="mb-2 compact">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Foto</th>
                                    <th>Email</th>
                                    <th>Nama</th>
                                    <th>No. Telepon</th>
                                    <th>Sertifikasi</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $i=1;
                                foreach($list_proctor_aktif as $p) { ?>
									<tr>
										<td><?php echo $i++; ?></td>
										<td>
											<span class="id-proctor d-none"><?php echo $p->id; ?></span>
											<img height="70"
												 src="<?php echo $p->get_link_profile(); ?>" alt="profil"></td>
										<td>
											<?php echo $p->email; ?>
										</td>
										<td><?php echo html_escape($p->nama_lengkap); ?></td>
										<td><?php echo html_escape($p->no_telepon); ?></td>
										<td style="width: 28%;">
											<div class="sertif-proctor">
												<?php if (empty($p->list_sertifikasi)) echo '-';
												else
													foreach($p->list_sertifikasi as $s) { ?>
														<span class="d-none id-sertif"><?php echo $s->id; ?></span>
														<?php echo html_escape($s->nama); ?><br>
													<?php } ?>
											</div>
										</td>
										<td>
											<?php if (admin_capable(Permissions::EDIT_LIST_PROCTOR)) {?>
												<button class="btn btn-sm m-1 btn-info" data-toggle="modal" data-target="#ubah-proctor">Ubah</button>
											<?php } ?>
											<?php if (admin_capable(Permissions::HAPUS_LIST_PROCTOR)) {?>
												<button class="btn btn-sm m-1 btn-danger" data-id="<?php echo $p->id; ?>" data-toggle="modal" data-target="#hapus-proctor">Hapus/Nonaktif</button>
											<?php } ?>
										</td>
									</tr>
								<?php } ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <th>#</th>
                                    <th>Foto</th>
                                    <th><input style="width:80px" type="text" ></th>
                                    <th><input style="width:80px" type="text" ></th>
                                    <th><input style="width:80px" type="text" ></th>
                                    <th><input style="width:120px" type="text" ></th>
                                    <th>Action</th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>

                    <div class="tab-pane" id="profil-proctor-nonaktif">
                        <div class="table-responsive">
                            <table id="t-profile-proctor" class="mb-2 compact">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Foto</th>
                                    <th>Email</th>
                                    <th>Nama</th>
                                    <th>No. Telepon</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $i=1;
                                foreach($list_proctor_nonaktif as $p) { ?>
									<tr>
										<td><?php echo $i++; ?></td>
										<td><img height="70" src="<?php echo $p->get_link_profile(); ?>" alt="profil"></td>
										<td><?php echo $p->email; ?></td>
										<td><?php echo html_escape($p->nama_lengkap); ?></td>
										<td><?php echo html_escape($p->no_telepon); ?></td>
										<td>
											<?php if (admin_capable(Permissions::EDIT_LIST_PROCTOR)) {?>
												<button class="btn btn-sm btn-success" data-id="<?php echo $p->id; ?>" data-toggle="modal" data-target="#aktifkan-proctor">Set Aktif</button>
											<?php } ?>
										</td>
									</tr>
								<?php } ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <th>#</th>
                                    <th>Foto</th>
                                    <th><input style="width:80px" type="text" ></th>
                                    <th><input style="width:80px" type="text" ></th>
                                    <th>No. Telepon</th>
                                    <th>Action</th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php } ?>

<?php function yield_bottom_before_script($_this, $data){?>
    <?php
	/**
	 * @var D_Sertifikasi[] $list_sertifikasi
	 * */
	$list_sertifikasi = $data['sertifikasi']; ?>
    <!-- Modal tambah proctor -->
    <?php if(admin_capable(Permissions::TAMBAH_LIST_PROCTOR)) {?>
        <div id="tambah-proctor" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-tambah-proctor" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-tambah-proctor">Tambah Proctor Baru</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/proctor/add_new'); ?>" enctype='multipart/form-data' >
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <label for="tambah-proctor-email">Alamat email (akun Microsoft, huruf kecil, tanpa spasi)</label>
                            <input class="form-control mb-2" id="tambah-proctor-email" type="email" name="email" required="required">

                            <label for="tambah-proctor-nama">Nama lengkap proctor</label>
                            <input class="form-control mb-2" id="tambah-proctor-nama" type="text" name="nama_lengkap" required="required">

                            <label for="tambah-proctor-telepon">Nomor telepon</label>
                            <div class="row mb-2">
                                <div class="col-2">
                                    <input type="text" readonly class="form-control-plaintext text-right" value="+62">
                                </div>
                                <div class="col-10">
                                    <input class="form-control mb-2" id="tambah-proctor-telepon" type="text" pattern="[0-9]+" name="nomor_telepon" required="required">
                                </div>
                            </div>

                            <label for="tambah-proctor-foto">Upload foto proctor <br><small>(jika tidak diberikan, maka akan memakai foto default)</small></label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="tambah-proctor-foto" name="foto">
                                <label class="custom-file-label" for="tambah-proctor-foto">File .jpg atau .png max 500KB</label>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Tambah</button>
                        </div>
                    </form>


                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>

    <!-- Modal edit proctor -->
    <?php if(admin_capable(Permissions::EDIT_LIST_PROCTOR)) {?>
        <div id="ubah-proctor" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-edit-proctor" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-edit-proctor">Ubah Data Proctor</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/proctor/update'); ?>" enctype="multipart/form-data">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <input type="hidden" name="id">
                            <label for="ubah-proctor-email">Alamat email (akun Microsoft, huruf kecil, tanpa spasi)</label>
                            <input class="form-control mb-2" id="ubah-proctor-email" type="email" name="email" required="required">

                            <label for="ubah-proctor-nama">Nama lengkap proctor</label>
                            <input class="form-control mb-2" id="ubah-proctor-nama" type="text" name="nama_lengkap" required="required">

                            <label for="ubah-proctor-telepon">Nomor telepon</label>
                            <div class="row mb-2">
                                <div class="col-2">
                                    <input type="text" readonly class="form-control-plaintext text-right" value="+62">
                                </div>
                                <div class="col-10">
                                    <input class="form-control mb-2" id="ubah-proctor-telepon" type="text" pattern="[0-9]+" name="nomor_telepon" required="required">
                                </div>
                            </div>

                            <div class="custom-control custom-checkbox my-2">
                                <input id="ubah-proctor-ganti-foto" class="custom-control-input" type="checkbox" name="ganti_profil">
                                <label for="ubah-proctor-ganti-foto" class="custom-control-label">Ganti foto proctor?</label>
                            </div>

                            <div>
                                <label for="ubah-proctor-foto">Upload foto baru<br><small>(jika tidak diberikan, maka akan memakai foto default)</small></label>
                                <div class="custom-file mb-4">
                                    <input type="file" class="custom-file-input" id="ubah-proctor-foto" name="foto">
                                    <label class="custom-file-label" for="ubah-proctor-foto">File .jpg atau .png max 500KB</label>
                                </div>
                            </div>

                            Sertifikasi Proctor<br>
                            <?php foreach($list_sertifikasi as $sertif) { ?>
                                <div class="custom-control custom-checkbox my-2">
                                    <input id="edit-proctor-sertif-<?php echo $sertif->id; ?>" class="custom-control-input sertif" type="checkbox" name="sertif[]" value="<?php echo $sertif->id; ?>">
                                    <label for="edit-proctor-sertif-<?php echo $sertif->id; ?>" class="custom-control-label"><?php echo html_escape($sertif->nama); ?></label>
                                </div>

                            <?php } ?>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Ubah</button>
                        </div>
                    </form>

                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>

    <!-- Modal hapus proctor -->
    <?php if(admin_capable(Permissions::HAPUS_LIST_PROCTOR)) {?>
        <div id="hapus-proctor" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-hapus-proctor" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-hapus-proctor">Anda yakin ingin menghapus proctor ini?</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/proctor/delete'); ?>">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <input type="hidden" name="id">
                            <div class="mb-2">
                                Proctor : <strong class="m-hapus-proctor-nama"></strong>
                            </div>
                            <div class="alert alert-warning fade show" role="alert">
                                <strong class="d-block mb-2">Jika proctor ini baru saja ditambahkan, atau belum pernah mengikuti sertifikasi apapun,
                                    maka akan dihapus dari database.</strong>
                                <strong class="d-block">Jika proctor ini sudah pernah mengikuti sertifikasi, akan di nonaktifkan (tidak dihapus).</strong>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-danger float-right">Hapus/Nonaktif</button>
                        </div>
                    </form>

                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>

    <!-- Modal aktifkan proctor -->
    <?php if(admin_capable(Permissions::EDIT_LIST_PROCTOR)) {?>
        <div id="aktifkan-proctor" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-aktifkan-proctor" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-aktifkan-proctor">Konfirmasi</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/proctor/set_aktif'); ?>">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <input type="hidden" name="id">
                            <div class="mb-2">
                                Proctor : <strong class="m-aktifkan-proctor-nama"></strong>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success float-right">Set Aktif</button>
                        </div>
                    </form>

                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
    <script type="text/javascript">
        let table_proctor_aktif = setupTable('#t-profil-proctor-aktif');
        let table_proctor_nonaktif = setupTable('#t-profile-proctor');

        const checkbox_ubah_proctor_foto = $('#ubah-proctor-ganti-foto');
        const form_ubah_proctor_foto = $('#ubah-proctor-foto');

        function switch_ubah_proctor_foto(){
            if (checkbox_ubah_proctor_foto.is(':checked')) form_ubah_proctor_foto.parent().parent().removeClass('d-none');
            else form_ubah_proctor_foto.val('').parent().parent().addClass('d-none');
        }

        switch_ubah_proctor_foto();
        checkbox_ubah_proctor_foto.on('change', function(){
            switch_ubah_proctor_foto();
        });


        $('#ubah-proctor').on('show.bs.modal', function (event) {
            let button = $(event.relatedTarget); // Button that triggered the modal
            var modal = $(this);

            let p = button.parent().parent();

            modal.find('.modal-body input[name=id]').val(p.children('td:eq(1)').children('.id-proctor').text());
            modal.find('.modal-body input[name=email]').val(p.children('td:eq(2)').text());
            modal.find('.modal-body input[name=nama_lengkap]').val(p.children('td:eq(3)').text());
            modal.find('.modal-body input[name=nomor_telepon]').val(p.children('td:eq(4)').text());

            let sertif_proctor = p.find('.sertif-proctor .id-sertif');
            let sertif=modal.find('.sertif');

            sertif.each(function(i, s){
                sertif_proctor.each(function(j, s_p){
                    if ($(s).val().trim() === $(s_p).text().trim())
                        $(s).attr('checked', true);
                });
            });
        });

        $('#hapus-proctor').on('show.bs.modal', function (event) {
            let button = $(event.relatedTarget); // Button that triggered the modal
            var modal = $(this);
            modal.find('.modal-body input[name=id]').val(button.data('id'));
            modal.find('.modal-body .m-hapus-proctor-nama').text(button.parent().parent().children('td:eq(3)').text());
        });

        $('#aktifkan-proctor').on('show.bs.modal', function (event) {
            let button = $(event.relatedTarget); // Button that triggered the modal
            var modal = $(this);
            modal.find('.modal-body input[name=id]').val(button.data('id'));
            modal.find('.modal-body .m-aktifkan-proctor-nama').text(button.parent().parent().children('td:eq(3)').text());
        });
    </script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('admin/components/container_main', [ 'data' => $data]); ?>

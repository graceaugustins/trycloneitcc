<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php function yield_title($_this, $data){?> Role Administrator <?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col-7 align-self-center">
        <h3 class="page-title text-dark font-weight-medium mb-1">
            <?php yield_title($_this, $data); ?>
        </h3>
    </div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
    <?php
    /** @var D_Role[] $all_roles */
    $all_roles = $data['all_roles'];
    ?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <?php if(admin_capable('tambah_list_hak_akses')){ ?>
                    <button class="btn btn-primary float-md-right mb-4 mr-md-2" type="button" data-toggle='modal' data-target='#tambah-role'>Tambah role baru</button>
                <?php } ?>
                <form action="" method="GET" class="mb-3">
                    <select style="max-width: 300px;" class="custom-select text-dark " name="id_role" onchange="this.form.submit()">
                        <option value="">Pilih role</option>
                        <?php foreach($all_roles as $role) { ?>
                            <option value="<?php echo $role->id; ?>"
                                <?php if ($_this->input->get('id_role') === $role->id) echo 'selected'; ?>
                            >
                                <?php echo html_escape($role->nama_role); ?>
                            </option>
                        <?php } ?>
                    </select>
                </form>

                <?php if (!empty($data['selected_role'])) {
                    /** @var D_Role $selected_role */
                    $selected_role = $data['selected_role'];
                    ?>

                    <?php if(admin_capable(Permissions::EDIT_LIST_HAK_AKSES)){ ?>
                        <button class="btn btn-light mb-3" type="button" data-toggle='modal' data-target='#rename-role'>Rename Role</button>
                    <?php } ?>

                    <form action="<?php echo base_url('admin/roles/update_cap'); ?>" method="POST">
                        <input type="hidden" name="id_role" value="<?php echo $selected_role->id; ?>">
                        <div class="table-responsive">
                            <table id="t-cap-role" class="table table-sm table-striped table-bordered mb-2">
                                <thead>
                                <tr>
                                    <th>Capability</th>
                                    <th>Deskripsi</th>
                                    <th>Bisa?</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($selected_role->capabilities as $cap) { ?>
                                    <tr>
                                        <td style="min-width: 200px;"><?php echo html_escape($cap->nama); ?></td>
                                        <td style="min-width: 400px;"><?php echo html_escape($cap->deskripsi); ?></td>
                                        <td>
                                            <select style="width: 130px;" class="custom-select bg-white text-dark" name="cap[<?php echo $cap->id; ?>]">
                                                <option value="n">Tidak</option>
                                                <option value="y" <?php if ($cap->is_eligible) echo 'selected'; ?>>Ya</option>
                                            </select>
                                        </td>
                                    </tr>
                                <?php } ?>

                                </tbody>
                                <tfoot>
                                <tr>
                                    <th>Capability</th>
                                    <th>Deskripsi</th>
                                    <th>Bisa?</th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                        <?php if(admin_capable(Permissions::EDIT_LIST_HAK_AKSES)) { ?>
                            <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                            <button type="submit" class="btn btn-success">Update</button>
                        <?php } ?>

                        <?php if(admin_capable(Permissions::HAPUS_LIST_HAK_AKSES)){ ?>
                            <button class="btn btn-outline-danger float-right" type="button" data-toggle='modal' data-target='#hapus-role'>Hapus role ini</button>
                        <?php } ?>
                    </form>

                <?php } ?>

            </div>
        </div>
    </div>
<?php } ?>

<?php function yield_bottom_before_script($_this, $data){?>
    <!-- Modal tambah role baru -->
    <?php if(admin_capable(Permissions::TAMBAH_LIST_HAK_AKSES)) {?>
        <div id="tambah-role" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-tambah-role" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-sm">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-tambah-role">Tambah Role Baru</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/roles/add_role'); ?>">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <input type="text" name="role_name" class="form-control" required="required" placeholder="Cth : Administrasi">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success">Tambah</button>
                        </div>
                    </form>

                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>

    <!-- Modal edit role -->
    <?php if(admin_capable(Permissions::EDIT_LIST_HAK_AKSES) && !empty($data['selected_role']) ) {
        /** @var D_Role $selected_role */
        $selected_role = $data['selected_role'];
        ?>
        <div id="rename-role" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-edit-role" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-edit-role">Rename Role</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/roles/update_role'); ?>">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <input type="hidden" name="id_role" value="<?php echo $selected_role->id; ?>">
                            <label for="ubah-role-nama">Nama role baru</label>
                            <input class="form-control mb-2" id="ubah-role-nama" type="text" name="nama_role" required="required" value="<?php echo html_escape($selected_role->nama_role); ?>">
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Ubah</button>
                        </div>
                    </form>

                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>

    <!-- Modal hapus role -->
    <?php if(admin_capable(Permissions::HAPUS_LIST_HAK_AKSES) && !empty($data['selected_role']) ) {
        /** @var D_Role $selected_role */
        $selected_role = $data['selected_role'];
        ?>
        <div id="hapus-role" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-hapus-role" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-sm">
                <div class="modal-content">
                    <div class="modal-header modal-colored-header bg-danger">
                        <h4 class="modal-title" id="label-hapus-role">Hapus Role Ini ?</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/roles/delete_role'); ?>">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <input type="hidden" name="id_role" value="<?php echo $selected_role->id; ?>">
                            Nama role : <span class="font-weight-medium"><?php echo html_escape($selected_role->nama_role); ?></span>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-danger">Hapus</button>
                        </div>
                    </form>

                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('admin/components/container_main', [ 'data' => $data]); ?>
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php function yield_title($_this, $data){?> Sertifikasi dan Program <?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col-7 align-self-center">
        <h3 class="page-title text-dark font-weight-medium mb-1">
            <?php yield_title($_this, $data); ?>
        </h3>
    </div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
    <?php
	/**
	 * @var D_Sertifikasi[] $list_sertifikasi
	 * @var D_Sertifikasi $data['selected_sertifikasi']
	 * */
    $list_sertifikasi = $data['sertifikasi'];
    $control = $data['control'];
    ?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <!-- Tabs -->
                <ul class="nav nav-tabs nav-bordered mb-3">
                    <li class="nav-item">
                        <a href="#tab-sertif" data-toggle="tab" class="nav-link <?php if ($control['active_tab'] === 'sertifikasi') echo 'active'; ?> ">
                            Sertifikasi
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#tab-program" data-toggle="tab" class="nav-link <?php if ($control['active_tab'] === 'program') echo 'active'; ?>">
                            Program
                        </a>
                    </li>
                </ul>

                <div class="tab-content">
                    <div class="tab-pane <?php if ($control['active_tab'] === 'sertifikasi') echo 'show active'; ?>" id="tab-sertif">

                        <?php if(admin_capable('tambah_list_sertifikasi')) {?>
                            <button class="btn btn-light mb-3" type="button" data-toggle='modal' data-target='#modal-tambah-sertif'>Tambah Sertifikasi Baru</button>
                        <?php } ?>

                        <div class="table-responsive">
                            <table id="t-sertifikasi" class="table table-sm table-striped table-bordered mb-2">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Logo</th>
                                    <th>Sertifikasi</th>
                                    <th>Deskripsi</th>
                                    <th>Template Sertifikat</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $i=1; foreach($list_sertifikasi as $s){ ?>
                                    <tr>
                                        <td><?php echo $i++; ?>
                                            <span class="d-none id"><?php echo $s->id; ?></span>
                                        </td>
                                        <td><img height="70" src="<?php echo $s->get_link_logo(); ?>"></td>
                                        <td><?php echo html_escape($s->nama); ?></td>
                                        <td style="max-width: 350px;"><?php echo html_escape($s->deskripsi); ?></td>
                                        <td>
                                            <a target="_blank" href="<?php echo $s->link_template_sertifikat; ?>">Lihat</a>
                                        </td>
                                        <td>
                                            <?php if (admin_capable('edit_list_sertifikasi')) {?>
                                                <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#ubah-sertifikasi">Ubah</button>
                                            <?php } ?>
                                            <?php if (admin_capable('hapus_list_sertifikasi')) {?>
                                                <button class="btn btn-sm btn-danger" data-toggle="modal" data-target="#hapus-sertifikasi">
                                                    Hapus
                                                </button>
                                            <?php } ?>
                                        </td>

                                    </tr>
                                <?php } ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <th>#</th>
                                    <th>Logo</th>
                                    <th>Sertifikasi</th>
                                    <th>Deskripsi</th>
                                    <th>Template Sertifikat</th>
                                    <th>Action</th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>

                    <div class="tab-pane <?php if ($control['active_tab'] === 'program') echo 'show active'; ?>" id="tab-program">
                        <div class="row">
                            <div class="col-md-4">
                                <form action="" method="GET">
                                    <select onchange="this.form.submit();" class="custom-select text-dark" required="required" name="id_sertif">
                                        <option value="">Pilih Sertifikasi</option>
                                        <?php foreach($list_sertifikasi as $s) { ?>
                                            <option value="<?php echo $s->id; ?>"
                                                <?php if(!empty($data['selected_sertif']) && (int)$s->id === (int)$data['selected_sertif']->id) echo 'selected'; ?>
                                            >
                                                <?php echo html_escape($s->nama); ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </form>
                            </div>

                            <?php
							$selected_sertif = NULL;
							if (!empty($data['selected_sertif'])) {
								/**
								 * @var D_Sertifikasi $selected_sertif
								 * */
                            	$selected_sertif = $data['selected_sertif'];
							?>
                                <div class="col-md-8">
                                    <?php if(admin_capable('tambah_list_sertifikasi')) {?>
                                        <button class="btn btn-light mb-3 float-right" type="button" data-id_sertif="<?php echo $selected_sertif->id; ?>" data-toggle='modal' data-target='#modal-tambah-program'>Tambah Program Baru</button>
                                    <?php } ?>
                                </div>
                            <?php } ?>
                        </div>

                        <?php if (!empty($selected_sertif)) { ?>
                            <div class="table-responsive">
                                <table id="t-program" class="table table-sm table-striped table-bordered mb-2">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Logo</th>
                                        <th>Nama Program</th>
                                        <th>Link Assesment</th>
                                        <th>File Modul</th>
                                        <th>Skor (min lulus/max)</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $i=1; foreach($selected_sertif->list_program as $p){ ?>
                                        <tr>
                                            <td><?php echo $i++; ?>
                                                <span class="id-program d-none"><?php echo $p->id; ?></span>
                                            </td>
                                            <td>
                                                <img alt="logo" src="<?php echo $p->get_link_logo(); ?>" height="70">
                                            </td>
                                            <td><?php echo html_escape($p->nama_program); ?></td>
                                            <td>
                                                <a href="<?php echo $p->link_assesment; ?>" role="button" class="btn btn-sm btn-info" target="_blank">
                                                    Lihat assesment
                                                </a>
                                            </td>
                                            <td>
                                                <?php if (!empty($p->file_modul)){ ?>
                                                    <a href="<?php echo $p->get_link_modul(); ?>" role="button" class="btn btn-sm btn-info" target="_blank">
                                                        Lihat modul
                                                    </a>
                                                <?php } else { ?>
                                                    -
                                                <?php } ?>
                                            </td>
                                            <td>
                                                <span><?php echo $p->min_skor; ?></span>
                                                /
                                                <span><?php echo $p->max_skor; ?></span>
                                            </td>
                                            <td>
                                                <?php if (admin_capable('edit_list_sertifikasi')) {?>
                                                    <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#ubah-program">Ubah</button>
                                                <?php } ?>
                                                <?php if (admin_capable('hapus_list_sertifikasi')) {?>
                                                    <button class="btn btn-sm btn-danger" data-toggle="modal" data-target="#hapus-program">Hapus</button>
                                                <?php } ?>
                                            </td>

                                        </tr>
                                    <?php } ?>
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <th>#</th>
                                        <th>Logo</th>
                                        <th>Nama Program</th>
                                        <th>Link Assesment</th>
                                        <th>File Modul</th>
                                        <th>Skor (min lulus/maks)</th>
                                        <th>Action</th>
                                    </tr>
                                    </tfoot>
                                </table>
                            </div>
                        <?php } ?>

                    </div>
                </div>

            </div>
        </div>
    </div>
<?php } ?>

<?php function yield_bottom_before_script($_this, $data){?>
    <!-- Modal tambah sertifikasi -->
    <?php if(admin_capable(Permissions::TAMBAH_LIST_SERTIFIKASI)) {?>
        <div id="modal-tambah-sertif" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-tambah-sertifikasi" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-tambah-sertifikasi">Tambah Sertifikasi Baru</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/sertifikasi/program/add_sertifikasi'); ?>" enctype='multipart/form-data' >
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <label for="tambah-sertif-nama">Nama sertifikasi<span class="text-danger">*</span></label>
                            <input class="form-control mb-2" id="tambah-sertif-nama" type="text" name="nama_sertif" required="required">
                            <div class="form-group">
                                <label for="tambah-sertif-deskripsi">Deskripsi singkat (maks. 500 karakter)<span class="text-danger">*</span></label>
                                <textarea class="form-control" name="deskripsi" rows="3" required="required"></textarea>
                            </div>
                            <label for="tambah-sertif-foto">Upload Logo Sertifikasi (persegi)<span class="text-danger">*</span></label>
                            <div class="custom-file mb-3">
                                <input type="file" class="custom-file-input" id="tambah-sertif-foto" name="foto" required="required">
                                <label class="custom-file-label" for="tambah-sertif-foto">File .jpg atau .png max 500KB</label>
                            </div>
                            <label for="tambah-sertif-link">Link Template Sertifikat Keikutsertaan <span class="text-danger">*</span><br>
                                <small>(URL dengan awalan http:// atau https://)</small>
                            </label>
                            <input class="form-control mb-2" id="tambah-sertif-nama" type="text" name="link_template_sertifikat" required="required">
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Tambah</button>
                        </div>
                    </form>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>

    <!-- Modal tambah program -->
    <?php if(admin_capable(Permissions::TAMBAH_LIST_SERTIFIKASI) && !empty($data['selected_sertif'])) {?>
        <div id="modal-tambah-program" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-tambah-program" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-tambah-program">Tambah Program Sertifikasi</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/sertifikasi/program/add_program'); ?>" enctype='multipart/form-data' >
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <input type="hidden" name="id_sertif">

                            <label for="tambah-program-nama">Nama Program <span class="text-danger">*</span></label>
                            <input class="form-control mb-2" id="tambah-program-nama" type="text" name="nama_program" required="required">


                            <div class="form-group">
                                <label for="tambah-program-link">Link Assesment (wajib ada <code>http://</code> atau <code>https://</code>)<span class="text-danger">*</span></label>
                                <input class="form-control mb-2" id="tambah-program-link" type="text" name="link_assesment" required="required">
                            </div>

                            <div class="row">
                                <div class="col-12">Skor<span class="text-danger">*</span></div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="tambah-program-minskor">Minimum lulus</label>
                                        <input class="form-control mb-2" id="tambah-program-minskor" type="number" name="min_skor" required="required">
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="tambah-program-maxskor">Maksimum</label>
                                        <input class="form-control mb-2" id="tambah-program-maxskor" type="number" name="max_skor" required="required">
                                    </div>
                                </div>
                            </div>

                            <label for="tambah-program-modul">Upload Modul Training Resmi</label>
                            <div class="custom-file mb-3">
                                <input type="file" class="custom-file-input" id="tambah-program-modul" name="modul">
                                <label class="custom-file-label" for="tambah-program-foto">File .pdf max 17MB</label>
                            </div>

                            <label for="tambah-program-logo">Upload Logo Program <span class="text-danger">*</span></label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="tambah-program-logo" name="logo" required="required">
                                <label class="custom-file-label" for="tambah-program-foto">File .jpg atau .png max 500KB</label>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Tambah</button>
                        </div>
                    </form>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>

    <!-- Modal edit sertifikasi -->
    <?php if(admin_capable(Permissions::EDIT_LIST_SERTIFIKASI)) {?>
        <div id="ubah-sertifikasi" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-edit-sertifikasi" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-edit-sertifikasi">Ubah Data Sertifikasi</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/sertifikasi/program/update_sertifikasi'); ?>" enctype="multipart/form-data">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <input type="hidden" name="id">
                            <label for="ubah-sertif-nama">Nama Sertifikasi <span class="text-danger">*</span></label>
                            <input class="form-control mb-2" id="ubah-sertif-nama" type="text" name="nama" required="required">

                            <div class="form-group mb-3">
                                <label for="tambah-sertif-deskripsi">Deskripsi singkat (maks. 500 karakter)<span class="text-danger">*</span></label>
                                <textarea class="form-control" name="deskripsi" rows="3" required="required"></textarea>
                            </div>

                            <label for="ubah-sertif-logo">Upload Logo Sertifikasi (persegi)<br>
                                <small>(Jika logo tidak diupload, maka akan tetap menggunakan logo saat ini)</small>
                            </label>
                            <div class="custom-file mb-3">
                                <input type="file" class="custom-file-input" id="ubah-sertif-logo" name="logo">
                                <label class="custom-file-label" for="ubah-sertif-logo">File .jpg atau .png max 500KB</label>
                            </div>

                            <label for="ubah-sertif-link">Link Template Sertifikat Keikutsertaan
                            </label>
                            <input class="form-control mb-2" id="ubah-sertif-link" type="text" name="link_template_sertifikat" required="required">
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Ubah</button>
                        </div>
                    </form>

                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>

    <!-- Modal hapus sertifikasi -->
    <?php if(admin_capable(Permissions::HAPUS_LIST_SERTIFIKASI)) {?>
        <div id="hapus-sertifikasi" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-hapus-sertif" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-hapus-sertif">Anda yakin ingin menghapus sertifikasi ini?</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/sertifikasi/program/delete_sertifikasi'); ?>">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <input type="hidden" name="id">
                            <div class="mb-2">
                                Sertifikasi : <strong class="m-hapus-sertif-nama"></strong>
                            </div>
                            <div class="alert alert-warning fade show" role="alert">
                                <strong class="d-block mb-2">
                                    Jika sertifikasi ini tidak terikat dengan data apapun (belum pernah diadakan kegiatan),
                                    maka akan dihapus permanen beserta program dan seluruh data terkait (cth : modul program).
                                </strong>
                                <strong class="d-block">
                                    Jika kegiatan sertifikasi ini sudah pernah diadakan, maka tidak dihapus untuk menjaga history data.
                                </strong>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-danger float-right">Hapus</button>
                        </div>
                    </form>

                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>

    <!-- Modal edit program -->
    <?php if(admin_capable(Permissions::EDIT_LIST_SERTIFIKASI)) {?>
        <div id="ubah-program" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-edit-sertifikasi" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-edit-sertifikasi">Ubah Data Program</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/sertifikasi/program/update_program'); ?>" enctype="multipart/form-data">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <input type="hidden" name="id">
                            <label for="ubah-program-nama">Nama Program <span class="text-danger">*</span></label>
                            <input class="form-control mb-2" id="ubah-program-nama" type="text" name="nama_program" required="required">


                            <div class="form-group">
                                <label for="ubah-program-link">Link Assesment (wajib ada <code>http://</code> atau <code>https://</code>)<span class="text-danger">*</span></label>
                                <input class="form-control mb-2" id="ubah-program-link" type="text" name="link_assesment" required="required">
                            </div>

                            <div class="row">
                                <div class="col-12">Skor<span class="text-danger">*</span></div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="ubah-program-minskor">Minimum lulus</label>
                                        <input class="form-control mb-2" id="ubah-program-minskor" type="number" name="min_skor" required="required">
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="ubah-program-maxskor">Maksimum</label>
                                        <input class="form-control mb-2" id="ubah-program-maxskor" type="number" name="max_skor" required="required">
                                    </div>
                                </div>
                            </div>
                            <div class="custom-control custom-checkbox mb-1">
                                <input type="checkbox" class="custom-control-input" id="ubah-program-modul" name="ubah_modul">
                                <label class="custom-control-label" for="ubah-program-modul">Ubah Modul</label>
                            </div>
                            <div class="custom-file mb-3">
                                <input type="file" class="custom-file-input" id="file-modul" name="modul">
                                <label class="custom-file-label" for="file-modul">File .pdf max 10MB</label>
                            </div>

                            <div class="custom-control custom-checkbox mb-1">
                                <input type="checkbox" class="custom-control-input" id="ubah-program-logo" name="ubah_logo">
                                <label class="custom-control-label" for="ubah-program-logo">Ubah Logo</label>
                            </div>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="file-logo" name="logo">
                                <label class="custom-file-label" for="file-logo">File .jpg atau .png max 500KB</label>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Ubah</button>
                        </div>
                    </form>

                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>

    <!-- Modal hapus program -->
    <?php if(admin_capable(Permissions::HAPUS_LIST_SERTIFIKASI)) {?>
        <div id="hapus-program" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-hapus-program" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-hapus-program">Anda yakin ingin menghapus program ini?</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/sertifikasi/program/delete_program'); ?>">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <input type="hidden" name="id">
                            <div class="mb-2">
                                Program : <strong class="m-hapus-program-nama"></strong>
                            </div>
                            <div class="alert alert-warning fade show" role="alert">
                                <strong class="d-block mb-2">
                                    Jika program ini tidak terikat dengan kegiatan apapun (belum pernah diadakan kegiatan),
                                    maka akan dihapus permanen beserta program dan seluruh data terkait (cth : modul program).
                                </strong>
                                <strong class="d-block">
                                    Jika kegiatan sertifikasi ini sudah pernah diadakan, maka akan diubah ke nonaktif untuk menjaga history data.
                                </strong>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-danger float-right">Hapus</button>
                        </div>
                    </form>

                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data){?>
    <script type="text/javascript">

		$('#file-modul').parent().addClass('d-none');
		$('#ubah-program-modul').on('change', function(){
			if (this.checked)
				$('#file-modul').parent().removeClass('d-none');
			else $('#file-modul').parent().addClass('d-none').val('');
		});

		$('#file-logo').parent().addClass('d-none');
		$('#ubah-program-logo').on('change', function(){
			if (this.checked)
				$('#file-logo').parent().removeClass('d-none');
			else $('#file-logo').parent().addClass('d-none').val('');
		});

        $('#modal-tambah-program').on('show.bs.modal', function (event) {
            let button = $(event.relatedTarget); // Button that triggered the modal
            var modal = $(this);
            modal.find('.modal-body input[name=id_sertif]').val(button.data('id_sertif'));
        });

        $('#ubah-sertifikasi').on('show.bs.modal', function (event) {
            let button = $(event.relatedTarget); // Button that triggered the modal
            var modal = $(this);
            let p = button.parent().parent();
            modal.find('.modal-body input[name=id]').val(p.find('td:eq(0) .id').text());
            modal.find('.modal-body input[name=nama]').val(p.children('td:eq(2)').text());
            modal.find('.modal-body textarea[name=deskripsi]').val(p.children('td:eq(3)').text());
            modal.find('.modal-body input[name=link_template_sertifikat]').val(p.find('td:eq(4) a').attr('href'));
        });

        $('#hapus-sertifikasi').on('show.bs.modal', function (event) {
            let button = $(event.relatedTarget); // Button that triggered the modal
            var modal = $(this);
            let p = button.parent().parent();
            modal.find('.modal-body input[name=id]').val(p.find('td:eq(0) .id').text());
            modal.find('.modal-body .m-hapus-sertif-nama').text(p.children('td:eq(2)').text());
        });

        $('#ubah-program').on('show.bs.modal', function (event) {
            let button = $(event.relatedTarget); // Button that triggered the modal
            var modal = $(this);
            let p = button.parent().parent();
            modal.find('.modal-body input[name=id]').val(p.children('td:eq(0)').children('.id-program').text());
            modal.find('.modal-body input[name=nama_program]').val(p.children('td:eq(2)').text());
            modal.find('.modal-body input[name=link_assesment]').val(p.children('td:eq(3)').children('a').attr('href'));
            modal.find('.modal-body input[name=min_skor]').val(p.children('td:eq(5)').children('span:eq(0)').text());
            modal.find('.modal-body input[name=max_skor]').val(p.children('td:eq(5)').children('span:eq(1)').text());
        });

        $('#hapus-program').on('show.bs.modal', function (event) {
            let button = $(event.relatedTarget); // Button that triggered the modal
            var modal = $(this);
            let p = button.parent().parent();
            modal.find('.modal-body input[name=id]').val(p.children('td:eq(0)').children('.id-program').text());
            modal.find('.modal-body .m-hapus-program-nama').text(p.children('td:eq(2)').text());
        });
    </script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('admin/components/container_main', [ 'data' => $data]); ?>

<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> Detail User <?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col-7 align-self-center">
        <h3 class="page-title text-dark font-weight-medium mb-1">
            <?php yield_title($_this, $data); ?>
        </h3>
    </div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
	<?php
	/** @var D_User $user */
	$user = $data['user'];
	/** @var D_Bidang_User_ITPLN[] $list_bidang */
	$list_bidang = $data['list_bidang'];
	/** @var D_Jabatan_User_ITPLN $jabatan_user */
	$jabatan_user = $data['jabatan_user'];
	$is_user_mahasiswa = ($user->tipe_user === General_Constants::MAHASISWA);
	$is_user_umum = ($user->tipe_user === General_Constants::UMUM);
	$is_user_itpln = ($user->tipe_user === General_Constants::ITPLN);
	$selected_bidang_user = NULL;
	if ($is_user_itpln)
	{
		$id_bidang = (int)$jabatan_user->id_bidang;
		$selected_bidang_user = array_filter($list_bidang, function($bidang) use ($id_bidang){
			return (int)$bidang->id === $id_bidang;
		});
		/** @var D_Bidang_User_ITPLN $selected_bidang_user */
		$selected_bidang_user = reset($selected_bidang_user);
	}
	?>
<div class="col-12">
    <form action="" method="POST" id="form-tambah-kegiatan" enctype="multipart/form-data">
        <div class="row">
            <div class="col-md-2">
                <div class="card">
                    <div class="card-body">
                        <img class="d-block px-2 pt-2 mb-2 w-100" src="<?php echo $user->get_link_profile(); ?>" alt="profil">
                    </div>
                </div>
            </div>
            <div class="col-md-10">
                <div class="card">
                    <div class="card-body">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="row g-2">
                            <div class="col-md-6">
								<!-- Tanggal Daftar -->
                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Tanggal Daftar</label>
                                    <input readonly type="text" class="col-sm-8 pl-md-0 form-control-plaintext"
                                           value="<?php echo tgl_indo($user->time_registered, 'Y-m-d H:i:s')
                                               .' '.DateTime::createFromFormat('Y-m-d H:i:s', $user->time_registered)->format('H:i:s').' WIB';  ?>">
                                </div>
								<!-- Tipe -->
                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Tipe User</label>
                                    <input readonly type="text" class="col-sm-8 pl-md-0 form-control-plaintext"
                                           value="<?php echo strtoupper($user->tipe_user); ?>">
                                </div>
								<!-- Aktif -->
                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Aktif</label>
                                    <select name="aktif" class="col-sm-8 custom-select text-body" required>
                                        <option value="y" <?php if ($user->aktif) echo 'selected'; ?>>Aktif</option>
                                        <option value="n" <?php if (!$user->aktif) echo 'selected'; ?>>Tidak Aktif</option>
                                    </select>
                                </div>
								<!-- Nama Depan -->
                                <div class="form-group row ">
                                    <label class="col-sm-4 col-form-label">Nama Depan</label>
                                    <input name="nama_depan" type="text" class="col-sm-8 form-control" required
                                           value="<?php echo $user->nama_depan; ?>">
                                </div>
								<!-- Nama Belakang -->
                                <div class="form-group row ">
                                    <label class="col-sm-4 col-form-label">Nama Belakang</label>
                                    <input name="nama_belakang" type="text" class="col-sm-8 form-control" required
                                           value="<?php echo $user->nama_belakang; ?>">
                                </div>
								<!-- Jenis Kelamin -->
                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Jenis Kelamin</label>
                                    <select name="jenis_kelamin" class="col-sm-8 custom-select text-body" required>
                                        <option value="l" <?php if ($user->jenis_kelamin === General_Constants::LAKI_LAKI) echo 'selected'; ?>>Laki-laki</option>
                                        <option value="p" <?php if ($user->jenis_kelamin === General_Constants::PEREMPUAN) echo 'selected'; ?>>Perempuan</option>
                                    </select>
                                </div>
								<!-- Email -->
                                <div class="form-group row ">
                                    <label class="col-sm-4 col-form-label">Email</label>
                                    <input name="email" type="email" class="col-sm-8 form-control" required value="<?php echo $user->email; ?>">
                                </div>
								<!-- Bidang & Jabatan -->
								<?php if ($is_user_itpln) {?>
								<script id="list-bidang-jabatan" type="application/json"><?php echo json_encode($list_bidang); ?></script>
								<script id="jabatan-user" type="application/json"><?php echo json_encode($jabatan_user); ?></script>
								<div class="form-group row">
									<label class="col-sm-4 col-form-label">Bidang</label>
									<select id="dropdown-bidang" name="id_bidang" class="col-sm-8 custom-select text-body" required>
										<?php foreach ($list_bidang as $bidang) { ?>
											<option
												value="<?php echo $bidang->id; ?>"
												<?php if ((int)$jabatan_user->id_bidang === (int)$bidang->id) echo "selected"; ?>
											>
												<?php echo $bidang->nama_bidang; ?>
											</option>
										<?php } ?>
									</select>
								</div>
								<div class="form-group row">
									<label class="col-sm-4 col-form-label">Jabatan</label>
									<select id="dropdown-jabatan" name="id_jabatan" class="col-sm-8 custom-select text-body" required>
										<?php foreach ($selected_bidang_user->list_jabatan as $jabatan) { ?>
											<option
													value="<?php echo $jabatan->id; ?>"
													<?php if ((int)$jabatan_user->id === (int)$jabatan->id) echo "selected"; ?>
											>
												<?php echo $jabatan->nama_jabatan; ?>
											</option>
										<?php } ?>
									</select>
								</div>
								<?php } ?>
								<!-- Instansi -->
                                <?php if ($is_user_umum) { ?>
                                    <div class="row mb-2">
                                        <div class="col-sm-4">
                                            Instansi
                                        </div>
                                        <div class="col-sm-8 px-0">
                                            <?php if (empty($user->list_instansi)) {?>
                                                <small class="d-block">- <i>Kosong</i> - </small>
                                            <?php } else {?>
                                            <ul class="list-group">
                                                <?php foreach($user->list_instansi as $instansi_user) {?>
                                                <li class="list-group-item">
                                                    <a class="d-block" href="<?php echo base_url('admin/user/instansi/'.$instansi_user->id); ?>"><?php echo $instansi_user->nama; ?></a>
                                                </li>
                                                <?php } ?>
                                            </ul>
                                            <?php } ?>
                                        </div>
                                    </div>
                                <?php } ?>
								<!-- Angkatan, Prodi, NIM-->
                                <?php if ($is_user_mahasiswa) {?>
                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Angkatan</label>
                                    <input readonly type="text" class="col-sm-8 pl-md-0 form-control-plaintext" value="<?php echo $user->angkatan; ?>">
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Program Studi</label>
                                    <input readonly type="text" class="col-sm-8 pl-md-0 form-control-plaintext"
										   value="<?php
										   if(in_array($user->jurusan, array_keys(config_item('JURUSAN'))))
										   		echo config_item('JURUSAN')[$user->jurusan];
										   else echo "-"; ?>">
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">NIM</label>
                                    <input name="nim" type="text" class="col-sm-8 form-control" required value="<?php echo $user->nim; ?>">
                                </div>
                                <?php } ?>
                            </div>

                            <div class="col-md-6">
								<!-- Kata sandi -->
                                <?php if ($is_user_umum) {?>
                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Kata sandi</label>
                                    <div class="col-sm-8 pl-0">
                                        <small>Kata sandi baru</small>
                                        <input type="password" class="form-control" name="new_password">
                                        <small>Ulangi kata sandi</small>
                                        <input type="password" class="form-control" name="new_password2">
                                    </div>
                                </div>
                                <?php } ?>
								<!-- NIK/NIDN -->
                                <?php if ($is_user_umum || $is_user_itpln) {?>
                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">
										NIK<?php if ($is_user_itpln) echo "/NIDN"; ?>
									</label>
                                    <input name="nik" type="text" class="col-sm-8 form-control" required value="<?php echo $user->nik; ?>">
                                </div>
                                <?php } ?>
								<!-- Alamat -->
                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Alamat</label>
                                    <textarea name="alamat" required class="col-sm-8 form-control" rows="3"><?php echo $user->alamat; ?></textarea>
                                </div>
								<!-- No Telepon-->
                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">No. Telepon</label>
                                    <input name="no_telepon" type="number" class="col-sm-8 form-control" required value="<?php echo $user->no_telepon; ?>">
                                </div>
								<!-- ID Line -->
                                <?php if ($is_user_mahasiswa) {?>
                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">ID line</label>
                                    <input name="id_line" type="text" class="col-sm-8 form-control" value="<?php echo $user->id_line; ?>">
                                </div>
                                <?php } ?>
								<!-- ID Telegram -->
								<?php if ($is_user_mahasiswa || $is_user_umum) {?>
									<div class="form-group row">
										<label class="col-sm-4 col-form-label">ID Telegram</label>
										<input name="id_telegram" type="text" class="col-sm-8 form-control" value="<?php echo $user->id_telegram; ?>">
									</div>
								<?php } ?>
								<!-- Username Certiport -->
                                <div class="form-group row ">
                                    <label class="col-sm-4 col-form-label">User. Certiport</label>
                                    <input name="username_certiport" type="text" class="col-sm-8 form-control" value="<?php echo $user->username_certiport; ?>">
                                </div>
								<!-- Password Certiport -->
                                <div class="form-group row ">
                                    <label class="col-sm-4 col-form-label">Pass. Certiport</label>
                                    <input name="password_certiport" type="text" class="col-sm-8 form-control" value="<?php echo $user->password_certiport; ?>">
                                </div>
								<!-- Foto Profil -->
                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Ubah Foto Profil (<a href="<?php echo $user->get_link_profile(); ?>" target="_blank">lihat</a>)</label>
                                    <div class="col-sm-8 pl-0">
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" id="foto_profil" name="file_fotoprofil">
                                            <label class="custom-file-label" for="foto_profil">File .jpg atau .png max 500KB</label>
                                        </div>
                                    </div>
                                </div>
								<!-- KTM -->
                                <?php if ($is_user_mahasiswa) {?>
                                    <div class="form-group row">
                                        <label class="col-sm-4 col-form-label">Ubah KTM (<a href="<?php echo $user->get_link_ktm(); ?>" target="_blank">lihat</a>)</label>
                                        <div class="col-sm-8 pl-0">
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" id="ktm" name="file_ktm">
                                                <label class="custom-file-label" for="ktm">File .jpg atau .png max 500KB</label>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
								<!-- KTP -->
                                <?php if ($is_user_umum) {?>
                                    <div class="form-group row">
                                        <label class="col-sm-4 col-form-label">Ubah KTP (<a href="<?php echo $user->get_link_ktp(); ?>" target="_blank">lihat</a>)</label>
                                        <div class="col-sm-8 pl-0">
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" id="ktp" name="file_ktp">
                                                <label class="custom-file-label" for="ktp">File .jpg atau .png max 500KB</label>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                            <div class="col-12"><hr></div>
							<?php if (admin_capable(Permissions::EDIT_LIST_USER)) { ?>
                            <div class="col-12">
                                <button type="submit" class="btn btn-block btn-success">Update data user</button>
                            </div>
							<?php } ?>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
	<?php
	/** @var D_User $user */
	$user = $data['user'];
	?>
	<?php if ($user->tipe_user === General_Constants::ITPLN) { ?>
		<script>
			const json_list_bidang = JSON.parse(document.getElementById('list-bidang-jabatan').textContent);
			function refresh_jabatan(bidang = $('#dropdown-bidang')){
				let dropdown = $('#dropdown-jabatan');
				dropdown.html('');
				let current_id = bidang.val();
				$(json_list_bidang).each(function(){
					if (parseInt(this.id) === parseInt(current_id))
					{
						let that = this;
						$(that.list_jabatan).each(function(){
							let data = this;
							let item = $('<option></option>').val(data.id).text(data.nama_jabatan);
							dropdown.append(item);
						});
					}
				});
			}
			$('#dropdown-bidang').on('change', function(){
				refresh_jabatan();
			});
		</script>
	<?php } ?>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('admin/components/container_main', [ 'data' => $data]); ?>

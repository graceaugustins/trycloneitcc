<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> Konfigurasi Sistem <?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col-7 align-self-center">
        <h3 class="page-title text-dark font-weight-medium mb-1">
            <?php yield_title($_this, $data); ?>
        </h3>
    </div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
<div class="col-12">
    <div class="card card-sm">
        <div class="card-body">
            <h4 class="card-title">Konfigurasi pemilik akun ITCC</h4>
            <p>*Akun ini dipakai oleh sistem untuk memberikan layanan kepada user menggunakan Office365. <br>
                Contohnya, proses pengiriman email resmi secara otomatis menggunakan akun resmi ITCC.</p>
            <div class="bg-body text-dark p-3 border">
                <div>Email sistem : <code><b><?php if (!empty($data['email'])) echo $data['email']; else echo 'Belum ada'; ?></b></code></div>
                <div>
                    <p>Langkah-langkah mengupdate email sistem : </p>
                    <ul>
                        <li>
                            Copy link berikut ini, lalu buka di <code>incognito window</code>, atau window browser lain yang tidak ada login Office365. <br>
                            <a href="<?php echo $data['link']; ?>"><?php echo $data['link']; ?></a><br>
                            (link akan kadaluarsa dalam 3 menit)
                        </li>
                        <li>
                            Akan muncul halaman login Office365, silahkan login menggunakan akun resmi ITCC.
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php } ?>

<?php function yield_bottom_before_script($_this, $data){?>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('admin/components/container_main', [ 'data' => $data]); ?>
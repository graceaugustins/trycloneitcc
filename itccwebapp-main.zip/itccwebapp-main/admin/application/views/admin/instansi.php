<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> Instansi <?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col-7 align-self-center">
        <h3 class="page-title text-dark font-weight-medium mb-1">
            <?php yield_title($_this, $data); ?>
        </h3>
    </div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
<div class="col-12">
    <div class="card">
        <div class="card-body">

            <div class="my-2">
                <?php if(admin_capable('tambah_list_sertifikasi')) {?>
                    <button class="btn btn-light mb-3 float-right" type="button" data-toggle='modal' data-target='#tambah-instansi'>Tambah Instansi Baru</button>
                <?php } ?>
            </div>

            <div class="table-responsive">
                <table id="t-instansi" class="compact mb-2">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>No. Telepon</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    foreach($data['instansi_all'] as $instansi) {?>
                        <tr>
                            <td>
                                <?php echo $i++; ?>
                                <span class="d-none id-instansi"><?php echo $instansi['id']; ?></span>
                            </td>
                            <td><?php echo $instansi['nama']; ?></td>
                            <td><?php echo $instansi['alamat']; ?></td>
                            <td><?php echo $instansi['no_telepon']; ?></td>
                            <td>
                                <a role="button" href="<?php echo base_url('admin/user/instansi/'.$instansi['id']); ?>" class="btn btn-primary btn-sm">
                                    Lihat
                                </a>
                                <?php if(admin_capable(Permissions::EDIT_LIST_INSTANSI)) {?>
                                    <button class="btn btn-light btn-sm" type="button" data-toggle='modal' data-target='#ubah-instansi'>
                                        Ubah
                                    </button>
                                <?php } ?>
								<?php if(admin_capable(Permissions::HAPUS_LIST_INSTANSI)) {?>
									<button class="btn btn-danger btn-sm" type="button" data-toggle='modal' data-target='#hapus-instansi'>
										Hapus
									</button>
								<?php } ?>
                            </td>
                        </tr>
                    <?php } ?>
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>#</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>No. Telepon</th>
                        <th>Action</th>
                    </tr>
                    </tfoot>
                </table>
            </div>

        </div>
    </div>
</div>

<?php if(!empty($data['instansi_selected'])) {
$instansi_selected = $data['instansi_selected']['instansi'];
$user_instansi_selected = $data['instansi_selected']['users'];
?>
<div class="col-12">
    <div class="card">
        <div class="card-body">
            <div class="row mb-5">
                <div class="col-12">
                    <h4 class="font-weight-medium">Detail Instansi - <?php echo $instansi_selected['nama']; ?></h4>
                </div>

                <div class="col-12">
                    +62 <?php echo $instansi_selected['no_telepon']; ?>
                </div>
                <div class="col-12">
                    <small>
                        <?php echo $instansi_selected['alamat']; ?>
                    </small>
                </div>

                <div class="col-12 mt-4">
                    <?php if(admin_capable('edit_list_instansi')) {?>
                        <div>
                            <button class="d-block btn btn-light mb-3" type="button" id="btn-search-user-instansi">Tambah User (Umum)</button>
                        </div>
                        <div class="row d-none" id="search-user-instansi-box">
                            <div class="col-12">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <input class="form-control search-user-umum" type="text" id="search-user-instansi-nama-depan" placeholder="Nama Depan">
                                            </div>
                                            <div class="col-md-4">
                                                <input class="form-control search-user-umum" type="text" id="search-user-instansi-nama-belakang" placeholder="Nama Belakang">
                                            </div>
                                            <div class="col-md-4">
                                                <input class="form-control search-user-umum" type="text" id="search-user-instansi-email" placeholder="Email">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 text-right">
                                        <button class="btn btn-success mb-2" id="btn-tambah-user-instansi">Tambah</button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div style="height: 250px;overflow-y: scroll;">
                                    <div class="table-responsive w-100">
                                        <table class="w-100 table table-sm table-bordered" id="search-user-instansi-result">
                                            <thead>
                                            <tr>
                                                <th>Nama Depan</th>
                                                <th>Nama Belakang</th>
                                                <th>Email</th>
                                                <th></th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <form class="d-none" method="POST" id="frm-tambah-user-instansi" action="<?php echo base_url('admin/user/instansi/'.$instansi_selected['id'].'/add_users');?>">
                                    <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                                    <div id="additional-parameter"></div>
                                </form>
                                <div class="table-responsive w-100" style="height: 250px;overflow-y: scroll;">
                                    <table class="w-100 table table-sm table-bordered" id="search-user-instansi-selected">
                                        <thead>
                                        <tr>
                                            <th>Nama Depan</th>
                                            <th>Nama Belakang</th>
                                            <th>Email</th>
                                            <th></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
            <form class="d-none" method="POST" id="frm-hapus-user-instansi" action="<?php echo base_url('admin/user/instansi/'.$instansi_selected['id'].'/remove_user');?>">
                <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                <input type="hidden" name="id">
            </form>
            <div class="table-responsive" id="wrapper-t-user-instansi">
                <table id="t-user-instansi" class="compact mb-2">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Foto</th>
                        <th>Email</th>
                        <th>Nama</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    foreach($user_instansi_selected as $user) {?>
                        <tr>
                            <td>
                                <?php echo $i++; ?>
                            </td>
                            <td><img src="<?php echo base_url(config_item('UPLOAD_FOTO_PROFIL')['upload_path'].$user['file_fotoprofil']);?>" height="50"></td>
                            <td><?php echo $user['email']; ?></td>
                            <td><?php echo $user['nama_depan'].' '.$user['nama_belakang']; ?></td>
                            <td>
                                <span class="d-none id"><?php echo $user['id_instansi_user']; ?></span>
                                <?php if(admin_capable('edit_list_instansi')) {?>
                                <a target="_blank" role="button" class="btn btn-sm btn-light" href="<?php echo base_url('admin/user/'.$user['id']); ?>">Lihat User</a>
                                <button class="btn btn-sm btn-danger hapus-user-instansi">Hapus</button>
                                <?php } ?>
                            </td>
                        </tr>
                    <?php } ?>
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>#</th>
                        <th>Foto</th>
                        <th>Email</th>
                        <th>Nama</th>
                        <th>Action</th>
                    </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>
<?php } ?>

<?php } ?>

<?php function yield_bottom_before_script($_this, $data){?>
    <?php if(admin_capable(Permissions::TAMBAH_LIST_INSTANSI)) {?>
        <div id="tambah-instansi" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-tambah-instansi" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-tambah-instansi">Tambah Instansi Baru</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/user/instansi/add_new'); ?>">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <label for="tambah-instansi-nama">Nama Instansi</label>
                            <input class="form-control mb-2" id="tambah-instansi-nama" type="text" name="nama" required="required">

                            <label for="tambah-admin-notelp">Nomor Telepon</label>
							<input class="form-control mb-2" id="tambah-instansi-notelp" type="text" pattern="[0-9]+" name="no_telepon" required="required">

                            <label class="col-form-label">Alamat Instansi</label>
                            <textarea name="alamat" required class="form-control" rows="3" placeholder="Maksimal 200 karakter"></textarea>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Tambah</button>
                        </div>
                    </form>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>
    <?php if(admin_capable(Permissions::EDIT_LIST_INSTANSI)) {?>
        <div id="ubah-instansi" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-ubah-instansi" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-ubah-instansi">Edit Instansi Baru</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/user/instansi'); ?>">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <label for="ubah-instansi-nama">Nama Instansi</label>
                            <input class="form-control mb-2" id="ubah-instansi-nama" type="text" name="nama" required="required">

                            <label for="ubah-instansi-notelp">Nomor Telepon</label>
							<input class="form-control mb-2" id="ubah-instansi-notelp" type="text" pattern="[0-9]+" name="no_telepon" required="required">

                            <label class="col-form-label">Alamat Instansi</label>
                            <textarea name="alamat" required class="form-control" rows="3" placeholder="Maksimal 200 karakter"></textarea>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Ubah</button>
                        </div>
                    </form>


                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>
	<?php if(admin_capable(Permissions::HAPUS_LIST_INSTANSI)) {?>
		<div id="hapus-instansi" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-hapus-instansi" style="display: none;" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="label-hapus-instansi">Hapus Instansi ?</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					</div>

					<form method="POST" action="<?php echo base_url('admin/user/instansi'); ?>">
						<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
						<div class="modal-body">
							<div class="mb-2">
								Instansi : <strong class="m-hapus-instansi-nama"></strong>
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-danger">Hapus</button>
						</div>
					</form>


				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div>
	<?php } ?>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
<script>
    var table_instansi = setupTable('#t-instansi');
    var table_user_instansi = setupTable('#t-user-instansi');
    var wrapper_table_user_instansi = $('#wrapper-t-user-instansi');
    var table_search_user_instansi = $('#search-user-instansi-result');
    var table_search_user_instansi_selected = $('#search-user-instansi-selected');
    var btn_search_user_instansi = $('#btn-search-user-instansi');
    var search_box_user_instansi = $('#search-user-instansi-box');
    var btn_tambah_user_instansi = $('#btn-tambah-user-instansi');
    var frm_tambah_user_instansi = $('#frm-tambah-user-instansi');
    var frm_hapus_user_instansi = $('#frm-hapus-user-instansi');
    var show_search_box = false;

    $('#ubah-instansi').on('show.bs.modal', function (event) {
        let button = $(event.relatedTarget); // Button that triggered the modal
        let modal = $(this);
        let p = button.parent().parent();
        modal.find('form').attr('action', BASE_URL + 'admin/user/instansi/'+ p.find('td:eq(0) .id-instansi').text());
        modal.find('.modal-body input[name=nama]').val(p.find('td:eq(1)').text());
        modal.find('.modal-body textarea[name=alamat]').val(p.find('td:eq(2)').text());
        modal.find('.modal-body input[name=no_telepon]').val(p.find('td:eq(3)').text());

    });

	$('#hapus-instansi').on('show.bs.modal', function (event) {
		let button = $(event.relatedTarget); // Button that triggered the modal
		let modal = $(this);
		let p = button.parent().parent();
		modal.find('form').attr('action', BASE_URL + 'admin/user/instansi/'+ p.find('td:eq(0) .id-instansi').text() + '/delete');
		modal.find('.modal-body .m-hapus-instansi-nama').text(p.find('td:eq(1)').text());

	});

    btn_search_user_instansi.on('click', function(){
        show_search_box = !show_search_box;
        if (show_search_box)
        {
            wrapper_table_user_instansi.addClass('d-none');
            btn_search_user_instansi.text('Kembali');
            search_box_user_instansi.removeClass('d-none');
        }
        else
        {
            wrapper_table_user_instansi.removeClass('d-none');
            btn_search_user_instansi.text('Tambah User (Umum)');
            search_box_user_instansi.addClass('d-none');
        }
    });

    // search user umum untuk ditambahkan
    $('.search-user-umum').on('keyup', function(){
        let nama_depan = $('#search-user-instansi-nama-depan').val();
        let nama_belakang = $('#search-user-instansi-nama-belakang').val();
        let email = $('#search-user-instansi-email').val();
        if (nama_depan.trim() === "" && nama_belakang.trim() === "" && email.trim() === "")
            return;
        let param = get_param_ajax();
        param['count'] = 10;
        param['nama_depan'] = nama_depan;
        param['nama_belakang'] = nama_belakang;
        param['email'] = email;
        $.post(
            BASE_URL+'ajax/user_umum/get',
            param
        ).done(function(resp){
            if (resp.status === 'ok'){
                $('tbody', table_search_user_instansi).empty();
                $(resp.data.data).each(function(){
                    let id=$("<span></span>").append(this.id).addClass('d-none');
                    let row_nama_depan = $("<td></td>").append(this.nama_depan).append(id);
                    let row_nama_belakang = $("<td></td>").append(this.nama_belakang);
                    let row_email = $("<td></td>").append(this.email);
                    let row_tambah = $("<td><button type='button' class='btn btn-sm btn-success btn-block tambah-user-search'>Tambah</button></td>")
                    let row = $("<tr></tr>")
                        .append(row_nama_depan)
                        .append(row_nama_belakang)
                        .append(row_email)
                        .append(row_tambah);
                    $('tbody', table_search_user_instansi).append(row);
                });
            }
        });
    });

    // klik "Tambah" user search
    search_box_user_instansi.on('click', '.tambah-user-search', function(){
        $(this).addClass('d-none');
        let p = $(this).parent().parent();
        let row_hapus = $("<td><button type='button' class='btn btn-sm btn-danger btn-block hapus-user-search'>Hapus</button></td>")
        let row = $("<tr></tr>")
            .append(p.find('td:eq(0)').clone())
            .append(p.find('td:eq(1)').clone())
            .append(p.find('td:eq(2)').clone())
            .append(row_hapus);
        $('tbody', table_search_user_instansi_selected).append(row);
    });

    search_box_user_instansi.on('click', '.hapus-user-search', function(){
        let p = $(this).parent().parent();

        $('tbody tr', table_search_user_instansi).each(function(){
            if (
                p.find('td:eq(0)').text().trim() === $(this).find('td:eq(0)').text().trim() &&
                p.find('td:eq(1)').text().trim() === $(this).find('td:eq(1)').text().trim() &&
                p.find('td:eq(2)').text().trim() === $(this).find('td:eq(2)').text().trim()
            )
            {
                $(this).find('td:eq(3) button').removeClass('d-none');
            }
        });
        p.remove();
    });

    btn_tambah_user_instansi.on('click', function(){
        $('#additional-parameter', frm_tambah_user_instansi).empty();
        $("tbody tr", table_search_user_instansi_selected).each(function(){
            let id = $(this).find("td:eq(0) span").text();
            let input = $("<input>").attr('name', 'id[]').attr('value', id);
            $('#additional-parameter', frm_tambah_user_instansi).append(input);
        });
        frm_tambah_user_instansi.submit();
    });
    table_user_instansi.on('click', '.hapus-user-instansi', function(){
        let id = $(this).parent().find('.id').text();
        $("input[name=id]", frm_hapus_user_instansi).val(id);
        frm_hapus_user_instansi.submit();
    });
</script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('admin/components/container_main', [ 'data' => $data]); ?>

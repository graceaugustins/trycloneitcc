<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?>
<?php
/** @var D_Kelompok_U $kelompok */
$kelompok = $data['kelompok'];
?>
Update kelompok ujian '<?php echo $kelompok->nama_kelompok; ?>'
<?php } ?>
<?php function yield_page_header($_this, $data){?>
	<?php
	/** @var D_Kelompok_U $kelompok */
	$kelompok = $data['kelompok'];
	?>
    <div class="col-9 align-self-center">
        <h3 class="page-title text-dark font-weight-medium mb-1">
            <?php yield_title($_this, $data); ?>
        </h3>
    </div>
	<div class="col-md-3 align-self-center">
		<a role="button" href="<?php echo base_url("admin/sertifikasi/kegiatan/kelompok_u/detail/".$kelompok->id); ?>" class="btn btn-light btn-block">
			Kembali
		</a>
	</div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
<?php
/** @var D_Kelompok_U $kelompok */
$kelompok = $data['kelompok'];
/** @var D_Proctor[] $proctor_sesuai_sertif */
$proctor_sesuai_sertif = $data['proctor_sesuai_sertif'];
?>
<div class="col-12">
    <div class="card card-sm">
        <div class="card-body">
			<form action="" method="POST">
				<input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
				<div class="row mb-4">
					<div class="col-md-6 mb-4">
						<div class="form-group row">
							<label class="col-sm-4 col-form-label">
								Nama Kelompok <span class="text-danger">*</span>
							</label>
							<input required name="nama_kelompok" type="text" class="col-sm-8 form-control"
								   value="<?php echo $kelompok->nama_kelompok; ?>">
						</div>
						<div class="form-group row">
							<label class="col-sm-4 col-form-label">
								Program
							</label>
							<div class="col-sm-8 form-control-plaintext">
								<?php echo $kelompok->nama_program; ?>
							</div>
						</div>
					</div>
					<div class="col-md-6"></div>
					<div class="col-md-6">
						<div class="form-group row">
							<label class="col-sm-4 col-form-label">
								Tanggal <span class="text-danger">*</span>
							</label>
							<input required name="tanggal_ujian" type="date" class="form-control col-sm-8"
								   value="<?php echo $kelompok->mulai_ujian->format('Y-m-d'); ?>">
						</div>
						<div class="form-group row">
							<label class="col-sm-4 col-form-label">
								Waktu Mulai <span class="text-danger">*</span>
							</label>
							<div class="col-sm-8 row">
								<div class="col-8 pl-0">
									<input required
										   name="waktu_mulai_ujian"
										   type="text"
										   class="form-control bootstrap-timepicker"
										   value="<?php echo $kelompok->mulai_ujian->format('H:i:s') ?>"
									>
								</div>
								<div class="col-4 align-self-center p-0">
									WIB
								</div>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-4 col-form-label">
								Waktu Selesai <span class="text-danger">*</span>
							</label>
							<div class="col-sm-8 row">
								<div class="col-8 pl-0">
									<input required
										   name="waktu_selesai_ujian"
										   type="text"
										   class="form-control bootstrap-timepicker"
										   value="<?php echo $kelompok->selesai_ujian->format('H:i:s') ?>"
									>
								</div>
								<div class="col-4 align-self-center p-0">
									WIB
								</div>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-4 col-form-label">
								Lokasi <span class="text-danger">*</span>
							</label>
							<input required name="lokasi_ujian" type="text" class="col-sm-8 form-control"
								   value="<?php echo $kelompok->lokasi_ujian; ?>">
						</div>
						<div class="form-group row">
							<label class="col-sm-4 col-form-label">
								Daya Tampung <span class="text-danger">*</span>
							</label>
							<div class="col-sm-8 row">
								<div class="col-5 p-0">
									<input required name="min_peserta_ujian" type="number" class="form-control"
										   min="0"
										   value="<?php echo $kelompok->min_peserta_ujian; ?>">
								</div>
								<div class="col-2 align-self-center p-0 text-center">s/d</div>
								<div class="col-5 p-0">
									<input required name="max_peserta_ujian" type="number" class="form-control"
										   min="0"
										   value="<?php echo $kelompok->max_peserta_ujian; ?>">
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group row">
							<label class="col-sm-4 col-form-label">
								Proctor Ujian
							</label>
							<select name="id_proctor_ujian" class="col-sm-8 custom-select text-body">
								<option value="none">-</option>
								<?php foreach ($proctor_sesuai_sertif as $p) {?>
									<option value="<?php echo $p->id; ?>"
											<?php if ((int)$kelompok->id_proctor_ujian === (int)$p->id) echo "selected"; ?>
									>
										<?php echo $p->nama_lengkap; ?>
									</option>
								<?php } ?>
							</select>
						</div>
						<div class="form-group row">
							<label class="col-sm-4 col-form-label">
								Kesediaan Proctor Ujian
							</label>
							<div class="col-sm-8 px-0">
								<?php if (count($kelompok->list_kesediaan_proctor_ujian) === 0)  { ?>
									-
								<?php } else { ?>
									<ul class="list-group">
										<?php foreach($kelompok->list_kesediaan_proctor_ujian as $k_p) { ?>
											<li class="list-group-item list-group-item-info"><?php echo $k_p->nama_proctor; ?></li>
										<?php } ?>
									</ul>
								<?php } ?>
							</div>
						</div>
					</div>
					<div class="col-12 mt-5">
						<button type="submit" class="btn btn-block btn-info d-block mx-auto" style="width: 80%;">Update Data Kelompok</button>
					</div>
				</div>
			</form>
        </div>
    </div>
</div>
<?php } ?>

<?php function yield_bottom_before_script($_this, $data){?>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('admin/components/container_main', [ 'data' => $data]); ?>

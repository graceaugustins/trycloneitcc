<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<script type="text/javascript">
    function tambah_row_kriteria_regis_mhs(e, obj_table, a="0", j = "0", i="0")
    {
        let dropdown = $("<select style='width: 150px;' class='custom-select bg-white text-body'><option value='0'>Semua</option></select>");
        jurusan.forEach(function(value){
            dropdown.append("<option value='"+value.kode+"'>"+value.nama+"</option>");
        });
        dropdown.val(j);
        dropdown = $("<td></td>").append(dropdown);

        let angkatan = $('<input style="width: 100px;" type="number" min="0" class="form-control">').val(a);
        angkatan = $("<td></td>").append(angkatan);

        let idx = $('<input style="width: 100px;" type="number" min="0" class="form-control">').val(i);
        idx = $("<td></td>").append(idx);

        let button = $("<button type='button' class='btn btn-sm btn-danger'>Hapus</button>")
            .on('click', function(){
                $(this).parent().parent().remove();
            });
		button = $("<td></td>").append(button);

        let row = $('<tr></tr>');
        row.append(angkatan)
            .append(dropdown)
            .append(idx)
            .append(button);
        $('tbody',obj_table).append(row);
    }

    function tambah_row_kriteria_regis_umum(e, obj_table, t='instansi', d=null)
    {
        let a = (d === '0');
        let dropdown_tipe = $("<select class='custom-select bg-white text-body tipe-kriteria-regis-umum'></select>")
            .append("<option value='instansi' selected>Instansi</option>")
            .append("<option value='user'>User</option>")
            .on('change', function(){
                let parent = $(this).parent().parent();
				parent.find('td:eq(2) input[type=checkbox]').prop('checked', false);
                if ($(this).val() === "instansi")
                {
                    parent.find('td:eq(1) select').removeClass('d-none');
                    parent.find('td:eq(1) input').addClass('d-none');
                }
                else
                {
                    parent.find('td:eq(1) select').addClass('d-none');
                    parent.find('td:eq(1) input').removeClass('d-none');
                }
            }).val(t);
        dropdown_tipe = $("<td></td>").append(dropdown_tipe);
        let textbox_email = $('<input type="text" class="form-control search-email" placeholder="Email peserta">');
        let dropdown_instansi = $("<select class='custom-select bg-white text-body'></select>");

        daftar_instansi.forEach(function(value){
            dropdown_instansi.append(`<option value='${value.id}'>${value.nama}</option>`);
        });
        if (t === 'instansi') {
            textbox_email.addClass('d-none');
            if (d !== null && !a) dropdown_instansi.val(d);
            dropdown_instansi.prop('disabled', a);
        }
        else {
            dropdown_instansi.addClass('d-none');
            if (d !== null && !a) textbox_email.val(d);
            textbox_email.prop('disabled', a);
        }
        let data = $("<td></td>")
            .append(dropdown_instansi)
            .append(textbox_email);
        let checkbox_semua = $('<input type="checkbox" class="checkbox-semua-data-kriteria-regis-umum" value="">')
            .on('change', function(){
                let parent = $(this).parent().parent();
                let tipe = parent.find('.tipe-kriteria-regis-umum').val();
                if (tipe === 'instansi')
                    parent.find('td:eq(1) select').val('').prop('disabled', this.checked);
                else if (tipe === 'user')
                    parent.find('td:eq(1) input').val('').prop('disabled', this.checked);
            }).prop('checked', a);

        checkbox_semua = $('<td class="align-middle text-center"><label class="m-0"></label></td>')
            .append(checkbox_semua);
        let button_hapus = $("<button type='button' class='btn btn-sm btn-danger btn-hapus-kriteria-regis'>Hapus</button>")
            .on('click', function(){
                $(this).parent().parent().remove();
            });
        button_hapus = $("<td class='text-center'></td>").append(button_hapus);
        let row = $('<tr></tr>')
            .append(dropdown_tipe)
            .append(data)
            .append(checkbox_semua)
            .append(button_hapus);
        $('tbody',obj_table).append(row);
    }

    function tambah_diskon(e, obj_list,  t='umum',  j='nominal', v='0', d_pertama=0, d_daftar={dari: null, sampai: null}, disc=[])
    {
        let potongan_harga = $('<div class="potongan-harga py-3 my-2 border-secondary border-top"></div>');
        let btn_hapus = $('<button type="button" class="btn btn-sm btn-outline-danger mx-2 float-right">Hapus Potongan Harga Ini</button>')
            .on('click', function(){
                $(this).parent().remove();
            });

        let jenis = $('<div class="jenis mb-2"></div>').append('Jenis potongan harga: ');
        let dropdown_jenis = $('<select class="custom-select text-dark bg-white mr-2" style="width:200px;"></select>')
				.append('<option value="nominal">Nominal</option>')
            	.append('<option value="persen">Persen</option>')
            	.val(j);
        let input_value = $('<input type="number" style="width: 200px" min="0" value="0" required>').val(v);
        jenis.append(dropdown_jenis)
            .append('Value: ')
            .append(input_value);

        let checkbox_pendaftar_pertama = $('<input type="checkbox" class="mr-1 show-disc-pendaftar-pertama">')
            .prop('checked', d_pertama>0)
            .on('click', function(){
                if (this.checked)
                    $(this).parent().parent().children('.disc-pendaftar-pertama').removeClass('d-none');
                else
                    $(this).parent().parent().children('.disc-pendaftar-pertama').addClass('d-none');
            });
        let label_disc_pendaftar_pertama = $('<label class="d-block"></label>')
            .append(checkbox_pendaftar_pertama)
            .append('Potongan untuk beberapa pendaftar pertama');
        let input_pendaftar_pertama = $('<input type="number" min="0" value="0" style="width: 100px;" class="form-control d-inline-block">').val(d_pertama);
        let disc_pendaftar_pertama = $('<div class="mb-2 disc-pendaftar-pertama"></div>')
				.append('Terapkan potongan harga ini untuk')
            	.append(input_pendaftar_pertama)
            	.append('orang pertama');
        if (d_pertama === 0) disc_pendaftar_pertama.addClass('d-none');

        let checkbox_waktu_daftar = $('<input type="checkbox" class="mr-1 show-disc-waktu-daftar">')
            .prop('checked', (d_daftar.dari !== null && d_daftar.sampai !== null))
            .on('click', function(){
                if (this.checked)
                    $(this).parent().parent().children('.disc-waktu-daftar').removeClass('d-none');
                else
                    $(this).parent().parent().children('.disc-waktu-daftar').addClass('d-none');
            });
        let label_disc_waktu_daftar = $('<label class="d-block"></label>')
				.append(checkbox_waktu_daftar)
				.append('Potongan untuk user yang mendaftar dalam periode terentu');
        let datepicker_waktu_daftar_awal = $('<input type="date" class="form-control d-inline-block" style="width: 200px;">');
        let waktu_daftar_awal = $('<input type="text" class="form-control bootstrap-timepicker d-inline-block" style="width: 100px;">').timepicker(timepicker_config);
        if (d_daftar.dari !== null) {
            datepicker_waktu_daftar_awal.val(dayjs(d_daftar.dari).format('YYYY-MM-DD'));
            waktu_daftar_awal.val(dayjs(d_daftar.dari).format('HH:mm:ss'));
        }
        let datepicker_waktu_daftar_akhir = $('<input type="date" class="form-control d-inline-block" style="width: 200px;">');
        let waktu_daftar_akhir = $('<input type="text" class="form-control bootstrap-timepicker d-inline-block" style="width: 100px;">').timepicker(timepicker_config);
        if (d_daftar.sampai !== null) {
            datepicker_waktu_daftar_akhir.val(dayjs(d_daftar.sampai).format('YYYY-MM-DD'));
            waktu_daftar_akhir.val(dayjs(d_daftar.sampai).format('HH:mm:ss'));
        }

        let disc_waktu_daftar = $('<div class="mb-3 disc-waktu-daftar d-none"></div>')
            .append('Terapkan potongan harga ini untuk peserta yang mendaftar dari <br>')
            .append(datepicker_waktu_daftar_awal)
            .append(waktu_daftar_awal)
            .append(' WIB sampai ')
            .append(datepicker_waktu_daftar_akhir)
            .append(waktu_daftar_akhir)
            .append(' WIB');
		if (d_daftar.dari !== null && d_daftar.sampai !== null)
		{
			disc_waktu_daftar.removeClass('d-none');
		}
        let tbl_disc_mahasiswa = $('<div class="table-responsive"></div>');
        let tbl_disc_mhs = $('<table class=" table table-sm table-striped" style="max-width: 700px;"></table>');
        let thead = $('<thead></thead>');
        let tr = $('<tr></tr>')
            .append('<th>Angkatan</th>')
            .append('<th>Jurusan</th>')
            .append('<th>Index</th>')
            .append('<th>Action</th>');
        thead.append(tr);
        tbl_disc_mhs.append(thead).append('<tbody></tbody>');
        tbl_disc_mahasiswa.append(tbl_disc_mhs);

        let btn_tambah_disc_mhs = $('<button type="button" class="btn btn-sm btn-info mb-2 tambah-disc-mahasiswa">Tambah kriteria diskon untuk mahasiswa</button>')
            .on('click', function(){
                tambah_row_kriteria_regis_mhs(this, $(this).parent().find('table'));
            });
        let kriteria_mhs = $('<div class="my-3 disc-mahasiswa"></div>')
            .append(btn_tambah_disc_mhs)
            .append(tbl_disc_mahasiswa);

        let tbl_disc_umum = $('<table class=" table table-sm table-striped" style="max-width: 700px;"></table>');
        let thead_umum = $('<thead></thead>');
        let tr_umum = $('<tr></tr>')
            .append('<th>Tipe</th>')
            .append('<th>Data</th>')
            .append('<th class="text-center">Semua</th>')
            .append('<th class="text-center">Action</th>');
        thead_umum.append(tr_umum);
        tbl_disc_umum.append(thead_umum).append('<tbody></tbody>');
        let btn_tambah_disc_umum = $('<button type="button" class="btn btn-primary btn-sm m-2 tambah-disc-umum">Tambah Kriteria Diskon Umum</button>')
            .on('click', function(){
                tambah_row_kriteria_regis_umum(this, $(this).parent().find('table'));
            });
        let kriteria_umum = $('<div class="table-responsive disc-umum"></div>')
            .append(btn_tambah_disc_umum)
            .append(tbl_disc_umum);

        if (t === 'mahasiswa')
        {
            kriteria_umum.addClass('d-none');
            $(disc).each(function(){
                tambah_row_kriteria_regis_mhs(this, tbl_disc_mhs, this.angkatan, this.jurusan, this.index);
            });
        }
        else if (t === 'umum')
        {
            kriteria_mhs.addClass('d-none');
            $(disc).each(function(){
                tambah_row_kriteria_regis_umum(this, tbl_disc_umum, this.tipe, this.data);
            });
        }

        potongan_harga.append(btn_hapus)
            .append(jenis)
            .append(label_disc_pendaftar_pertama)
            .append(disc_pendaftar_pertama)
            .append(label_disc_waktu_daftar)
            .append(disc_waktu_daftar)
            .append(kriteria_umum)
            .append(kriteria_mhs);
        obj_list.append(potongan_harga);
    }

    function fill_search_user(
    		e,
			obj_table,
			obj_table_selected,
			dibuka_untuk = 'umum',
			nama_depan='',
			nama_belakang='',
			email='',
			callback = function () {})
    {
        if (nama_depan.trim() === "" && nama_belakang.trim() === "" && email.trim() === "") return;
        let param = get_param_ajax();
        param['count'] = 10;
        param['nama_depan'] = nama_depan;
        param['nama_belakang'] = nama_belakang;
        param['email'] = email;

        let endpoint = (dibuka_untuk === 'umum')? 'ajax/user_umum/get' : 'ajax/user_mhs/get';
        $.post(
            BASE_URL+endpoint,
            param
        ).done(function(resp){
            if (resp.status === 'ok'){
                $('tbody', obj_table).empty();
                $(resp.data.data).each(function(){
                    let id=$("<span></span>").append(this.id).addClass('d-none');
                    let nama_depan = this.nama_depan;
                    let nama_belakang = this.nama_belakang;
                    let email = this.email;

                    // cek apakah email yang diklik sudah dipilih sebelumnya
                    let btn_tambah = $("<button type='button' class='btn btn-sm btn-success btn-block'>Tambah</button>")
                        .on('click', function(){
                            $(this).addClass('d-none');
                            tambah_row_selected_user_ujian_saja(obj_table, obj_table_selected, email, nama_depan, nama_belakang );
							callback();
                        });
                    let row_tambah = $("<td></td>").append(btn_tambah);
                    let row_nama_depan = $("<td></td>").append(this.nama_depan).append(id);
                    let row_nama_belakang = $("<td></td>").append(this.nama_belakang);
                    let row_email = $("<td></td>").append(this.email);
                    let email_exists = false;
                    $('tbody tr', obj_table_selected).each(function(){
                        if ($('td:eq(2)', this).text().trim().toLowerCase() === email.toLowerCase())
                            email_exists = true;
                    });
                    if (email_exists) btn_tambah.addClass('d-none');
                    let row = $("<tr></tr>")
                        .append(row_nama_depan)
                        .append(row_nama_belakang)
                        .append(row_email)
                        .append(row_tambah);
                    $('tbody', obj_table).append(row);
                });
            }
        });
    }

    function tambah_row_selected_user_ujian_saja(obj_table_search, obj_table_selected, email, nama_depan="", nama_belakang="")
    {
        let row = $("<tr></tr>");
        let row_email = $("<td></td>").append(email);
        let row_nama_depan = $("<td></td>").append(nama_depan);
        let row_nama_belakang = $("<td></td>").append(nama_belakang);
        let btn_remove = $("<button type='button' class='btn btn-sm btn-danger'>Hapus</button>")
            .on('click', function(){
                $(this).parent().parent().remove();
                $('tbody tr', obj_table_search).each(function () {
                    if ($('td:eq(2)', this).text().trim().toLowerCase() === email.trim().toLowerCase())
                        $('td:eq(3) button', this).removeClass('d-none');
                });
            });
        let row_btn_remove = $("<td></td>").append(btn_remove);
        row.append(row_nama_depan).append(row_nama_belakang).append(row_email).append(row_btn_remove);
        $('tbody', obj_table_selected).append(row);
    }

    function add_row_user_boleh_ujian_saja(table_search, table_selected)
    {
        let p = $(table_selected).parent().parent();
        let btn_hapus = $("<button type='button' class='btn btn-sm btn-danger btn-block'>Hapus</button>")
            .on('click', function(){
                let p = $(this).parent().parent();
                $('tbody tr', table_search).each(function(){
                    if (
                        p.find('td:eq(0)').text().trim() === $(this).find('td:eq(0)').text().trim() &&
                        p.find('td:eq(1)').text().trim() === $(this).find('td:eq(1)').text().trim() &&
                        p.find('td:eq(2)').text().trim() === $(this).find('td:eq(2)').text().trim()
                    )
                    {
                        $(this).find('td:eq(3) button').removeClass('d-none');
                    }
                });
                p.remove();
            });
        let row_hapus = $("<td></td>").append(btn_hapus);
        let row = $("<tr></tr>")
            .append(p.find('td:eq(0)').clone())
            .append(p.find('td:eq(1)').clone())
            .append(p.find('td:eq(2)').clone())
            .append(row_hapus);
        $('tbody', table_selected).append(row);
    }

    function parse_kriteria_peserta(e, dibuka_untuk, table_mhs, table_umum,  )
    {
        let kriteria_peserta = [];
        if ( dibuka_untuk === 'mahasiswa')
        {
            $('tbody tr',table_mhs).each(function(){
                let angkatan = $('td:eq(0) input', this).val();
                let jurusan = $('td:eq(1) select', this).val();
                let index = $('td:eq(2) input', this).val();
                if (index !== '0') index = index.padStart(3, '0');
                kriteria_peserta.push({
                    angkatan: angkatan,
                    jurusan: jurusan,
                    index: index
                });
            });
        }
        else if (dibuka_untuk === 'umum')
        {
            $('tbody tr',table_umum).each(function(){
                let tipe = $('td:eq(0) select', this).val();
                let semua = $('td:eq(2) .checkbox-semua-data-kriteria-regis-umum', this).prop('checked');
                let data = null;
                if (semua) data = "0";
                else
                {
                    if (tipe === 'instansi')
                        data = $('td:eq(1) select', this).val();
                    else if (tipe === 'user')
                        data = $('td:eq(1) input', this).val();
                    else  return;
                }
                kriteria_peserta.push({
                    tipe: tipe,
                    data: data
                });
            });
        }
        return kriteria_peserta;
    }

    function parse_kriteria_ujian_saja(e, table_selected )
    {
        let kriteria_peserta_boleh_ujian_saja = [];
        $('tbody tr', table_selected).each(function(){
            let email = $('td:eq(2)', this).text().trim();
            kriteria_peserta_boleh_ujian_saja.push({
                email: email
            });
        });
        return kriteria_peserta_boleh_ujian_saja;
    }

    function parse_kriteria_diskon(e, list_diskon, dibuka_untuk)
    {
        let kriteria_diskon = [];
        let valid = true;
        $('.potongan-harga', list_diskon).each(function(index){
            let tipe = $('.jenis select', this).val();
            let value = $('.jenis input[type=number]', this).val();
            if (value==='')
            {
                alert('Value wajib diisi - potongan harga ' + (index+1));
                valid = false;
                return;
            }

            let disc_pendaftar_pertama = 0;
            if ($('.show-disc-pendaftar-pertama', this).prop('checked'))
                disc_pendaftar_pertama = $('.disc-pendaftar-pertama input[type=number]', this).val();
            let disc_waktu_daftar = {
                dari : null,
                sampai : null
            };
            if ($('.show-disc-waktu-daftar', this).prop('checked'))
            {
                let tgl_awal = $('.disc-waktu-daftar input[type=date]:eq(0)', this).val();
                let waktu_awal = $('.disc-waktu-daftar .bootstrap-timepicker:eq(0)', this).val();
                let tgl_akhir = $('.disc-waktu-daftar input[type=date]:eq(1)', this).val();
                let waktu_akhir = $('.disc-waktu-daftar .bootstrap-timepicker:eq(1)', this).val();

                if (tgl_awal === '' || tgl_akhir === '' )
                {
                    alert('Anda belum memilih tanggal periode untuk potongan harga ' + (index+1));
                    valid = false;
                    return;
                }
                disc_waktu_daftar = {
                    dari: tgl_awal+' '+ waktu_awal,
                    sampai: tgl_akhir+' '+waktu_akhir
                };
            }
            let disc = [];
            if (dibuka_untuk === 'mahasiswa')
            {
                $('.disc-mahasiswa table tbody tr', this).each(function(){
                    let angkatan = $('td:eq(0) input', this).val();
                    let jurusan = $('td:eq(1) select', this).val();
                    let index = $('td:eq(2) input', this).val();
					if (index !== '0') index = index.padStart(3, '0');
                    disc.push({
                        angkatan: angkatan,
                        jurusan: jurusan,
                        index: index
                    });
                });
            }
            else
            {
                $('.disc-umum table tbody tr', this).each(function(){
                    let tipe = $('td:eq(0) select', this).val();
                    let semua = $('td:eq(2) .checkbox-semua-data-kriteria-regis-umum', this).prop('checked');
                    let data = null;
                    if (semua) data = "0";
                    else
                    {
                        if (tipe === 'instansi')
                            data = $('td:eq(1) select', this).val();
                        else if (tipe === 'user')
                            data = $('td:eq(1) input', this).val();
                        else  return;
                    }
                    disc.push({
                        tipe: tipe,
                        data: data
                    });
                });
            }

            kriteria_diskon.push({
                tipe : tipe,
                value : value,
                disc_pendaftar_pertama : disc_pendaftar_pertama,
                disc_waktu_daftar : disc_waktu_daftar,
                disc : disc
            });
        });

        if (!valid) return null;
        return kriteria_diskon;
    }

</script>

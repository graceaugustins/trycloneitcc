<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- Tell the browser to be responsive to screen width -->
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Favicon icon -->
<link rel="icon" href="https://itcc.itpln.ac.id/home/wp-content/uploads/2021/12/200pxl-01-150x150.png" sizes="32x32">

<!-- Custom CSS -->
<link href="<?php echo base_url("assets/extra-libs/c3/c3.min.css");?>" rel="stylesheet">
<link href="<?php echo base_url("assets/libs/chartist/dist/chartist.min.css");?>" rel="stylesheet">
<link href="<?php echo base_url("assets/extra-libs/jvector/jquery-jvectormap-2.0.2.css");?>" rel="stylesheet" />
<!-- Custom CSS -->
<link href="<?php echo base_url("assets/dist/css/style.min.css");?>" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/css/bootstrap-timepicker.min.css" crossorigin="anonymous" />

<!-- Toastr -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.css" crossorigin="anonymous" />

<!-- FontAwesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />

<style>
	table.dataTable thead th, table.dataTable thead td,
	table.dataTable.compact thead th, table.dataTable.compact thead td{
		padding: 2px;
	}
	.stars-outer {
		display: inline-block;
		position: relative;
		font-family: FontAwesome;
	}

	.stars-outer::before {
		content: "\f006 \f006 \f006 \f006 \f006";
	}

	.stars-inner {
		position: absolute;
		top: 0;
		left: 0;
		white-space: nowrap;
		overflow: hidden;
		width: 0;
	}

	.stars-inner::before {
		content: "\f005 \f005 \f005 \f005 \f005";
		color: #f8ce0b;
	}
</style>
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->

<footer class="footer text-center text-muted">
    &copy; <script type="text/javascript">document.write(new Date().getFullYear())</script> Information Technology Certification Center - Institut Teknologi PLN Jakarta
</footer>
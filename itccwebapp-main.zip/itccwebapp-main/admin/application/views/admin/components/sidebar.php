<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><aside class="left-sidebar" data-sidebarbg="skin6">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar" data-sidebarbg="skin6">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <li class="sidebar-item"> 
                    <a class="sidebar-link sidebar-link" href="<?php echo base_url('admin'); ?>" aria-expanded="false">
                        <i data-feather="home" class="feather-icon"></i>
                        <span class="hide-menu">Dashboard</span>
                    </a>
                </li>

                <?php if(
                    admin_capable('lihat_kegiatan_sertifikasi') ||
                    admin_capable('lihat_list_sertifikasi') ||
                    admin_capable('lihat_history_sertifikasi')
                    ) { ?>
                <li class="sidebar-item">
                    <a class="sidebar-link has-arrow" href="javascript:void(0)"
                        aria-expanded="false">
                        <i data-feather="file-text" class="feather-icon"></i>
                        <span class="hide-menu">Sertifikasi </span>
                    </a>
                    <ul aria-expanded="false" class="collapse  first-level base-level-line">
                        <?php if(admin_capable('lihat_kegiatan_sertifikasi')) { ?>
                        <li class="sidebar-item">
                            <a href="<?php echo base_url('admin/sertifikasi/kegiatan'); ?>" class="sidebar-link">
                                <span class="hide-menu">Kegiatan</span>
                            </a>
                        </li>
                        <?php } ?>

                        <?php if(admin_capable('lihat_list_sertifikasi')) { ?>
                        <li class="sidebar-item">
                            <a href="<?php echo base_url('admin/sertifikasi/program'); ?>" class="sidebar-link">
                                <span class="hide-menu">Sertifikasi & Program</span>
                            </a>
                        </li>
                        <?php } ?>

                        <?php if(admin_capable('lihat_history_sertifikasi')) { ?>
                        <li class="sidebar-item">
                            <a href="<?php echo base_url('admin/sertifikasi/history'); ?>" class="sidebar-link">
                                <span class="hide-menu">History</span>
                            </a>
                        </li>
                        <?php } ?>
                    </ul>
                </li>
                <?php } ?>

                <?php if(admin_capable('lihat_list_trainer')) { ?>
                <li class="sidebar-item"> 
                    <a class="sidebar-link sidebar-link" href="<?php echo base_url('admin/trainer'); ?>" aria-expanded="false">
                        <i data-feather="users" class="feather-icon"></i>
                        <span class="hide-menu">Trainer</span>
                    </a>
                </li>
                <?php } ?>

                <?php if(admin_capable('lihat_list_proctor')) { ?>
                <li class="sidebar-item"> 
                    <a class="sidebar-link sidebar-link" href="<?php echo base_url('admin/proctor'); ?>" aria-expanded="false">
                        <i data-feather="users" class="feather-icon"></i>
                        <span class="hide-menu">Proctor</span>
                    </a>
                </li>
                <?php } ?>

                <?php if(admin_capable('lihat_list_user') || admin_capable('edit_list_user')) { ?>
                <li class="sidebar-item">
                    <a class="sidebar-link has-arrow" href="javascript:void(0)"
                        aria-expanded="false">
                        <i data-feather="users" class="feather-icon"></i>
                        <span class="hide-menu">User </span>
                    </a>
                    <ul aria-expanded="false" class="collapse  first-level base-level-line">
                        <li class="sidebar-item">
                            <a href="<?php echo base_url('admin/user/mahasiswa'); ?>" class="sidebar-link">
                                <span class="hide-menu">Mahasiswa</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="<?php echo base_url('admin/user/umum'); ?>" class="sidebar-link">
                                <span class="hide-menu">Umum</span>
                            </a>
                        </li>
						<li class="sidebar-item">
							<a href="<?php echo base_url('admin/user/itpln'); ?>" class="sidebar-link">
								<span class="hide-menu">ITPLN</span>
							</a>
						</li>
						<li class="sidebar-item">
							<a href="<?php echo base_url('admin/user/bidang_jabatan'); ?>" class="sidebar-link">
								<span class="hide-menu">Bidang & Jabatan</span>
							</a>
						</li>
                        <?php if(admin_capable('edit_list_user')) { ?>
                        <li class="sidebar-item">
                            <a href="<?php echo base_url('admin/user/certiport'); ?>" class="sidebar-link">
                                <span class="hide-menu">Akun Certiport</span>
                            </a>
                        </li>
                        <?php } ?>
                        <?php if(admin_capable('lihat_list_instansi')) { ?>
                        <li class="sidebar-item">
                            <a href="<?php echo base_url('admin/user/instansi'); ?>" class="sidebar-link">
                                <span class="hide-menu">Instansi</span>
                            </a>
                        </li>
                        <?php } ?>
                    </ul>
                </li>
                <?php } ?>

                <?php if(admin_capable('lihat_list_administrator')) { ?>
                <li class="sidebar-item"> 
                    <a class="sidebar-link sidebar-link" href="<?php echo base_url('admin/administrators'); ?>" aria-expanded="false">
                        <i data-feather="users" class="feather-icon"></i>
                        <span class="hide-menu">Administrators</span>
                    </a>
                </li>
                <?php } ?>

                <?php if(admin_capable('lihat_list_hak_akses')) { ?>
                <li class="sidebar-item"> 
                    <a class="sidebar-link sidebar-link" href="<?php echo base_url('admin/roles'); ?>" aria-expanded="false">
                        <i data-feather="sliders" class="feather-icon"></i>
                        <span class="hide-menu">Role Administrator</span>
                    </a>
                </li>
                <?php } ?>
                <?php if(admin_capable('edit_konfigurasi_sistem')) { ?>
                <li class="sidebar-item">
                    <a class="sidebar-link sidebar-link" href="<?php echo base_url('admin/sistem'); ?>" aria-expanded="false">
                        <i data-feather="settings" class="feather-icon"></i>
                        <span class="hide-menu">Konfigurasi Sistem</span>
                    </a>
                </li>
                <?php } ?>
                <?php if(admin_capable('lihat_history_sistem')) { ?>
                    <li class="sidebar-item">
                        <a class="sidebar-link sidebar-link" href="<?php echo base_url('admin/history'); ?>" aria-expanded="false">
                            <i data-feather="copy" class="feather-icon"></i>
                            <span class="hide-menu">History Sistem</span>
                        </a>
                    </li>
                <?php } ?>
            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</aside>

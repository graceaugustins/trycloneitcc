<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<script src="<?php echo base_url("assets/libs/jquery/dist/jquery.min.js"); ?>"></script>
<script src="<?php echo base_url("assets/libs/popper.js/dist/umd/popper.min.js"); ?>"></script>
<script src="<?php echo base_url("assets/libs/bootstrap/dist/js/bootstrap.min.js"); ?>"></script>

<script src="<?php echo base_url("assets/dist/js/app-style-switcher.js"); ?>"></script>
<script src="<?php echo base_url("assets/dist/js/feather.min.js"); ?>"></script>
<script src="<?php echo base_url("assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"); ?>"></script>
<script src="<?php echo base_url("assets/dist/js/sidebarmenu.js"); ?>"></script>
<!--Custom JavaScript -->
<script src="<?php echo base_url("assets/dist/js/custom.min.js"); ?>"></script>
<!--This page JavaScript -->
<script src="<?php echo base_url("assets/extra-libs/c3/d3.min.js"); ?>"></script>
<script src="<?php echo base_url("assets/extra-libs/c3/c3.min.js"); ?>"></script>

<script src="<?php echo base_url("assets/extra-libs/jvector/jquery-jvectormap-2.0.2.min.js"); ?>"></script>
<script src="<?php echo base_url("assets/extra-libs/jvector/jquery-jvectormap-world-mill-en.js"); ?>"></script>
<script src="<?php echo base_url("assets/libs/chart.js/dist/Chart.min.js"); ?>"></script>

<!-- DataTables -->
<script crossorigin="anonymous" type="text/javascript" src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>

<!-- Time Picker -->
<script src="<?php echo base_url('assets/extra-libs/bootstrap-timepicker/bootstrap-timepicker.js') ?>" crossorigin="anonymous"></script>

<!-- DayJS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.10.4/dayjs.min.js" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.10.4/locale/id.min.js" crossorigin="anonymous"></script>

<!-- Toastr -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js" crossorigin="anonymous"></script>

<script id="list-jurusan-config" type="application/json"><?php echo json_encode($this->config->item("JURUSAN")); ?></script>

<script type="text/javascript">
	const BASE_URL = "<?php echo base_url(); ?>";

	let j = JSON.parse(document.getElementById('list-jurusan-config').textContent);
	let a = [];
	for (let kode in j)
    {
        if (j.hasOwnProperty(kode))
        	a.push({
				kode: kode,
				nama: j[kode]
			});
    }
	const jurusan = a;

	const dt_config = {
        pagingType: 'simple',
        initComplete: function () {
            // Apply the search
            this.api().columns().every(function () {
                let that = this;

                $('input', this.footer()).on('keyup change clear', function () {
                    if (that.search() !== this.value) {
                        that
                            .search(this.value)
                            .draw();
                    }
                });
            });
        }
    };

	function setupTable(id)
    {
        // DataTable
        return $(id).DataTable(dt_config);
    }

    function format_rupiah(bilangan)
    {
        let	reverse = bilangan.toString().split('').reverse().join(''),
            ribuan 	= reverse.match(/\d{1,3}/g);
        ribuan	= ribuan.join('.').split('').reverse().join('');
        return "Rp. "+ribuan;
    }

    function get_param_ajax()
    {
        let param = {};
        param['<?php echo $this->security->get_csrf_token_name(); ?>'] = '<?php echo $this->security->get_csrf_hash(); ?>';
        return param;
    }

    const timepicker_config = {
        showInputs : true,
        showSeconds: true,
        showMeridian: false,
        secondStep : 1,
        minuteStep : 1,
        icons:{
            up: 'fas fa-angle-up',
            down: 'fas fa-angle-down'
        }
    };
	$('.bootstrap-timepicker').timepicker(timepicker_config);
    dayjs.locale('id');

	const starTotal = 5;
	$(".stars-inner").each(function(){
		let t = $(this);
		t.css("width",`${t.data("percentage")}%`);
	});
</script>

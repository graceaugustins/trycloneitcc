<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php function yield_title($_this, $data){?> Administrator <?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col-7 align-self-center">
        <h3 class="page-title text-dark font-weight-medium mb-1">
            <?php yield_title($_this, $data); ?>
        </h3>
    </div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
    <?php
    /** @var D_Administrator[] $all_administrators */
    $all_administrators = $data['administrators'];
    ?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <?php if (admin_capable(Permissions::TAMBAH_LIST_ADMINISTRATOR)) { ?>
                    <button class="btn btn-primary mb-4" data-toggle="modal" data-target="#tambah-admin">Tambah Administrator Baru</button>
                <?php } ?>
                <div class="table-responsive">
                    <table id="t-cap-role" class="table table-sm table-striped table-bordered mb-2">
                        <thead>
                        <tr>
                            <th class="align-middle">#</th>
                            <th class="align-middle">Email</th>
                            <th class="align-middle">Nama</th>
                            <th class="align-middle">Role</th>
                            <th class="align-middle"></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $i = 1;
                        foreach($all_administrators as $admin) { ?>
                            <tr>
                                <td class="align-middle">
                                    <?php echo $i++; ?>
                                    <span class="d-none id"><?php echo $admin->id; ?></span>
                                    <span class="d-none id-role"><?php echo $admin->id_role; ?></span>
                                </td>
                                <td class="align-middle"><?php echo html_escape($admin->email); ?></td>
                                <td class="align-middle"><?php echo html_escape($admin->nama); ?></td>
                                <td class="align-middle">
									<a href="<?php echo base_url('admin/roles?id_role='.$admin->id_role); ?>">
										<?php echo html_escape($admin->role->nama_role); ?>
									</a>
								</td>
                                <td class="align-middle">
                                    <?php if(admin_capable(Permissions::EDIT_LIST_ADMINISTRATOR)) {?>
                                        <button class="btn btn-info btn-sm m-1" data-toggle='modal' data-target='#edit-admin'>Ubah</button>
                                    <?php } ?>
                                    <?php if(admin_capable(Permissions::HAPUS_LIST_ADMINISTRATOR)) {?>
                                        <button class="btn btn-danger btn-sm m-1" data-toggle='modal' data-target='#hapus-admin'>Hapus</button>
                                    <?php } ?>
                                </td>
                            </tr>
                        <?php } ?>
                        </tbody>
                        <tfoot>
                        <tr>
                            <th class="align-middle">#</th>
                            <th class="align-middle">Email</th>
                            <th class="align-middle">Nama</th>
                            <th class="align-middle">Role</th>
                            <th class="align-middle"></th>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php } ?>

<?php function yield_bottom_before_script($_this, $data) { ?>
    <?php
    /** @var D_Role[] $all_roles */
    $all_roles = $data['roles'];
    ?>
    <!-- Modal tambah administrator -->
    <?php if(admin_capable(Permissions::TAMBAH_LIST_ADMINISTRATOR)) {?>
        <div id="tambah-admin" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-tambah-admin" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-tambah-admin">Tambah Administrator</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/administrators/add_new'); ?>">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <label for="tambah-admin-email">Alamat email (akun Microsoft, huruf kecil, tanpa spasi)</label>
                            <input class="form-control mb-2" id="tambah-admin-email" type="email" name="email" required="required">

                            <label for="tambah-admin-nama">Nama lengkap</label>
                            <input class="form-control mb-2" id="tambah-admin-nama" type="text" name="nama" required="required">

                            <label for="tambah-admin-role">Role</label>
                            <select name="id_role" class="form-control custom-select text-dark" id="tambah-admin-role">
                                <?php foreach($all_roles as $r) { ?>
                                    <option value='<?php echo $r->id; ?>'><?php echo html_escape($r->nama_role); ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Tambah</button>
                        </div>
                    </form>


                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>

    <!-- Modal edit administrator -->
    <?php if(admin_capable(Permissions::EDIT_LIST_ADMINISTRATOR)) {?>
        <div id="edit-admin" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-edit-cap" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-edit-cap">Ubah Administrator</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/administrators/update'); ?>">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <input type="hidden" name="id">
                            <label for="ubah-admin-email">Alamat email (akun Microsoft, huruf kecil, tanpa spasi)</label>
                            <input class="form-control mb-2" id="ubah-admin-email" type="email" name="email" required="required">
                            <label for="ubah-admin-nama">Nama lengkap</label>
                            <input class="form-control mb-2" id="ubah-admin-nama" type="text" name="nama" required="required">
                            <label for="ubah-admin-role">Role</label>
                            <select name="id_role" class="form-control custom-select text-dark" id='ubah-admin-role'>
                                <?php foreach($all_roles as $r) { ?>
                                    <option value='<?php echo $r->id; ?>'><?php echo html_escape($r->nama_role); ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Ubah</button>
                        </div>
                    </form>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>

    <!-- Modal hapus administrator -->
    <?php if(admin_capable(Permissions::HAPUS_LIST_ADMINISTRATOR)) {?>
        <div id="hapus-admin" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="label-hapus-admin" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="label-hapus-admin">Anda yakin ingin menghapus administrator ini?</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <form method="POST" action="<?php echo base_url('admin/administrators/delete'); ?>">
                        <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                        <div class="modal-body">
                            <input type="hidden" name="id">
                            <div>
                                Administrator : <strong class="m-hapus-admin-nama"></strong>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-danger float-right">Hapus</button>
                        </div>
                    </form>

                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php } ?>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
    <script type="text/javascript">

        $('#edit-admin').on('show.bs.modal', function (event) {
            let button = $(event.relatedTarget); // Button that triggered the modal
            let p = button.parent().parent();
            let id = p.find('td:eq(0) .id').text();
            let email = p.children('td:eq(1)').text();
            let nama=p.children('td:eq(2)').text();
            let id_role=p.find('td:eq(0) .id-role ').text();

            var modal = $(this);
            modal.find('.modal-body input[name=id]').val(id);
            modal.find('.modal-body input[name=email]').val(email);
            modal.find('.modal-body input[name=nama]').val(nama);
            modal.find(".modal-body option[value='"+id_role+"']").attr('selected', 'selected');
        });

        $('#hapus-admin').on('show.bs.modal', function (event) {
            let button = $(event.relatedTarget); // Button that triggered the modal
            let p = button.parent().parent();
            let id = p.find('td:eq(0) .id').text();
            let email = p.children('td:eq(1)').text();
            let nama=p.children('td:eq(2)').text();

            var modal = $(this);

            modal.find('.modal-body input[name=id]').val(id);
            modal.find('.modal-body .m-hapus-admin-nama').text(nama+' ('+email+')');
        });
    </script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('admin/components/container_main', [ 'data' => $data]); ?>

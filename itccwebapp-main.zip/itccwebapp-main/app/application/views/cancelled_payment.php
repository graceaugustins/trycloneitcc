<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>

<?php function yield_page_title($_this, $data){?>
Daftar Pembayaran
<?php } ?>

<?php function yield_page_header($_this, $data){?>
    <div class="col">
        <h2 class="page-title my-auto">
            <?php yield_page_title($_this, $data); ?>
        </h2>
    </div>
<?php } ?>

<?php function yield_page_content($_this, $data){?>
	<?php
	/** @var D_Kegiatan_User $selected_pendaftaran */
	$selected_pendaftaran = $data['selected_pendaftaran'];
	?>
<h3>Data Pembayaran - <?php echo $selected_pendaftaran->kegiatan->nama_kegiatan; ?></h3>
<div class="row row-cards">

    <div class="col-12">
        <div class="card">

            <div class="card-body table-responsive" style="padding: 0;">
                <table class="table card-table table-vcenter text-nowrap datatable">
                    <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal Upload</th>
                        <th>Nama Pengirim</th>
                        <th>Bank Pengirim</th>
                        <th>Waktu Transfer</th>
                        <th>Nominal Dibayar</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($selected_pendaftaran->list_bukti_bayar)) {?>
                        <tr>
                            <td colspan="7"><div class="hr-text mt-2 mb-1">Kosong</div></td>
                        </tr>
                    <?php } else {
                        $i = 1;
                        foreach($selected_pendaftaran->list_bukti_bayar as $bukti_bayar){?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo tgl_indo($bukti_bayar->timestamp->format('Y-m-d'), 'Y-m-d', TRUE)
                                .' '.$bukti_bayar->timestamp->format('H:i:s')
                                .' WIB'; ?></td>
                        <td><?php echo $bukti_bayar->nama_pengirim; ?></td>
                        <td><?php
							if (in_array($bukti_bayar->bank, array_keys($_this->config->item('LIST_BANK'))))
								echo $_this->config->item('LIST_BANK')[$bukti_bayar->bank];
							else echo strtoupper($bukti_bayar->bank); ?></td>
                        <td><?php echo tgl_indo($bukti_bayar->waktu_transfer->format('Y-m-d'), 'Y-m-d', TRUE)
                                .' '.$bukti_bayar->waktu_transfer->format('H:i:s')
                                .' WIB'; ?></td>
                        <td><?php echo format_rupiah($bukti_bayar->nominal_dibayar); ?></td>
                        <td>
                            <?php if($bukti_bayar->status === General_Constants::PEMBAYARAN_ACCEPTED) {?>
                            <span class="badge bg-success d-block mx-auto">Diterima</span>
                            <?php } elseif($bukti_bayar->status === General_Constants::PEMBAYARAN_REJECTED) { ?>
                            <span class="badge bg-warning d-block mx-auto">Tidak Diterima</span>
                            <?php } elseif($bukti_bayar->status === General_Constants::PEMBAYARAN_PENDING) { ?>
                            <span class="badge bg-azure d-block mx-auto">Pending</span>
                            <?php } ?>
                        </td>
                    </tr>
                    <?php }
                    }?>

                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('components/container_main', [ 'data' => $data]); ?>

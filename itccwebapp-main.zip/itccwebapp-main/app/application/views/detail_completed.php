<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php function yield_page_title($_this, $data){?>
	<?php
	/** @var D_Kegiatan_User $pendaftaran */
	$pendaftaran = $data['pendaftaran'];
	?>
	Detail Sertifikasi - <?php echo $pendaftaran->kegiatan->nama_kegiatan; ?>
<?php } ?>
<?php function yield_page_header($_this, $data){?>
	<div class="col">
		<h2 class="page-title my-auto">
			<?php yield_page_title($_this, $data); ?>
		</h2>
	</div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
	<?php
	/** @var D_Kegiatan_User $pendaftaran */
	$pendaftaran = $data['pendaftaran'];
	?>
	<div class="row row-cards">
		<div class="col-12">
			<div class="card">
				<div class="card-body">
					<div class="row mb-4 align-items-center">
						<div class="col-8">
							<div class="ps-2">
								<h1><?php echo $pendaftaran->kegiatan->nama_kegiatan; ?></h1>
							</div>
						</div>
						<div class="col-4">
							<img class="float-end mr-2" src="<?php echo $pendaftaran->kegiatan->sertifikasi->get_link_logo(); ?>" height="80" alt="logo">
						</div>
					</div>
					<div class="row mb-4">
						<div class="col-md-6 mb-3">
							<div class="row mb-2">
								<div class="col-md-4 mb-2 font-weight-medium">Deskripsi Kegiatan</div>
								<div class="col-md-8 mb-2"><?php echo $pendaftaran->kegiatan->deskripsi; ?></div>
							</div>
							<div class="row mb-2">
								<div class="col-md-4 mb-2 font-weight-medium">Nama Sertifikasi</div>
								<div class="col-md-8 mb-2"><?php echo $pendaftaran->kegiatan->sertifikasi->nama; ?></div>
							</div>
							<div class="row mb-2">
								<div class="col-md-4 mb-2 font-weight-medium">Deskripsi Sertifikasi</div>
								<div class="col-md-8 mb-2"><?php echo $pendaftaran->kegiatan->sertifikasi->deskripsi; ?></div>
							</div>
							<div class="row mb-2">
								<div class="col-md-4 mb-2 font-weight-medium">Program yang Anda Pilih</div>
								<div class="col-md-8 mb-2 align-items-center">
									<span><?php echo $pendaftaran->program->nama_program; ?></span>
									<img class="float-end" style="margin-right: 30px;" height="50" src="<?php echo $pendaftaran->program->get_link_logo(); ?>" alt="logo">
								</div>
							</div>
						</div>
						<div class="col-md-6 mb-3">
							<div class="row mb-2">
								<div class="col-md-4 mb-2 font-weight-medium">Pelaksanaan Training</div>
								<div class="col-md-8 mb-2"><?php echo $pendaftaran->kegiatan->keterangan_training; ?></div>
							</div>
							<div class="row mb-2">
								<div class="col-md-4 mb-2 font-weight-medium">Pelaksanaan Ujian</div>
								<div class="col-md-8 mb-2"><?php echo $pendaftaran->kegiatan->keterangan_ujian; ?></div>
							</div>
						</div>
					</div>
					<div class="row mb-4">
						<?php $ujian_saja = $pendaftaran->jenis === General_Constants::UJIAN_SAJA; ?>
						<?php if (!$ujian_saja) { ?>
						<div class="col-md-6 mb-4">
							<div class="mb-3">
								<h3>Training</h3>
							</div>
							<div class="row mb-2">
								<div class="col-md-4 mb-2 font-weight-medium">Kelompok Training</div>
								<div class="col-md-8 mb-2">
									<?php if (empty($pendaftaran->id_kelompok_t)) { ?>
										<div class="badge bg-warning mb-2">Tidak Ada</div>
									<?php } else {?>
										<b><?php echo $pendaftaran->kelompok_t->nama_kelompok; ?></b>
									<?php } ?>
								</div>
							</div>
							<div class="row mb-2">
								<div class="col-md-4 mb-2 font-weight-medium">Tanggal</div>
								<div class="col-md-8 mb-2">
									<?php if (empty($pendaftaran->id_kelompok_t)) {?>
										<div class="badge bg-warning">Tidak Ada</div>
									<?php } else {?>
										<b><?php echo tgl_indo($pendaftaran->kelompok_t->mulai_training->format('Y-m-d'), 'Y-m-d'); ?></b>
									<?php } ?>
								</div>
							</div>
							<div class="row mb-2">
								<div class="col-md-4 mb-2 font-weight-medium">Waktu</div>
								<div class="col-md-8 mb-2">
									<?php if (empty($pendaftaran->id_kelompok_t)) {?>
										<div class="badge bg-warning">Tidak Ada</div>
									<?php } else {?>
										<span class="font-monospace">
                                            <?php echo $pendaftaran->kelompok_t->mulai_training->format('H:i:s') ?>
                                        </span>
										s/d
										<span class="font-monospace">
                                            <?php echo $pendaftaran->kelompok_t->selesai_training->format('H:i:s') ?>
                                        </span>
										WIB
									<?php } ?>
								</div>
							</div>
							<div class="row mb-2">
								<div class="col-md-4 mb-2 font-weight-medium">Lokasi</div>
								<div class="col-md-8 mb-2">
									<?php if (empty($pendaftaran->id_kelompok_t)) {?>
										<div class="badge bg-warning">Tidak Ada</div>
									<?php } else {?>
										<?php echo $pendaftaran->kelompok_t->lokasi_training; ?>
									<?php } ?>
								</div>
							</div>
						</div>
						<?php } ?>
						<div class="col-md-6 mb-4">
							<div class="mb-3">
								<h3>Ujian</h3>
							</div>
							<div class="row mb-2">
								<div class="col-md-4 mb-2 font-weight-medium">Kelompok Ujian</div>
								<div class="col-md-8 mb-2">
									<?php if (empty($pendaftaran->id_kelompok_u)) {?>
										<div class="badge bg-warning mb-2">Tidak Ada</div>
									<?php } else {?>
										<b><?php echo $pendaftaran->kelompok_u->nama_kelompok; ?></b>
									<?php } ?>
								</div>
							</div>
							<div class="row mb-2">
								<div class="col-md-4 mb-2 font-weight-medium">Tanggal</div>
								<div class="col-md-8 mb-2">
									<?php if (empty($pendaftaran->id_kelompok_u)) {?>
										<div class="badge bg-warning">Tidak Ada</div>
									<?php } else {?>
										<b><?php echo tgl_indo($pendaftaran->kelompok_u->mulai_ujian->format('Y-m-d'), 'Y-m-d'); ?></b>
									<?php } ?>
								</div>
							</div>
							<div class="row mb-2">
								<div class="col-md-4 mb-2 font-weight-medium">Waktu</div>
								<div class="col-md-8 mb-2">
									<?php if (empty($pendaftaran->id_kelompok_u)) {?>
										<div class="badge bg-warning">Tidak Ada</div>
									<?php } else {?>
										<span class="font-monospace">
                                            <?php echo $pendaftaran->kelompok_u->mulai_ujian->format('H:i:s') ?>
                                        </span>
										s/d
										<span class="font-monospace">
                                            <?php echo $pendaftaran->kelompok_u->selesai_ujian->format('H:i:s') ?>
                                        </span>
										WIB
									<?php } ?>
								</div>
							</div>
							<div class="row mb-2">
								<div class="col-md-4 mb-2 font-weight-medium">Lokasi</div>
								<div class="col-md-8 mb-2">
									<?php if (empty($pendaftaran->id_kelompok_u)) {?>
										<div class="badge bg-warning">Tidak Ada</div>
									<?php } else {?>
										<?php echo $pendaftaran->kelompok_u->lokasi_ujian; ?>
									<?php } ?>
								</div>
							</div>

						</div>
					</div>

						<div class="row mb-4">
							<div class="col-md-6 mb-3">
								<div class="row">
									<div class="col-12 mb-3">
										<h3>Kehadiran</h3>
									</div>
									<?php if (!$ujian_saja && !empty($pendaftaran->id_kelompok_t)) {?>
									<div class="col-12 mb-3">
										<div class="row">
											<div class="col-12 mb-2"><b>Training</b></div>
											<div class="col-md-6 mb-2">
												Sesi 1 :
												<?php if ($pendaftaran->hadir_training_sesi1) {?>
													<div class="badge bg-success">HADIR</div>
												<?php } else { ?>
													<div class="badge bg-danger">TIDAK HADIR</div>
												<?php } ?>
											</div>
											<div class="col-md-6 mb-2">
												Sesi 2 :
												<?php if ($pendaftaran->hadir_training_sesi2) {?>
													<div class="badge bg-success">HADIR</div>
												<?php } else { ?>
													<div class="badge bg-danger">TIDAK HADIR</div>
												<?php } ?>
											</div>
										</div>
									</div>
									<?php } ?>
									<div class="col-12">
										<div class="row">
											<div class="col-12 mb-2">
												<b>Ujian :</b>
												<?php if ($pendaftaran->hadir_ujian) {?>
													<div class="badge bg-success">HADIR</div>
												<?php } else { ?>
													<div class="badge bg-danger">TIDAK HADIR</div>
												<?php } ?>
											</div>
										</div>
									</div>
								</div>

							</div>
							<div class="col-md-6 mb-3">
								<h3 style="font-size: 20px;">
									Skor Ujian :
									<?php
									if ($pendaftaran->status_kelulusan === General_Constants::STATUS_PENDING) {?>
										<div class="badge bg-info">PENDING</div>
									<?php } else { ?>
										<?php echo $pendaftaran->skor_ujian; ?>
										<?php if ($pendaftaran->status_kelulusan === General_Constants::STATUS_TIDAK_LULUS) {?>
											<div class="badge bg-danger">TIDAK LULUS</div>
										<?php } elseif ($pendaftaran->status_kelulusan === General_Constants::STATUS_LULUS) { ?>
											<div class="badge bg-success">LULUS</div>
										<?php } ?>
									<?php } ?>
								</h3>
								<?php if ($pendaftaran->status_kelulusan === General_Constants::STATUS_TIDAK_LULUS) {?>
								<div class="alert alert-info alert-dismissible bg-white" role="alert">
									Bagi peserta yang tidak lulus akan mendapatkan sertifikat keikutsertaan dari ITCC,
									dan dapat dilihat di menu <b>E-Certificate</b>.
								</div>
								<?php } ?>
							</div>
						</div>


				</div>
			</div>
		</div>
	</div>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('components/container_main', ['data' => $data]); ?>

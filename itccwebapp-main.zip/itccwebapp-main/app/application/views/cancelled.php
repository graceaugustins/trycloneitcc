<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<?php function yield_page_title($_this, $data){?>Kegiatan yang dibatalkan<?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col">
        <h2 class="page-title my-auto">
            <?php yield_page_title($_this, $data); ?>
        </h2>
    </div>
<?php } ?>

<?php function yield_page_content($_this, $data){?>
	<?php
	/** @var D_Kegiatan_User[] $list_kegiatan_dibatalkan */
	$list_kegiatan_dibatalkan = $data['list_kegiatan_dibatalkan'];
	?>
<div class="alert alert-info bg-white" role="alert">
    Berikut adalah list daftar kegiatan yang dibatalkan oleh ITCC (kegiatan yang anda ikuti). <br>
    Untuk info lebih lanjut mengenai pembatalan kegiatan, silahkan cek info di grup resmi ITCC, atau hubungi kontak resmi ITCC.
</div>
<div class="row row-cards">
    <?php if (empty($list_kegiatan_dibatalkan)) {?>
        <div class="hr-text">Kosong</div>
    <?php } else foreach($list_kegiatan_dibatalkan as $cancelled) {?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="row g-2 align-items-center">
                    <div class=" col-md-9">
                        <div class="row align-items-center">
                            <div class="col-auto">
                                <div class="avatar avatar-lg" style="background-image: url(<?php echo $cancelled->kegiatan->sertifikasi->get_link_logo(); ?>)"></div>
                            </div>
                            <div class="col">
                                <div class="row">
                                    <div class="col-md-7 my-2">
                                        <h4 class="card-title m-0">
                                            <?php echo $cancelled->kegiatan->nama_kegiatan; ?>
                                        </h4>
                                        <div class="mt-1">
                                            <span class="badge bg-cyan "><?php echo $cancelled->kegiatan->sertifikasi->nama; ?></span>
                                        </div>
                                        <div class="text-muted mt-1">
                                            <?php echo $cancelled->program->nama_program; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-5 my-2">
                                        <div>Keterangan : </div>
                                        <div><?php echo $cancelled->kegiatan->keterangan_batal; ?></div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class=" col-md-3">
                        <a href="<?php echo base_url('sertifikasi/cancelled/'.$cancelled->id.'/payment'); ?>" role="button" class="d-block btn btn-info mb-2" style="white-space: normal;">
                            Info Pembayaran
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php } ?>
</div>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('components/container_main', ['data' => $data]); ?>

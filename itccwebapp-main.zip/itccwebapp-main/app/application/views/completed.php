<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php function yield_page_title($_this, $data){?>Sertifikasi Anda yang Sudah Diikuti<?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col">
        <h2 class="page-title my-auto">
            <?php yield_page_title($_this, $data); ?>
        </h2>
    </div>
<?php } ?>

<?php function yield_page_content($_this, $data){?>
	<?php
	/** @var D_Kegiatan_User[] $list_kegiatan_sudah_dilaksanakan */
	$list_kegiatan_sudah_dilaksanakan = $data['list_kegiatan_sudah_dilaksanakan'];
	?>
    <div class="row row-cards">
        <?php if (empty($list_kegiatan_sudah_dilaksanakan)) { ?>
        <div class="hr-text">Kosong</div>
        <?php } else foreach($list_kegiatan_sudah_dilaksanakan as $completed) {?>
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row g-2 align-items-center">
                        <div class=" col-md-9">
                            <div class="row align-items-center">
                                <div class="col-auto">
                                    <div class="avatar avatar-lg" style="background-image: url(<?php echo $completed->kegiatan->sertifikasi->get_link_logo(); ?>)"></div>
                                </div>
                                <div class="col">
                                    <h4 class="card-title m-0 nama-kegiatan">
                                        <?php echo $completed->kegiatan->nama_kegiatan; ?>
                                    </h4>
                                    <div class="text-muted mt-1">
                                        <?php echo $completed->kegiatan->sertifikasi->nama; ?>
                                    </div>
                                    <div class="mt-1">
                                        <?php if ($completed->status_kelulusan === General_Constants::STATUS_PENDING) { ?>
                                        <span class="badge bg-info">Pending</span>
                                        <?php } elseif ($completed->status_kelulusan === General_Constants::STATUS_TIDAK_LULUS) {?>
                                            <span class="badge bg-danger">Tidak Lulus</span>
                                        <?php } elseif ($completed->status_kelulusan === General_Constants::STATUS_LULUS) {?>
                                            <span class="badge bg-success">Lulus</span>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class=" col-md-3">
                            <a href="<?php echo base_url('sertifikasi/completed/'.$completed->id); ?>" role="button" class="d-block btn btn-light mb-2" style="white-space: normal;">
                                Info Sertifikasi
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>
    </div>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('components/container_main', ['data' => $data]); ?>

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<?php function yield_page_title($_this, $data){?>Sertifikasi Anda yang Sedang Berjalan<?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col">
        <h2 class="page-title my-auto">
            <?php yield_page_title($_this, $data); ?>
        </h2>
    </div>
<?php } ?>

<?php function yield_page_content($_this, $data){?>
	<?php
	/** @var D_Kegiatan_User $selected_pendaftaran */
	$selected_pendaftaran = $data['selected_pendaftaran'];
	$sekarang = new DateTime();
	$kegiatan_dibuka_untuk_itpln = $selected_pendaftaran->kegiatan->dibuka_untuk === General_Constants::ITPLN;
	?>
	<?php $ujian_saja = ($selected_pendaftaran->jenis === General_Constants::UJIAN_SAJA); ?>
    <div class="row row-cards">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-4 align-items-center">
                        <div class="col-8">
							<div class="ps-2">
								<h1><?php echo $selected_pendaftaran->kegiatan->nama_kegiatan; ?></h1>
							</div>
                        </div>
                        <div class="col-4">
                            <img class="float-end mr-2" src="<?php echo $selected_pendaftaran->kegiatan->sertifikasi->get_link_logo(); ?>" height="80" alt="logo">
                        </div>
                    </div>
                    <div class="row mb-4">
                        <div class="col-md-6 mb-3">
                            <div class="row mb-2">
                                <div class="col-md-4 mb-2 font-weight-medium">Deskripsi Kegiatan</div>
                                <div class="col-md-8 mb-2"><?php echo $selected_pendaftaran->kegiatan->deskripsi; ?></div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-md-4 mb-2 font-weight-medium">Nama Sertifikasi</div>
                                <div class="col-md-8 mb-2"><?php echo $selected_pendaftaran->kegiatan->sertifikasi->nama; ?></div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-md-4 mb-2 font-weight-medium">Deskripsi Sertifikasi</div>
                                <div class="col-md-8 mb-2"><?php echo $selected_pendaftaran->kegiatan->sertifikasi->deskripsi; ?></div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-md-4 mb-2 font-weight-medium">Program yang Anda Pilih</div>
                                <div class="col-md-8 mb-2 align-items-center">
                                    <span><?php echo $selected_pendaftaran->program->nama_program; ?></span>
                                    <img class="float-end" style="margin-right: 30px;" height="50" src="<?php echo $selected_pendaftaran->program->get_link_logo(); ?>" alt="logo">
                                </div>
                            </div>
							<div class="row mb-2">
								<div class="col-md-4 mb-2 font-weight-medium">Paket yang dipilih</div>
								<div class="col-md-8 mb-2">
									<?php echo ($selected_pendaftaran->jenis === General_Constants::TRAINING_DAN_UJIAN)? "Training & Ujian" : "Ujian Saja"; ?>
								</div>
							</div>
                            <div class="row mb-2">
                                <div class="col-md-4 mb-2 font-weight-medium">Link Grup</div>
                                <div class="col-md-8 mb-2">
                                    <a href="<?php echo $selected_pendaftaran->kegiatan->link_grup; ?>"><?php echo $selected_pendaftaran->kegiatan->link_grup; ?></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="row mb-2">
                                <div class="col-md-4 mb-2 font-weight-medium">Pelaksanaan Training</div>
                                <div class="col-md-8 mb-2"><?php echo $selected_pendaftaran->kegiatan->keterangan_training; ?></div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-md-4 mb-2 font-weight-medium">Pelaksanaan Ujian</div>
                                <div class="col-md-8 mb-2"><?php echo $selected_pendaftaran->kegiatan->keterangan_ujian; ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-4">
						<?php if (!$ujian_saja) { ?>
                        <div class="col-md-6 mb-4">
                            <div class="mb-3">
                                <h3>Training</h3>
                            </div>
							<div class="row mb-2">
								<div class="col-md-4 mb-2 font-weight-medium">Kelompok Training</div>
								<div class="col-md-8 mb-2">
									<?php if (empty($selected_pendaftaran->id_kelompok_t)) {?>
										<div class="badge bg-warning mb-2">Belum Ada Kelompok Training</div>
										<?php if (!$kegiatan_dibuka_untuk_itpln) { ?>
										<div>
											<a role="button" target="_blank" class="btn btn-success"
											   href="<?php echo base_url('sertifikasi/pilih-kelompok-t/'.$selected_pendaftaran->id); ?>">
												Klik untuk Pilih Kelompok Training
											</a>
										</div>
										<?php } ?>
									<?php } else {?>
										<b><?php echo $selected_pendaftaran->kelompok_t->nama_kelompok; ?></b>
									<?php } ?>
								</div>
							</div>
                            <div class="row mb-2">
                                <div class="col-md-4 mb-2 font-weight-medium">Tanggal</div>
                                <div class="col-md-8 mb-2">
                                    <?php if (empty($selected_pendaftaran->id_kelompok_t)) {?>
                                        <div class="badge bg-warning">Belum Ada Kelompok Training</div>
                                    <?php } else {?>
                                        <b><?php echo tgl_indo($selected_pendaftaran->kelompok_t->mulai_training->format('Y-m-d'), 'Y-m-d'); ?></b>
                                    <?php } ?>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-md-4 mb-2 font-weight-medium">Waktu</div>
                                <div class="col-md-8 mb-2">
                                    <?php if (empty($selected_pendaftaran->id_kelompok_t)) {?>
										<div class="badge bg-warning">Belum Ada Kelompok Training</div>
                                    <?php } else {?>
                                        <span class="font-monospace">
                                            <?php echo $selected_pendaftaran->kelompok_t->mulai_training->format('H:i:s') ?>
                                        </span>
                                        s/d
                                        <span class="font-monospace">
                                            <?php echo $selected_pendaftaran->kelompok_t->selesai_training->format('H:i:s') ?>
                                        </span>
                                        WIB
                                    <?php } ?>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-md-4 mb-2 font-weight-medium">Lokasi</div>
                                <div class="col-md-8 mb-2">
                                    <?php if (empty($selected_pendaftaran->id_kelompok_t)) {?>
										<div class="badge bg-warning">Belum Ada Kelompok Training</div>
                                    <?php } else {?>
                                        <?php echo $selected_pendaftaran->kelompok_t->lokasi_training; ?>
                                    <?php } ?>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-md-4 mb-2 font-weight-medium">Link Assesment</div>
                                <div class="col-md-8 mb-2">
                                    <?php if (empty($selected_pendaftaran->id_kelompok_t)) {?>
										<div class="badge bg-warning">Belum Ada Kelompok Training</div>
                                    <?php } elseif (
									(int)$selected_pendaftaran->kelompok_t->jumlah_peserta <
									(int)$selected_pendaftaran->kelompok_t->min_peserta_training) {?>
										<div class="badge bg-dark">Belum memenuhi kuota minimum</div>
									<?php } elseif (
											$selected_pendaftaran->kelompok_t->mulai_training <= $sekarang &&
											$selected_pendaftaran->kelompok_t->selesai_training >= $sekarang
									) { ?>
                                        <a target="_blank" role="button" href="<?php echo $selected_pendaftaran->program->link_assesment; ?>" class="d-block me-4 btn btn-info btn-block">Buka Link Assesment</a>
                                    <?php } else { ?>
										<div class="badge bg-warning">Training belum dimulai</div>
									<?php } ?>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-md-4 mb-2 font-weight-medium">Materi Training</div>
                                <div class="col-md-8 mb-2">
                                    <?php if (empty($selected_pendaftaran->id_kelompok_t)) {?>
										<div class="badge bg-warning">Belum Ada Kelompok Training</div>
                                    <?php } elseif (
											(int)$selected_pendaftaran->kelompok_t->jumlah_peserta <
											(int)$selected_pendaftaran->kelompok_t->min_peserta_training
									) {?>
										<div class="badge bg-dark">Belum memenuhi kuota minimum</div>
									<?php }  elseif (
											$selected_pendaftaran->kelompok_t->mulai_training <= $sekarang &&
											$selected_pendaftaran->kelompok_t->selesai_training >= $sekarang
									) { ?>
                                        <a target="_blank" role="button" href="<?php echo base_url('sertifikasi/materi-training/'.$selected_pendaftaran->id); ?>" class="d-block me-4 btn btn-info btn-block">
                                            Lihat Materi Training
                                        </a>
                                    <?php } else { ?>
										<div class="badge bg-warning">Training belum dimulai</div>
									<?php } ?>
                                </div>
                            </div>
                        </div>
						<?php } ?>
                        <div class="col-md-6 mb-4">
                            <div class="mb-3">
                                <h3>Ujian</h3>
                            </div>
							<div class="row mb-2">
								<div class="col-md-4 mb-2 font-weight-medium">Kelompok Ujian</div>
								<div class="col-md-8 mb-2">
									<?php if (empty($selected_pendaftaran->id_kelompok_u)) {?>
										<div class="badge bg-warning mb-2">Belum Ada Kelompok Ujian</div>
										<?php if (!$kegiatan_dibuka_untuk_itpln) { ?>
										<div>
											<a role="button" target="_blank" class="btn btn-success"
											   href="<?php echo base_url('sertifikasi/pilih-kelompok-u/'.$selected_pendaftaran->id); ?>">
												Klik untuk Pilih Kelompok Ujian
											</a>
										</div>
										<?php } ?>
									<?php } else {?>
										<b><?php echo $selected_pendaftaran->kelompok_u->nama_kelompok; ?></b>
									<?php } ?>
								</div>
							</div>
                            <div class="row mb-2">
                                <div class="col-md-4 mb-2 font-weight-medium">Tanggal</div>
                                <div class="col-md-8 mb-2">
                                    <?php if (empty($selected_pendaftaran->id_kelompok_u)) {?>
                                        <div class="badge bg-warning">Belum Ada Kelompok Ujian</div>
                                    <?php } else {?>
                                        <b><?php echo tgl_indo($selected_pendaftaran->kelompok_u->mulai_ujian->format('Y-m-d'), 'Y-m-d'); ?></b>
                                    <?php } ?>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-md-4 mb-2 font-weight-medium">Waktu</div>
                                <div class="col-md-8 mb-2">
                                    <?php if (empty($selected_pendaftaran->id_kelompok_u)) {?>
										<div class="badge bg-warning">Belum Ada Kelompok Ujian</div>
                                    <?php } else {?>
                                        <span class="font-monospace">
                                            <?php echo $selected_pendaftaran->kelompok_u->mulai_ujian->format('H:i:s') ?>
                                        </span>
                                        s/d
                                        <span class="font-monospace">
                                            <?php echo $selected_pendaftaran->kelompok_u->selesai_ujian->format('H:i:s') ?>
                                        </span>
                                        WIB
                                    <?php } ?>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-md-4 mb-2 font-weight-medium">Lokasi</div>
                                <div class="col-md-8 mb-2">
                                    <?php if (empty($selected_pendaftaran->id_kelompok_u)) {?>
										<div class="badge bg-warning">Belum Ada Kelompok Ujian</div>
                                    <?php } else {?>
                                        <?php echo $selected_pendaftaran->kelompok_u->lokasi_ujian; ?>
                                    <?php } ?>
                                </div>
                            </div>

                        </div>
                    </div>
					<?php if (!empty($selected_pendaftaran->id_kelompok_t) || !empty($selected_pendaftaran->id_kelompok_u)) { ?>
                    <div class="row mb-4">
                        <div class="col-md-6 mb-3">
                            <div class="row">
                                <div class="col-12 mb-3">
                                    <h3>Kehadiran</h3>
                                </div>
								<?php if (
										!empty($selected_pendaftaran->id_kelompok_t) &&
										!$ujian_saja
								) {?>
                                <div class="col-12 mb-3">
                                    <div class="row">
                                        <div class="col-12 mb-2"><b>Training</b></div>
                                        <div class="col-md-6 mb-2">
                                            Sesi 1 :
                                            <?php if ($selected_pendaftaran->hadir_training_sesi1) {?>
                                                <div class="badge bg-success">HADIR</div>
                                            <?php } else { ?>
                                                <div class="badge bg-danger">TIDAK HADIR</div>
                                            <?php } ?>
                                        </div>
                                        <div class="col-md-6 mb-2">
                                            Sesi 2 :
                                            <?php if ($selected_pendaftaran->hadir_training_sesi2) {?>
                                                <div class="badge bg-success">HADIR</div>
                                            <?php } else { ?>
                                                <div class="badge bg-danger">TIDAK HADIR</div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
								<?php } ?>
								<?php if(!empty($selected_pendaftaran->id_kelompok_u)) { ?>
                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-12 mb-2">
                                            <b>Ujian :</b>
                                            <?php if ($selected_pendaftaran->hadir_ujian) {?>
                                                <div class="badge bg-success">HADIR</div>
                                            <?php } else { ?>
                                                <div class="badge bg-danger">TIDAK HADIR</div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
								<?php } ?>
                            </div>

                        </div>
                        <div class="col-md-6 mb-3">
                            <h3 style="font-size: 20px;">
                                Skor Ujian :
                                <?php
                                if ($selected_pendaftaran->status_kelulusan === General_Constants::STATUS_PENDING) {?>
                                    <div class="badge bg-info">PENDING</div>
                                <?php } else { ?>
                                    <?php echo $selected_pendaftaran->skor_ujian; ?>

                                    <?php if ($selected_pendaftaran->status_kelulusan === General_Constants::STATUS_TIDAK_LULUS) {?>
                                        <div class="badge bg-danger">TIDAK LULUS</div>
                                    <?php } elseif ($selected_pendaftaran->status_kelulusan === General_Constants::STATUS_LULUS) { ?>
                                        <div class="badge bg-success">LULUS</div>
                                    <?php } ?>
                                <?php } ?>
                            </h3>
                            <div class="alert alert-info alert-dismissible bg-white" role="alert">
                                Bagi peserta yang tidak lulus akan mendapatkan sertifikat keikutsertaan dari ITCC,
                                dan dapat dilihat di menu <b>E-Certificate</b>.
                            </div>
                        </div>
                    </div>
					<?php } ?>
                </div>
            </div>
        </div>
    </div>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('components/container_main', ['data' => $data]); ?>

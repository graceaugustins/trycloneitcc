<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php function yield_page_title($_this, $data){?>E-Certificate Saya<?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col">
        <h2 class="page-title my-auto">
            <?php yield_page_title($_this, $data); ?>
        </h2>
    </div>
<?php } ?>

<?php function yield_page_content($_this, $data){?>
<div class="alert alert-info bg-white" role="alert">
    E-Certificate merupakan bukti keikutsertaan dalam kegiatan yang di adakan oleh ITCC (MOS dan MCF wajib lulus info lebih lanjut klik <a href="https://itcc.itpln.ac.id/home/info-mos-dan-mcf/">Disini</a>) <br>
    Seluruh E-Certificate yang diterbitkan ITCC dapat diverifikasi di link berikut:  <a href="<?php echo base_url('verify'); ?>" target="_blank" class="alert-link"><?php echo base_url('verify'); ?></a>
</div>
<div class="row row-cards">
	<?php
	/** @var D_Sertifikat_Keikutsertaan[] $ecerts */
	$ecerts = $data['ecerts'];
	?>
    <?php if (empty($ecerts)) {?>
        <div class="hr-text">Kosong</div>
    <?php } else foreach($ecerts as $ecert) {?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="row g-2 align-items-center">
                    <div class=" col-md-9">
                        <div class="row align-items-center">
                            <div class="col-auto">
                                <div class="avatar avatar-lg" style="background-image: url(<?php echo $ecert->pendaftaran->kegiatan->sertifikasi->get_link_logo(); ?>)"></div>
                            </div>
                            <div class="col">
                                <h4 class="card-title m-0">
                                    <?php echo $ecert->pendaftaran->kegiatan->nama_kegiatan; ?>
                                </h4>
                                <div class="mt-1">
                                    <span class="badge bg-cyan "><?php echo $ecert->pendaftaran->kegiatan->sertifikasi->nama; ?></span>
                                </div>
                                <div class="text-muted mt-1">
                                    <?php echo $ecert->pendaftaran->program->nama_program; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class=" col-md-3">
                        <a href="<?php echo base_url('sertifikasi/completed/'.$ecert->pendaftaran->id); ?>" role="button" class="d-block btn btn-info mb-2" style="white-space: normal;">
                            Info Sertifikasi
                        </a>
                        <a href="<?php echo base_url('e-certs/'.$ecert->id); ?>" target="_blank" role="button" class="d-block btn btn-success mb-2" style="white-space: normal;">
                            Unduh E-Certificate
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php } ?>
</div>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('components/container_main', ['data' => $data]); ?>

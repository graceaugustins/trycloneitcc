<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
    <?php $this->load->view('components/head'); ?>
    <title><?php if (function_exists('yield_page_title')) yield_page_title(); ?> - ITCC</title>
    <?php if (function_exists('yield_top_after_title')) yield_top_after_title(); ?>
</head>
<body class="antialiased border-top-wide border-primary d-flex flex-column">
<div class="flex-fill d-flex flex-column justify-content-center py-4">
    <?php if (function_exists('yield_page_content')) yield_page_content($this, $data); ?>
</div>
<?php $this->load->view('components/bottomscript'); ?>
</body>
</html>

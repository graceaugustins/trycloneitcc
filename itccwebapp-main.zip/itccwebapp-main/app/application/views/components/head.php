<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
<meta http-equiv="X-UA-Compatible" content="ie=edge"/>

<!-- CSS files -->
<link href="<?php echo base_url('assets/libs/selectize/dist/css/selectize.css'); ?>" rel="stylesheet"/>
<link href="<?php echo base_url('assets/css/tabler.min.css'); ?>" rel="stylesheet"/>
<link href="<?php echo base_url('assets/css/tabler-flags.min.css'); ?>" rel="stylesheet"/>
<link href="<?php echo base_url('assets/css/tabler-payments.min.css'); ?>" rel="stylesheet"/>

<link href="<?php echo base_url('assets/css/tabler-vendors.min.css'); ?>" rel="stylesheet"/>
<link href="<?php echo base_url('assets/css/demo.min.css'); ?>" rel="stylesheet"/>

<link rel="icon" href="https://itcc.itpln.ac.id/home/wp-content/uploads/2021/12/200pxl-01-150x150.png" sizes="32x32" />

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!-- Libs JS -->

<script src="<?php echo base_url('assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js'); ?>"></script>

<script src="<?php echo base_url('assets/libs/jquery/dist/jquery.slim.min.js'); ?>"></script>
<script src="<?php echo base_url("../admin/assets/libs/jquery/dist/jquery.min.js"); ?>"></script>
<script src="<?php echo base_url('assets/libs/selectize/dist/js/standalone/selectize.min.js'); ?>"></script>
<!-- Tabler Core -->
<script src="<?php echo base_url('assets/js/tabler.min.js'); ?>"></script>

<!-- DayJS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.10.4/dayjs.min.js" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.10.4/locale/id.min.js" crossorigin="anonymous"></script>

<script>
	const BASE_URL = "<?php echo base_url(); ?>";

	// daftar jurusan
	const jurusan = [
		{
			kode : "31",
			nama : "S1 Informatika"
		},
		{
			kode : "11",
			nama : "S1 Elektro"
		},
		{
			kode : "21",
			nama : "S1 Sipil"
		},
		{
			kode : "12",
			nama : "S1 Mesin"
		},
		{
			kode : "71",
			nama : "D3 Elektro"
		},
		{
			kode : "72",
			nama : "D3 Mesin"
		}

	];

	dayjs.locale('id');

	function get_param_ajax()
	{
		let param = {};
		param['<?php echo $this->security->get_csrf_token_name(); ?>'] = '<?php echo $this->security->get_csrf_hash(); ?>';
		return param;
	}

	// dismiss alert user
	function dismiss_info(that)
	{
		let id = $(that).parent().data('id');
		let param = get_param_ajax();
		$.post(
				BASE_URL+'ajax/info/'+id+'/dismiss',
				param
		).done(function(data){});
	}
</script>

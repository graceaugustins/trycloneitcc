<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php
$is_user_itpln = $_SESSION['user']['tipe_user'] === General_Constants::ITPLN;
?>

<div class="navbar-expand-md">
    <div class="collapse navbar-collapse" id="navbar-menu">
        <div class="navbar navbar-light">
            <div class="container-xl">
                <ul class="navbar-nav">
                    <li class="nav-item <?php if ($this->uri->uri_string() === 'dashboard') echo "active"; ?>">
                        <a class="nav-link" href="<?php echo base_url('dashboard'); ?>" >
                            <span class="nav-link-icon d-md-none d-lg-inline-block"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><polyline points="5 12 3 12 12 3 21 12 19 12" /><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7" /><path d="M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v6" /></svg>
                            </span>
                            <span class="nav-link-title">
                                Beranda
                            </span>
                        </a>
                    </li>
                    <li class="nav-item dropdown <?php
						$list_uri = ['sertifikasi/ongoing', 'sertifikasi/completed', 'sertifikasi/cancelled'];
						if (!$is_user_itpln) $list_uri[] = 'sertifikasi/wait-approval';
                        if (in_array($this->uri->uri_string(),$list_uri ) )
                            echo "active"; ?>">
                        <a class="nav-link dropdown-toggle" href="#navbar-extra" data-bs-toggle="dropdown" role="button" aria-expanded="false" >
                            <span class="nav-link-icon d-md-none d-lg-inline-block"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M14 3v4a1 1 0 0 0 1 1h4" /><path d="M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z" /><line x1="9" y1="17" x2="9" y2="12" /><line x1="12" y1="17" x2="12" y2="16" /><line x1="15" y1="17" x2="15" y2="14" /></svg>
                            </span>
                            <span class="nav-link-title">
                                Sertifikasi Saya
                            </span>
                        </a>
                        <div class="dropdown-menu">
							<?php if (!$is_user_itpln) { ?>
                            <a class="dropdown-item" href="<?php echo base_url('sertifikasi/wait-approval'); ?>" >
                                Menunggu Approve
                            </a>
							<?php } ?>
                            <a class="dropdown-item" href="<?php echo base_url('sertifikasi/ongoing'); ?>" >
                                Sedang Berjalan
                            </a>
                            <a class="dropdown-item" href="<?php echo base_url('sertifikasi/completed'); ?>" >
                                Sudah Diikuti
                            </a>
                            <a class="dropdown-item" href="<?php echo base_url('sertifikasi/cancelled'); ?>" >
                                Dibatalkan
                            </a>
                        </div>
                    </li>
                    <li class="nav-item <?php if ($this->uri->uri_string() === 'e-certs') echo "active"; ?>">
                        <a class="nav-link" href="<?php echo base_url('e-certs'); ?>" >
                            <span class="nav-link-icon d-md-none d-lg-inline-block"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><circle cx="15" cy="15" r="3" /><path d="M13 17.5v4.5l2 -1.5l2 1.5v-4.5" /><path d="M10 19h-5a2 2 0 0 1 -2 -2v-10c0 -1.1 .9 -2 2 -2h14a2 2 0 0 1 2 2v10a2 2 0 0 1 -1 1.73" /><line x1="6" y1="9" x2="18" y2="9" /><line x1="6" y1="12" x2="9" y2="12" /><line x1="6" y1="15" x2="8" y2="15" /></svg>
                            </span>
                            <span class="nav-link-title">
                                E-Certificate
                            </span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php $this->load->view('components/head'); ?>
    <title><?php if (function_exists('yield_page_title')) yield_page_title($this, $data); ?> - ITCC</title>
    <?php if (function_exists('yield_top')) yield_top(); ?>
</head>
<body class="antialiased">
<div class="page">
    <?php $this->load->view('components/navbar'); ?>
    <?php $this->load->view('components/menu'); ?>
    <div class="content">
        <div class="container-xl">
			<?php foreach(get_warning() as $w) {?>
				<div class="alert alert-warning alert-dismissible bg-white" role="alert">
					<div class="d-flex">
						<div>
							<h4 class="alert-title"><?php echo $w; ?></h4>
						</div>
					</div>
					<a class="btn-close" data-bs-dismiss="alert" aria-label="close"></a>
				</div>
			<?php } clear_warning(); ?>
			<?php
			foreach($this->user_model->get_list_info($_SESSION['user']['id']) as $i) {?>
				<div class="alert alert-important alert-success alert-dismissible" role="alert"
					 data-id="<?php echo $i['id']; ?>">
					<div class="d-flex">
						<div>
							<h4 class="alert-title"><?php echo $i['info']; ?></h4>
						</div>
					</div>
					<a class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="close"
					   onclick="dismiss_info(this)"
					></a>
				</div>
			<?php } ?>
            <!-- Page title -->
            <div class="page-header d-print-none">
                <div class="row align-items-center">
                    <?php if (function_exists('yield_page_header')) yield_page_header($this, $data); ?>
                </div>
            </div>
            <?php if (function_exists('yield_page_content')) yield_page_content($this, $data); ?>
        </div>
        <?php $this->load->view('components/footer'); ?>
    </div>
</div>
<?php if (function_exists('yield_bottom_before_script')) yield_bottom_before_script($this, $data); ?>
<?php $this->load->view('components/bottomscript'); ?>
<?php if (function_exists('yield_bottom_after_script')) yield_bottom_after_script($this, $data); ?>
</body>
</html>

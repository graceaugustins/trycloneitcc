<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><footer class="footer footer-transparent d-print-none">
    <div class="container">
        <div class="row text-center align-items-center flex-row-reverse">
            <div class="col-lg-auto ms-lg-auto">
                <ul class="list-inline list-inline-dots mb-0">
                    <li class="list-inline-item"><a href="<?php echo base_url(); ?>" class="link-secondary">Halaman Utama SITASI</a></li>
                </ul>
            </div>
            <div class="col-12 col-lg-auto mt-3 mt-lg-0">
                <ul class="list-inline list-inline-dots mb-0">
                    <li class="list-inline-item">
                        Copyright &copy; <script type="text/javascript">document.write(new Date().getFullYear())</script>
                        <a href="https://itcc.itpln.ac.id" class="link-secondary">ITCC</a>.
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>

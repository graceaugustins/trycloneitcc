<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php function yield_page_title($_this, $data){?> Beranda <?php } ?>
<?php function yield_page_header($_this, $data){?>
    <div class="col">
        <h2 class="page-title my-auto">
            <?php yield_page_title($_this, $data); ?>
        </h2>
    </div>
<?php } ?>
<?php function yield_page_content($_this, $data){?>
	<?php
	/**
	 * @var D_Kegiatan[] $list_kegiatan
	 * @var array $list_boleh_ujian_saja
	 * @var D_Pendaftaran_Kegiatan[] $list_pendaftaran
	 * @var D_User $me
	 * @var CI_Controller $_this
	 * */
	$list_kegiatan = $data['list_kegiatan'];
	$list_boleh_ujian_saja = $data['list_boleh_ujian_saja'];
	$list_pendaftaran = $data['list_pendaftaran'];
	$me = $data['me'];
	$user_itpln = $me->tipe_user === General_Constants::ITPLN;
	?>
<h3>Sertifikasi yang dibuka</h3>
<?php if (!$user_itpln) { ?>
<div class="alert alert-success bg-white text-center" role="alert">
    <h4 class="alert-title">Anda dapat melihat akumulasi biaya yang harus anda bayar setelah anda mendaftar.</h4>
</div>
<?php } ?>
<div class="row row-cards">
    <?php if (empty($list_kegiatan)) {?>
        <div class="hr-text">Kosong</div>
    <?php } else foreach($list_kegiatan as $keg) {?>
    <div class="col-md-12 col-xl-6">
        <div class="card">
            <div class="card-body">
                <h3 class="card-title"><?php echo $keg->nama_kegiatan; ?></h3>
				<span class="d-none dibuka-untuk"><?php echo $keg->dibuka_untuk; ?></span>
                <span class="d-none id-kegiatan"><?php echo $keg->id; ?></span>
                <span class="d-none sertifikasi"><?php echo $keg->sertifikasi->nama; ?></span>
                <span class="d-none deskripsi-sertifikasi"><?php echo $keg->sertifikasi->deskripsi; ?></span>
                <span class="d-none logo-sertifikasi"><?php echo $keg->sertifikasi->get_link_logo(); ?></span>
                <span class="d-none deskripsi-kegiatan"><?php echo $keg->deskripsi; ?></span>
                <span class="d-none biaya-t-u"><?php
					echo format_rupiah($keg->biaya_t_u);
					if ($keg->biaya_t_u === 0) echo " (Gratis)";
					?></span>
                <span class="d-none biaya-u"><?php
					echo format_rupiah($keg->biaya_u);
					if ($keg->biaya_u === 0) echo " (Gratis)";
					?></span>
				<span class="d-none boleh-ujian-saja"><?php echo (in_array((int)$keg->id, $list_boleh_ujian_saja)) ? 'true': 'false'; ?></span><span></span>
                <ul class="d-none program">
                    <?php foreach($keg->program_kegiatan as $p) { ?>
                    <li>
                        <span class="d-none id-program-kegiatan"><?php echo $p->id_program_kegiatan; ?></span>
                        <span class="d-none logo-program"><?php echo $p->get_link_logo(); ?></span>
                        <span class="nama-program"><?php echo $p->nama_program; ?></span>
                    </li>
                    <?php } ?>
                </ul>
                <strong>Program yang dibuka:</strong>
                <div class="d-flex">
                    <?php foreach($keg->program_kegiatan as $p) { ?>
                        <div class="p-1">
                            <img width="50" src="<?php echo $p->get_link_logo(); ?>" alt="">
                        </div>
                    <?php } ?>
                </div>
                <table class="mb-2">
					<?php if (!empty($keg->awal_registrasi) && !empty($keg->akhir_registrasi)) { ?>
                    <tr>
                        <td class="align-top">Registrasi</td>
                        <td class="align-top">:</td>
                        <td class="align-top tgl-registrasi">
                            <?php echo tgl_indo($keg->awal_registrasi->format('Y-m-d'), 'Y-m-d'); ?>
                            s/d
                            <?php echo tgl_indo($keg->akhir_registrasi->format('Y-m-d'), 'Y-m-d'); ?>
                        </td>
                    </tr>
					<?php } ?>
                    <tr>
                        <td class="align-top">Training</td>
                        <td class="align-top">:</td>
                        <td class="align-top tgl-training"><?php echo $keg->keterangan_training; ?></td>
                    </tr>
                    <tr>
                        <td class="align-top">Ujian</td>
                        <td class="align-top">:</td>
                        <td class="align-top tgl-ujian"><?php echo $keg->keterangan_ujian; ?></td>
                    </tr>
                </table>
				<?php if ($keg->dibuka_untuk !== General_Constants::ITPLN) { ?>
                <div class="alert alert-info" role="alert">
                    <div class="d-flex">
                        <div>
                            <svg class="alert-icon icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><line x1="9" y1="15" x2="15" y2="9" /><circle cx="9.5" cy="9.5" r=".5" fill="currentColor" /><circle cx="14.5" cy="14.5" r=".5" fill="currentColor" /><path d="M5 7.2a2.2 2.2 0 0 1 2.2 -2.2h1a2.2 2.2 0 0 0 1.55 -.64l.7 -.7a2.2 2.2 0 0 1 3.12 0l.7 .7a2.2 2.2 0 0 0 1.55 .64h1a2.2 2.2 0 0 1 2.2 2.2v1a2.2 2.2 0 0 0 .64 1.55l.7 .7a2.2 2.2 0 0 1 0 3.12l-.7 .7a2.2 2.2 0 0 0 -.64 1.55v1a2.2 2.2 0 0 1 -2.2 2.2h-1a2.2 2.2 0 0 0 -1.55 .64l-.7 .7a2.2 2.2 0 0 1 -3.12 0l-.7 -.7a2.2 2.2 0 0 0 -1.55 -.64h-1a2.2 2.2 0 0 1 -2.2 -2.2v-1a2.2 2.2 0 0 0 -.64 -1.55l-.7 -.7a2.2 2.2 0 0 1 0 -3.12l.7 -.7a2.2 2.2 0 0 0 .64 -1.55v-1" /></svg>
                        </div>
                        <div>
                            <h4 class="alert-title alert-link">Biaya Pendaftaran (Training & Ujian) :
                                <?php
								echo format_rupiah($keg->biaya_t_u);
								if ($keg->biaya_t_u === 0) echo " (Gratis)";
                                ?>
                            </h4>
                        </div>
                    </div>
                </div>
				<?php } ?>
            </div>
            <!-- Card footer -->
            <div class="card-footer">
                <div class="d-flex">
                    <p class="my-auto"><?php echo $keg->get_total_pendaftar_all(); ?> pendaftar</p>
                    <?php if ($keg->dibuka_untuk !== General_Constants::ITPLN) {?>
                        <?php
                            $id_kegiatan = (int)$keg->id;
                            $pendaftaran_filtered = array_filter($list_pendaftaran, function($p) use ($id_kegiatan){
                                return $id_kegiatan === (int)$p->id_kegiatan;
                            });
                        ?>
                        <?php if (empty($pendaftaran_filtered)) {?>
                            <a role="button" class="btn btn-primary ms-auto" data-bs-toggle="modal" data-bs-target="#detailsertif">Detail</a>
                        <?php } else { ?>
                            <?php $pendaftaran = reset($pendaftaran_filtered); if ($pendaftaran->approved) {?>
                                <a href="<?php echo base_url('sertifikasi/ongoing'); ?>" class="btn btn-success ms-auto">Sudah di-approve</a>
                            <?php } else { ?>
                                <a href="<?php echo base_url('sertifikasi/wait-approval'); ?>" class="btn btn-success ms-auto">Anda sudah mendaftar</a>
                            <?php } ?>
                        <?php } ?>
                    <?php } else { ?>
					<a href="<?php echo base_url('sertifikasi/ongoing'); ?>" class="btn btn-success ms-auto">Sudah di-approve</a>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
    <?php } ?>
</div>
<?php } ?>

<?php function yield_bottom_before_script($_this, $data){?>
	<?php
	/**
	 * @var D_User $me
	 * */
	$me = $data['me'];
	?>
<!-- detail sertifikasi -->
<div class="modal modal-blur fade" id="detailsertif" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Detail</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form action="<?php echo base_url('registrasi'); ?>" method="POST">
                <input type="hidden" name="<?php echo $_this->security->get_csrf_token_name(); ?>" value="<?php echo $_this->security->get_csrf_hash(); ?>">
                <input type="hidden" name="id" value="">
                <div class="modal-body">
                    <div class="d-flex">
                        <div class="my-auto">
                            <h2 id="detail-nama-kegiatan"></h2>
                        </div>
                        <div class="ms-auto" style="margin-right: 10px;min-width: 50px;">
                            <img id="detail-logo-sertif"  width="50" height="50">
                        </div>
                    </div>
                    <div class="hr-text">Rincian Kegiatan</div>
                    <div class="row mt-2">
                        <div class="col-md-6">
                            <p><b>Sertifikasi</b></p>
                            <span class="badge bg-cyan" id="detail-nama-sertif"></span>

                            <p class="mt-2" align="justify" id="detail-deskripsi-sertif"></p>
                        </div>

                        <div class="col-md-6">
                            <p><b>Deskripsi Kegiatan</b></p>
                            <p class="mt-2" align="justify" id="detail-deskripsi-kegiatan"></p>
                        </div>
                    </div>

                    <h2 class="text-center">Program yang dibuka</h2>
                    <div class="row g-2 align-items-center my-2 text-center justify-content-center" id="detail-program">
                        <div class="col-md-4 my-2">
                            <img class="d-block mx-auto" width="100">
                            <p>77-248: Microsoft Office Word 2016</p>
                        </div>
                    </div>
                    <div class="row mt-2">

                        <div class="col-md-6">
                            <p><b>Pelaksanaan</b></p>
                            <ul>
								<?php if ($me->tipe_user !== General_Constants::ITPLN) { ?>
                                <li id="detail-tgl-regis">Registrasi : 99 Des 2099 s/d 99 Des 2099</li>
								<?php } ?>
                                <li id="detail-tgl-training">Training : 99 Des 2099 s/d 99 Des 2099</li>
                                <li id="detail-tgl-ujian">Ujian : 99 Des 2099 s/d 99 Des 2099</li>
                            </ul>
                        </div>

						<?php if ($me->tipe_user !== General_Constants::ITPLN) { ?>
                        <div class="col-md-6">
                            <p><b>Biaya Pendaftaran</b></p>
                            <div class="row mb-3">
                                <div class="col-md-6 mb-1">
                                    Training dan Ujian
                                </div>
                                <div class="col-md-6">
                                    <strong class="text-info" id="detail-biaya-t-u"><u></u></strong>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-6 mb-1">
                                    Ujian saja
                                </div>
                                <div class="col-md-6">
                                    <strong class="text-info" id="detail-biaya-u"><u></u></strong>
                                </div>
                            </div>
                        </div>
						<?php } ?>
                    </div>

                    <hr>
					<?php ?>
                    <h3 class="text-center">Berminat untuk mendaftar?</h3>
					<?php if ($me->tipe_user !== General_Constants::ITPLN) { ?>
                    <div class="mb-4">
                        <div class="form-label text-center">
                            Silahkan pilih paket sertifikasi
						</div>
                        <select class="form-select" name="jenis" required="required">
                            <option value=""> Pilih</option>
                            <option value="t_u">Training & Ujian</option>
                            <option value="u">Ujian Saja </option>
                        </select>
                    </div>
					<?php } ?>
                    <div class="mb-3">
                        <div class="form-label text-center">
                            Silahkan pilih program sertifikasi yang dinginkan, lalu klik Daftar
						</div>
                        <select class="form-select" name="program" required="required">
                        </select>
                    </div>


                </div>

                <div class="modal-footer">
                    <a href="#" class="btn btn-link link-secondary" data-bs-dismiss="modal">
                        Kembali
                    </a>
                    <!-- add .btn-loading -->
                    <button type="submit" class="btn btn-primary ms-auto" >
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><polyline points="9 11 12 14 20 6" /><path d="M20 12v6a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2h9" /></svg>
                        Daftar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php } ?>

<?php function yield_bottom_after_script($_this, $data) { ?>
<script>
    $('#detailsertif').on('show.bs.modal', function (event) {
        let button = $(event.relatedTarget); // Button that triggered the modal
        let modal = $(this);
        let p = button.parent().parent().parent();
        modal.find('input[name=id]').val(p.find('.id-kegiatan').text());
        modal.find('.modal-body #detail-nama-kegiatan').text(p.find('.card-title').text());
        modal.find('.modal-body #detail-nama-sertif').text(p.find('.sertifikasi').text());
        modal.find('.modal-body #detail-deskripsi-sertif').text(p.find('.deskripsi-sertifikasi').text());
        modal.find('.modal-body #detail-logo-sertif').attr('src', p.find('.logo-sertifikasi').text());
        modal.find('.modal-body #detail-deskripsi-kegiatan').text(p.find('.deskripsi-kegiatan').text());
        let program = modal.find('.modal-body #detail-program');
        program.html('');
        p.find('.program li').each(function(){
            let element = $("<div class='col-md-4 my-2'></div>")
                            .append('<img class="d-block mx-auto" src="'+$(this).find('.logo-program').text()+'" width="100">')
                            .append("<p>"+$(this).find('.nama-program').text()+"</p>");
            program.append(element);
        });
        modal.find('.modal-body #detail-tgl-regis').text("Registrasi : " + p.find('table .tgl-registrasi').text());
        modal.find('.modal-body #detail-tgl-training').text(p.find('table .tgl-training').text());
        modal.find('.modal-body #detail-tgl-ujian').text(p.find('table .tgl-ujian').text());
        modal.find('.modal-body #detail-biaya-t-u u').text(p.find('.biaya-t-u').text());
        modal.find('.modal-body select[name=jenis] option[value=t_u]').text("Training & Ujian ("+ p.find('.biaya-t-u').text() + ")");
        if (p.find('.boleh-ujian-saja').text().trim().toLowerCase() === 'true')
		{
			modal.find('.modal-body #detail-biaya-u u').text(p.find('.biaya-u').text());
			modal.find('.modal-body select[name=jenis] option[value=u]').removeClass('d-none').text("Ujian Saja ("+ p.find('.biaya-u').text() + ")");
		}
        else
		{
			modal.find('.modal-body #detail-biaya-u').parent().parent().addClass('d-none');
			modal.find('.modal-body select[name=jenis] option[value=u]').addClass('d-none');
		}
        let dropdown_program = modal.find('.modal-body select[name=program]');
        dropdown_program.html('');
        p.find('.program li').each(function(){
            let element = $('<option></option>')
                .attr('value', $(this).find('.id-program-kegiatan').text())
                .text($(this).find('.nama-program').text());
            dropdown_program.append(element);
        });
        dropdown_program.val(dropdown_program.find('option:eq(0)').attr('value'));
    });
</script>
<?php } ?>

<?php
$data = isset($data) ? $data : [];
$this->load->view('components/container_main', [ 'data' => $data]); ?>

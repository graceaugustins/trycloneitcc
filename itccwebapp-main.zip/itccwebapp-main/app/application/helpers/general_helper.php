<?php
defined('BASEPATH') OR exit('No direct script access allowed');

function load_data_class($file)
{
	require_once(APPPATH.'models'.DIRECTORY_SEPARATOR.'data'.DIRECTORY_SEPARATOR.'D_'.$file.'.php');
}

/*
 * warning alert
 * */
function set_warning($warning)
{
    $_SESSION['warning'][] = (string)$warning;
}

function get_warning()
{
    if (!isset($_SESSION['warning'])) $_SESSION['warning'] = [];
    return $_SESSION['warning'];
}

function clear_warning()
{
    $_SESSION['warning'] = [];
}

/*
 * Validasi Date dan DateTime berdasarkan
 * format
 * */
function valid_date_time($date, $format)
{
    if (!is_string($date)) return FALSE;
    $d = DateTime::createFromFormat($format, $date);
    return !empty($d);
}

function valid_json_str($json)
{
    if (!is_string($json)) return FALSE;
    // decode the JSON data
    $result = json_decode($json);
    if (json_last_error() === JSON_ERROR_NONE)
        return TRUE;
    return FALSE;
}

function tgl_indo($tanggal, $format, $singkat = FALSE)
{
    $dt = DateTime::createFromFormat($format, $tanggal);
    $new_dt = $dt->format('Y-m-d');
    $bulan = array (
        1 =>   'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember'
    );

    $pecahkan = explode('-', $new_dt);
    // variabel pecahkan 0 = tanggal
    // variabel pecahkan 1 = bulan
    // variabel pecahkan 2 = tahun
    if ($singkat)
        return $pecahkan[2] . ' ' . substr($bulan[ (int)$pecahkan[1] ], 0,3) . ' ' . $pecahkan[0];
    return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
}

function format_rupiah($angka){
    if (!is_numeric($angka)) $angka = 0;
    $hasil_rupiah = "Rp " . number_format($angka,2,',','.');
    return $hasil_rupiah;
}

function verify_recaptcha_v2($secret, $captcha)
{
    if (empty($captcha)) return FALSE;
    $url = 'https://www.google.com/recaptcha/api/siteverify?secret='.urlencode($secret).'&response='.urlencode($captcha);
    $response = file_get_contents($url);
    $response = json_decode($response,true);
    if($response["success"])
        return TRUE;
    return FALSE;
}

class General_Constants {
	// dibuka untuk
	const MAHASISWA = 'mahasiswa';
	const UMUM = 'umum';
	const ITPLN = 'itpln';

	// jenis kelamin
	const LAKI_LAKI = 'l';
	const PEREMPUAN = 'p';

	// jenis pendaftaran
	const TRAINING_DAN_UJIAN = 't_u';
	const UJIAN_SAJA = 'u';

	// status kelulusan
	const STATUS_PENDING = "pending";
	const STATUS_LULUS = "lulus";
	const STATUS_TIDAK_LULUS = "tidak_lulus";

	// status pembayaran
	const PEMBAYARAN_PENDING = 'pending';
	const PEMBAYARAN_REJECTED = 'reject';
	const PEMBAYARAN_ACCEPTED = 'accept';
}


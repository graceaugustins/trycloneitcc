<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Autentikasi_mhs extends CI_Controller{
    public function show_login()
    {
        $data = [];
        $data['next'] = base_url('dashboard');

        // cek variabel get next (dari halaman lain)
        if (!empty($this->input->get('next')))
        {
            $get = explode('?', $this->input->get('next'));
            $data['next'] = base_url($get[0]);
        }
        $this->load->view('mahasiswa/login', ['data' => $data]);
    }

    public function proses_login()
    {
        // Kalau akun valid dan
        // mengunjungi url ini lagi, redirect
        $next = isset($_SESSION['next']) ? $_SESSION['next'] : base_url('dashboard');
        unset($_SESSION['next']);
        if (isset($_SESSION['user']) && $_SESSION['user']['tipe_user'] === "mahasiswa")
        {
            redirect($next);
        }

        $this->load->library('user_token');
        $email = trim(strtolower($this->user_token->getEmail()));

        // Email ada : auth berhasil tapi tidak valid
        // Email tidak ada : belum auth dan tidak valid
        if (empty($email)) redirect(base_url("mhs/login"));
		if (!$this->is_email_mahasiswa($email))
		{
			set_warning("E-mail anda terdeteksi bukan alamat email mahasiswa.");
			redirect(base_url("login"));
		}

        // Cek valid email
        // Apakah email ini mahasiswa
        $this->load->model('proses_login_model');

        // kalau email tidak ada di db,
        // tampilkan halaman regis
        if (!$this->proses_login_model->mhs_exists($email))
        {
            // token untuk memastikan alur, dan tidak perlu cek lagi
            $_SESSION['previous_flow'] = 'proses_login_mhs';
            redirect(base_url("mhs/isi_data"));
        }
        // ambil detail mhs
        $_SESSION['user'] = $this->proses_login_model->get_detail_mhs($email);
        redirect($next);
    }

    public function logout()
    {
        $_SESSION = [];
        session_destroy();
        redirect(base_url('msauth/signout'));
    }

	private function is_email_mahasiswa($email): bool
	{
		$side_email = explode('@', $email);
		$username = $side_email[0];
		if (strlen($username) >=5 && ctype_digit(substr($username, -5, 5))) return TRUE;
		return FALSE;
	}
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax extends CI_Controller {

    // $this->reply('ok', 'SUCCESS', ['data'=>123])
    // $this->reply('fail', 'ERR_NOT_PERMITTED', ['data'=>123]
    private function reply($status, $message, $data = [])
    {
    	$this->output->set_content_type('application/json')
	        ->set_output(json_encode(html_escape([
    			'status' => strtolower((string)$status),
    			'message' => strtoupper((string)$message),
    			'data' => $data
    		])));
    }

    public function get_instansi()
    {
        // tidak ada cek tipe login, karena bisa diakses semuanya
        $this->load->model('user_model');
        $this->reply('ok', 'SUCCESS', $this->user_model->get_instansi());
    }

	public function dismiss_info($id_info)
	{
		$this->load->model('user_model');
		$info = $this->user_model->get_single_info($id_info);
		$status = FALSE;
		if (
			!empty($info) &&
			(int)$info['id_user'] === (int)$_SESSION['user']['id']
		)
		{
			$status = $this->user_model->update_info($id_info, ['display' => false]);
		}
		$this->reply('ok', 'SUCCESS', ($status) ? 'true' : 'false');
    }
}

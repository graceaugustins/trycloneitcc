<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @property M_kegiatan $m_kegiatan
 * @property CI_Input $input
 */
class Welcome extends CI_Controller {
	public function index()
	{
		$this->load->model('m_kegiatan');
		$list_kegiatan = $this->m_kegiatan->get_kegiatan_in_registrasi();
		foreach ($list_kegiatan as $kegiatan)
		{
			$kegiatan->load_sertifikasi();
			$kegiatan->load_list_program();
			$kegiatan->load_kelompok_training();
		}
		$this->load->view('home', ['list_kegiatan' => $list_kegiatan]);
	}
}

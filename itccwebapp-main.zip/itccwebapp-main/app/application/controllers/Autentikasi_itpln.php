<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Autentikasi_itpln extends CI_Controller{
    public function show_login()
    {
        $data = [];
        $data['next'] = base_url('dashboard');

        // cek variabel get next (dari halaman lain)
        if (!empty($this->input->get('next')))
        {
            $get = explode('?', $this->input->get('next'));
            $data['next'] = base_url($get[0]);
        }
        $this->load->view('itpln/login', ['data' => $data]);
    }

    public function proses_login()
    {
        // Kalau akun valid dan
        // mengunjungi url ini lagi, redirect
        $next = isset($_SESSION['next']) ? $_SESSION['next'] : base_url('dashboard');
        unset($_SESSION['next']);
        if (isset($_SESSION['user']) && $_SESSION['user']['tipe_user'] === "itpln")
        {
            redirect($next);
        }

        $this->load->library('user_token');
        $email = trim(strtolower($this->user_token->getEmail()));

        // Email ada : auth berhasil tapi tidak valid
        // Email tidak ada : belum auth dan tidak valid
		// cek juga email ini email mahasiswa / bukan
		// kalau bukan email mahasiswa berarti valid
        if (empty($email)) redirect(base_url("itpln/login"));
		if ($this->is_email_mahasiswa($email))
		{
			set_warning("E-mail anda terdeteksi sebagai alamat email mahasiswa, bukan alamat email internal IT-PLN.");
			redirect(base_url("login"));
		}

        // Cek valid email
        // Apakah email ini itpln
        $this->load->model('proses_login_model');

        // kalau email tidak ada di db,
        // tampilkan halaman regis
        if (!$this->proses_login_model->itpln_exists($email))
        {
            // token untuk memastikan alur, dan tidak perlu cek lagi
            $_SESSION['previous_flow'] = 'proses_login_itpln';
            redirect(base_url("itpln/isi_data"));
        }
        // ambil detail user
        $_SESSION['user'] = $this->proses_login_model->get_detail_itpln($email);
        redirect($next);
    }

    public function logout()
    {
        $_SESSION = [];
        session_destroy();
        redirect(base_url('msauth/signout'));
    }

	private function is_email_mahasiswa($email): bool
	{
		$side_email = explode('@', $email);
		$username = $side_email[0];
		if (strlen($username) >=5 && ctype_digit(substr($username, -5, 5))) return TRUE;
		return FALSE;
    }
}

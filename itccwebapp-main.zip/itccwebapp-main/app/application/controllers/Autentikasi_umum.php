<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Autentikasi_umum extends CI_Controller{
    public function show_login()
    {
        $next = 'dashboard';
        // cek variabel get next (dari halaman lain)
        if (!empty($this->input->get('next')))
        {
            $get = explode('?', $this->input->get('next'));
            $next = $get[0];
        }
        if (isset($_SESSION['user']) && $_SESSION['user']['tipe_user'] === 'umum')
            redirect(base_url($next));
        $_SESSION['next'] = $next;
        $this->load->view('umum/login');
    }

    public function verify_login()
    {
        if (!isset($_SESSION['next'])) redirect(base_url('mhs/login'));
        $next = $_SESSION['next'];
        $email = $this->input->post('email');
        $user_pass = $this->input->post('user_pass');
        if (empty($email) || empty($user_pass))
        {
            set_warning("Alamat email dan kata sandi wajib diberikan.");
            redirect(base_url("umum/login?next=$next"));
        }
        $email = strtolower(trim($email));
        $this->load->model('user_model');
        $user = $this->user_model->get_user_umum([
            'email' => $email
        ]);
        if (empty($user))
        {
            set_warning("Alamat email tidak dapat ditemukan.");
            redirect(base_url("umum/login?next=$next"));
        }
        $user = reset($user);
        if (!password_verify($user_pass, $user['user_pass']))
        {
            // limit bruteforce dengan delay 1 detik
            sleep(1);
            set_warning("Kata sandi yang diberikan tidak cocok.");
            redirect(base_url("umum/login?next=$next"));
        }
        unset($_SESSION['next']);
        $_SESSION['user'] = $user;
        redirect(base_url($next));
    }

    public function show_daftar()
    {
        $this->load->view('umum/daftar');
    }

    public function proses_email_daftar()
    {
        if (verify_recaptcha_v2(
                $this->config->item('RECAPTCHA_V2_SECRET_KEY'),
                $this->input->post('g-recaptcha-response')
            ) === FALSE)
        {
            set_warning("Captcha tidak valid.");
            redirect(base_url('umum/daftar'));
        }
        $email = strtolower(trim($this->input->post('email')));
        if (filter_var($email, FILTER_VALIDATE_EMAIL) === FALSE)
        {
            set_warning("Email tidak valid.");
            redirect(base_url('umum/daftar'));
        }
        // cek apakah sudah ada email pendaftaran yang terkirim 3 jam terakhir
        $jarak = time()-10800;
        $this->load->model('proses_login_model');
        if ($this->proses_login_model->count_daftar($email, $jarak) >= 2)
        {
            set_warning("Terlalu banyak request untuk email ini. Silahkan coba lagi nanti.");
            redirect(base_url('umum/daftar'));
        }

        // cek apakah sudah terdaftar atau belum
        $this->load->model('user_model');
        $mhs = $this->user_model->get_user_mhs([
            'email' => $email
        ]);
        $umum = $this->user_model->get_user_umum([
            'email' => $email
        ]);
        if (!empty($umum))
        {
            set_warning("Alamat email yang anda masukkan sudah terdaftar.");
            redirect(base_url('umum/daftar'));
        }
        if (!empty($mhs))
        {
            set_warning("Alamat email yang anda masukkan tidak valid, karena sudah terdaftar sebagai mahasiswa IT-PLN.");
            redirect(base_url('umum/daftar'));
        }
        // generate token
        $timestamp = (string)time();
        $action = 'confirm_email';
        $this->load->library('encryption');
        $token = $this->encryption->encrypt($action.$email.$timestamp);
        $link = base_url('umum/daftar/verify-email?act='.$action.'&e='.$email.'&t='.$timestamp.'&key='.urlencode($token));
        $data = [
            'link' => $link
        ];
        // kirim email
        $this->load->library('system_functions');
		try {
			$this->system_functions->send_email('email/umum_confirm_email',$email,'Pendaftaran Akun Baru', $data);
		} catch (Exception $e){
			set_warning("Terjadi kesalahan dalam mengirimkan email.");
			redirect(base_url('umum/daftar'));
		}

        // tandai sudah mengirim email
        $this->proses_login_model->add_action('signup', $email);
        // buat pertanda sudah melewati controller ini
        $_SESSION['ask_confirmation_email'] = TRUE;
        redirect(base_url('umum/daftar/email-sent'));
    }

    public function show_email_sent()
    {
        if (!isset($_SESSION['ask_confirmation_email']))
            redirect(base_url('umum/daftar'));
        unset($_SESSION['ask_confirmation_email']);
        $this->load->view('umum/daftar_email_sent');
    }

    public function verify_confirmation_link()
    {
        $action = $this->input->get('act');
        $email = $this->input->get('e');
        $timestamp = $this->input->get('t');
        $token = $this->input->get('key');

        if (!is_string($action) || !is_string($email) || !is_string($timestamp) || !is_string($token))
        {
            $this->load->view('umum/daftar_verify_failed');
            return;
        }
        $text = 'confirm_email'.$email.$timestamp;
        $this->load->library('encryption');
        $plaintext = $this->encryption->decrypt($token);
        if ($plaintext === FALSE || $text !== $plaintext)
        {
            $this->load->view('umum/daftar_verify_failed');
            return;
        }
        // cek timestamp
        $timestamp = (int)$timestamp;
        $now = time();
        if ($now - $timestamp > 3600)
        {
            $this->load->view('umum/daftar_verify_failed');
            return;
        }
        $this->load->model('user_model');
        if ($this->user_model->email_exists($email))
        {
            $this->load->view('warning', [
                'title' => 'Akun sudah dibuat',
                'description' => 'Proses pembuatan akun tidak dapat dilanjutkan karena email sudah terdaftar.'
            ]);
            return;
        }
        // tandai link konfirmasi valid
        $_SESSION['confirm_email'] = $email;
        redirect(base_url('umum/isi_data'));
    }

    public function show_forgot_password()
    {
        $this->load->view('umum/forgot_password');
    }

    public function send_email_recovery()
    {
        if (verify_recaptcha_v2(
                $this->config->item('RECAPTCHA_V2_SECRET_KEY'),
                $this->input->post('g-recaptcha-response')
            ) === FALSE)
        {
            set_warning("Captcha tidak valid.");
            redirect(base_url('umum/forgot-password'));
        }
        $email = strtolower(trim($this->input->post('email')));
        if (filter_var($email, FILTER_VALIDATE_EMAIL) === FALSE)
        {
            set_warning("Email tidak valid.");
            redirect(base_url('umum/forgot-password'));
        }
        // cek apakah sudah ada email recovery yang terkirim 6 jam terakhir
        $jarak = time()-21600;
        $this->load->model('proses_login_model');
        if ($this->proses_login_model->count_forgot($email, $jarak) >= 2)
        {
            set_warning("Terlalu banyak request untuk email ini. Silahkan coba lagi nanti.");
            redirect(base_url('umum/forgot-password'));
        }

        // cek apakah sudah terdaftar atau belum
        $this->load->model('user_model');
        $mhs = $this->user_model->get_user_mhs([
            'email' => $email
        ]);
        $umum = $this->user_model->get_user_umum([
            'email' => $email
        ]);
        if (empty($umum))
        {
            if (empty($mhs))
                set_warning("Alamat email yang anda masukkan tidak terdaftar.");
            else
                set_warning("Alamat email yang anda masukkan tidak valid, dikarenakan alamat email tersebut adalah alamat mahasiswa IT-PLN.");
            redirect(base_url('umum/forgot-password'));
        }

        // generate token
        $timestamp = (string)time();
        $action = 'recover_account';
        $this->load->library('encryption');
        $token = $this->encryption->encrypt($action.$email.$timestamp);
        $link = base_url('umum/recover-account?act='.$action.'&e='.$email.'&t='.$timestamp.'&key='.urlencode($token));
        $now = new DateTime();
        $data = [
            'link' => $link,
            'tanggal' => tgl_indo($now->format('Y-m-d'), 'Y-m-d'),
            'waktu' => $now->format('H:i')
        ];
        // kirim email
        $this->load->library('system_functions');
        $this->system_functions->send_email('email/umum_forgot_password',$email,'Pemulihan Akun', $data);
        // tandai sudah mengirim email
        $this->proses_login_model->add_action('recovery', $email);
        // buat pertanda sudah melewati controller ini
        $_SESSION['ask_recovery'] = TRUE;
        redirect(base_url('umum/forgot-password/email-sent'));
    }

    public function show_email_recovery_sent()
    {
        if (!isset($_SESSION['ask_recovery']))
            redirect(base_url('umum/forgot-password'));
        unset($_SESSION['ask_recovery']);
        $this->load->view('umum/forgot_email_sent');
    }

    public function verify_email_recovery()
    {
        $action = $this->input->get('act');
        $email = $this->input->get('e');
        $timestamp = $this->input->get('t');
        $token = $this->input->get('key');

        if (empty($action) || empty($email) || empty($timestamp) || empty($token))
        {
            $this->load->view('warning', [
                'title' => 'Link tidak valid',
                'description' => 'Link pemulihan akun anda tidak valid.'
            ]);
            return;
        }
        $text = 'recover_account'.$email.$timestamp;
        $this->load->library('encryption');
        $plaintext = $this->encryption->decrypt($token);
        if ($plaintext === FALSE || $text !== $plaintext)
        {
            $this->load->view('warning', [
                'title' => 'Link tidak valid',
                'description' => 'Link pemulihan akun anda tidak valid.'
            ]);
            return;
        }
        // cek timestamp
        $timestamp = (int)$timestamp;
        $now = time();
        if ($now - $timestamp > 900)
        {
            $this->load->view('warning', [
                'title' => 'Link tidak valid',
                'description' => 'Link pemulihan akun anda sudah kadaluarsa.'
            ]);
            return;
        }
        $this->load->model('user_model');
        $user = $this->user_model->get_user_umum([
            'email' => $email
        ]);
        if (empty($user))
        {
            $this->load->view('warning', [
                'title' => 'Akun tidak dapat ditemukan',
                'description' => 'Proses pemulihan akun tidak dapat dilanjutkan karena alamat email tidak terhubung ke akun user umum manapun.'
            ]);
            return;
        }
        $user = html_escape($user[0]);
        $_SESSION['show_change_password'] = [time(), $user];
        redirect((base_url('umum/form-recover-account')));
    }

    public function show_ubah_password()
    {
        if (!isset($_SESSION['show_change_password'])) redirect(base_url());
        $time = $_SESSION['show_change_password'][0];
        if (time() - $time > 120)
        {
            $this->load->view('warning', [
                'title' => 'Gagal memulihkan akun',
                'description' => 'Silahkan klik kembali link pemulihan akun yang dikirimkan ke email Anda.'
            ]);
            return;
        }
        $user = $_SESSION['show_change_password'][1];
        $this->load->view('umum/form_recover_account', ['data' => $user]);
    }

    public function ubah_password()
    {
        if (!isset($_SESSION['show_change_password'])) redirect(base_url('umum/login'));
        $password1 = $this->input->post('user_pass1');
        $password2 = $this->input->post('user_pass2');
        if (empty($password1) || empty($password2))
        {
            set_warning("Kata sandi tidak boleh kosong.");
            redirect(base_url('umum/form-recover-account'));
        }
        if (strlen($password1) < 8 || $password1 !== $password2)
        {
            set_warning("Kata sandi harus sama, dan terdiri dari minimal 8 karakter.");
            redirect(base_url('umum/form-recover-account'));
        }

        $time = $_SESSION['show_change_password'][0];
        if (time() - $time > 300)
        {
            unset($_SESSION['show_change_password']);
            $this->load->view('warning', [
                'title' => 'Gagal memulihkan akun',
                'description' => 'Sesi telah melewati 5 menit. Silahkan klik kembali link pemulihan akun yang dikirimkan ke email Anda.'
            ]);
            return;
        }
        $new_password = password_hash($password1, PASSWORD_DEFAULT);
        $this->load->model('user_model');
        if ($this->user_model->update_user($_SESSION['show_change_password'][1]['id'], [
            'user_pass' => $new_password
            ]) === FALSE)
        {
            set_warning("Terjadi kegagalan dalam memulihkan akun Anda.");
            redirect(base_url('umum/form-recover-account'));
        }
        unset($_SESSION['show_change_password']);
        $this->load->view('umum/success_recovery_account');
    }

    public function logout()
    {
        $_SESSION = [];
        session_destroy();
        redirect(base_url('umum/login'));
    }
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use Microsoft\Graph\Graph;
use Microsoft\Graph\Model;

class Auth extends CI_Controller {
    public function signin()
    {
        // cek parameter next untuk redirect
        // jika login berhasil
        if ( !is_string($this->input->get('next')) || $this->input->get('next') === "")
        {
            redirect(base_url());
            return;
        }
        // cek tipe login_type
        // kalau tidak ada, redirect
        if ( !is_string($this->input->get('login_type')))
        {
            redirect(base_url());
            return;
        }
        $loginType = strtolower(trim($_GET['login_type']));
        if ( !in_array($loginType, ['mhs', 'itpln']))
        {
            redirect(base_url());
            return;
        }
        $_SESSION['login_type'] = $loginType;
        $_SESSION['next'] = $this->input->get('next');
        // Initialize the OAuth client
        $oauthClient = new \League\OAuth2\Client\Provider\GenericProvider([
            'clientId'                => $this->config->item('USER_OAUTH_APP_ID'),
            'clientSecret'            => $this->config->item('USER_OAUTH_APP_PASSWORD'),
            'redirectUri'             => $this->config->item('USER_OAUTH_REDIRECT_URI'),
            'urlAuthorize'            => $this->config->item('OAUTH_AUTHORITY').$this->config->item('OAUTH_AUTHORIZE_ENDPOINT'),
            'urlAccessToken'          => $this->config->item('OAUTH_AUTHORITY').$this->config->item('OAUTH_TOKEN_ENDPOINT'),
            'urlResourceOwnerDetails' => '',
            'scopes'                  => $this->config->item('USER_OAUTH_SCOPES')
        ]);
        $authUrl = $oauthClient->getAuthorizationUrl();
        // Save client state so we can validate in callback
        $_SESSION['oauthState'] = $oauthClient->getState();
        redirect($authUrl);
    }

    public function callback()
    {
        $this->load->library('User_token');
        // Validate state
        $expectedState = !empty($_SESSION['oauthState'])? $_SESSION['oauthState'] : NULL;
        unset($_SESSION['oauthState']);
        $providedState = $this->input->get('state');
        if (empty($expectedState))
        {
            // If there is no expected state in the session,
            // do nothing and redirect to the home page.
            redirect(base_url());
        }
        if (!isset($providedState) || $expectedState != $providedState)
        {
            redirect(base_url());
        }
        // Authorization code should be in the "code" query param
        if (!empty($this->input->get('code')))
        {
            $authCode = $this->input->get('code');
            // Initialize the OAuth client
            $oauthClient = new \League\OAuth2\Client\Provider\GenericProvider([
                'clientId'                => $this->config->item('USER_OAUTH_APP_ID'),
                'clientSecret'            => $this->config->item('USER_OAUTH_APP_PASSWORD'),
                'redirectUri'             => $this->config->item('USER_OAUTH_REDIRECT_URI'),
                'urlAuthorize'            => $this->config->item('OAUTH_AUTHORITY').$this->config->item('OAUTH_AUTHORIZE_ENDPOINT'),
                'urlAccessToken'          => $this->config->item('OAUTH_AUTHORITY').$this->config->item('OAUTH_TOKEN_ENDPOINT'),
                'urlResourceOwnerDetails' => '',
                'scopes'                  => $this->config->item('USER_OAUTH_SCOPES')
            ]);

            try {
                // Make the token request
                $accessToken = $oauthClient->getAccessToken('authorization_code', [
                    'code' => $authCode
                ]);

                $graph = new Graph();
                $graph->setAccessToken($accessToken->getToken());

                $user = $graph->createRequest('GET', '/me?$select=displayName,mail,userPrincipalName')
                    ->setReturnType(Model\User::class)
                    ->execute();

                $this->user_token->storeTokens($accessToken, $user);
                // redirect ke halaman proses login sesuai dengan tipenya
                // tidak perlu sanitasi, karena sudah disanitasi di signin()
				if (!empty($_SESSION['login_type']))
				{
					$login_type = $_SESSION['login_type'];
					unset($_SESSION['login_type']);
					redirect(base_url($login_type.'/proses_login'));
				}
                else redirect(base_url('error?message=ERROR_UNKNOWN_LOGIN_TYPE'));
            }
            catch (League\OAuth2\Client\Provider\Exception\IdentityProviderException $e) {
                redirect(base_url('error?message=ERROR_GETPROFILE_GRAPH'));
            }
        }
        redirect(base_url('error?message=ERROR_NOT_AUTHORIZED'));
    }

    public function signout()
    {
        $next = '';
        if ($this->input->get('next') !== NULL) $next = $this->input->get('next');

        $this->load->library('User_token');
        $this->user_token->clearTokens();
        redirect('https://login.microsoftonline.com/common/oauth2/v2.0/logout?post_logout_redirect_uri='.base_url($next));
    }
}

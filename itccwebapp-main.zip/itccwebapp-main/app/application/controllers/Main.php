<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @property M_kegiatan $m_kegiatan
 * @property User_token $user_token
 * @property CI_Config $config
 * @property M_user $m_user
 * @property CI_Input $input
 */
class Main extends CI_Controller {
	private $me = NULL;

    public function __construct()
    {
        parent::__construct();
		$this->load->model('user_model');
        // perbarui data session
        if (!empty($_SESSION['user']))
        {
        	$this->load->model('m_user');
        	if ($this->m_user->is_id_user_exists($_SESSION['user']['id']) === FALSE)
			{
				unset($_SESSION['user']);
			}
        	else
			{
				load_data_class('User');
				$this->me = new D_User($_SESSION['user']['id']);
			}
        }
    }

	public function system_callback()
	{
		$this->load->library('system_functions');
		$this->system_functions->callback();
	}

    private function redirect_if_not_logged_in()
    {
        if (empty($_SESSION['user']))
        {
            clear_warning();
            redirect(base_url('login?next='.$this->uri->uri_string()));
        }
    }

    private function redirect_if_not_active()
    {
        $this->redirect_if_not_logged_in();
        if ($this->me->aktif === FALSE)
            redirect(base_url('user_not_active'));
    }

    public function show_not_active()
    {
        $this->redirect_if_not_logged_in();
        if ($this->me->aktif === FALSE)
            $this->load->view('not_active');
        else redirect(base_url('dashboard'));
    }

    public function show_login()
    {
        $next = 'dashboard';
        // cek variabel get next (dari halaman lain)
        if (!empty($this->input->get('next')))
        {
            $get = explode('?', $this->input->get('next'));
            $next = $get[0];
        }
        $data = [
            'next' => $next
        ];
        $this->load->view('login', ['data' => $data]);
    }

    public function show_isi_data($tipe)
    {
        if ($tipe === General_Constants::MAHASISWA)
        {
            if (!isset($_SESSION['previous_flow']) || $_SESSION['previous_flow'] !== "proses_login_mhs")
                redirect(base_url("mhs/login"));

            // cek ulang
            $this->load->library('user_token');
            if (!$this->user_token->isLoggedIn()) redirect(base_url("mhs/login"));
            $email = trim(strtolower($this->user_token->getEmail()));
            // Cek valid email
            // Apakah email ini mahasiswa
            $this->load->model('m_user');
            // kalau email tidak ada di db,
            // tampilkan halaman regis
            if (!$this->m_user->is_email_user_exists($email))
            {
                $data = [];
                $data['email'] = $email;
                $this->load->view('mahasiswa/isi_data', $data);
                return;
            }
            redirect(base_url("mhs/login"));
        }
        elseif($tipe === General_Constants::UMUM)
        {
            if (!isset($_SESSION['confirm_email'])) redirect(base_url('umum/daftar'));
            $email = $_SESSION['confirm_email'];
            $this->load->model('m_user');
            if (!$this->m_user->is_email_user_exists($email))
            {
                $data = [];
                $data['email'] = $email;
                $this->load->view('umum/isi_data', $data);
                return;
            }
            redirect(base_url("umum/login"));
        }
        elseif ($tipe === General_Constants::ITPLN)
		{
			if (!isset($_SESSION['previous_flow']) || $_SESSION['previous_flow'] !== "proses_login_itpln")
				redirect(base_url("itpln/login"));

			// cek ulang
			$this->load->library('user_token');
			if (!$this->user_token->isLoggedIn()) redirect(base_url("itpln/login"));
			$email = trim(strtolower($this->user_token->getEmail()));
			// Cek valid email
			// Apakah email ini mahasiswa
			$this->load->model('m_user');
			// kalau email tidak ada di db,
			// tampilkan halaman regis
			if (!$this->m_user->is_email_user_exists($email))
			{
				$data = [];
				$data['email'] = $email;
				$this->load->model('m_user');
				$list_bidang = $this->m_user->get_list_bidang();
				foreach($list_bidang as $b)
				{
					$b->load_list_jabatan();
				}
				$data['list_bidang'] = $list_bidang;
				$this->load->view('itpln/isi_data', $data);
				return;
			}
			redirect(base_url("itpln/login"));
		}
    }

    public function tambah_user($tipe)
    {
        if ($tipe === General_Constants::MAHASISWA)
        {
			if (!isset($_SESSION['previous_flow']) || $_SESSION['previous_flow'] !== "proses_login_mhs")
				redirect(base_url("mhs/login"));
            // cek ulang
            $this->load->library('user_token');
            if (!$this->user_token->isLoggedIn()) redirect(base_url("mhs/login"));
            $email = trim(strtolower($this->user_token->getEmail()));
            // Cek valid email
            // Apakah email ini mahasiswa
            $this->load->model('m_user');
            // kalau email ada,
            // arahkan ke login
            if ($this->m_user->is_email_user_exists($email)) redirect(base_url("mhs/login"));

			$redirect_uri = base_url("mhs/isi_data");
            if ($this->input->post('consent') === NULL)
            {
                set_warning("Anda wajib mengkonfirmasi bahwa data anda telah benar dan dapat dipertanggungjawabkan.");
            }
			load_data_class('User');
            $user = new D_User();
            $user->email = $email;
            $user->tipe_user = General_Constants::MAHASISWA;
            $user->nama_depan = $this->input->post('nama_depan');
			$user->nama_belakang = $this->input->post('nama_belakang');
			$user->jenis_kelamin = $this->input->post('jenis_kelamin');
			$user->alamat = $this->input->post('alamat');
			$user->no_telepon = $this->input->post('no_telepon');
            $user->id_line = $this->input->post('id_line');
			$user->id_telegram = $this->input->post('id_telegram');
			$user->nim = $this->input->post('nim');

            if (isset($_FILES['file_fotoprofil']) && trim($_FILES['file_fotoprofil']['name']) !== '')
            {
                if($user->upload_profil('file_fotoprofil') === FALSE)
                {
					set_warning("Gagal mengupload Pas Foto. Silahkan coba lagi. Jika tetap gagal, hubungi Asisten ITCC untuk bantuan lebih lanjut.");
					redirect($redirect_uri);
                }
            }

			if (isset($_FILES['file_ktm']) && trim($_FILES['file_ktm']['name']) !== '')
			{
				if($user->upload_ktm('file_ktm') === FALSE)
				{
					$user->hapus_profil();
					set_warning("Gagal mengupload KTM. Silahkan coba lagi. Jika tetap gagal, hubungi Asisten ITCC untuk bantuan lebih lanjut.");
					redirect($redirect_uri);
				}
			}

			// Akun Certiport
			if ($this->input->post('punya_akun_certiport') !== NULL)
			{
				$username = trim($this->input->post('username_certiport'));
				$password = $this->input->post('password_certiport');
				if (is_string($username) && !empty($username) && is_string($password) && !empty($password))
				{
					$user->username_certiport = $username;
					$user->password_certiport = $password;
				}
			}

            $this->load->model("m_user");
            if ( $this->m_user->add_new_user($user) === FALSE)
            {
            	$user->hapus_profil();
            	$user->hapus_ktm();
                set_warning("Terjadi kesalahan dalam menyimpan data Anda. Silahkan coba lagi. Jika tetap gagal, hubungi Asisten ITCC untuk bantuan lebih lanjut.");
				redirect($redirect_uri);
            }
			$this->load->model('user_model');
            $user = $this->user_model->get_user_mhs([
                'id' => $user->id
            ]);
            $_SESSION['user'] = reset($user);
            unset($_SESSION['previous_flow']);
            redirect(base_url("dashboard"));
        }
        elseif($tipe === General_Constants::UMUM)
        {
            if (!isset($_SESSION['confirm_email'])) redirect(base_url("umum/daftar"));
            $email = $_SESSION['confirm_email'];
            $this->load->model('m_user');
			if ($this->m_user->is_email_user_exists($email)) redirect(base_url("umum/login"));

			$redirect_uri = base_url("umum/isi_data");
            $form_data_valid = TRUE;

            load_data_class('User');
            $user = new D_User();
            $user->email = $email;
            $user->nama_depan = $this->input->post('nama_depan');
			$user->nama_belakang = $this->input->post('nama_belakang');
			$user->jenis_kelamin = $this->input->post('jenis_kelamin');
			$user->alamat = $this->input->post('alamat');
			$user->no_telepon = $this->input->post('no_telepon');
			$user->nik = $this->input->post('nik');

			if ($this->input->post('punya_akun_certiport') !== NULL)
			{
				$username = trim($this->input->post('username_certiport'));
				$password = $this->input->post('password_certiport');
				if (is_string($username) && !empty($username) && is_string($password) && !empty($password))
				{
					$user->username_certiport = $username;
					$user->password_certiport = $password;
				}
			}

            // Password
            $password1 = $this->input->post('password1');
            $password2 = $this->input->post('password2');
            if (empty($password1) || empty($password2))
			{
				set_warning("Kata sandi wajib diisi.");
				$form_data_valid = FALSE;
			}
            if (strlen($password1) < 8 || $password1 !== $password2)
			{
				set_warning("Kata sandi harus sama dan minimal 8 karakter.");
				$form_data_valid = FALSE;
			}

            // Cek Instansi
            $id_instansi = NULL;
            if (!empty($this->input->post('id_instansi')))
			{
				$id = $this->input->post('id_instansi');
				if (!ctype_digit($id) || !$this->m_user->is_id_instansi_exists($id))
					set_warning("Instansi tidak dapat ditemukan.");
				else
				{
					$id_instansi = $id;
				}
			}

            if (!empty($this->input->post('id_telegram')))
			{
				$user->id_telegram = $this->input->post('id_telegram');
			}

			if ($this->input->post('consent') === NULL)
			{
				set_warning("Anda wajib mengkonfirmasi bahwa data anda telah benar dan dapat dipertanggungjawabkan.");
				$form_data_valid = FALSE;
			}

            if (isset($_FILES['file_fotoprofil']) && trim($_FILES['file_fotoprofil']['name']) !== '')
            {
                if($user->upload_profil('file_fotoprofil') === FALSE)
                {
					set_warning("Gagal mengupload Pas Foto. Silahkan coba lagi. Jika tetap gagal, hubungi Asisten ITCC untuk bantuan lebih lanjut.");
                }
            }

            if (isset($_FILES['file_ktp']) && trim($_FILES['file_ktp']['name']) !== '')
            {
                if($user->upload_ktp('file_ktp') === FALSE)
                {
					set_warning("Gagal mengupload KTP. Silahkan coba lagi. Jika tetap gagal, hubungi Asisten ITCC untuk bantuan lebih lanjut.");
				}
            }

			if (!$form_data_valid || $user->validate_data(TRUE) === FALSE)
			{
				$user->hapus_profil();
				$user->hapus_ktp();
				$_SESSION['form_data'] = [
					'nama_depan' => $user->nama_depan,
					'nama_belakang' => $user->nama_belakang,
					'jenis_kelamin' => $user->jenis_kelamin,
					'alamat' => $user->alamat,
					'no_telepon' => $user->no_telepon,
					'nik' => $user->nik,
					'id_telegram' => $user->id_telegram,
					'username_certiport' => $user->username_certiport,
					'password_certiport' => $user->password_certiport
				];
				redirect($redirect_uri);
			}
			$user->password = password_hash($password1, PASSWORD_DEFAULT);
            if ( $this->m_user->add_new_user($user) === FALSE)
            {
				$user->hapus_profil();
				$user->hapus_ktp();
                set_warning("Terjadi kesalahan dalam menyimpan data Anda. Silahkan coba lagi. Jika tetap gagal, hubungi Asisten ITCC untuk bantuan lebih lanjut.");
                redirect($redirect_uri);
            }
			$this->load->model('user_model');
            if (!empty($id_instansi))
			{
				if ($this->user_model->add_user_to_instansi($id, $id_instansi) === FALSE)
					set_warning("Gagal dalam menambahkan data instansi Anda.");
			}
            $user = $this->user_model->get_user_umum([
                'id' => $user->id
            ]);
            $_SESSION['user'] = reset($user);
            redirect(base_url('dashboard'));
        }
        elseif ($tipe === General_Constants::ITPLN)
		{
			if (!isset($_SESSION['previous_flow']) || $_SESSION['previous_flow'] !== "proses_login_itpln")
				redirect(base_url("itpln/login"));
			// cek ulang
			$this->load->library('user_token');
			if (!$this->user_token->isLoggedIn()) redirect(base_url("itpln/login"));
			$email = trim(strtolower($this->user_token->getEmail()));
			// Cek valid email
			// Apakah email ini mahasiswa
			$this->load->model('m_user');
			// kalau email ada,
			// arahkan ke login
			if ($this->m_user->is_email_user_exists($email)) redirect(base_url("itpln/login"));

			$redirect_uri = base_url("itpln/isi_data");
			if ($this->input->post('consent') === NULL)
			{
				set_warning("Anda wajib mengkonfirmasi bahwa data anda telah benar dan dapat dipertanggungjawabkan.");
			}
			load_data_class('User');
			$user = new D_User();
			$user->email = $email;
			$user->tipe_user = General_Constants::ITPLN;
			$user->nama_depan = $this->input->post('nama_depan');
			$user->nama_belakang = $this->input->post('nama_belakang');
			$user->jenis_kelamin = $this->input->post('jenis_kelamin');
			$user->alamat = $this->input->post('alamat');
			$user->no_telepon = $this->input->post('no_telepon');
			$user->nik = $this->input->post('nik');
			$user->id_jabatan = $this->input->post('id_jabatan');

			if (isset($_FILES['file_fotoprofil']) && trim($_FILES['file_fotoprofil']['name']) !== '')
			{
				if($user->upload_profil('file_fotoprofil') === FALSE)
				{
					set_warning("Gagal mengupload Pas Foto. Silahkan coba lagi. Jika tetap gagal, hubungi Asisten ITCC untuk bantuan lebih lanjut.");
					redirect($redirect_uri);
				}
			}
			else redirect($redirect_uri);

			$this->load->model("m_user");
			if ( $this->m_user->add_new_user($user) === FALSE)
			{
				$user->hapus_profil();
				set_warning("Terjadi kesalahan dalam menyimpan data Anda. Silahkan coba lagi. Jika tetap gagal, hubungi Asisten ITCC untuk bantuan lebih lanjut.");
				redirect($redirect_uri);
			}
			$this->load->model('user_model');
			$user = $this->user_model->get_user_itpln([
				'id' => $user->id
			]);
			$_SESSION['user'] = reset($user);
			unset($_SESSION['previous_flow']);
			redirect(base_url("dashboard"));
		}
    }

    public function show_dashboard()
    {
        $this->redirect_if_not_active();
        $this->load->model('m_kegiatan');
		$list_kegiatan = [];

		// user dengan tipe ITPLN belum tentu terdaftar, karena
		// untuk user ITPLN, registrasi dilakukan otomatis dari halaman dashboard ini.
		if ($this->me->tipe_user !== General_Constants::ITPLN)
        	$list_kegiatan = $this->m_kegiatan->get_kegiatan_in_registrasi();
		else
			$list_kegiatan = $this->m_kegiatan->get_kegiatan_before_pelaksanaan();

        // filter registrasi
		$list_boleh_ujian_saja = [];

		/** @var D_Pendaftaran_Kegiatan[] $list_pendaftaran */
		$list_pendaftaran = [];
		load_data_class('Kegiatan');
		$this->load->model('m_kegiatan');
        foreach($list_kegiatan as $k_keg => $keg)
        {
        	if (!$this->m_kegiatan->user_sudah_mendaftar_kegiatan($this->me, $keg))
			{
				if (!$keg->user_sesuai_kriteria_registrasi($this->me))
				{
					unset($list_kegiatan[$k_keg]);
				}
				else
				{
					// kalau dibuka untuk itpln, langsung registrasikan
					if ($keg->dibuka_untuk === General_Constants::ITPLN)
					{
						// cari data pendaftaran yang sesuai
						$email = trim(strtolower($this->me->email));
						$selected_pendaftaran = array_filter($keg->list_peserta_kegiatan_itpln, function ($p) use ($email){
							return trim(strtolower($p->email)) === $email;
						});
						/** @var D_Peserta_Kegiatan_ITPLN $selected_pendaftaran */
						$selected_pendaftaran = reset($selected_pendaftaran);
						$pendaftaran = new D_Pendaftaran_Kegiatan();
						$pendaftaran->id_user = $this->me->id;
						$pendaftaran->id_kegiatan = $keg->id;
						$pendaftaran->jenis = General_Constants::TRAINING_DAN_UJIAN;
						$pendaftaran->id_program_kegiatan = $selected_pendaftaran->id_program_kegiatan;
						if ($this->m_kegiatan->registrasi($pendaftaran))
						{
							if ($this->m_kegiatan->set_approve_registrasi($pendaftaran->id, true) === FALSE)
								set_warning("Gagal registrasi kegiatan '".$keg->nama_kegiatan."'");
						}
						else set_warning("Gagal registrasi kegiatan '".$keg->nama_kegiatan."'");
					}
					if (
						$keg->dibuka_untuk !== General_Constants::ITPLN &&
						$keg->kriteria_peserta_boleh_ujian_saja->user_sesuai_kriteria($this->me)
					)
						$list_boleh_ujian_saja[] = (int)$keg->id;

				}
			}
        	else
			{
				$pendaftaran = $this->m_kegiatan->get_pendaftaran($this->me, $keg);
				$list_pendaftaran[] = $pendaftaran;
			}
        }
		foreach ($list_kegiatan as $keg) {
			$keg->load_sertifikasi();
			$keg->load_list_program();
		}
        $data = [
            'list_kegiatan' => $list_kegiatan,
			'list_boleh_ujian_saja' => $list_boleh_ujian_saja,
			'list_pendaftaran' => $list_pendaftaran,
			'me' => $this->me
        ];
        $this->load->view('dashboard', ['data' => $data]);
    }

    public function registrasi_kegiatan()
    {
        $this->redirect_if_not_active();
		$redirect = base_url("dashboard");
        load_data_class('Kegiatan');
        $pendaftaran = new D_Pendaftaran_Kegiatan();
        $pendaftaran->id_user = $this->me->id;
        $pendaftaran->id_kegiatan = $this->input->post('id');
        $pendaftaran->jenis = $this->input->post('jenis');
        $pendaftaran->id_program_kegiatan = $this->input->post('program');

        $this->load->model('m_kegiatan');
        if ($this->m_kegiatan->registrasi($pendaftaran) === FALSE)
        {
            set_warning("Terjadi kesalahan dalam proses registrasi.");
			redirect($redirect);
        }
        // kirim email tanda sudah mendaftar
        $data = [
            'nama_kegiatan' => $pendaftaran->kegiatan->nama_kegiatan,
            'link' => base_url('sertifikasi/wait-approval')
        ];
        $this->load->library('system_functions');
		try {
			$this->system_functions->send_email('email/sukses_registrasi',$this->me->email,'Pendaftaran Berhasil', $data);
		}
        catch (Exception $e)
		{
			set_warning("Terjadi kesalahan dalam mengirimkan email.");
		} finally {
			redirect(base_url('sertifikasi/wait-approval'));
		}

    }

    public function show_menunggu_approval()
    {
        $this->redirect_if_not_active();
        $this->load->model('kegiatan_model');
		$this->load->model('m_user');
        $list_kegiatan_not_approved = $this->m_user->get_list_pendaftaran_belum_approve($this->me);
        foreach ($list_kegiatan_not_approved as $pendaftaran)
		{
			$pendaftaran->load_kegiatan();
			$pendaftaran->kegiatan->load_sertifikasi();
			$pendaftaran->load_program();
		}
        $data = [
            'list_kegiatan_not_approved' => $list_kegiatan_not_approved
        ];
        $this->load->view('wait_approval', ['data' => $data]);
    }

    public function show_upload_bukti_bayar()
    {
        $this->redirect_if_not_active();
        $this->load->model('m_user');
        $list_pendaftaran = $this->m_user->get_list_pendaftaran_user($this->me);
		foreach($list_pendaftaran as $l)
		{
			$l->load_kegiatan();
		}
        $data = [
            'list_pendaftaran' => $list_pendaftaran
        ];
        // load data pembayaran kalau ada parameter get
        $id_pendaftaran = $this->input->get('id_pendaftaran');
        if (ctype_digit($id_pendaftaran))
        {
            foreach($list_pendaftaran as $l)
            {
                if ((int)$id_pendaftaran === (int)$l->id)
                {
                	$n =  clone $l;
                	$n->load_list_pembayaran();
                	$n->kegiatan->load_sertifikasi();
                    $data['selected'] = $n;
                }
            }
        }
        $this->load->view('upload_receipts', ['data' => $data]);
    }

    public function upload_bukti_bayar()
    {
        $this->redirect_if_not_active();
        $id_pendaftaran = $this->input->post('id');
        $this->load->model('m_kegiatan');
        $redirect = base_url('sertifikasi/wait-approval');
        if (!ctype_digit($id_pendaftaran) || $this->m_kegiatan->is_id_pendaftaran_exists($id_pendaftaran) === FALSE)
        {
            set_warning("Kegiatan tidak valid.");
            redirect($redirect);
        }
		$this->load->model('m_user');
        $pendaftaran = $this->m_user->get_pendaftaran_user_by_id($id_pendaftaran);
		if ((int)$pendaftaran->id_user !== (int)$this->me->id)
		{
			set_warning("ID pendaftaran tidak valid.");
			redirect($redirect);
		}

		$redirect = base_url('sertifikasi/upload-bukti-bayar');
		$list_kegiatan_not_approved = $this->m_user->get_list_pendaftaran_belum_approve($this->me);
		$selected = array_filter($list_kegiatan_not_approved, function($val) use ($id_pendaftaran){
			$sekarang = new DateTime();
			$val->load_kegiatan();
			return
				(int)$val->id === (int)$id_pendaftaran &&
				!empty($val->kegiatan->batas_upload_bukti_bayar) &&
				$val->kegiatan->batas_upload_bukti_bayar > $sekarang;
		});
		if (empty($selected))
		{
			set_warning("Kegiatan tidak ditemukan. Periksa kembali apakah anda mendaftar kegiatan ini, dan batas pembayaran kegiatan belum lewat.");
			redirect($redirect);
		}

		$redirect = base_url('sertifikasi/upload-bukti-bayar?id_pendaftaran='.$id_pendaftaran);

		$tanggal = $this->input->post('tanggal');
		$waktu = $this->input->post('waktu');
		if (!valid_date_time($tanggal, 'Y-m-d'))
		{
			set_warning("Tanggal transaksi tidak valid.");
			redirect($redirect);
		}
		if (!valid_date_time($waktu, 'H:i:s'))
		{
			set_warning("Waktu transaksi tidak valid.");
			redirect($redirect);
		}

		load_data_class('Kegiatan');
        $bukti = new D_Pembayaran_Kegiatan();
        $bukti->id_pendaftaran = $id_pendaftaran;
		$bukti->nama_pengirim = $this->input->post('nama');
		$bukti->bank = $this->input->post('bank');
		$bukti->nominal_dibayar = $this->input->post('nominal');
		$bukti->waktu_transfer = DateTime::createFromFormat('Y-m-d H:i:s', $tanggal.' '.$waktu);

        if (isset($_FILES['bukti']) && trim($_FILES['bukti']['name']) !== '')
        {
            if($bukti->upload_bukti('bukti') === FALSE)
            {
				set_warning("Gagal mengupload bukti bayar. Silahkan coba lagi. Jika tetap gagal, hubungi Asisten ITCC untuk bantuan lebih lanjut.");
				redirect($redirect);
            }
        }
        else
        {
            set_warning("File bukti bayar wajib diberikan.");
            redirect($redirect);
        }
        if ($this->m_kegiatan->add_new_bukti_bayar($bukti) === FALSE)
        {

            $bukti->hapus_profil();
            set_warning("Gagal dalam menyimpan data pembayaran. Silahkan coba beberapa saat lagi.");
			redirect($redirect);
        }
		redirect($redirect);
    }

    public function show_sedang_berjalan()
    {
        $this->redirect_if_not_active();
        $this->load->model('m_user');
        $list_pendaftaran_sedang_berjalan = $this->m_user->get_list_pendaftaran_sedang_berjalan($this->me);
        foreach($list_pendaftaran_sedang_berjalan as $d)
		{
			$d->load_kegiatan();
			$d->kegiatan->load_sertifikasi();
			$d->load_program();
			$d->load_kelompok_t();
			$d->load_kelompok_u();
		}
        $data = [
            'list_pendaftaran_sedang_berjalan' => $list_pendaftaran_sedang_berjalan
        ];
        $this->load->view('ongoing', ['data' =>$data]);
    }

    public function show_detail_ongoing($id_pendaftaran)
    {
        $this->redirect_if_not_active();
        $callback = base_url('sertifikasi/ongoing');
		$this->load->model('m_user');
		$list_pendaftaran_sedang_berjalan = $this->m_user->get_list_pendaftaran_sedang_berjalan($this->me);
        $selected_pendaftaran = array_filter($list_pendaftaran_sedang_berjalan, function ($d) use ($id_pendaftaran){
        	return (int)$d->id === (int)$id_pendaftaran;
		});
        if (empty($selected_pendaftaran))
		{
			{
				set_warning("Kegiatan yang anda pilih tidak termasuk dalam kegiatan yang sedang berjalan.");
				redirect($callback);
			}
		}
        /** @var D_Kegiatan_User $selected_pendaftaran */
        $selected_pendaftaran = reset($selected_pendaftaran);
        if ((int)$selected_pendaftaran->id_user !== (int)$this->me->id)
        {
            set_warning("Data registrasi anda tidak valid.");
			redirect($callback);
        }
        $selected_pendaftaran->load_kegiatan();
        $selected_pendaftaran->kegiatan->load_sertifikasi();
        $selected_pendaftaran->load_program();
        $selected_pendaftaran->load_kelompok_t();
        $selected_pendaftaran->load_kelompok_u();
		$data = [
            'selected_pendaftaran' => $selected_pendaftaran
        ];
        $this->load->view('detail_ongoing', ['data' => $data]);
    }

    public function show_pilih_kelompok_t($id_pendaftaran)
    {
        $this->redirect_if_not_active();
		$callback = base_url('sertifikasi/ongoing');
		$this->load->model('m_user');
		$list_pendaftaran_sedang_berjalan = $this->m_user->get_list_pendaftaran_sedang_berjalan($this->me);
		$selected_pendaftaran = array_filter($list_pendaftaran_sedang_berjalan, function ($d) use ($id_pendaftaran){
			return (int)$d->id === (int)$id_pendaftaran;
		});
		if (empty($selected_pendaftaran))
		{
			{
				set_warning("Kegiatan yang anda pilih tidak termasuk dalam kegiatan yang sedang berjalan.");
				redirect($callback);
			}
		}
		/** @var D_Kegiatan_User $selected_pendaftaran */
		$selected_pendaftaran = reset($selected_pendaftaran);
		if ((int)$selected_pendaftaran->id_user !== (int)$this->me->id)
		{
			set_warning("Data registrasi anda tidak valid.");
			redirect($callback);
		}
		$selected_pendaftaran->load_kegiatan();
		$selected_pendaftaran->kegiatan->load_sertifikasi();
		$selected_pendaftaran->kegiatan->load_kelompok_training();
		$selected_pendaftaran->load_program();
		$callback = base_url('sertifikasi/ongoing/'.$id_pendaftaran);
		if ($selected_pendaftaran->kegiatan->dibuka_untuk === General_Constants::ITPLN)
		{
			set_warning("Anda tidak dapat memilih kelompok training.");
			redirect($callback);
		}
		if (!empty($selected_pendaftaran->id_kelompok_t))
        {
            set_warning("Anda sudah memilih kelompok training sebelumnya.");
			redirect($callback);
        }
        if ($selected_pendaftaran->jenis === General_Constants::UJIAN_SAJA)
		{
			set_warning("Anda tidak dapat memilih kelompok training, dikarenakan paket yang dipilih adalah Ujian Saja.");
			redirect($callback);
		}
        /*
         * cek apakah batas pilih kelompok masih dalam batas wajar
         * => tanggal training pertama = 20, maka batas akhir = 17 23:59:00
         * */
        $jarak_pilih_kelompok = new DateInterval('P3D');
        if (!empty($selected_pendaftaran->kegiatan->list_kelompok_training))
        {
            $now = new DateTime();
            $max_dt_pilih_kelompok = DateTime::createFromFormat('Y-m-d H:i:s', '2099-12-31 12:12:12');
            foreach($selected_pendaftaran->kegiatan->list_kelompok_training as $kelompok)
            {
                $max_dt_pilih_kelompok = min(
                    $max_dt_pilih_kelompok,
                    clone $kelompok->mulai_training
                );
            }
            $max_dt_pilih_kelompok->sub($jarak_pilih_kelompok)->setTime(23,59,0);
            if ($now >= $max_dt_pilih_kelompok)
            {
                set_warning('Anda tidak bisa memilih kelompok, dikarenakan batas pemilihan kelompok adalah H-3 dari pelaksanaan training, yaitu tanggal '
                    .tgl_indo($max_dt_pilih_kelompok->format('Y-m-d'), 'Y-m-d'). ' '. $max_dt_pilih_kelompok->format('H:i:s') .' WIB.');
				redirect($callback);
            }
        }
        $id_program_kegiatan = (int)$selected_pendaftaran->id_program_kegiatan;
        // filter hanya kelompok yang sesuai id program kegiatan
        $kelompok_t_sesuai_program = array_filter($selected_pendaftaran->kegiatan->list_kelompok_training, function($kel) use ($id_program_kegiatan){
            return (int)$kel->id_program_kegiatan === $id_program_kegiatan;
        });

        $data = [
            'selected_pendaftaran' => $selected_pendaftaran,
			'kelompok_t_sesuai_program' => $kelompok_t_sesuai_program
        ];

        $this->load->view('pilih_kelompok_t', ['data' => $data]);
    }

    public function pilih_kelompok_t($id_pendaftaran)
    {
        $this->redirect_if_not_active();
		$callback = base_url('sertifikasi/ongoing');
		$this->load->model('m_user');
		$list_pendaftaran_sedang_berjalan = $this->m_user->get_list_pendaftaran_sedang_berjalan($this->me);
		$selected_pendaftaran = array_filter($list_pendaftaran_sedang_berjalan, function ($d) use ($id_pendaftaran){
			return (int)$d->id === (int)$id_pendaftaran;
		});
		if (empty($selected_pendaftaran))
		{
			{
				set_warning("Kegiatan yang anda pilih tidak termasuk dalam kegiatan yang sedang berjalan.");
				redirect($callback);
			}
		}
		/** @var D_Kegiatan_User $selected_pendaftaran */
		$selected_pendaftaran = reset($selected_pendaftaran);
		if ((int)$selected_pendaftaran->id_user !== (int)$this->me->id)
		{
			set_warning("Data registrasi anda tidak valid.");
			redirect($callback);
		}
		$selected_pendaftaran->load_kegiatan();
		$selected_pendaftaran->kegiatan->load_sertifikasi();
		$selected_pendaftaran->kegiatan->load_kelompok_training();
		$selected_pendaftaran->load_program();
		$callback = base_url('sertifikasi/ongoing/'.$id_pendaftaran);
		if ($selected_pendaftaran->kegiatan->dibuka_untuk === General_Constants::ITPLN)
		{
			set_warning("Anda tidak dapat memilih kelompok training.");
			redirect($callback);
		}
		$callback = base_url('sertifikasi/ongoing/'.$id_pendaftaran);
        if (!empty($selected_pendaftaran->id_kelompok_t))
        {
            set_warning("Anda sudah memilih kelompok sebelumnya.");
			redirect($callback);
        }
        $id_kelompok = $this->input->post('id');
        if (empty($selected_pendaftaran->kegiatan->list_kelompok_training))
        {
            set_warning("Tidak ada kelompok training.");
			redirect($callback);
        }
        if (!ctype_digit($id_kelompok))
        {
            set_warning("Data kelompok yang dipilih tidak valid.");
			redirect($callback);
        }

        $id_program_kegiatan = (int)$selected_pendaftaran->id_program_kegiatan;
        $selected_kelompok = array_filter($selected_pendaftaran->kegiatan->list_kelompok_training, function($kel) use ($id_kelompok, $id_program_kegiatan){
            return (int)$kel->id === (int)$id_kelompok && (int)$kel->id_program_kegiatan === $id_program_kegiatan;
        });
        if (empty($selected_kelompok))
        {
            set_warning("Kelompok yang dipilih tidak valid.");
			redirect($callback);
        }
        /** @var D_Kelompok_T $selected_kelompok */
        $selected_kelompok = reset($selected_kelompok);
        if ((int)$selected_kelompok->jumlah_peserta+1 > (int)$selected_kelompok->max_peserta_training)
        {
            set_warning("Kelompok tidak dapat dipilih lagi karena sudah penuh.");
			redirect($callback);
        }
        /*
         * cek apakah batas pilih kelompok masih dalam batas wajar
         * => tanggal training pertama = 20, maka batas akhir = 17 23:59:00
         * */
        $jarak_pilih_kelompok = new DateInterval('P3D');
        $now = new DateTime();
        $max_dt_pilih_kelompok = DateTime::createFromFormat('Y-m-d H:i:s', '2099-12-31 12:12:12');
        foreach($selected_pendaftaran->kegiatan->list_kelompok_training as $kelompok)
        {
            $max_dt_pilih_kelompok = min(
                $max_dt_pilih_kelompok,
                clone $kelompok->mulai_training
            );
        }
        $max_dt_pilih_kelompok->sub($jarak_pilih_kelompok)->setTime(23,59,0);
        if ($now >= $max_dt_pilih_kelompok)
        {
            set_warning('Anda tidak bisa memilih kelompok, dikarenakan batas pemilihan kelompok adalah H-3 dari pelaksanaan training, yaitu tanggal '
                .tgl_indo($max_dt_pilih_kelompok->format('Y-m-d'), 'Y-m-d'). ' '. $max_dt_pilih_kelompok->format('H:i:s') .' WIB.');
			redirect($callback);
        }

        $selected_pendaftaran->id_kelompok_t = $id_kelompok;
        if ($this->m_user->update_kelompok_t_u_pendaftaran($selected_pendaftaran) === FALSE)
        {
            set_warning("Terjadi kesalahan dalam memilih kelompok training. Silahkan coba lagi.");
			redirect($callback);
        }
        $data = [
            'kelompok' => [
            	'nama_kelompok' => $selected_kelompok->nama_kelompok
			],
            'link' => base_url('sertifikasi/ongoing')
        ];
        $this->load->library('system_functions');
		try {
			$this->system_functions->send_email(
				'email/sukses_pilih_kelompok_training',
				$this->me->email,
				'Pemberitahuan Kelompok Training Sertifikasi',
				$data
			);
		} catch (Exception $e){
			set_warning("Terjadi Kesalahan dalam mengirimkan email.");
		} finally {
			redirect($callback);
		}
    }

	public function show_pilih_kelompok_u($id_pendaftaran)
	{
		$this->redirect_if_not_active();
		$callback = base_url('sertifikasi/ongoing');
		$this->load->model('m_user');
		$list_pendaftaran_sedang_berjalan = $this->m_user->get_list_pendaftaran_sedang_berjalan($this->me);
		$selected_pendaftaran = array_filter($list_pendaftaran_sedang_berjalan, function ($d) use ($id_pendaftaran){
			return (int)$d->id === (int)$id_pendaftaran;
		});
		if (empty($selected_pendaftaran))
		{
			{
				set_warning("Kegiatan yang anda pilih tidak termasuk dalam kegiatan yang sedang berjalan.");
				redirect($callback);
			}
		}
		/** @var D_Kegiatan_User $selected_pendaftaran */
		$selected_pendaftaran = reset($selected_pendaftaran);
		if ((int)$selected_pendaftaran->id_user !== (int)$this->me->id)
		{
			set_warning("Data registrasi anda tidak valid.");
			redirect($callback);
		}
		$selected_pendaftaran->load_kegiatan();
		$selected_pendaftaran->kegiatan->load_sertifikasi();
		$selected_pendaftaran->kegiatan->load_kelompok_ujian();
		$selected_pendaftaran->load_program();

		$callback = base_url('sertifikasi/ongoing/'.$id_pendaftaran);
		if ($selected_pendaftaran->kegiatan->dibuka_untuk === General_Constants::ITPLN)
		{
			set_warning("Anda tidak dapat memilih kelompok ujian.");
			redirect($callback);
		}
		if (!empty($selected_pendaftaran->id_kelompok_u))
		{
			set_warning("Anda sudah memilih kelompok ujian sebelumnya.");
			redirect($callback);
		}

		if ($selected_pendaftaran->jenis !== General_Constants::UJIAN_SAJA && empty($selected_pendaftaran->id_kelompok_t))
		{
			set_warning("Kelompok ujian dapat dipilih jika sudah memilih kelompok training.");
			redirect($callback);
		}

		/*
		 * cek apakah batas pilih kelompok masih dalam batas wajar
		 * => tanggal training pertama = 20, maka batas akhir = 17 23:59:00
		 * */
		$jarak_pilih_kelompok = new DateInterval('P3D');
		if (!empty($selected_pendaftaran->kegiatan->list_kelompok_ujian))
		{
			$now = new DateTime();
			$max_dt_pilih_kelompok = DateTime::createFromFormat('Y-m-d H:i:s', '2099-12-31 12:12:12');
			foreach($selected_pendaftaran->kegiatan->list_kelompok_ujian as $kelompok)
			{
				$max_dt_pilih_kelompok = min(
					$max_dt_pilih_kelompok,
					clone $kelompok->mulai_ujian
				);
			}
			$max_dt_pilih_kelompok->sub($jarak_pilih_kelompok)->setTime(23,59,0);
			if ($now >= $max_dt_pilih_kelompok)
			{
				set_warning('Anda tidak bisa memilih kelompok, dikarenakan batas pemilihan kelompok adalah H-3 dari pelaksanaan ujian, yaitu tanggal '
					.tgl_indo($max_dt_pilih_kelompok->format('Y-m-d'), 'Y-m-d'). ' '. $max_dt_pilih_kelompok->format('H:i:s') .' WIB.');
				redirect($callback);
			}
		}
		$id_program_kegiatan = (int)$selected_pendaftaran->id_program_kegiatan;
		// filter hanya kelompok yang sesuai id program kegiatan
		$kelompok_u_sesuai_program = array_filter($selected_pendaftaran->kegiatan->list_kelompok_ujian, function($kel) use ($id_program_kegiatan){
			return (int)$kel->id_program_kegiatan === $id_program_kegiatan;
		});

		$data = [
			'selected_pendaftaran' => $selected_pendaftaran,
			'kelompok_u_sesuai_program' => $kelompok_u_sesuai_program
		];

		$this->load->view('pilih_kelompok_u', ['data' => $data]);
	}

	public function pilih_kelompok_u($id_pendaftaran)
	{
		$this->redirect_if_not_active();
		$callback = base_url('sertifikasi/ongoing');
		$this->load->model('m_user');
		$list_pendaftaran_sedang_berjalan = $this->m_user->get_list_pendaftaran_sedang_berjalan($this->me);
		$selected_pendaftaran = array_filter($list_pendaftaran_sedang_berjalan, function ($d) use ($id_pendaftaran){
			return (int)$d->id === (int)$id_pendaftaran;
		});
		if (empty($selected_pendaftaran))
		{
			{
				set_warning("Kegiatan yang anda pilih tidak termasuk dalam kegiatan yang sedang berjalan.");
				redirect($callback);
			}
		}
		/** @var D_Kegiatan_User $selected_pendaftaran */
		$selected_pendaftaran = reset($selected_pendaftaran);
		if ((int)$selected_pendaftaran->id_user !== (int)$this->me->id)
		{
			set_warning("Data registrasi anda tidak valid.");
			redirect($callback);
		}
		$selected_pendaftaran->load_kegiatan();
		$selected_pendaftaran->kegiatan->load_sertifikasi();
		$selected_pendaftaran->kegiatan->load_kelompok_ujian();
		$selected_pendaftaran->load_program();

		$callback = base_url('sertifikasi/ongoing/'.$id_pendaftaran);
		if ($selected_pendaftaran->kegiatan->dibuka_untuk === General_Constants::ITPLN)
		{
			set_warning("Anda tidak dapat memilih kelompok ujian.");
			redirect($callback);
		}

		if (!empty($selected_pendaftaran->id_kelompok_u))
		{
			set_warning("Anda sudah memilih kelompok ujian sebelumnya.");
			redirect($callback);
		}
		if ($selected_pendaftaran->jenis !== General_Constants::UJIAN_SAJA && empty($selected_pendaftaran->id_kelompok_t))
		{
			set_warning("Kelompok ujian dapat dipilih jika sudah memilih kelompok training.");
			redirect($callback);
		}
		$id_kelompok = $this->input->post('id');
		if (empty($selected_pendaftaran->kegiatan->list_kelompok_ujian))
		{
			set_warning("Tidak ada kelompok ujian.");
			redirect($callback);
		}
		if (!ctype_digit($id_kelompok))
		{
			set_warning("Data kelompok yang dipilih tidak valid.");
			redirect($callback);
		}

		$id_program_kegiatan = (int)$selected_pendaftaran->id_program_kegiatan;
		$selected_kelompok = array_filter($selected_pendaftaran->kegiatan->list_kelompok_ujian, function($kel) use ($id_kelompok, $id_program_kegiatan){
			return (int)$kel->id === (int)$id_kelompok && (int)$kel->id_program_kegiatan === $id_program_kegiatan;
		});
		if (empty($selected_kelompok))
		{
			set_warning("Kelompok yang dipilih tidak valid.");
			redirect($callback);
		}
		/** @var D_Kelompok_U $selected_kelompok */
		$selected_kelompok = reset($selected_kelompok);
		if ((int)$selected_kelompok->jumlah_peserta+1 > (int)$selected_kelompok->max_peserta_ujian)
		{
			set_warning("Kelompok tidak dapat dipilih lagi karena sudah penuh.");
			redirect($callback);
		}
		/*
		 * cek apakah batas pilih kelompok masih dalam batas wajar
		 * => tanggal training pertama = 20, maka batas akhir = 17 23:59:00
		 * */
		$jarak_pilih_kelompok = new DateInterval('P3D');
		$now = new DateTime();
		$max_dt_pilih_kelompok = DateTime::createFromFormat('Y-m-d H:i:s', '2099-12-31 12:12:12');
		foreach($selected_pendaftaran->kegiatan->list_kelompok_ujian as $kelompok)
		{
			$max_dt_pilih_kelompok = min(
				$max_dt_pilih_kelompok,
				clone $kelompok->mulai_ujian
			);
		}
		$max_dt_pilih_kelompok->sub($jarak_pilih_kelompok)->setTime(23,59,0);
		if ($now >= $max_dt_pilih_kelompok)
		{
			set_warning('Anda tidak bisa memilih kelompok, dikarenakan batas pemilihan kelompok adalah H-3 dari pelaksanaan ujian, yaitu tanggal '
				.tgl_indo($max_dt_pilih_kelompok->format('Y-m-d'), 'Y-m-d'). ' '. $max_dt_pilih_kelompok->format('H:i:s') .' WIB.');
			redirect($callback);
		}

		$selected_pendaftaran->id_kelompok_u = $id_kelompok;
		if ($this->m_user->update_kelompok_t_u_pendaftaran($selected_pendaftaran) === FALSE)
		{
			set_warning("Terjadi kesalahan dalam memilih kelompok ujian. Silahkan coba lagi.");
			redirect($callback);
		}
		$data = [
			'kelompok' => [
				'nama_kelompok' => $selected_kelompok->nama_kelompok
			],
			'link' => base_url('sertifikasi/ongoing')
		];
		$this->load->library('system_functions');
		try {
			$this->system_functions->send_email(
				'email/sukses_pilih_kelompok_ujian',
				$this->me->email,
				'Pemberitahuan Kelompok Ujian Sertifikasi',
				$data
			);
		} catch (Exception $e){
			set_warning("Terjadi Kesalahan dalam mengirimkan email.");
		} finally {
			redirect($callback);
		}
	}

    public function show_materi_training($id_pendaftaran)
    {
        $this->redirect_if_not_active();
        $callback = base_url('sertifikasi/ongoing');
        $this->load->model('m_kegiatan');
        if ($this->m_kegiatan->is_id_pendaftaran_exists($id_pendaftaran) === FALSE)
		{
			set_warning("Kegiatan tidak valid.");
			redirect($callback);
		}
        $this->load->model('m_user');
        $pendaftaran = $this->m_user->get_pendaftaran_user_by_id($id_pendaftaran);
        if ((int)$pendaftaran->id_user !== (int)$this->me->id)
        {
            set_warning("Anda tidak bisa melihat materi untuk sesi pendaftaran ini.");
			redirect($callback);
        }
        if (empty($pendaftaran->id_kelompok_t))
        {
            set_warning("Silahkan pilih kelompok training terlebih dahulu.");
			redirect($callback);
        }
        $pendaftaran->load_kegiatan();
        $pendaftaran->kegiatan->load_kelompok_ujian();
        /*
         * cek apakah batas akses materi masih dalam periode
         * (sebelum hari terakhir ujian)
         * => tanggal terakhir ujian = 20, maka batas akhir = 21 23:59:00
         * Kalau belum ada kelompok ujian, berarti hitung sebelum awal pelaporan
         * */
        $now = new DateTime();
        $batas = DateTime::createFromFormat('Y-m-d H:i:s', '1990-12-31 12:12:12');
        foreach($pendaftaran->kegiatan->list_kelompok_ujian as $kelompok)
        {
            $batas = max(
                $batas,
                clone $kelompok->selesai_ujian
            );
        }
        $batas->setTime(23,59,0);
        if ((count($pendaftaran->kegiatan->list_kelompok_ujian)>0 && $now >= $batas) || $now > $pendaftaran->kegiatan->awal_pelaporan)
        {
            set_warning('Anda tidak dapat melihat materi training, karena periode kegiatan sudah berakhir.');
			redirect($callback);
        }
        $pendaftaran->load_kelompok_t();
        $pendaftaran->kelompok_t->load_list_materi();
        $pendaftaran->load_program();
        $data = [
        	'pendaftaran' => $pendaftaran
		];
        $this->load->view('materi_training', ['data' => $data]);
    }

    public function show_profile()
    {
        $this->redirect_if_not_active();
        $this->me->load_jabatan();
        $data = [
        	'me' => $this->me
		];
        $this->load->view('profile', ['data' => $data]);
    }

    public function show_sudah_selesai()
    {
        $this->redirect_if_not_active();
        $list_kegiatan_sudah_dilaksanakan = $this->m_user->get_list_pendaftaran_sudah_dilaksanakan($this->me);
        foreach ($list_kegiatan_sudah_dilaksanakan as $d)
		{
			$d->load_kegiatan();
			$d->kegiatan->load_sertifikasi();
		}
        $data = [
            'list_kegiatan_sudah_dilaksanakan' => $list_kegiatan_sudah_dilaksanakan
        ];
        $this->load->view('completed', ['data' => $data]);
    }

    public function show_detail_completed($id_pendaftaran)
    {
        $this->redirect_if_not_active();
        $callback = base_url('sertifikasi/ongoing');
        $this->load->model('m_kegiatan');
        if ($this->m_kegiatan->is_id_pendaftaran_exists($id_pendaftaran) === FALSE)
		{
			set_warning("Kegiatan tidak valid.");
			redirect($callback);
		}
        $pendaftaran = $this->m_user->get_pendaftaran_user_by_id($id_pendaftaran);
        if ((int)$pendaftaran->id_user !== (int)$this->me->id)
        {
            set_warning("Data registrasi anda tidak valid.");
			redirect($callback);
        }

        $pendaftaran->load_kegiatan();
        $pendaftaran->kegiatan->load_sertifikasi();
        $pendaftaran->kegiatan->load_kelompok_ujian();
        $sekarang = new DateTime();
        $berakhir = TRUE;
        foreach ($pendaftaran->kegiatan->list_kelompok_ujian as $kelompok)
		{
			if ($sekarang < $kelompok->selesai_ujian)
				$berakhir = FALSE;
		}
        if (!$berakhir)
		{
			set_warning("Kegiatan yang anda pilih belum berakhir.");
			redirect($callback);
		}
        $pendaftaran->load_program();
		$pendaftaran->load_kelompok_t();
		$pendaftaran->load_kelompok_u();

		$data = [
			'pendaftaran' => $pendaftaran
		];
        $this->load->view('detail_completed', ['data' => $data]);
    }

    public function show_ecerts()
    {
        $this->redirect_if_not_active();
        $ecerts = $this->m_user->get_list_pendaftaran_punya_ecerts($this->me);
        foreach ($ecerts as $e)
		{
			$e->load_pendaftaran();
			$e->pendaftaran->load_kegiatan();
			$e->pendaftaran->load_program();
			$e->pendaftaran->kegiatan->load_sertifikasi();
		}
        $data = [
            'ecerts' => $ecerts
        ];
        $this->load->view('ecerts', ['data' => $data]);
    }

    public function download_ecerts($id)
    {
        $this->redirect_if_not_active();
        $callback = base_url('e-certs');
        if ($this->m_user->is_id_ecert_exists($id) === FALSE)
        {
            set_warning("E-certificate tidak ditemukan.");
            redirect($callback);
        }
        load_data_class('User');
        $ecert = new D_Sertifikat_Keikutsertaan($id);
        $ecert->load_pendaftaran();
        $ecert->pendaftaran->load_user();
        $ecert->pendaftaran->load_kegiatan();
        $ecert->pendaftaran->kegiatan->load_sertifikasi();
        if ((int)$ecert->pendaftaran->id_user !== (int)$this->me->id)
        {
            set_warning("Anda tidak memiliki akses untuk e-certificate ini.");
			redirect($callback);
        }
        $param = [
            '${nama}' => $ecert->pendaftaran->user->nama_depan.' '.$ecert->pendaftaran->user->nama_belakang,
            '${sertifikasi}' => $ecert->pendaftaran->kegiatan->sertifikasi->nama,
            '${serial}' => $ecert->kode,
            '${tanggal_terbit}' => $ecert->tanggal_terbit->format('F d, Y')
        ];
        $template = "";
		try {
			$template = file_get_contents($ecert->pendaftaran->kegiatan->sertifikasi->link_template_sertifikat);
		} catch (Exception $ex) {

		} finally {
			$new = str_replace(array_keys($param), array_values($param), $template);
			exit($new);
		}
    }

    public function show_verify()
    {
        $this->load->view('verify', ['data' => []]);
    }

    public function verify_ecert()
    {
        $serial = $this->input->post('serial');
        if (!is_string($serial) || trim($serial) === '')
        {
            set_warning('Kode verifikasi E-Certificate tidak boleh kosong.');
            redirect(base_url('verify'));
        }
        $this->load->model('ecerts_model');
        $ecert = $this->ecerts_model->get_ecert([
            'serial' => $serial
        ]);
        if (empty($ecert))
        {
            set_warning('Kode verifikasi E-Certificate tidak ditemukan.');
            redirect(base_url('verify'));
        }
        $ecert['serial'] = $ecert['kode'];
        $data = [
            'ecert' => $ecert
        ];
        $this->load->view('verify', ['data' => html_escape($data)]);
    }

    public function show_cancelled()
    {
        $this->redirect_if_not_active();
        $list_kegiatan_dibatalkan = $this->m_user->get_list_pendaftaran_dibatalkan($this->me);
        foreach ($list_kegiatan_dibatalkan as $keg)
		{
			$keg->load_kegiatan();
			$keg->kegiatan->load_sertifikasi();
			$keg->load_program();
		}
        $data = [
            'list_kegiatan_dibatalkan' => $list_kegiatan_dibatalkan
        ];
        $this->load->view('cancelled', ['data' => $data]);
    }

    public function show_cancelled_payment($id_pendaftaran)
    {
        $this->redirect_if_not_active();

		$list_kegiatan_dibatalkan = $this->m_user->get_list_pendaftaran_dibatalkan($this->me);
		$selected_pendaftaran = array_filter($list_kegiatan_dibatalkan, function ($k) use ($id_pendaftaran){
			return (int)$id_pendaftaran === (int)$k->id;
		});
		if (empty($selected_pendaftaran))
        {
            set_warning('Detail pembayaran tidak dapat ditemukan');
            redirect(base_url('sertifikasi/cancelled'));
        }
		/** @var D_Kegiatan_User $selected_pendaftaran */
		$selected_pendaftaran = reset($selected_pendaftaran);
		$selected_pendaftaran->load_list_pembayaran();
		$selected_pendaftaran->load_kegiatan();
        $data = [
            'selected_pendaftaran' => $selected_pendaftaran
        ];
        $this->load->view('cancelled_payment', ['data' => $data]);
    }
}

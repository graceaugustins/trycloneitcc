<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route[''] = 'welcome';
$route['/'] = 'welcome';
$route['default_controller'] = 'welcome';
$route['404_override'] = 'error_page';
$route['translate_uri_dashes'] = FALSE;

$route['sistem/callback']   = 'main/system_callback';

$route['msauth/callback'] 	= 'auth/callback';
$route['msauth/signin'] 	= 'auth/signin';
$route['msauth/signout'] 	= 'auth/signout';

$route['login']             = 'main/show_login';

$route['mhs/login']         = 'autentikasi_mhs/show_login';
$route['mhs/proses_login']  = 'autentikasi_mhs/proses_login';
$route['mhs/logout']        = 'autentikasi_mhs/logout';

$route['itpln/login']         = 'autentikasi_itpln/show_login';
$route['itpln/proses_login']  = 'autentikasi_itpln/proses_login';
$route['itpln/logout']        = 'autentikasi_itpln/logout';

$route['mhs/isi_data']                      = 'main/show_isi_data/mahasiswa';
$route['mhs/submit_registrasi']['POST']     = 'main/tambah_user/mahasiswa';

$route['itpln/isi_data']                      = 'main/show_isi_data/itpln';
$route['itpln/submit_registrasi']['POST']     = 'main/tambah_user/itpln';

$route['umum/login']                        = 'autentikasi_umum/show_login';
$route['umum/login/verify']                 = 'autentikasi_umum/verify_login';
$route['umum/logout']                       = 'autentikasi_umum/logout';
$route['umum/daftar']                       = 'autentikasi_umum/show_daftar';
$route['umum/daftar/submit-email']['POST']  = 'autentikasi_umum/proses_email_daftar';
$route['umum/daftar/email-sent']            = 'autentikasi_umum/show_email_sent';
$route['umum/daftar/verify-email']          = 'autentikasi_umum/verify_confirmation_link';
$route['umum/forgot-password']['GET']       = 'autentikasi_umum/show_forgot_password';
$route['umum/forgot-password']['POST']      = 'autentikasi_umum/send_email_recovery';
$route['umum/forgot-password/email-sent']   = 'autentikasi_umum/show_email_recovery_sent';
$route['umum/recover-account']['GET']       = 'autentikasi_umum/verify_email_recovery';
$route['umum/form-recover-account']['GET']  = 'autentikasi_umum/show_ubah_password';
$route['umum/recover-account']['POST']      = 'autentikasi_umum/ubah_password';

$route['umum/isi_data']                     = 'main/show_isi_data/umum';
$route['umum/submit_registrasi']['POST']    = 'main/tambah_user/umum';

$route['dashboard']                     = 'main/show_dashboard';
$route['registrasi']['POST']            = 'main/registrasi_kegiatan';
$route['user_not_active']               = 'main/show_not_active';
$route['profile']                       = 'main/show_profile';
$route['sertifikasi/wait-approval']     = 'main/show_menunggu_approval';
$route['sertifikasi/ongoing']           = 'main/show_sedang_berjalan';
$route['sertifikasi/ongoing/(:num)']    = 'main/show_detail_ongoing/$1';
$route['sertifikasi/completed']         = 'main/show_sudah_selesai';
$route['sertifikasi/completed/(:num)']  = 'main/show_detail_completed/$1';
$route['sertifikasi/cancelled']         = 'main/show_cancelled';
$route['sertifikasi/cancelled/(:num)/payment']         = 'main/show_cancelled_payment/$1';
$route['e-certs']                       = 'main/show_ecerts';
$route['e-certs/(:num)']                = 'main/download_ecerts/$1';
$route['verify']['GET']                 = 'main/show_verify';
$route['verify']['POST']                = 'main/verify_ecert';

$route['sertifikasi/upload-bukti-bayar']['GET']         = 'main/show_upload_bukti_bayar';
$route['sertifikasi/upload-bukti-bayar']['POST']        = 'main/upload_bukti_bayar';
$route['sertifikasi/materi-training/(:num)']['GET']    	= 'main/show_materi_training/$1';

$route['sertifikasi/pilih-kelompok-t/(:num)']['GET']    = 'main/show_pilih_kelompok_t/$1';
$route['sertifikasi/pilih-kelompok-t/(:num)']['POST']   = 'main/pilih_kelompok_t/$1';

$route['sertifikasi/pilih-kelompok-u/(:num)']['GET']    = 'main/show_pilih_kelompok_u/$1';
$route['sertifikasi/pilih-kelompok-u/(:num)']['POST']   = 'main/pilih_kelompok_u/$1';

$route['ajax/instansi/get_all']['POST']  		    = 'ajax/get_instansi';
$route['ajax/info/(:num)/dismiss']['POST']  		= 'ajax/dismiss_info/$1';

$route['error']['GET'] = 'error_page';

// disable accessing controller directly (dirty hack)
$route['[^`]+'] = 'error_page';

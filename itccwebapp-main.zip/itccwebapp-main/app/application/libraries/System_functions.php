<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use Microsoft\Graph\Graph;
use Microsoft\Graph\Model;

use GuzzleHttp\Client;
use Ypio\MSGraphFileConverter\Configuration;
use Ypio\MSGraphFileConverter\Exceptions\MSGraphException;
use Ypio\MSGraphFileConverter\FileConverter;
use Ypio\MSGraphFileConverter\Formats\FormatToPdfFrom;

class System_functions {
    protected $CI;

    public function __construct()
    {
        // Assign the CodeIgniter super-object
        $this->CI =& get_instance();
        $this->CI->load->model('config_model');
    }

    public function create_token()
    {
        // Initialize the OAuth client
        $oauthClient = new \League\OAuth2\Client\Provider\GenericProvider([
            'clientId'                => $this->CI->config->item('SYSTEM_OAUTH_APP_ID'),
            'clientSecret'            => $this->CI->config->item('SYSTEM_OAUTH_APP_PASSWORD'),
            'redirectUri'             => $this->CI->config->item('SYSTEM_OAUTH_REDIRECT_URI'),
            'urlAuthorize'            => $this->CI->config->item('OAUTH_AUTHORITY').$this->CI->config->item('OAUTH_AUTHORIZE_ENDPOINT'),
            'urlAccessToken'          => $this->CI->config->item('OAUTH_AUTHORITY').$this->CI->config->item('OAUTH_TOKEN_ENDPOINT'),
            'urlResourceOwnerDetails' => '',
            'scopes'                  => $this->CI->config->item('SYSTEM_OAUTH_SCOPES')
        ]);
        $authUrl = $oauthClient->getAuthorizationUrl();
        // Save client state so we can validate in callback
        $_SESSION['oauthState'] = $oauthClient->getState();
        redirect($authUrl);
    }

    public function callback()
    {
        // Validate state
        $expectedState = $_SESSION['oauthState'];
        unset($_SESSION['oauthState']);
        $providedState = $this->CI->input->get('state');
        if (!isset($expectedState))
        {
            // If there is no expected state in the session,
            // do nothing and redirect to the home page.
            redirect(base_url());
        }
        if (!isset($providedState) || $expectedState != $providedState)
        {
            redirect(base_url());
        }
        // Authorization code should be in the "code" query param
        if (!empty($this->CI->input->get('code')))
        {
            $authCode = $this->CI->input->get('code');
            // Initialize the OAuth client
            $oauthClient = new \League\OAuth2\Client\Provider\GenericProvider([
                'clientId'                => $this->CI->config->item('SYSTEM_OAUTH_APP_ID'),
                'clientSecret'            => $this->CI->config->item('SYSTEM_OAUTH_APP_PASSWORD'),
                'redirectUri'             => $this->CI->config->item('SYSTEM_OAUTH_REDIRECT_URI'),
                'urlAuthorize'            => $this->CI->config->item('OAUTH_AUTHORITY').$this->CI->config->item('OAUTH_AUTHORIZE_ENDPOINT'),
                'urlAccessToken'          => $this->CI->config->item('OAUTH_AUTHORITY').$this->CI->config->item('OAUTH_TOKEN_ENDPOINT'),
                'urlResourceOwnerDetails' => '',
                'scopes'                  => $this->CI->config->item('SYSTEM_OAUTH_SCOPES')
            ]);

            try {
                // Make the token request
                $accessToken = $oauthClient->getAccessToken('authorization_code', [
                    'code' => $authCode
                ]);

                $graph = new Graph();
                $graph->setAccessToken($accessToken->getToken());

                $user = $graph->createRequest('GET', '/me?$select=displayName,mail,userPrincipalName')
                    ->setReturnType(Model\User::class)
                    ->execute();

                $this->storeTokens($accessToken, $user);
                redirect(base_url());
            }
            catch (League\OAuth2\Client\Provider\Exception\IdentityProviderException $e) {
                redirect(base_url('error?message=ERROR_GETPROFILE_GRAPH'));
            }
        }
        redirect(base_url('error?message=ERROR_NOT_AUTHORIZED'));
    }
    
    public function get_access_token() {
        // Check if tokens exist
        $access_token = $this->CI->config_model->get('access_token');
        $refresh_token = $this->CI->config_model->get('refresh_token');
        $token_expires = $this->CI->config_model->get('token_expires');
        if (empty($access_token) || empty($refresh_token) || empty($token_expires))
            return NULL;
        $token_expires = (int)$token_expires;
        // Check if token is expired
        //Get current time + 5 minutes (to allow for time differences)
        $now = time() + 300;
        if ($now >= $token_expires)
        {
            // Token is expired (or very close to it)
            // so let's refresh

            // Initialize the OAuth client
            $oauthClient = new \League\OAuth2\Client\Provider\GenericProvider([
                'clientId'                => $this->CI->config->item('SYSTEM_OAUTH_APP_ID'),
                'clientSecret'            => $this->CI->config->item('SYSTEM_OAUTH_APP_PASSWORD'),
                'redirectUri'             => $this->CI->config->item('SYSTEM_OAUTH_REDIRECT_URI'),
                'urlAuthorize'            => $this->CI->config->item('OAUTH_AUTHORITY').$this->CI->config->item('OAUTH_AUTHORIZE_ENDPOINT'),
                'urlAccessToken'          => $this->CI->config->item('OAUTH_AUTHORITY').$this->CI->config->item('OAUTH_TOKEN_ENDPOINT'),
                'urlResourceOwnerDetails' => '',
                'scopes'                  => $this->CI->config->item('SYSTEM_OAUTH_SCOPES')
            ]);

            try {
                $newToken = $oauthClient->getAccessToken('refresh_token', [
                    'refresh_token' => $refresh_token
                ]);

                $graph = new Graph();
                $graph->setAccessToken($newToken->getToken());

                $user = $graph->createRequest('GET', '/me?$select=displayName,mail,userPrincipalName')
                    ->setReturnType(Model\User::class)
                    ->execute();

                // Store the new values
                $this->storeTokens($newToken, $user);
                return $newToken->getToken();
            }
            catch (Exception $e) {
                return NULL;
            }
        }
        return $access_token;
    }

    public function storeTokens($accessToken, $user) {
        $this->CI->config_model->set('access_token', $accessToken->getToken());
        $this->CI->config_model->set('refresh_token', $accessToken->getRefreshToken());
        $this->CI->config_model->set('token_expires', $accessToken->getExpires());
        $this->CI->config_model->set('token_identifier', $user->getMail());
    }

    public function send_email($path, $email, $subject, $data)
    {
        $body =  $this->CI->load->view($path, $data, TRUE);
        $graph = new Graph();
        $graph->setAccessToken($this->get_access_token());
        $requestBody = [
            'message' => [
                'subject' => $subject,
                'body' => [
                    'contentType' => 'HTML',
                    'content' => $body
                ],
                'toRecipients' => [
                    [
                        'emailAddress' => [
                            'address' => $email
                        ]
                    ]
                ]
            ]
        ];

        $mail = $graph->createRequest("POST", "/me/sendMail")
            ->attachBody($requestBody)
            ->execute();
    }
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_token {
    protected $CI;

    public function __construct()
    {
        // Assign the CodeIgniter super-object
        $this->CI =& get_instance();
    }

    public function storeTokens($accessToken, $user) {
        $_SESSION['UserToken']['accessToken'] = $accessToken->getToken();
        $_SESSION['UserToken']['refreshToken'] = $accessToken->getRefreshToken();
        $_SESSION['UserToken']['tokenExpires'] = $accessToken->getExpires();
        $_SESSION['UserToken']['userName'] = $user->getDisplayName();
        $_SESSION['UserToken']['userEmail'] = $user->getMail() !== null ? $user->getMail() : $user->getUserPrincipalName();
    }

    public function clearTokens() {
        if (isset($_SESSION['UserToken'])) unset($_SESSION['UserToken']);
    }

    public function getEmail()
    {
        if(isset($_SESSION['UserToken']))
            return $_SESSION['UserToken']['userEmail'];
        return NULL;
    }

    public function getAccessToken() {
        // Check if tokens exist
        if (
            !isset($_SESSION['UserToken']['accessToken']) ||
            !isset($_SESSION['UserToken']['refreshToken']) ||
            !isset($_SESSION['UserToken']['tokenExpires'])
        )
        {
            return '';
        }

        // Check if token is expired
        //Get current time + 5 minutes (to allow for time differences)
        $now = time() + 300;
        if ($now >= $_SESSION['UserToken']['tokenExpires'])
        {
            // Token is expired (or very close to it)
            // so let's refresh

            // Initialize the OAuth client
            $oauthClient = new \League\OAuth2\Client\Provider\GenericProvider([
                'clientId'                => $this->CI->config->item('USER_OAUTH_APP_ID'),
                'clientSecret'            => $this->CI->config->item('USER_OAUTH_APP_PASSWORD'),
                'redirectUri'             => $this->CI->config->item('USER_OAUTH_REDIRECT_URI'),
                'urlAuthorize'            => $this->CI->config->item('OAUTH_AUTHORITY').$this->CI->config->item('OAUTH_AUTHORIZE_ENDPOINT'),
                'urlAccessToken'          => $this->CI->config->item('OAUTH_AUTHORITY').$this->CI->config->item('OAUTH_TOKEN_ENDPOINT'),
                'urlResourceOwnerDetails' => '',
                'scopes'                  => $this->CI->config->item('USER_OAUTH_SCOPES')
            ]);

            try {
                $newToken = $oauthClient->getAccessToken('refresh_token', [
                    'refresh_token' => $_SESSION['UserToken']['refreshToken']
                ]);

                // Store the new values
                $this->updateTokens($newToken);
                return $newToken->getToken();
            }
            catch (League\OAuth2\Client\Provider\Exception\IdentityProviderException $e) {
                return '';
            }
        }

        return $_SESSION['UserToken']['accessToken'];
    }

    public function updateTokens($accessToken) {
        $_SESSION['UserToken']['accessToken'] = $accessToken->getToken();
        $_SESSION['UserToken']['refreshToken'] = $accessToken->getRefreshToken();
        $_SESSION['UserToken']['tokenExpires'] = $accessToken->getExpires();
    }

    public function isLoggedIn(): bool
	{
        $accessToken = $this->getAccessToken();
        if ( $accessToken === '' || $accessToken === null)
            return false;
        return true;
    }
}

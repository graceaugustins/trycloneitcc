<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Proses_login_model extends CI_Model{
    public function mhs_exists($email)
    {
        $email = trim(strtolower($email));

        $query = $this->db->query(
            "SELECT COUNT(id) AS jumlah FROM users WHERE tipe_user='mahasiswa' AND email=?",
            [$email]
        )->row_array();
        if ((int)$query['jumlah'] > 0)
            return TRUE;
        return FALSE;
    }

	public function itpln_exists($email)
	{
		$email = trim(strtolower($email));

		$query = $this->db->query(
			"SELECT COUNT(id) AS jumlah FROM users WHERE tipe_user='itpln' AND email=?",
			[$email]
		)->row_array();
		if ((int)$query['jumlah'] > 0)
			return TRUE;
		return FALSE;
	}
    public function get_detail_mhs($email)
    {
        $mhs =  $this->db->query(
            "SELECT * FROM users WHERE tipe_user='mahasiswa' AND email=?",
            [$email]
        )->row_array();

        $mhs['aktif'] = $mhs['aktif'] === 'y';
        return $mhs;
    }

	public function get_detail_itpln($email)
	{
		$itpln =  $this->db->query(
			"SELECT * FROM users WHERE tipe_user='itpln' AND email=?",
			[$email]
		)->row_array();

		$itpln['aktif'] = $itpln['aktif'] === 'y';
		return $itpln;
	}

    /*
     * Cek jumlah permintaan pembuatan akun
     * */
    public function count_daftar($email, $time)
    {
        $c = $this->db->query(
            "SELECT COUNT(email) as jumlah FROM limit_action WHERE act='signup' AND email=? AND UNIX_TIMESTAMP(waktu) > ?",
            [(string)$email, (int)$time]
        )->row_array();
        return (int)$c['jumlah'];
    }

    public function count_forgot($email, $time)
    {
        $c = $this->db->query(
            "SELECT COUNT(email) as jumlah FROM limit_action WHERE act='recovery' AND email=? AND UNIX_TIMESTAMP(waktu) > ?",
            [(string)$email, (int)$time]
        )->row_array();
        return (int)$c['jumlah'];
    }

    public function add_action($act, $email)
    {
        $this->db->trans_start();
        $this->db->query(
            "INSERT INTO limit_action(act, email) VALUES (?,?)",
            [(string)$act, (string)$email]
        );
        $this->db->trans_complete();
    }
}

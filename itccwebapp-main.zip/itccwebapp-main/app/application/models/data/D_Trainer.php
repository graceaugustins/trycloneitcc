<?php defined('BASEPATH') OR exit('No direct script access allowed');
class D_Trainer {
	var $id = NULL;
	var $email = "";
	var $nama_lengkap = "";
	var $no_telepon = "";
	var $file_foto = "default.jpg";
	var $aktif = TRUE;

	/**
	 * @var D_Sertifikasi[] $list_sertifikasi
	 **/
	var $list_sertifikasi = NULL;

	/**
	 * @var D_Performa_Trainer[] $performance
	 **/
	var $performance = NULL;
	/**
	 * @var D_Materi_Trainer[] $list_materi
	 **/
	var $list_materi = NULL;

	public function __construct($id_trainer = NULL)
	{
		if ($id_trainer === NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT * FROM trainer WHERE id = ?",
			[(int)$id_trainer]
		)->row_array();
		if (empty($k)) return;
		$this->id = $k['id'];
		$this->email = $k['email'];
		$this->nama_lengkap = $k['nama_lengkap'];
		$this->no_telepon = $k['no_telepon'];
		$this->file_foto = $k['file_foto'];
		$this->aktif = ($k['aktif'] === 'y');
	}

	public function validate_data($create = FALSE): bool
	{
		$errors = [];
		if (!$create && !is_numeric($this->id))
			$errors[] = "ID trainer tidak boleh kosong.";
		if (empty($this->nama_lengkap) || trim($this->nama_lengkap) === '')
			$errors[] = "Nama trainer tidak boleh kosong.";

		$this->no_telepon = (string)$this->no_telepon;
		if (!ctype_digit($this->no_telepon))
			$errors[] = "Nomor telepon tidak valid.";

		$this->email = strtolower(trim($this->email));
		if (filter_var( $this->email, FILTER_VALIDATE_EMAIL) === FALSE )
			$errors[] = "Email tidak valid.";

		foreach ($errors as $err)
		{
			set_warning($err);
		}
		$valid = (count($errors) === 0);
		if ($valid)
		{
			$this->nama_lengkap = ucwords(trim($this->nama_lengkap));
		}
		return $valid;
	}

	public function load_list_program()
	{
		if ($this->list_sertifikasi !== NULL) return;
		if ($this->id === NULL) return;
		$CI =& get_instance();
		$list_id_sertif_program = $CI->db->query(
			"SELECT program_trainer.id_program, program.id_sertif AS id_sertifikasi
			FROM program_trainer
			JOIN program ON program.id = program_trainer.id_program
			WHERE program_trainer.id_trainer = ?",
			[$this->id]
		)->result_array();

		load_data_class('Sertifikasi');
		load_data_class('Program');

		/** @var D_Sertifikasi[] $list_sertifikasi_trainer */
		$list_sertifikasi_trainer = [];

		$list_id_sertif = [];
		foreach($list_id_sertif_program as $row)
		{
			$list_id_sertif[] = (int)$row['id_sertifikasi'];
		}
		$list_id_sertif = array_unique($list_id_sertif);
		foreach ($list_id_sertif as $id)
		{
			$list_sertifikasi_trainer[] = new D_Sertifikasi($id);
		}

		foreach($list_sertifikasi_trainer as $k_sertif => $sertif)
		{
			$id_sertif = $sertif->id;
			$list_row_program = array_filter($list_id_sertif_program, function($row) use ($id_sertif){
				return (int)$row['id_sertifikasi'] === $id_sertif;
			});
			foreach($list_row_program as $row_program)
			{
				$list_sertifikasi_trainer[$k_sertif]->list_program[] = new D_Program($row_program['id_program']);
			}
		}
		$this->list_sertifikasi = $list_sertifikasi_trainer;
	}

	public function load_performance()
	{
		if ($this->list_sertifikasi === NULL) $this->load_list_program();
		$this->performance = [];

		$CI =& get_instance();
		foreach($this->list_sertifikasi as $sertif)
		{
			$performance = new D_Performa_Trainer();
			$performance->id_sertifikasi = $sertif->id;
			foreach($sertif->list_program as $program)
			{
				$performance_program = new D_Program_Performa_Trainer();
				$performance_program->id_program = $program->id;
				$q = $CI->db->query(
					"SELECT COUNT(1) AS jumlah_lulus
					FROM pendaftaran
					JOIN kelompok_t ON kelompok_t.id = pendaftaran.id_kelompok_t
					JOIN program_kegiatan ON program_kegiatan.id = kelompok_t.id_program_kegiatan
					JOIN program ON program_kegiatan.id_program = program.id
					WHERE 
					program_kegiatan.id_program = ? AND 
					pendaftaran.skor_ujian BETWEEN program.min_skor AND program.max_skor AND 
					kelompok_t.id_trainer_sesi1 = ? AND 
					kelompok_t.id_trainer_sesi2 = ?",
					[
						$program->id,
						$this->id,
						$this->id
					]
				)->row_array();
				$q = $q['jumlah_lulus'];
				$performance_program->total_lulus = (int)$q;

				$q = $CI->db->query(
					"SELECT COUNT(1) AS jumlah_tidaklulus
					FROM pendaftaran
					JOIN kelompok_t ON kelompok_t.id = pendaftaran.id_kelompok_t
					JOIN program_kegiatan ON program_kegiatan.id = kelompok_t.id_program_kegiatan
					JOIN program ON program_kegiatan.id_program = program.id
					WHERE 
					program_kegiatan.id_program = ? AND 
					pendaftaran.skor_ujian BETWEEN 0 AND program.min_skor AND 
					kelompok_t.id_trainer_sesi1 = ? AND 
					kelompok_t.id_trainer_sesi2 = ?",
					[
						$program->id,
						$this->id,
						$this->id
					]
				)->row_array();
				$q = $q['jumlah_tidaklulus'];
				$performance_program->total_tidak_lulus = (int)$q;
				$performance->list_program[] = $performance_program;
			}
			$this->performance[] = $performance;
		}
	}

	public function upload_profil($param_name): bool
	{
		$CI =& get_instance();
		$CI->load->library('upload', config_item('UPLOAD_PROFIL_TRAINER'), 'upload_profil');
		if ($CI->upload_profil->do_upload($param_name))
			$this->file_foto = $CI->upload_profil->data('file_name');
		else
			return FALSE;
		return TRUE;
	}

	public function hapus_profil()
	{
		if ($this->file_foto === "default.jpg") return;
		$path = config_item('UPLOAD_PROFIL_TRAINER')['upload_path'].$this->file_foto;
		if (file_exists($path)) unlink($path);
	}

	public function pernah_partisipasi(): bool
	{
		if (empty($this->id)) return FALSE;
		$CI =& get_instance();
		$s = $CI->db->query(
			"SELECT COUNT(id) AS jumlah FROM kelompok_t WHERE id_trainer_sesi1=? OR id_trainer_sesi2=?",
			[$this->id, $this->id]
		)->row_array();
		$s = $s['jumlah'];
		return ((int)$s >0);
	}

	public function load_materi()
	{
		// lazy load
		if (!empty($this->list_materi)) return;
		$CI =& get_instance();
		$s = $CI->db->query(
			"SELECT * FROM materi_training WHERE id_trainer = ?",
			[$this->id]
		)->result_array();
		$this->list_materi = [];
		foreach($s as $materi)
		{
			$m = new D_Materi_Trainer();
			$m->id = (int)$materi['id'];
			$m->id_trainer = (int)$materi['id_trainer'];
			$m->id_program = (int)$materi['id_program'];
			$m->nama_file = $materi['nama_file'];
			$m->deskripsi = $materi['deskripsi'];
			$this->list_materi[] = $m;
		}
	}

	public function get_link_profile(): string
	{
		return base_url(config_item('UPLOAD_PROFIL_TRAINER')['upload_path'].$this->file_foto);
	}
}

class D_Materi_Trainer{
	var $id = NULL;
	var $id_trainer = NULL;
	var $id_program = NULL;
	var $nama_file = "";
	var $deskripsi = "";

	public function get_link_materi(): string
	{
		return base_url('../admin/storage/?type=upload_materi_training&file_name='.$this->nama_file);
	}

	public function hapus_file()
	{
		$path = config_item('UPLOAD_MATERI_TRAINING')['upload_path'].$this->nama_file;
		if (file_exists($path)) unlink($path);
	}

	public function validate_data($mode_create = FALSE): bool
	{
		$errors = [];
		if (!$mode_create && (empty($this->id) ||!is_numeric($this->id)) )
			$errors[] = "ID materi tidak boleh kosong.";
		if (!is_string($this->deskripsi) || trim($this->deskripsi) === '')
			$errors[] = "Deskripsi materi tidak boleh kosong.";
		if (empty($this->id_program))
			$errors[] = "Program tidak valid.";
		if (empty($this->id_trainer))
			$errors[] = "Trainer tidak valid.";
		if (strlen($this->nama_file) === 0)
			$errors[] = "File materi wajib diberikan.";

		foreach ($errors as $err)
		{
			set_warning($err);
		}
		$valid = (count($errors) === 0);
		if ($valid)
		{
			$this->deskripsi = ucfirst(trim($this->deskripsi));
		}
		return $valid;
	}

	public function upload_materi($param_name): bool
	{
		$CI =& get_instance();
		$CI->load->library('upload', config_item('UPLOAD_MATERI_TRAINING'), 'upload_materi');
		if ($CI->upload_materi->do_upload($param_name))
			$this->nama_file = $CI->upload_materi->data('file_name');
		else
			return FALSE;
		return TRUE;
	}
}

class D_Performa_Trainer{
	var $id_sertifikasi = NULL;
	/**
	 * @var D_Program_Performa_Trainer[] $list_program
	 */
	var $list_program = NULL;
}

class D_Program_Performa_Trainer{
	var $id_program = NULL;
	var $total_lulus = 0;
	var $total_tidak_lulus = 0;
}

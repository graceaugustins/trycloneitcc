<?php defined('BASEPATH') OR exit('No direct script access allowed');

class D_User {
	private $max_length_alamat = 200;

	var $id = NULL;
	var $time_registered = NULL;
	var $aktif = TRUE;
	var $tipe_user = General_Constants::UMUM;

	var $nama_depan = "";
	var $nama_belakang = "";
	var $jenis_kelamin = General_Constants::LAKI_LAKI;

	var $email = "";
	var $password = "";
	var $angkatan = "";
	var $jurusan = "";

	var $nim = "";
	var $nik = "";
	var $alamat = "";
	var $no_telepon = "";
	var $id_line = NULL;
	var $id_telegram = NULL;
	var $file_ktm = "";
	var $file_ktp = "";
	var $file_fotoprofil = "";
	var $id_jabatan = NULL;

	/** @var D_Jabatan_User_ITPLN $jabatan */
	var $jabatan = NULL;

	var $username_certiport = NULL;
	var $password_certiport = NULL;

	/** @var D_Instansi_User[] $list_instansi */
	var $list_instansi = NULL;

	public function __construct($id_user = NULL)
	{
		if ($id_user === NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT * FROM users WHERE id = ?",
			[(int)$id_user]
		)->row_array();
		if (empty($k)) return;
		$this->id = $k['id'];
		$this->time_registered = $k['time_registered'];
		$this->aktif = ($k['aktif'] === 'y');
		$this->tipe_user = $k['tipe_user'];
		$this->nama_depan = $k['nama_depan'];
		$this->nama_belakang = $k['nama_belakang'];
		$this->jenis_kelamin = $k['jenis_kelamin'];
		$this->email = $k['email'];
		$this->password = $k['user_pass'];
		$this->angkatan = $k['angkatan'];
		$this->jurusan = $k['jurusan'];
		$this->nim = $k['nim'];
		$this->nik = $k['nik'];
		$this->alamat = $k['alamat'];
		$this->no_telepon = $k['no_telepon'];
		$this->id_line = $k['id_line'];
		$this->id_telegram = $k['id_telegram'];
		$this->file_ktm = $k['file_ktm'];
		$this->file_ktp = $k['file_ktp'];
		$this->file_fotoprofil = $k['file_fotoprofil'];
		$this->id_jabatan = $k['id_jabatan'];
		$this->username_certiport = $k['username_certiport'];
		$this->password_certiport = $k['password_certiport'];
	}

	public function load_jabatan()
	{
		if ($this->id_jabatan === NULL) return;
		if ($this->jabatan !== NULL) return;
		$this->jabatan = new D_Jabatan_User_ITPLN($this->id_jabatan);
	}

	public function validate_data($mode_create = FALSE): bool
	{
		$errors = [];
		if (!$mode_create && (empty($this->id) ||!is_numeric($this->id)) )
			$errors[] = "ID user tidak boleh kosong.";
		if (!is_string($this->email) || filter_var($this->email, FILTER_VALIDATE_EMAIL) === FALSE)
			$errors[] = "Email tidak boleh kosong.";
		if (!is_string($this->nama_depan) || trim($this->nama_depan) === '')
			$errors[] = "Nama depan tidak boleh kosong.";
		if (!is_string($this->nama_belakang) || trim($this->nama_belakang) === '')
			$errors[] = "Nama belakang tidak boleh kosong.";
		if (
			!in_array(
				$this->tipe_user,
				[
					General_Constants::UMUM,
					General_Constants::ITPLN,
					General_Constants::MAHASISWA
				]
			)
		)
			$errors[] = 'Tipe user tidak valid.';
		if (!in_array($this->jenis_kelamin, [General_Constants::LAKI_LAKI, General_Constants::PEREMPUAN]))
			$errors[] = 'Jenis kelamin tidak valid.';

		if (!is_string($this->alamat) || trim($this->alamat) === '')
			$errors[] = "Alamat tidak boleh kosong.";

		if (is_string($this->alamat) && strlen(trim($this->alamat)) > $this->max_length_alamat)
			$errors[] = "Alamat tidak boleh melebihi ".$this->max_length_alamat." karakter.";

		if (!ctype_digit($this->no_telepon))
			$errors[] = "Nomor telepon tidak valid.";

		if (strlen($this->file_fotoprofil) === 0)
			$errors[] = "Foto tidak boleh kosong.";

		if ($this->tipe_user === General_Constants::MAHASISWA)
		{
			if (!ctype_digit($this->nim) || strlen($this->nim) !== 9)
				$errors[] = "NIM tidak valid.";
			else{
				$this->angkatan = substr($this->nim, 0, 4);
				$this->jurusan = substr($this->nim, 4, 2);
				$CI =& get_instance();
				$list_jurusan = array_keys((array)$CI->config->item("JURUSAN"));
				if (!in_array($this->jurusan, $list_jurusan))
					$errors[] = "Kode jurusan tidak valid.";
			}

			if (strlen($this->file_ktm) === 0)
				$errors[] = "Foto KTM tidak boleh kosong.";
		}
		elseif ($this->tipe_user === General_Constants::UMUM)
		{
			if (!ctype_digit($this->nik) || strlen($this->nik) !== 16)
			{
				$errors[] = "NIK tidak valid.";
			}
			if (strlen($this->file_ktp) === 0)
				$errors[] = "Foto KTP tidak boleh kosong.";
		}
		elseif ($this->tipe_user === General_Constants::ITPLN)
		{
			if (!ctype_digit($this->nik))
			{
				$errors[] = "NIK/NIDN tidak valid.";
			}
			if (is_numeric($this->id_jabatan))
			{
				$CI =& get_instance();
				$CI->load->model('m_user');
				if ($CI->m_user->is_id_jabatan_exists($this->id_jabatan) === FALSE)
					$errors[] = "Jabatan tidak valid.";
			}
			else $errors[] = "Jabatan wajib diberikan.";

		}

		foreach ($errors as $err)
		{
			set_warning($err);
		}
		$valid = (count($errors) === 0);
		if ($valid)
		{
			$this->nama_depan = trim($this->nama_depan);
			$this->nama_belakang = trim($this->nama_belakang);
			$this->alamat = trim($this->alamat);
		}
		return $valid;
	}

	public function upload_profil($param_name): bool
	{
		$CI =& get_instance();
		$CI->load->library('upload', config_item('UPLOAD_FOTO_PROFIL'), 'upload_profil');
		if ($CI->upload_profil->do_upload($param_name))
			$this->file_fotoprofil = $CI->upload_profil->data('file_name');
		else
			return FALSE;
		return TRUE;
	}

	public function hapus_profil()
	{
		$path = config_item('UPLOAD_FOTO_PROFIL')['upload_path'].$this->file_fotoprofil;
		if (file_exists($path)) unlink($path);
	}

	public function get_link_profile(): string
	{
		return base_url(config_item('UPLOAD_FOTO_PROFIL')['upload_path'].$this->file_fotoprofil);
	}

	public function upload_ktm($param_name): bool
	{
		$CI =& get_instance();
		$CI->load->library('upload', config_item('UPLOAD_KTM'), 'upload_ktm');
		if ($CI->upload_ktm->do_upload($param_name))
			$this->file_ktm = $CI->upload_ktm->data('file_name');
		else
			return FALSE;
		return TRUE;
	}

	public function hapus_ktm()
	{
		$path = config_item('UPLOAD_KTM')['upload_path'].$this->file_ktm;
		if (file_exists($path)) unlink($path);
	}

	public function get_link_ktm(): string
	{
		return base_url(config_item('UPLOAD_KTM')['upload_path'].$this->file_ktm);
	}

	public function upload_ktp($param_name): bool
	{
		$CI =& get_instance();
		$CI->load->library('upload', config_item('UPLOAD_KTP'), 'upload_ktp');
		if ($CI->upload_ktp->do_upload($param_name))
			$this->file_ktp = $CI->upload_ktp->data('file_name');
		else
			return FALSE;
		return TRUE;
	}

	public function hapus_ktp()
	{
		$path = config_item('UPLOAD_KTP')['upload_path'].$this->file_ktp;
		if (file_exists($path)) unlink($path);
	}

	public function get_link_ktp(): string
	{
		return base_url(config_item('UPLOAD_KTP')['upload_path'].$this->file_ktp);
	}

	public function load_list_instansi()
	{
		if (empty($this->id)) return;
		if ($this->list_instansi !== NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT instansi.* FROM instansi_user 
			JOIN instansi ON instansi.id = instansi_user.id_instansi
			WHERE instansi_user.id_user = ?",
			[$this->id]
		)->result_array();
		$this->list_instansi = [];
		foreach($k as $result)
		{
			$instansi = new D_Instansi_User();
			$instansi->id = $result['id'];
			$instansi->nama = $result['nama'];
			$instansi->alamat = $result['alamat'];
			$instansi->no_telepon = $result['no_telepon'];
			$this->list_instansi[] = $instansi;
		}
	}

}

class D_Instansi_User{
	var $id = NULL;
	var $nama = "";
	var $alamat = "";
	var $no_telepon = "";
}

class D_Info_User{
	var $id = NULL;
	var $id_user = NULL;
	var $waktu = NULL;
	var $info = "";
	var $display = TRUE;
}

class D_Kegiatan_User{
	var $id = NULL;
	var $waktu = NULL;
	var $id_user = NULL;
	var $id_kegiatan = NULL;
	var $id_program_kegiatan = NULL;
	var $jenis = General_Constants::TRAINING_DAN_UJIAN;
	var $diskon = 0;
	var $approved = FALSE;

	var $id_program = NULL;
	/** @var D_Program $program */
	var $program = NULL;

	/** @var D_Pembayaran_Kegiatan[] $list_bukti_bayar */
	var $list_bukti_bayar = NULL;

	var $id_kelompok_t = NULL;
	/** @var D_Kelompok_T $kelompok_t */
	var $kelompok_t = NULL;
	var $hadir_training_sesi1 = FALSE;
	var $hadir_training_sesi2 = FALSE;

	var $id_kelompok_u = NULL;
	/** @var D_Kelompok_U $kelompok_u */
	var $kelompok_u = NULL;
	var $hadir_ujian = FALSE;
	var $skor_ujian = -1;

	var $status_kelulusan = General_Constants::STATUS_PENDING;

	/** @var D_Kegiatan $kegiatan */
	var $kegiatan = NULL;
	/** @var D_User $user */
	var	$user = NULL;

	/** @var D_Sertifikat_Keikutsertaan $sertifikat_keikutsertaan */
	var	$sertifikat_keikutsertaan = NULL;

	public function __construct($id = NULL)
	{
		if ($id === NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT pendaftaran.*, program_kegiatan.id_program,
				   	program.min_skor,
					program.max_skor
			FROM pendaftaran 
			JOIN program_kegiatan ON program_kegiatan.id = pendaftaran.id_program_kegiatan
			JOIN program ON program_kegiatan.id_program = program.id
			WHERE pendaftaran.id=?",
			[(int)$id]
		)->row_array();
		if (empty($k)) return;
		$this->surface_fill_from_db($k);
	}

	public function load_kegiatan()
	{
		if ($this->id_kegiatan === NULL) return;
		if ($this->kegiatan !== NULL) return;
		load_data_class('Kegiatan');
		$this->kegiatan = new D_Kegiatan($this->id_kegiatan);
	}

	public function load_kelompok_t()
	{
		if ($this->id_kelompok_t === NULL) return;
		if ($this->kelompok_t !== NULL) return;
		load_data_class('Kelompok_T');
		$this->kelompok_t = new D_Kelompok_T($this->id_kelompok_t);
	}

	public function load_kelompok_u()
	{
		if ($this->id_kelompok_u === NULL) return;
		if ($this->kelompok_u !== NULL) return;
		load_data_class('Kelompok_U');
		$this->kelompok_u = new D_Kelompok_U($this->id_kelompok_u);
	}

	public function load_list_pembayaran()
	{
		if ($this->id === NULL) return;
		if ($this->list_bukti_bayar !== NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT 
			bukti_bayar.*, 
			users.nim, 
			users.nama_depan, 
			users.nama_belakang, 
			users.angkatan, 
			users.email, 
			users.jurusan,
			pendaftaran.id_user
			FROM bukti_bayar 
			JOIN pendaftaran ON bukti_bayar.id_pendaftaran = pendaftaran.id
			JOIN users ON pendaftaran.id_user = users.id
			WHERE pendaftaran.id=?
			ORDER BY bukti_bayar.waktu DESC",
			[$this->id]
		)->result_array();
		load_data_class('Kegiatan');
		$this->list_bukti_bayar = [];
		foreach($k as $list)
		{
			$bukti = new D_Pembayaran_Kegiatan();
			$bukti->surface_fill_data_from_db_result($list);
			$this->list_bukti_bayar[] = $bukti;
		}
	}

	public function surface_fill_from_db($q)
	{
		$this->id = $q['id'];
		$this->waktu = $q['waktu'];
		$this->id_user = $q['id_user'];
		$this->id_kegiatan = $q['id_kegiatan'];
		$this->id_program = $q['id_program'];
		$this->id_program_kegiatan = $q['id_program_kegiatan'];
		$this->jenis = $q['jenis'];
		$this->diskon = (int)$q['diskon'];
		$this->approved = ($q['approved'] === 'y');
		$this->id_kelompok_t = $q['id_kelompok_t'];
		$this->id_kelompok_u = $q['id_kelompok_u'];
		$this->hadir_training_sesi1 = ($q['hadir_training_sesi1'] === 'y');
		$this->hadir_training_sesi2 = ($q['hadir_training_sesi2'] === 'y');
		$this->hadir_ujian = ($q['hadir_ujian'] === 'y');
		$this->skor_ujian = (int)$q['skor_ujian'];
		$min_skor = (int)$q['min_skor'];
		$max_skor = (int)$q['max_skor'];
		if ($this->skor_ujian === -1)
			$this->status_kelulusan = General_Constants::STATUS_PENDING;
		elseif($this->skor_ujian < $min_skor)
			$this->status_kelulusan = General_Constants::STATUS_TIDAK_LULUS;
		else $this->status_kelulusan = General_Constants::STATUS_LULUS;
	}

	public function load_program()
	{
		if ($this->id_program === NULL) return;
		if ($this->program !== NULL) return;
		load_data_class('Program');
		$this->program = new D_Program($this->id_program);
	}

	public function load_user()
	{
		if (empty($this->id) || empty($this->id_user)) return;
		if ($this->user !== NULL) return;
		$this->user = new D_User($this->id_user);
	}

}

class D_Sertifikat_Keikutsertaan{
	var $id = NULL;
	/** @var DateTime $tanggal_terbit */
	var $tanggal_terbit = NULL;
	var $kode = "";

	var $id_pendaftaran = NULL;
	/** @var D_Kegiatan_User $pendaftaran */
	var $pendaftaran = NULL;

	public function __construct($id = NULL)
	{
		if ($id === NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT * FROM sertifikat_keikutsertaan WHERE id = ?",
			[(int)$id]
		)->row_array();
		if (empty($k)) return;
		$this->surface_fill_from_db($k);
	}

	public function surface_fill_from_db($k)
	{
		$this->id = $k['id'];
		$this->id_pendaftaran = $k['id_pendaftaran'];
		$this->tanggal_terbit = DateTime::createFromFormat('Y-m-d H:i:s', $k['tanggal_terbit']);
		$this->kode = $k['kode'];
	}

	public function load_pendaftaran()
	{
		if (empty($this->id) || empty($this->id_pendaftaran)) return;
		if ($this->pendaftaran !== NULL) return;
		$this->pendaftaran = new D_Kegiatan_User($this->id_pendaftaran);
	}
}

class D_Bidang_User_ITPLN{
	var $id = NULL;
	var $nama_bidang = '';
	/** @var D_Jabatan_User_ITPLN[] $list_jabatan */
	var $list_jabatan = NULL;

	public function __construct($id = NULL)
	{
		if ($id === NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT * FROM bidang_itpln WHERE id = ?",
			[$id]
		)->row_array();
		if (empty($k)) return;
		$this->surface_fill_from_db($k);
	}

	public function validate_data($mode_create = FALSE): bool
	{
		if ($mode_create && !empty($this->id)) return FALSE;
		if (!$mode_create && $this->id === NULL) return FALSE;
		$errors = [];
		if (!is_string($this->nama_bidang) || trim($this->nama_bidang) === "")
		{
			$errors[] = "Nama bidang tidak valid.";
		}
		foreach ($errors as $e) {
			set_warning($e);
		}
		$valid = count($errors) === 0;
		if ($valid)
		{
			$this->nama_bidang = trim($this->nama_bidang);
		}
		return $valid;
	}

	public function surface_fill_from_db($k)
	{
		$this->id = $k['id'];
		$this->nama_bidang = $k['nama_bidang'];
	}

	public function load_list_jabatan()
	{
		if ($this->id === NULL) return;
		if ($this->list_jabatan !== NULL) return;
		$CI =& get_instance();
		$query = $CI->db->query(
			"SELECT jabatan_itpln.*, bidang_itpln.nama_bidang 
			FROM jabatan_itpln
			JOIN bidang_itpln ON bidang_itpln.id = jabatan_itpln.id_bidang
			WHERE bidang_itpln.id = ?",
			[$this->id]
		)->result_array();
		$this->list_jabatan = [];
		foreach ($query as $result) {
			$jabatan = new D_Jabatan_User_ITPLN();
			$jabatan->surface_fill_from_db($result);
			$this->list_jabatan[] = $jabatan;
		}
	}
}

class D_Jabatan_User_ITPLN{
	var $id = NULL;
	var $id_bidang = NULL;
	var $nama_bidang = '';
	var $nama_jabatan = '';

	public function validate_data($mode_create = FALSE): bool
	{
		if ($mode_create && !empty($this->id)) return FALSE;
		if (!$mode_create && $this->id === NULL) return FALSE;
		$errors = [];
		if ($this->id_bidang === NULL)
		{
			$errors[] = "Bidang tidak boleh kosong.";
		}
		$CI =& get_instance();
		$CI->load->model('m_user');
		if ($this->id_bidang !== NULL)
		{
			if ($CI->m_user->is_id_bidang_exists($this->id_bidang) === FALSE)
			{
				$errors[] = "Bidang yang dipilih tidak valid.";
			}
		}
		if (!is_string($this->nama_jabatan) || trim($this->nama_jabatan) === "")
		{
			$errors[] = "Nama jabatan tidak valid.";
		}
		foreach ($errors as $e) {
			set_warning($e);
		}
		$valid = count($errors) === 0;
		if ($valid)
		{
			$this->nama_bidang = trim($this->nama_bidang);
		}
		return $valid;
	}

	public function __construct($id = NULL)
	{
		if ($id === NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT jabatan_itpln.*, bidang_itpln.nama_bidang 
			FROM jabatan_itpln
			JOIN bidang_itpln ON bidang_itpln.id = jabatan_itpln.id_bidang
			WHERE jabatan_itpln.id = ?",
			[$id]
		)->row_array();
		if (empty($k)) return;
		$this->surface_fill_from_db($k);
	}

	public function surface_fill_from_db($k)
	{
		$this->id = $k['id'];
		$this->id_bidang = $k['id_bidang'];
		$this->nama_bidang = $k['nama_bidang'];
		$this->nama_jabatan = $k['nama_jabatan'];
	}
}

<?php defined('BASEPATH') OR exit('No direct script access allowed');
class D_Proctor {
	var $id = NULL;
	var $email = "";
	var $nama_lengkap = "";
	var $no_telepon = "";
	var $file_foto = "default.jpg";
	var $aktif = TRUE;

	/**
	 * @var D_Sertifikasi[] $list_sertifikasi
	 **/
	var $list_sertifikasi = NULL;

	public function __construct($id_proctor = NULL)
	{
		if ($id_proctor === NULL) return;
		$CI =& get_instance();
		$k = $CI->db->query(
			"SELECT * FROM proctor WHERE id = ?",
			[(int)$id_proctor]
		)->row_array();
		if (empty($k)) return;
		$this->id = $k['id'];
		$this->email = $k['email'];
		$this->nama_lengkap = $k['nama_lengkap'];
		$this->no_telepon = $k['no_telepon'];
		$this->file_foto = $k['file_foto'];
		$this->aktif = ($k['aktif'] === 'y');
	}

	public function validate_data($create = FALSE): bool
	{
		$errors = [];
		if (!$create && !is_numeric($this->id))
			$errors[] = "ID trainer tidak boleh kosong.";
		if (empty($this->nama_lengkap) || trim($this->nama_lengkap) === '')
			$errors[] = "Nama trainer tidak boleh kosong.";

		$this->no_telepon = (string)$this->no_telepon;
		if (!ctype_digit($this->no_telepon))
			$errors[] = "Nomor telepon tidak valid.";

		$this->email = strtolower(trim($this->email));
		if (filter_var( $this->email, FILTER_VALIDATE_EMAIL) === FALSE )
			$errors[] = "Email tidak valid.";

		foreach ($errors as $err)
		{
			set_warning($err);
		}
		$valid = (count($errors) === 0);
		if ($valid)
		{
			$this->nama_lengkap = ucwords(trim($this->nama_lengkap));
		}
		return $valid;
	}

	public function load_list_sertifikasi()
	{
		if ($this->list_sertifikasi !== NULL) return;
		if ($this->id === NULL) return;
		$CI =& get_instance();
		$list_id_sertif = $CI->db->query(
			"SELECT id_sertifikasi
			FROM sertifikasi_proctor
			WHERE id_proctor=?",
			[$this->id]
		)->result_array();

		load_data_class('Sertifikasi');
		$this->list_sertifikasi = [];
		foreach($list_id_sertif as $id)
		{
			$s = new D_Sertifikasi($id['id_sertifikasi']);
			$this->list_sertifikasi[] = $s;
		}
	}

	public function upload_profil($param_name): bool
	{
		$CI =& get_instance();
		$CI->load->library('upload', config_item('UPLOAD_PROFIL_PROCTOR'), 'upload_profil');
		if ($CI->upload_profil->do_upload($param_name))
			$this->file_foto = $CI->upload_profil->data('file_name');
		else
			return FALSE;
		return TRUE;
	}

	public function hapus_profil()
	{
		if ($this->file_foto === "default.jpg") return;
		$path = config_item('UPLOAD_PROFIL_PROCTOR')['upload_path'].$this->file_foto;
		if (file_exists($path)) unlink($path);
	}

	public function pernah_partisipasi(): bool
	{
		if (empty($this->id)) return FALSE;
		$CI =& get_instance();
		$t = $CI->db->query(
			"SELECT COUNT(1) AS jumlah 
			FROM kelompok_t 
			WHERE id_proctor_training=?",
			[$this->id]
		)->row_array();
		$u = $CI->db->query(
			"SELECT COUNT(1) AS jumlah 
			FROM kelompok_u 
			WHERE id_proctor_ujian=?",
			[$this->id]
		)->row_array();
		$t = $t['jumlah'];
		$u = $u['jumlah'];
		return ((int)$t + (int)$u) > 0;
	}

	public function get_link_profile(): string
	{
		return base_url(config_item('UPLOAD_PROFIL_PROCTOR')['upload_path'].$this->file_foto);
	}
}

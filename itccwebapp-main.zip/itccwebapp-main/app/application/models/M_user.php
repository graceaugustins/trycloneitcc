<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_user extends CI_Model{

	public function is_id_user_exists($id) : bool
	{
		$query = $this->db->query("SELECT COUNT(1) AS jumlah
			FROM users WHERE id=?",
			[(int)$id]
		)->row_array();
		return ((int)$query['jumlah']>0);
	}

	public function is_email_user_exists($email): bool
	{
		$query = $this->db->query("SELECT COUNT(1) AS jumlah
			FROM users WHERE email=?",
			[$email]
		)->row_array();
		return ((int)$query['jumlah']>0);
	}

	public function add_new_user(D_User $user)
	{
		if (!empty($user->id)) return FALSE;
		if (!$user->validate_data(true)) return FALSE;
		$this->db->trans_start();
		if ($user->tipe_user === General_Constants::MAHASISWA)
		{
			$this->db->query(
				"INSERT INTO users 
    			(
    			 tipe_user,
    			 nama_depan, 
    			 nama_belakang, 
    			 jenis_kelamin, 
    			 email,
    			 angkatan,
    			 jurusan,
    			 nim,
    			 alamat,
    			 no_telepon,
				 file_ktm,
    			 file_fotoprofil,
    			 username_certiport,
    			 password_certiport
			 	) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
				[
					General_Constants::MAHASISWA,
					strtoupper($user->nama_depan),
					strtoupper($user->nama_belakang),
					$user->jenis_kelamin,
					$user->email,
					$user->angkatan,
					$user->jurusan,
					$user->nim,
					$user->alamat,
					$user->no_telepon,
					$user->file_ktm,
					$user->file_fotoprofil,
					$user->username_certiport,
					$user->password_certiport
				]
			);
			$user->id = (int)$this->db->insert_id();
		}
		elseif ($user->tipe_user === General_Constants::UMUM)
		{
			$this->db->query(
				"INSERT INTO users 
    			(
    			 tipe_user,
    			 nama_depan, 
    			 nama_belakang, 
    			 jenis_kelamin, 
    			 email,
    			 user_pass,
    			 nik,
    			 alamat,
    			 no_telepon,
				 file_ktp,
    			 file_fotoprofil,
    			 username_certiport,
    			 password_certiport
			 	) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
				[
					General_Constants::UMUM,
					strtoupper($user->nama_depan),
					strtoupper($user->nama_belakang),
					$user->jenis_kelamin,
					$user->email,
					$user->password,
					$user->nik,
					$user->alamat,
					$user->no_telepon,
					$user->file_ktp,
					$user->file_fotoprofil,
					$user->username_certiport,
					$user->password_certiport
				]
			);
			$user->id = (int)$this->db->insert_id();
			if (!empty($user->id_line))
				$this->db->query(
					"UPDATE users SET id_line = ? WHERE id = ?",
					[
						$user->id_line,
						$user->id
					]
				);
			if (!empty($user->id_telegram))
				$this->db->query(
					"UPDATE users SET id_telegram = ? WHERE id = ?",
					[
						$user->id_telegram,
						$user->id
					]
				);
		}
		elseif ($user->tipe_user === General_Constants::ITPLN)
		{
			$this->db->query(
				"INSERT INTO users 
    			(
    			 tipe_user,
    			 nama_depan, 
    			 nama_belakang, 
    			 jenis_kelamin, 
    			 email,
    			 nik,
    			 alamat,
    			 no_telepon,
    			 file_fotoprofil,
    			 id_jabatan
			 	) VALUES (?,?,?,?,?,?,?,?,?,?)",
				[
					General_Constants::ITPLN,
					strtoupper($user->nama_depan),
					strtoupper($user->nama_belakang),
					$user->jenis_kelamin,
					$user->email,
					$user->nik,
					$user->alamat,
					$user->no_telepon,
					$user->file_fotoprofil,
					$user->id_jabatan
				]
			);
			$user->id = (int)$this->db->insert_id();
		}
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function is_id_instansi_exists($id) : bool
	{
		$query = $this->db->query("SELECT COUNT(1) AS jumlah
			FROM instansi WHERE id=?",
			[(int)$id]
		)->row_array();
		return ((int)$query['jumlah']>0);
	}


	/**
	 * @return D_Kegiatan_User[]
	 * */
	public function get_list_pendaftaran_belum_approve(D_User $user): array
	{
		$sekarang = new DateTime();
		$q = $this->db->query(
			"SELECT pendaftaran.*, program_kegiatan.id_program,
       				program.min_skor,
					program.max_skor
            FROM pendaftaran
			JOIN kegiatan ON kegiatan.id = pendaftaran.id_kegiatan
			JOIN program_kegiatan ON pendaftaran.id_program_kegiatan = program_kegiatan.id
			JOIN program ON program_kegiatan.id_program = program.id
			WHERE pendaftaran.id_user = ? AND  kegiatan.batal = 'n' AND ?  < kegiatan.akhir_pelaporan AND pendaftaran.approved = 'n'
            ORDER BY pendaftaran.waktu DESC",
			[
				$user->id,
				$sekarang->format('Y-m-d H:i:s')
			]
		)->result_array();
		load_data_class('User');
		$result = [];
		foreach($q as $list)
		{
			$data = new D_Kegiatan_User();
			$data->surface_fill_from_db($list);
			$result[] = $data;
		}
		return $result;
	}

	/**
	 * @return D_Kegiatan_User[]
	 * */
	public function get_list_pendaftaran_user(D_User $user): array
	{
		$q = $this->db->query(
			"SELECT pendaftaran.*, program_kegiatan.id_program,
      			 	program.min_skor,
					program.max_skor
            FROM pendaftaran
			JOIN kegiatan ON kegiatan.id = pendaftaran.id_kegiatan
			JOIN program_kegiatan ON pendaftaran.id_program_kegiatan = program_kegiatan.id
			JOIN program ON program_kegiatan.id_program = program.id
			WHERE pendaftaran.id_user = ?
            ORDER BY pendaftaran.waktu DESC",
			[
				$user->id
			]
		)->result_array();
		load_data_class('User');
		$result = [];
		foreach($q as $list)
		{
			$data = new D_Kegiatan_User();
			$data->surface_fill_from_db($list);
			$result[] = $data;
		}
		return $result;
	}

	/**
	 * @param $id
	 * @return D_Kegiatan_User
	 */
	public function get_pendaftaran_user_by_id($id): D_Kegiatan_User
	{
		$q = $this->db->query(
			"SELECT pendaftaran.*, program_kegiatan.id_program,
				   	program.min_skor,
					program.max_skor
            FROM pendaftaran
			JOIN kegiatan ON kegiatan.id = pendaftaran.id_kegiatan
			JOIN program_kegiatan ON pendaftaran.id_program_kegiatan = program_kegiatan.id
			JOIN program ON program_kegiatan.id_program = program.id
			WHERE pendaftaran.id = ?
            ORDER BY pendaftaran.waktu DESC",
			[
				$id
			]
		)->row_array();
		load_data_class('User');
		$data = new D_Kegiatan_User();
		$data->surface_fill_from_db($q);
		return $data;
	}

	/**
	 * @return D_Kegiatan_User[]
	 * */
	public function get_list_pendaftaran_sedang_berjalan(D_User $user): array
	{
		$sekarang = new DateTime();
		$q = $this->db->query(
			"SELECT pendaftaran.*, program_kegiatan.id_program,
				   	program.min_skor,
					program.max_skor,
					kegiatan.akhir_pelaporan,
					MAX(kelompok_u.selesai_ujian) AS selesai,
					COUNT(kelompok_u.id) AS jumlah_kelompok_u
			FROM pendaftaran 
			JOIN kegiatan ON kegiatan.id = pendaftaran.id_kegiatan
			JOIN program_kegiatan ON program_kegiatan.id = pendaftaran.id_program_kegiatan
			JOIN program ON program_kegiatan.id_program = program.id
			LEFT JOIN kelompok_u ON kelompok_u.id_kegiatan = kegiatan.id
			WHERE pendaftaran.id_user=? AND kegiatan.batal='n' AND pendaftaran.approved='y'
			GROUP BY kegiatan.id
			HAVING ? < selesai OR (jumlah_kelompok_u=0 AND ? < kegiatan.akhir_pelaporan)
			ORDER BY pendaftaran.waktu DESC",
			[
				$user->id,
				$sekarang->format('Y-m-d H:i:s'),
				$sekarang->format('Y-m-d H:i:s')
			]
		)->result_array();
		load_data_class('User');
		$result = [];
		foreach($q as $list)
		{
			$data = new D_Kegiatan_User();
			$data->surface_fill_from_db($list);
			$result[] = $data;
		}
		return $result;
	}

	/**
	 * @return D_Kegiatan_User[]
	 * */
	public function get_list_pendaftaran_sudah_dilaksanakan(D_User $user): array
	{
		$sekarang = new DateTime();
		$q = $this->db->query(
			"SELECT pendaftaran.*, program_kegiatan.id_program,
				   	program.min_skor,
					program.max_skor,
					kegiatan.akhir_pelaporan,
					MAX(kelompok_u.selesai_ujian) AS selesai
			FROM pendaftaran 
			JOIN kegiatan ON kegiatan.id = pendaftaran.id_kegiatan
			JOIN program_kegiatan ON program_kegiatan.id = pendaftaran.id_program_kegiatan
			JOIN program ON program_kegiatan.id_program = program.id
			LEFT JOIN kelompok_u ON kelompok_u.id_kegiatan = kegiatan.id
			WHERE pendaftaran.id_user=? AND kegiatan.batal='n' AND pendaftaran.approved='y'
			GROUP BY kegiatan.id
			HAVING ? >= selesai
			ORDER BY pendaftaran.waktu DESC",
			[
				$user->id,
				$sekarang->format('Y-m-d H:i:s')
			]
		)->result_array();
		load_data_class('User');
		$result = [];
		foreach($q as $list)
		{
			$data = new D_Kegiatan_User();
			$data->surface_fill_from_db($list);
			$result[] = $data;
		}
		return $result;
	}

	/**
	 * @return D_Kegiatan_User[]
	 * */
	public function get_list_pendaftaran_dibatalkan(D_User $user): array
	{
		$q = $this->db->query(
			"SELECT pendaftaran.*, program_kegiatan.id_program,
				   	program.min_skor,
					program.max_skor,
					kegiatan.akhir_pelaporan
			FROM pendaftaran 
			JOIN kegiatan ON kegiatan.id = pendaftaran.id_kegiatan
			JOIN program_kegiatan ON program_kegiatan.id = pendaftaran.id_program_kegiatan
			JOIN program ON program_kegiatan.id_program = program.id
			WHERE pendaftaran.id_user=? AND kegiatan.batal='y'
			ORDER BY pendaftaran.waktu DESC",
			[
				$user->id
			]
		)->result_array();
		load_data_class('User');
		$result = [];
		foreach($q as $list)
		{
			$data = new D_Kegiatan_User();
			$data->surface_fill_from_db($list);
			$result[] = $data;
		}
		return $result;
	}

	/**
	 * @return D_Sertifikat_Keikutsertaan[]
	 * */
	public function get_list_pendaftaran_punya_ecerts(D_User $user): array
	{
		$q = $this->db->query(
			"SELECT sertifikat_keikutsertaan.*
			FROM sertifikat_keikutsertaan
			JOIN pendaftaran ON pendaftaran.id=sertifikat_keikutsertaan.id_pendaftaran
			WHERE pendaftaran.id_user = ?
			ORDER BY pendaftaran.waktu DESC",
			[
				$user->id
			]
		)->result_array();
		load_data_class('User');
		$result = [];
		foreach($q as $list)
		{
			$data = new D_Sertifikat_Keikutsertaan();
			$data->surface_fill_from_db($list);
			$result[] = $data;
		}
		return $result;
	}

	public function update_kelompok_t_u_pendaftaran(D_Kegiatan_User $pendaftaran): bool
	{
		if (empty($pendaftaran->id)) return FALSE;

		$this->db->trans_start();
		$this->db->query(
			"UPDATE pendaftaran SET 
    		id_kelompok_t = ?, 
    		id_kelompok_u = ?
    		WHERE id = ?",
			[
				$pendaftaran->id_kelompok_t,
				$pendaftaran->id_kelompok_u,
				$pendaftaran->id,
			]
		);
		$this->db->trans_complete();
		return $this->db->trans_status();
	}

	public function is_id_ecert_exists($id) : bool
	{
		$query = $this->db->query("SELECT COUNT(1) AS jumlah
			FROM sertifikat_keikutsertaan WHERE id=?",
			[(int)$id]
		)->row_array();
		return ((int)$query['jumlah']>0);
	}

	public function is_id_bidang_exists($id): bool
	{
		$query = $this->db->query("SELECT COUNT(1) AS jumlah
			FROM bidang_itpln WHERE id=?",
			[(int)$id]
		)->row_array();
		return ((int)$query['jumlah']>0);
	}

	public function is_id_jabatan_exists($id): bool
	{
		$query = $this->db->query("SELECT COUNT(1) AS jumlah
			FROM jabatan_itpln WHERE id=?",
			[(int)$id]
		)->row_array();
		return ((int)$query['jumlah']>0);
	}

	/**
	 * @return D_Bidang_User_ITPLN[]
	 * */
	public function get_list_bidang(): array
	{
		$query = $this->db->query(
			"SELECT * FROM bidang_itpln"
		)->result_array();
		load_data_class('User');
		$result = [];
		foreach($query as $r)
		{
			$bidang = new D_Bidang_User_ITPLN();
			$bidang->surface_fill_from_db($r);
			$result[] = $bidang;
		}
		return $result;
	}
}

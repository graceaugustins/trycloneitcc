<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Ecerts_model extends CI_Model{

    public function get_ecerts($id_user)
    {
        $result = $this->db->query(
            "SELECT sertifikat_keikutsertaan.*, pendaftaran.id_kegiatan, pendaftaran.id_program_kegiatan
            FROM sertifikat_keikutsertaan
            JOIN pendaftaran ON sertifikat_keikutsertaan.id_pendaftaran = pendaftaran.id
            WHERE pendaftaran.id_user=?",
            [(int)$id_user]
        )->result_array();
        foreach ($result as $k_r => $r)
        {
            $result[$k_r]['pendaftaran'] = $this->db->query(
                "SELECT * FROM pendaftaran WHERE id=?",
                [(int)$r['id_pendaftaran']]
            )->row_array();
        }
        foreach ($result as $k_r => $r)
        {
            $result[$k_r]['kegiatan'] = $this->db->query(
                "SELECT * FROM kegiatan WHERE id=?",
                [(int)$r['pendaftaran']['id_kegiatan']]
            )->row_array();
            $result[$k_r]['program'] = $this->db->query(
                "SELECT program.* 
                FROM program_kegiatan
                JOIN program ON program_kegiatan.id_program = program.id
                WHERE program_kegiatan.id=?",
                [(int)$r['pendaftaran']['id_program_kegiatan']]
            )->row_array();
        }
        foreach ($result as $k_r => $r)
        {
            $result[$k_r]['sertifikasi'] = $this->db->query(
                "SELECT * FROM sertifikasi WHERE id=?",
                [(int)$r['kegiatan']['id_sertifikasi']]
            )->row_array();
        }
        return $result;
    }

    public function get_ecert($columns)
    {
        if (isset($columns['id']))
            $result = $this->db->query(
                "SELECT sertifikat_keikutsertaan.*, pendaftaran.id_kegiatan, pendaftaran.id_program_kegiatan
                FROM sertifikat_keikutsertaan
                JOIN pendaftaran ON sertifikat_keikutsertaan.id_pendaftaran = pendaftaran.id
                WHERE sertifikat_keikutsertaan.id=?",
                [(int)$columns['id']]
            )->row_array();
        if (isset($columns['serial']))
            $result = $this->db->query(
                "SELECT sertifikat_keikutsertaan.*, pendaftaran.id_kegiatan, pendaftaran.id_program_kegiatan
                FROM sertifikat_keikutsertaan
                JOIN pendaftaran ON sertifikat_keikutsertaan.id_pendaftaran = pendaftaran.id
                WHERE sertifikat_keikutsertaan.kode=?",
                [$columns['serial']]
            )->row_array();
        if (empty($result)) return $result;
        $result['pendaftaran'] = $this->db->query(
            "SELECT * FROM pendaftaran WHERE id=?",
            [(int)$result['id_pendaftaran']]
        )->row_array();
        $result['user'] = $this->db->query(
            "SELECT * FROM users WHERE id=?",
            [(int)$result['pendaftaran']['id_user']]
        )->row_array();
        $result['kegiatan'] = $this->db->query(
            "SELECT * FROM kegiatan WHERE id=?",
            [(int)$result['pendaftaran']['id_kegiatan']]
        )->row_array();
        $result['program'] = $this->db->query(
            "SELECT program.* 
                FROM program_kegiatan
                JOIN program ON program_kegiatan.id_program = program.id
                WHERE program_kegiatan.id=?",
            [(int)$result['pendaftaran']['id_program_kegiatan']]
        )->row_array();
        $result['kegiatan'] = $this->db->query(
            "SELECT * FROM kegiatan WHERE id=?",
            [(int)$result['pendaftaran']['id_kegiatan']]
        )->row_array();
        $result['sertifikasi'] = $this->db->query(
            "SELECT * FROM sertifikasi WHERE id=?",
            [(int)$result['kegiatan']['id_sertifikasi']]
        )->row_array();

        $result['pendaftaran']['approved'] = ($result['pendaftaran']['approved'] === 'y');
        $result['pendaftaran']['hadir_training_sesi1'] = ($result['pendaftaran']['hadir_training_sesi1'] === 'y');
        $result['pendaftaran']['hadir_training_sesi2'] = ($result['pendaftaran']['hadir_training_sesi2'] === 'y');
        $result['pendaftaran']['hadir_ujian'] = ($result['pendaftaran']['hadir_ujian'] === 'y');
        $result['pendaftaran']['skor_ujian'] = (int)$result['pendaftaran']['skor_ujian'];
        return $result;
    }
}

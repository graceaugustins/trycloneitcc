<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model{

    /*
     * Tambah user baru
     * */
    public function tambah_user($tipe_user, $data)
    {
        $this->db->trans_start();
        if ($tipe_user === 'mahasiswa')
        {
            $this->db->query(
                "INSERT INTO users 
                    (tipe_user, nama_depan, nama_belakang, jenis_kelamin,
                     email, angkatan, jurusan, nim, alamat, no_telepon, id_line, file_ktm, file_fotoprofil) 
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                [
                    $tipe_user,
                    $data['nama_depan'],
                    $data['nama_belakang'],
                    $data['jenis_kelamin'],
                    $data['email'],
                    $data['angkatan'],
                    $data['jurusan'],
                    $data['nim'],
                    $data['alamat'],
                    $data['no_telepon'],
                    $data['id_line'],
                    $data['file_ktm'],
                    $data['file_fotoprofil']
                ]
            );
        }
        elseif ($tipe_user === 'umum')
        {
            $this->db->query(
                "INSERT INTO users 
                    (tipe_user, nama_depan, nama_belakang, jenis_kelamin,
                     email, user_pass, nik, alamat, no_telepon, file_ktp, file_fotoprofil) 
                VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                [
                    $tipe_user,
                    $data['nama_depan'],
                    $data['nama_belakang'],
                    $data['jenis_kelamin'],
                    $data['email'],
                    $data['user_pass'],
                    $data['nik'],
                    $data['alamat'],
                    $data['no_telepon'],
                    $data['file_ktp'],
                    $data['file_fotoprofil']
                ]
            );
        }
		$id = $this->db->insert_id();
		if (!empty($data['username_certiport']) && !empty($data['password_certiport']))
			$this->db->query(
				"UPDATE users 
                    SET username_certiport=?, password_certiport=?
                	WHERE id=?",
				[
					$data['username_certiport'],
					$data['password_certiport'],
					$id
				]
			);
		if (!empty($data['id_telegram']))
			$this->db->query(
				"UPDATE users 
                    SET id_telegram=?
                	WHERE id=?",
				[
					$data['id_telegram'],
					$id
				]
			);
        $this->db->trans_complete();
        if ($this->db->trans_status() === TRUE)
            return (int)$id;
        return FALSE;
    }

    /*
     * Cek apakah email user sudah ada di database
     * */
    public function email_exists($email): bool
	{
        $email = trim(strtolower($email));
        $query = $this->db->query(
            "SELECT COUNT(id) AS jumlah FROM users WHERE email=?",
            [$email]
        )->row_array();
        if ((int)$query['jumlah'] > 0)
            return TRUE;
        return FALSE;
    }

    /*
     * Get data user tipe mahasiswa berdasarkan id, sort default nama depan
     * */
    public function get_user_mhs($columns)
    {
        $query = "SELECT * FROM users ";
        $result = [];
        if (isset($columns['id']))
        {
            $result = $this->db->query(
                "$query WHERE tipe_user='mahasiswa' AND id=?",
                [(int)$columns['id']]
            )->result_array();
        }
        if (isset($columns['email']))
        {
            $result = $this->db->query(
                "$query WHERE tipe_user='mahasiswa' AND email=?",
                [(string)$columns['email']]
            )->result_array();
        }
        foreach($result as $k => $r)
        {
            $result[$k]['aktif'] = ($r['aktif'] === 'y');
        }
        return $result;
    }

    /*
     * get data user umum berdasarkan id
     * */
    public function get_user_umum($columns)
    {
        $query = "SELECT * FROM users ";
        $result = [];
        if (isset($columns['id']))
        {
            $result = $this->db->query(
                "$query WHERE tipe_user='umum' AND id=?",
                [(int)$columns['id']]
            )->result_array();
        }
        if (isset($columns['email']))
        {
            $result = $this->db->query(
                "$query WHERE tipe_user='umum' AND email=?",
                [(string)$columns['email']]
            )->result_array();
        }
        foreach($result as $k => $r)
        {
            $result[$k]['aktif'] = ($r['aktif'] === 'y');
			$result[$k]['instansi'] = $this->db->query(
				"SELECT instansi.* 
				FROM instansi_user
				JOIN instansi ON instansi.id = instansi_user.id_instansi
				WHERE instansi_user.id_user = ?",
				[(int)$r['id']]
			)->result_array();
        }
        return $result;
    }

	/*
	 * Get data user tipe itpln berdasarkan id, sort default nama depan
	 * */
	public function get_user_itpln($columns)
	{
		$query = "SELECT * FROM users ";
		$result = [];
		if (isset($columns['id']))
		{
			$result = $this->db->query(
				"$query WHERE tipe_user='itpln' AND id=?",
				[(int)$columns['id']]
			)->result_array();
		}
		if (isset($columns['email']))
		{
			$result = $this->db->query(
				"$query WHERE tipe_user='itpln' AND email=?",
				[(string)$columns['email']]
			)->result_array();
		}
		foreach($result as $k => $r)
		{
			$result[$k]['aktif'] = ($r['aktif'] === 'y');
		}
		return $result;
	}

    public function update_user($id, $columns)
    {
        $this->db->trans_start();
        if (isset($columns['aktif']))
        {
            $aktif = ($columns['aktif']) ? 'y' : 'n';
            $this->db->query(
                "UPDATE users SET aktif=? WHERE id=?",
                [(string)$aktif, (int)$id]
            );
        }
        if (isset($columns['user_pass']))
        {
            $this->db->query(
                "UPDATE users SET user_pass=? WHERE id=?",
                [(string)$columns['user_pass'], (int)$id]
            );
        }
        $this->db->trans_complete();
        return $this->db->trans_status();
    }

	public function get_instansi($id = NULL)
	{
		if (!empty($id))
		{
			$instansi_selected = [];
			$instansi = $this->db->query(
				"SELECT * FROM instansi WHERE id=?",
				[(int)$id]
			)->row_array();
			if (empty($instansi)) return $instansi;
			$instansi_selected['instansi'] = $instansi;
			$instansi_selected['users'] = $this->db->query(
				"SELECT users.*, instansi_user.id AS id_instansi_user
                FROM instansi_user
                JOIN users ON instansi_user.id_user = users.id
                WHERE instansi_user.id_instansi=?",
				[(int)$id]
			)->result_array();
			return $instansi_selected;
		}
		return $this->db->query(
			"SELECT * FROM instansi"
		)->result_array();
	}

	public function instansi_exists($id)
	{
		$num = $this->db->query(
			"SELECT COUNT(1) AS jumlah FROM instansi WHERE id=?",
			[(int)$id]
		)->row_array();
		return (int)$num['jumlah'] > 0;
    }

	public function add_user_to_instansi($id_user, $id_instansi)
	{
		$num = $this->db->query(
			"SELECT COUNT(1) AS jumlah FROM instansi_user WHERE id_user=? AND id_instansi=?",
			[(int)$id_user, (int)$id_instansi]
		)->row_array();
		if ((int)$num['jumlah'] === 0)
		{
			$this->db->trans_start();
			$this->db->query(
				"INSERT INTO instansi_user (id_user, id_instansi) VALUES (?, ?)",
				[(int)$id_user, (int)$id_instansi]
			);
			$this->db->trans_complete();
			return $this->db->trans_status();
		}
		return TRUE;
    }

	public function get_list_info($id_user)
	{
		return $this->db->query(
			"SELECT * FROM info_user WHERE id_user=? AND display='y' ORDER BY waktu DESC",
			[(int)$id_user]
		)->result_array();
    }

	public function get_single_info($id_info)
	{
		return $this->db->query(
			"SELECT * FROM info_user WHERE id=?",
			[(int)$id_info]
		)->row_array();
	}

	public function update_info($id_info, $c)
	{
		$this->db->trans_start();
		if (isset($c['display']))
		{
			$display = ($c['display']) ? 'y' : 'n';
			$this->db->query(
				"UPDATE info_user SET display=? WHERE id=?",
				[$display, (int)$id_info]
			);
		}
		$this->db->trans_complete();
		return $this->db->trans_status();
	}
}

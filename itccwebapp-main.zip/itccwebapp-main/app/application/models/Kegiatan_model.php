<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kegiatan_model extends CI_Model{

	public function get_kegiatan_dalam_masa_registrasi()
	{
		$sekarang = new DateTime();
		$id = $this->db->query(
			"SELECT id
            FROM kegiatan 
            WHERE batal = 'n'
            AND ? BETWEEN awal_registrasi AND akhir_registrasi",
			[(string)$sekarang->format('Y-m-d H:i:s')]
		)->result_array();
		$kegiatan = [];
		foreach($id as $id_kegiatan)
		{
			$kegiatan[] =  $this->get_kegiatan($id_kegiatan['id']);
		}
		return $kegiatan;
	}

    public function get_kegiatan_akan_dilaksanakan()
    {
        $sekarang = new DateTime();
        $id = $this->db->query(
            "SELECT kegiatan.id, MIN(kelompok.mulai_training) AS mulai, MAX(kelompok.selesai_ujian) AS selesai
            FROM kegiatan 
            LEFT JOIN kelompok ON kelompok.id_kegiatan = kegiatan.id
            WHERE kegiatan.batal = 'n'
            GROUP BY kegiatan.id
            HAVING mulai > ? OR mulai IS NULL",
            [(string)$sekarang->format('Y-m-d H:i:s')]
        )->result_array();
        $kegiatan = [];
        foreach($id as $id_kegiatan)
        {
            $kegiatan[] =  $this->get_kegiatan($id_kegiatan['id']);
        }
        return $kegiatan;
    }

    public function get_kegiatan_sedang_dilaksanakan()
    {
        $sekarang = new DateTime();
        $id = $this->db->query(
            "SELECT kegiatan.id, MIN(kelompok.mulai_training) AS mulai, MAX(kelompok.selesai_ujian) AS selesai
            FROM kegiatan 
            JOIN kelompok ON kelompok.id_kegiatan = kegiatan.id
            WHERE kegiatan.batal = 'n'
            GROUP BY kegiatan.id
            HAVING ? BETWEEN mulai AND selesai",
            [(string)$sekarang->format('Y-m-d H:i:s')]
        )->result_array();
        $kegiatan = [];
        foreach($id as $id_kegiatan)
        {
            $kegiatan[] =  $this->get_kegiatan($id_kegiatan['id']);
        }
        return $kegiatan;
    }

    public function get_kegiatan_sudah_dilaksanakan($id_user)
    {
        $sekarang = new DateTime();
        $id = $this->db->query(
            "SELECT pendaftaran.id AS id_pendaftaran, 
       				kegiatan.id, MIN(kelompok.mulai_training) AS mulai, 
       				MAX(kelompok.selesai_ujian) AS selesai
            FROM users 
            JOIN pendaftaran ON pendaftaran.id_user = users.id
            JOIN kegiatan ON kegiatan.id = pendaftaran.id_kegiatan 
            JOIN kelompok ON kelompok.id_kegiatan = kegiatan.id
            WHERE users.id=? AND kegiatan.batal = 'n'
            GROUP BY kegiatan.id
            HAVING ? > selesai
            ORDER BY selesai DESC",
            [
                (int)$id_user,
                (string)$sekarang->format('Y-m-d H:i:s')
            ]
        )->result_array();
        $kegiatan = [];
        foreach($id as $id_kegiatan)
        {
            $k = $this->get_kegiatan($id_kegiatan['id']);
            $k['pendaftaran'] = $this->get_pendaftaran($id_kegiatan['id_pendaftaran']);
            $kegiatan[] = $k;
        }
        return $kegiatan;
    }

    public function get_kegiatan_menunggu_pembayaran($id_user)
    {
        $pendaftaran = $this->db->query(
            "SELECT pendaftaran.*
            FROM pendaftaran 
            JOIN kegiatan ON kegiatan.id = pendaftaran.id_kegiatan
            WHERE pendaftaran.id_user=? AND kegiatan.batal='n' AND pendaftaran.approved='n' 
            ORDER BY pendaftaran.waktu DESC",
            [(int)$id_user]
        )->result_array();
        foreach($pendaftaran as $k_daftar => $daftar)
        {
            $pendaftaran[$k_daftar]['kegiatan'] = $this->get_kegiatan($daftar['id_kegiatan']);
            $pendaftaran[$k_daftar]['approved'] = ($daftar['approved'] === 'y');
            $pendaftaran[$k_daftar]['diskon'] = (int) $daftar['diskon'];
        }
        return $pendaftaran;
    }

	public function get_kegiatan_user($id_user)
	{
		$pendaftaran = $this->db->query(
			"SELECT pendaftaran.*, kegiatan.harga_t_u, kegiatan.harga_u
            FROM pendaftaran 
            JOIN kegiatan ON kegiatan.id = pendaftaran.id_kegiatan
            WHERE pendaftaran.id_user=? AND kegiatan.batal='n'
            ORDER BY pendaftaran.waktu DESC",
			[(int)$id_user]
		)->result_array();
		foreach($pendaftaran as $k_daftar => $daftar)
		{
			$pendaftaran[$k_daftar]['kegiatan'] = $this->get_kegiatan($daftar['id_kegiatan']);
			$pendaftaran[$k_daftar]['approved'] = ($daftar['approved'] === 'y');
			$pendaftaran[$k_daftar]['diskon'] = (int)$daftar['diskon'];
			$pendaftaran[$k_daftar]['harga_t_u'] = (int)$daftar['harga_t_u'];
			$pendaftaran[$k_daftar]['harga_u'] = (int)$daftar['harga_u'];
		}
		return $pendaftaran;
	}

    public function get_kegiatan_dibatalkan($id_user)
    {
        $pendaftaran = $this->db->query(
            "SELECT pendaftaran.*
            FROM pendaftaran 
            JOIN kegiatan ON kegiatan.id = pendaftaran.id_kegiatan
            WHERE pendaftaran.id_user=? AND kegiatan.batal='y' 
            ORDER BY kegiatan.akhir_registrasi DESC",
            [(int)$id_user]
        )->result_array();
        foreach($pendaftaran as $k_daftar => $daftar)
        {
            $pendaftaran[$k_daftar]['kegiatan'] = $this->get_kegiatan($daftar['id_kegiatan']);
            $pendaftaran[$k_daftar]['approved'] = ($daftar['approved'] === 'y');
            $pendaftaran[$k_daftar]['diskon'] = (int) $daftar['diskon'];
        }
        return $pendaftaran;
    }

    public function get_kegiatan($id)
    {
        $kegiatan = $this->db->query(
            "SELECT * FROM kegiatan WHERE id=?",
            [(int)$id]
        )->row_array();
        if (empty($kegiatan)) return $kegiatan;

        $kegiatan['harga_t_u'] = (int)$kegiatan['harga_t_u'];
        $kegiatan['harga_u'] = (int)$kegiatan['harga_u'];
        $kegiatan['registrasi_dibuka'] = $kegiatan['registrasi_dibuka'] === 'y';
		$kegiatan['batal'] = $kegiatan['batal'] === 'y';

        $kegiatan['program'] = $this->db->query(
            "SELECT program_kegiatan.id AS id_program_kegiatan, program_kegiatan.id_program,
                    program.*
                    FROM program_kegiatan
                    JOIN program ON program_kegiatan.id_program = program.id
                    WHERE program_kegiatan.id_kegiatan=?",
            [(int)$id]
        )->result_array();

        $kegiatan['kelompok'] = $this->get_kelompok([
            'id_kegiatan' => $kegiatan['id']
        ]);

        $kegiatan['sertifikasi'] = $this->db->query(
            "SELECT * FROM sertifikasi WHERE id=?",
            [(int)$kegiatan['id_sertifikasi']]
        )->row_array();

        return $kegiatan;
    }

    public function get_kelompok($columns)
    {
        $kel = [];
        if (isset($columns['id_kegiatan']))
            $kel = $this->db->query(
                "SELECT k.*, 
                        p.nama_program, 
                        pk.id_program,
                        t.nama_lengkap AS trainer_sesi1, 
                        t2.nama_lengkap AS trainer_sesi2,  
                        proc_t.nama_lengkap AS proctor_training,
                        proc_u.nama_lengkap AS proctor_ujian
                FROM kelompok k
                JOIN program_kegiatan pk on k.id_program_kegiatan = pk.id
                JOIN program p on pk.id_program = p.id
                LEFT JOIN trainer t on k.id_trainer_sesi1 = t.id
                LEFT JOIN trainer t2 on k.id_trainer_sesi2 = t2.id
                LEFT JOIN proctor proc_t ON k.id_proctor_training = proc_t.id
                LEFT JOIN proctor proc_u ON k.id_proctor_training = proc_u.id
                WHERE k.id_kegiatan=?
                ORDER BY k.nama_kelompok",
                [(int)$columns['id_kegiatan']]
            )->result_array();
        if (isset($columns['id']))
            $kel = $this->db->query(
                "SELECT k.*, 
                        p.nama_program, 
                        pk.id_program,
                        t.nama_lengkap AS trainer_sesi1, 
                        t2.nama_lengkap AS trainer_sesi2,  
                        proc_t.nama_lengkap AS proctor_training,
                        proc_u.nama_lengkap AS proctor_ujian
                FROM kelompok k
                JOIN program_kegiatan pk on k.id_program_kegiatan = pk.id
                JOIN program p on pk.id_program = p.id
                LEFT JOIN trainer t on k.id_trainer_sesi1 = t.id
                LEFT JOIN trainer t2 on k.id_trainer_sesi2 = t2.id
                LEFT JOIN proctor proc_t ON k.id_proctor_training = proc_t.id
                LEFT JOIN proctor proc_u ON k.id_proctor_training = proc_u.id
                WHERE k.id=?
                ORDER BY k.nama_kelompok",
                [(int)$columns['id']]
            )->result_array();

        foreach($kel as $k_kel => $val)
        {
			$jumlah_terisi_t = $this->db->query(
				"SELECT COUNT(1) AS jumlah FROM pendaftaran WHERE id_kelompok_t=?",
				[(int)$val['id']]
			)->row_array();
			$kel[$k_kel]['jumlah_peserta_t'] = $jumlah_terisi_t['jumlah'];
			$jumlah_terisi_u = $this->db->query(
				"SELECT COUNT(1) AS jumlah FROM pendaftaran WHERE id_kelompok_u=?",
				[(int)$val['id']]
			)->row_array();
			$kel[$k_kel]['jumlah_peserta_u'] = $jumlah_terisi_u['jumlah'];
        }

        return $kel;
    }

    public function get_jumlah_pendaftar($id_kegiatan)
    {
        $result = $this->db->query(
            "SELECT COUNT(id) AS jumlah FROM pendaftaran WHERE id_kegiatan=?",
            [(int)$id_kegiatan]
        )->row_array();
        return (int)$result['jumlah'];
    }

    public function registrasi($id_user, $id_kegiatan, $id_program_kegiatan, $jenis, $diskon)
    {
        $this->db->trans_start();
        $this->db->query(
            "INSERT INTO pendaftaran (id_user, id_kegiatan, id_program_kegiatan, jenis, diskon) VALUES (?,?,?,?,?)",
            [
                (int)$id_user,
                (int)$id_kegiatan,
                (int)$id_program_kegiatan,
                (string)$jenis,
                (int)$diskon
            ]
        );
        $id = $this->db->insert_id();
        $this->db->trans_complete();
        if ($this->db->trans_status() === TRUE)
            return (int)$id;
        return FALSE;
    }

    public function get_id_pendaftaran($id_user, $id_kegiatan)
    {
        $result = $this->db->query(
            "SELECT id FROM pendaftaran WHERE id_user=? AND id_kegiatan=?",
            [(int)$id_user, (int)$id_kegiatan]
        )->row_array();
        if (isset($result['id']))
            return $result['id'];
        return $result;
    }

    public function get_list_bukti_bayar($id_pendaftaran)
    {
        $result = $this->db->query(
            "SELECT * FROM bukti_bayar WHERE id_pendaftaran=?",
            [(int)$id_pendaftaran]
        )->result_array();
        foreach ($result as $k_r => $r)
        {
            $result[$k_r]['nominal_dibayar'] = (int)$r['nominal_dibayar'];
        }
        return $result;
    }

    public function upload_bukti_bayar($id_pendaftaran, $waktu_transfer, $bank,
                                       $nama_pengirim, $nominal_dibayar, $file_bukti)
    {
        $this->db->trans_start();
        $this->db->query(
            "INSERT INTO bukti_bayar (id_pendaftaran, file_bukti, waktu_transfer, nominal_dibayar, nama_pengirim, bank) 
            VALUES (?,?,?,?,?,?)",
            [
                (int)$id_pendaftaran, (string)$file_bukti, (string)$waktu_transfer, (int)$nominal_dibayar, (string)$nama_pengirim, (string)$bank
            ]
        );
        $id = $this->db->insert_id();
        $this->db->trans_complete();
        if ($this->db->trans_status() === TRUE)
            return (int)$id;
        return FALSE;
    }

	/*
	 * Ambil data jumlah peserta registrasi kegiatan
	 * */
	public function get_statistik_regis($id, $parameter)
	{
		$result = [];
		foreach($parameter as $param )
		{
			if ($param === 'total')
			{
				$value = $this->db->query(
					"SELECT COUNT(id) AS jumlah FROM pendaftaran WHERE id_kegiatan=?",
					[(int)$id]
				)->row_array();
				$value = $value['jumlah'];
				$result['total'] = (int)$value;
			}
			elseif ($param === 'approved')
			{
				$value = $this->db->query(
					"SELECT COUNT(id) AS jumlah FROM pendaftaran WHERE id_kegiatan=? AND approved='y'",
					[(int)$id]
				)->row_array();
				$value = $value['jumlah'];
				$result['approved'] = (int)$value;
			}
			elseif ($param === 'sudah_pilih_kelompok_t')
			{
				$value = $this->db->query(
					"SELECT COUNT(id) AS jumlah FROM pendaftaran WHERE id_kegiatan=? AND approved='y' AND id_kelompok_t IS NOT NULL",
					[(int)$id]
				)->row_array();
				$value = $value['jumlah'];
				$result['sudah_pilih_kelompok_t'] = (int)$value;
			}
			elseif ($param === 'sudah_pilih_kelompok_u')
			{
				$value = $this->db->query(
					"SELECT COUNT(id) AS jumlah FROM pendaftaran WHERE id_kegiatan=? AND approved='y' AND id_kelompok_u IS NOT NULL",
					[(int)$id]
				)->row_array();
				$value = $value['jumlah'];
				$result['sudah_pilih_kelompok_u'] = (int)$value;
			}
		}
		return $result;
	}

    /*
     * Kegiatan sedang berjalan :
     * kalau periode ujian belum berakhir
     * */
    public function get_sertifikasi_berjalan($id_user)
    {
        $pendaftaran = $this->db->query(
            "SELECT pendaftaran.*,
					kegiatan.akhir_pelaporan,
					MAX(kelompok.selesai_ujian) AS selesai,
					COUNT(kelompok.id) AS jumlah_kelompok
			FROM pendaftaran 
			JOIN kegiatan ON kegiatan.id = pendaftaran.id_kegiatan
			LEFT JOIN kelompok ON kelompok.id_kegiatan = kegiatan.id
			WHERE pendaftaran.id_user=? AND kegiatan.batal='n' AND pendaftaran.approved='y'
			GROUP BY kegiatan.id
			HAVING NOW() < selesai OR (jumlah_kelompok=0 AND NOW() < kegiatan.akhir_pelaporan)
			ORDER BY pendaftaran.waktu DESC",
            [(int)$id_user]
        )->result_array();
        foreach($pendaftaran as $k_daftar => $daftar)
        {
            $pendaftaran[$k_daftar]['kegiatan'] = $this->get_kegiatan($daftar['id_kegiatan']);
            $pendaftaran[$k_daftar]['approved'] = ($daftar['approved'] === 'y');
            $pendaftaran[$k_daftar]['hadir_training_sesi1'] = ($daftar['hadir_training_sesi1'] === 'y');
            $pendaftaran[$k_daftar]['hadir_training_sesi2'] = ($daftar['hadir_training_sesi2'] === 'y');
            $pendaftaran[$k_daftar]['diskon'] = (int) $daftar['diskon'];
        }
        foreach($pendaftaran as $k_daftar => $daftar)
        {
            $now = new DateTime();
            $max = clone $now;
            foreach($daftar['kegiatan']['kelompok'] as $k_kel => $kel)
            {
                $selesai_training = DateTime::createFromFormat('Y-m-d H:i:s', $kel['selesai_training']);
                $selesai_ujian = DateTime::createFromFormat('Y-m-d H:i:s', $kel['selesai_ujian']);
                $max = max($max, $selesai_training, $selesai_ujian);
            }
            // kalau masih sama, artinya tidak ada tanggal yang lebih
            // di kelompok ini
            if ($max === $now && count($daftar['kegiatan']['kelompok']) > 0)
            {
                unset($pendaftaran[$k_daftar]);
            }
        }
        // cek apakah ada kelompok yang dipilih
        foreach($pendaftaran as $k_daftar => $daftar)
        {
            if (!empty($daftar['id_kelompok_t']))
            {
                $id_kelompok_t = (int)$daftar['id_kelompok_t'];
                $kelompok = array_filter($daftar['kegiatan']['kelompok'], function($kel) use ($id_kelompok_t){
                    return (int)$kel['id'] === $id_kelompok_t;
                });
                $pendaftaran[$k_daftar]['selected_kelompok_t'] = reset($kelompok);
            }

			if (!empty($daftar['id_kelompok_u']))
			{
				$id_kelompok_u = (int)$daftar['id_kelompok_u'];
				$kelompok = array_filter($daftar['kegiatan']['kelompok'], function($kel) use ($id_kelompok_u){
					return (int)$kel['id'] === $id_kelompok_u;
				});
				$pendaftaran[$k_daftar]['selected_kelompok_u'] = reset($kelompok);
			}
        }
        return $pendaftaran;
    }

    public function get_pendaftaran($id)
    {
        $pendaftaran = $this->db->query(
            "SELECT * FROM pendaftaran 
            WHERE id=?",
            [(int)$id]
        )->row_array();
        if (!empty($pendaftaran))
        {
            $pendaftaran['kegiatan'] = $this->get_kegiatan($pendaftaran['id_kegiatan']);
            $pendaftaran['hadir_training_sesi2'] = ($pendaftaran['hadir_training_sesi2'] === 'y');
            $pendaftaran['hadir_training_sesi1'] = ($pendaftaran['hadir_training_sesi1'] === 'y');
            $pendaftaran['hadir_ujian'] = ($pendaftaran['hadir_ujian'] === 'y');
            $pendaftaran['approved'] = ($pendaftaran['approved'] === 'y');
            $pendaftaran['diskon'] = (int)$pendaftaran['diskon'];
        }
        return $pendaftaran;
    }

    public function update_pendaftaran($id_pendaftaran, $columns)
    {
        $this->db->trans_start();
        if (isset($columns['id_kelompok_t']))
        {
            $id_kelompok = $columns['id_kelompok_t'];
            if (is_numeric($id_kelompok))
            {
                $this->db->query(
                    "UPDATE pendaftaran SET id_kelompok_t=? WHERE id=?",
                    [$id_kelompok, (int)$id_pendaftaran]
                );
            }
            elseif (strtolower($id_kelompok) === 'null')
			{
				$this->db->query(
					"UPDATE pendaftaran SET id_kelompok_t=NULL WHERE id=?",
					[(int)$id_pendaftaran]
				);
			}
        }

		if (isset($columns['id_kelompok_u']))
		{
			$id_kelompok = $columns['id_kelompok_u'];
			if (is_numeric($id_kelompok))
			{
				$this->db->query(
					"UPDATE pendaftaran SET id_kelompok_u=? WHERE id=?",
					[$id_kelompok, (int)$id_pendaftaran]
				);
			}
			elseif (strtolower($id_kelompok) === 'null')
			{
				$this->db->query(
					"UPDATE pendaftaran SET id_kelompok_u=NULL WHERE id=?",
					[(int)$id_pendaftaran]
				);
			}
		}
        $this->db->trans_complete();
        return $this->db->trans_status();
    }

    public function get_materi_training($id_kelompok)
    {
        $kelompok = $this->get_kelompok(['id' => $id_kelompok]);
        if (empty($kelompok)) return [];
        $kelompok = $kelompok[0];
        $materi1 = [];
        $materi2 = [];
        if (!empty($kelompok['id_trainer_sesi1']))
            $materi1 = $this->db->query(
                "SELECT * FROM materi_training WHERE id_trainer=?",
                [(int)$kelompok['id_trainer_sesi1']]
            )->result_array();
        if (!empty($kelompok['id_trainer_sesi2']) && (int)$kelompok['id_trainer_sesi2'] !== (int)$kelompok['id_trainer_sesi1'])
            $materi2 = $this->db->query(
                "SELECT * FROM materi_training WHERE id_trainer=?",
                [(int)$kelompok['id_trainer_sesi2']]
            )->result_array();
        $materi = [];
        foreach($materi1 as $m)
        {
            $materi[] = $m;
        }
        foreach($materi2 as $m)
        {
            $materi[] = $m;
        }
        return $materi;
    }
}
